import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0, (java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 10, (int) (byte) 1, (int) (short) 0, (int) (short) 10, (int) '#', (int) (byte) 0, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        int int2 = dateTime1.getWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (byte) 1, (int) (short) 1, (int) (byte) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', (int) 'a', 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test012");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560342939905L + "'", long0 == 1560342939905L);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            int int2 = dateTime0.get(dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((long) 'a', (int) ' ', (int) (byte) 0, (int) (short) -1, 37);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("5:35:39 AM PDT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.LocalTime localTime5 = dateTime4.toLocalTime();
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfMinute();
//        java.lang.String str13 = gregorianChronology10.toString();
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) '4', (org.joda.time.Chronology) gregorianChronology10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(localTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5:35:40 AM PDT" + "'", str7.equals("5:35:40 AM PDT"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str13.equals("GregorianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-24) + "'", int1 == (-24));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(0, 0, (int) (byte) 10, (int) (byte) 10, 0, 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withWeekOfWeekyear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withDayOfMonth((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) 37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) 20140);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-20140L) + "'", long2 == (-20140L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setMillisOfDay((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.property(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(24, 10, 20140, 10, 2019, (int) (short) 0, (int) 'a', dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("5:35:40 AM PDT", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5:35:40 AM PDT\" is malformed at \":35:40 AM PDT\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.secondOfMinute();
        org.joda.time.DurationField durationField9 = gregorianChronology6.minutes();
        org.joda.time.DurationField durationField10 = gregorianChronology6.months();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField11 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField5, durationField10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("5:35:40 AM PDT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5:35:40 AM PDT\" is malformed at \" AM PDT\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale7 = null;
        try {
            long long8 = delegatedDateTimeField4.set((long) '4', "PST", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((-24));
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 1.0f, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 335);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray7 = gregorianChronology0.get(readablePeriod4, (long) 12, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField4 = gregorianChronology0.months();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(24, false);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfSecond((-24));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        java.lang.String str4 = property3.getName();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsText(locale5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        try {
            int int8 = property3.compareTo(readableInstant7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "year" + "'", str4.equals("year"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.append(dateTimePrinter6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendMillisOfSecond(20142);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (short) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-24));
//        java.lang.Appendable appendable5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.LocalTime localTime8 = dateTime7.toLocalTime();
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.minus(readablePeriod10);
//        org.joda.time.DateTime dateTime13 = dateTime7.plusHours(0);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime13.withZone(dateTimeZone14);
//        int int17 = dateTime13.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime13.plus(readablePeriod18);
//        try {
//            dateTimeFormatter0.printTo(appendable5, (org.joda.time.ReadableInstant) dateTime19);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(localTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "5:35:42 AM PDT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(24, false);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendPattern("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
//        int int5 = dateTime1.getDayOfMonth();
//        int int6 = dateTime1.getCenturyOfEra();
//        int int7 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        try {
//            int int9 = dateTime1.get(dateTimeFieldType8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 21 + "'", int6 == 21);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20144 + "'", int7 == 20144);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        java.util.Locale locale3 = null;
        try {
            java.lang.String str4 = mutableDateTime1.toString("", locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 216);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 0.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationField durationField5 = gregorianChronology2.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.LocalTime localTime8 = dateTime7.toLocalTime();
        int[] intArray10 = gregorianChronology2.get((org.joda.time.ReadablePartial) localTime8, (long) '#');
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(localTime8);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        java.util.Locale locale4 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = property2.set("hi!", locale4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.DurationField durationField8 = gregorianChronology5.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
        int[] intArray13 = gregorianChronology5.get((org.joda.time.ReadablePartial) localTime11, (long) '#');
        int[] intArray18 = new int[] { (short) -1, (short) 100, 12 };
        java.util.Locale locale20 = null;
        try {
            int[] intArray21 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) localTime11, 10, intArray18, "", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(2, 0, (int) (byte) 0, (int) 'a', 881);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = property2.set(372);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 372 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime1.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.DateTime.Property property8 = dateTime1.property(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = mutableDateTime1.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField4 = gregorianChronology0.months();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType6, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.addDays((int) '#');
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withDate(12, 20143, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20143 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        mutableDateTime0.add((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.year();
//        mutableDateTime0.setRounding(dateTimeField15);
//        int int17 = mutableDateTime0.getRoundingMode();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5:35:46 AM PDT" + "'", str8.equals("5:35:46 AM PDT"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withMonthOfYear(299);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 299 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 335, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology1.get(readablePeriod5, (long) 935, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime1.addYears(24);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.secondOfMinute();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.centuryOfEra();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType9, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 1, 282, 2019, (int) ' ', (int) (byte) 100, 0, 21, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType6, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology1, locale6);
        org.joda.time.Chronology chronology8 = dateTimeParserBucket7.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            dateTimeParserBucket7.saveField(dateTimeFieldType9, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.LocalTime localTime5 = dateTime4.toLocalTime();
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime4.withDayOfWeek((int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(localTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5:35:47 AM PDT" + "'", str7.equals("5:35:47 AM PDT"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale5 = null;
        int int6 = delegatedDateTimeField4.getMaximumTextLength(locale5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType7, (int) (byte) 100, 881, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.weekyearOfCentury();
//        org.joda.time.DurationField durationField10 = gregorianChronology4.days();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 572 + "'", int3 == 572);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter0.parseLocalTime("20140");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20140\" is malformed at \"140\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendWeekyear(24, (int) (byte) 100);
        boolean boolean8 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("5:35:45 AM PDT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 5:35:45 AM PDT");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 2019, "");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((-24));
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(20140, (int) (short) 0, (int) ' ', (int) (short) 100, 935, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology1, locale6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.dayOfMonth();
        try {
            long long13 = gregorianChronology1.getDateTimeMillis(1, 335, 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 335 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long7 = delegatedDateTimeField4.add((long) 1, (long) (short) 10);
        try {
            long long10 = delegatedDateTimeField4.set((-210866760000000L), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36000001L + "'", long7 == 36000001L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(100L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology8 = julianChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((int) (short) 1, 2019, 377, 20142, (int) 'a', (int) (byte) 100, 4, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20142 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        long long4 = durationField1.subtract((long) 299, 377);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-991526399701L) + "'", long4 == (-991526399701L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("1969-12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond((int) 'a', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendDecimal(dateTimeFieldType12, (int) '4', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-24));
        java.lang.Integer int5 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.LocalDate localDate7 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(int5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = property2.set("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond((int) 'a', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFixedSignedDecimal(dateTimeFieldType12, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 2, (int) (byte) 1, (int) 'a');
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime1.withField(dateTimeFieldType4, 216);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("5:35:45 AM PDT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5:35:45 AM PDT\" is malformed at \":35:45 AM PDT\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology1, locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            dateTimeParserBucket7.saveField(dateTimeFieldType8, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.yearOfEra();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = property3.set("hi!", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = delegatedDateTimeField12.getAsText(12, locale14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField19 = gregorianChronology16.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
        int[] intArray24 = gregorianChronology16.get((org.joda.time.ReadablePartial) localTime22, (long) '#');
        int[] intArray25 = null;
        int int26 = delegatedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localTime22, intArray25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.LocalTime localTime29 = dateTime28.toLocalTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.secondOfMinute();
        org.joda.time.DurationField durationField33 = gregorianChronology30.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology34);
        org.joda.time.LocalTime localTime36 = dateTime35.toLocalTime();
        int[] intArray38 = gregorianChronology30.get((org.joda.time.ReadablePartial) localTime36, (long) '#');
        int int39 = delegatedDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localTime29, intArray38);
        try {
            int[] intArray41 = offsetDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localTime6, 377, intArray38, 282);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 377");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12" + "'", str15.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(localTime29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(localTime36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendFractionOfDay(335, (-1));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder7.appendTimeZoneOffset("12", true, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone2.getName(0L, locale5);
//        long long10 = dateTimeZone2.convertLocalToUTC((long) 12, false, (-20140L));
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology12 = julianChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology11);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime13, 20140);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20140");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 12L + "'", long10 == 12L);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfDay((int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFixedDecimal(dateTimeFieldType9, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
//        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withZone(dateTimeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
//        org.joda.time.DateTime.Property property12 = dateTime10.year();
//        java.lang.String str13 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime15 = dateTime10.withDayOfYear((int) '4');
//        mutableDateTime5.setMillis((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime18 = dateTime15.plusDays(12);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime15, 24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 24");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(localTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5:35:50 AM PDT" + "'", str13.equals("5:35:50 AM PDT"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.weekyearOfCentury();
//        try {
//            long long14 = gregorianChronology4.getDateTimeMillis(335, 2019, 20140, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 200 + "'", int3 == 200);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        try {
            mutableDateTime2.setDateTime(20143365, 20143365, 0, 12, 4, 299, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 299 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.LocalTime localTime5 = dateTime4.toLocalTime();
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//        try {
//            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(localTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5:35:50 AM PDT" + "'", str7.equals("5:35:50 AM PDT"));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 935);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90695 + "'", int2 == 90695);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getSecondOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20150 + "'", int3 == 20150);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        long long6 = offsetDateTimeField3.add((long) 282, 0L);
        java.util.Locale locale9 = null;
        try {
            long long10 = offsetDateTimeField3.set((long) 4, "GregorianChronology[America/Los_Angeles]", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 282L + "'", long6 == 282L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral("5:35:42 AM PDT");
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendShortText(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.secondOfMinute();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        int[] intArray16 = gregorianChronology8.get((org.joda.time.ReadablePartial) localTime14, (long) '#');
        int[] intArray17 = null;
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localTime14, intArray17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.secondOfMinute();
        org.joda.time.DurationField durationField25 = gregorianChronology22.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.LocalTime localTime28 = dateTime27.toLocalTime();
        int[] intArray30 = gregorianChronology22.get((org.joda.time.ReadablePartial) localTime28, (long) '#');
        int int31 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime21, intArray30);
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.secondOfMinute();
        org.joda.time.DurationField durationField36 = gregorianChronology33.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.LocalTime localTime39 = dateTime38.toLocalTime();
        int[] intArray41 = gregorianChronology33.get((org.joda.time.ReadablePartial) localTime39, (long) '#');
        int int42 = delegatedDateTimeField4.getMaximumValue(readablePartial32, intArray41);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(localTime28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(localTime39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendFractionOfDay(335, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMinuteOfHour(572);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        java.lang.Class<?> wildcardClass2 = illegalInstantException1.getClass();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) wildcardClass2, (org.joda.time.DateTimeZone) cachedDateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Class");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        try {
            mutableDateTime2.setDayOfMonth(365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime0.millisOfSecond();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime14 = property12.set("1969-12-31");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31\" for millisOfSecond is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5:35:51 AM PDT" + "'", str8.equals("5:35:51 AM PDT"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        try {
            mutableDateTime2.setMinuteOfHour(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        long long6 = offsetDateTimeField3.add((long) 282, 0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        long long14 = delegatedDateTimeField11.add((long) 1, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.secondOfMinute();
        org.joda.time.DurationField durationField18 = gregorianChronology15.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        int[] intArray23 = gregorianChronology15.get((org.joda.time.ReadablePartial) localTime21, (long) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.secondOfMinute();
        org.joda.time.DurationField durationField27 = gregorianChronology24.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.LocalTime localTime30 = dateTime29.toLocalTime();
        int[] intArray32 = gregorianChronology24.get((org.joda.time.ReadablePartial) localTime30, (long) '#');
        int int33 = delegatedDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localTime21, intArray32);
        java.util.Locale locale34 = null;
        try {
            java.lang.String str35 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) localTime21, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 282L + "'", long6 == 282L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 36000001L + "'", long14 == 36000001L);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(localTime30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime1.withHourOfDay((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 73 + "'", int3 == 73);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(5, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(20140);
        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((int) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withZone(dateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
//        org.joda.time.DateTime.Property property18 = dateTime16.year();
//        java.lang.String str19 = dateTimeFormatter12.print((org.joda.time.ReadableInstant) dateTime16);
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime22 = dateTime16.plus((long) 372);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5:35:52 AM PDT" + "'", str8.equals("5:35:52 AM PDT"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "5:35:52 AM PDT" + "'", str19.equals("5:35:52 AM PDT"));
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(0, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTimeZoneOffset("20142", false, 20150, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
//        int int5 = dateTime1.getDayOfMonth();
//        int int6 = dateTime1.getCenturyOfEra();
//        int int7 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime1.plusMonths(935);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 21 + "'", int6 == 21);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20152 + "'", int7 == 20152);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        java.lang.String str4 = property3.getName();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsText(locale5);
        org.joda.time.DateTime dateTime8 = property3.setCopy(881);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withZone(dateTimeZone10);
        try {
            java.lang.String str12 = dateTime8.toString(dateTimeFormatter9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "year" + "'", str4.equals("year"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 1, (long) 24);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-23L) + "'", long2 == (-23L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 20143365);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        mutableDateTime0.add((long) 2019);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.year();
//        mutableDateTime0.setRounding(dateTimeField15);
//        try {
//            mutableDateTime0.setWeekOfWeekyear(372);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 372 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5:35:54 AM PDT" + "'", str8.equals("5:35:54 AM PDT"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsShortText(20140, locale9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField15.getAsText(12, locale17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.secondOfMinute();
        org.joda.time.DurationField durationField22 = gregorianChronology19.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.LocalTime localTime25 = dateTime24.toLocalTime();
        int[] intArray27 = gregorianChronology19.get((org.joda.time.ReadablePartial) localTime25, (long) '#');
        int[] intArray28 = null;
        int int29 = delegatedDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localTime25, intArray28);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = delegatedDateTimeField34.getAsText(12, locale36);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.secondOfMinute();
        org.joda.time.DurationField durationField41 = gregorianChronology38.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.LocalTime localTime44 = dateTime43.toLocalTime();
        int[] intArray46 = gregorianChronology38.get((org.joda.time.ReadablePartial) localTime44, (long) '#');
        int[] intArray47 = null;
        int int48 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localTime44, intArray47);
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology49);
        org.joda.time.LocalTime localTime51 = dateTime50.toLocalTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology52);
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology52.secondOfMinute();
        org.joda.time.DurationField durationField55 = gregorianChronology52.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology56);
        org.joda.time.LocalTime localTime58 = dateTime57.toLocalTime();
        int[] intArray60 = gregorianChronology52.get((org.joda.time.ReadablePartial) localTime58, (long) '#');
        int int61 = delegatedDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localTime51, intArray60);
        int[] intArray68 = new int[] { (short) 0, 20150, 935, 299, 377, 10 };
        int int69 = delegatedDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localTime51, intArray68);
        int[] intArray75 = new int[] { (byte) 0, 100, 216, 'a' };
        java.util.Locale locale77 = null;
        try {
            int[] intArray78 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) localTime51, (-24), intArray75, "12", locale77);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -24");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20140" + "'", str10.equals("20140"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "12" + "'", str18.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "12" + "'", str37.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(localTime44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(localTime51);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(localTime58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.Instant instant3 = instant0.plus((long) 335);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) instant0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(21, 0, 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 21 + "'", int3 == 21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendPattern("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        long long6 = offsetDateTimeField3.add((long) 282, 0L);
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType8, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 282L + "'", long6 == 282L);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 90695, (long) 299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27117805 + "'", int2 == 27117805);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean10 = gregorianChronology4.equals((java.lang.Object) 10);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology4.weekyearOfCentury();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 689 + "'", int3 == 689);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-210866760000000L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
        org.joda.time.MutableDateTime mutableDateTime5 = property2.add((long) 20143);
        org.joda.time.DateTime dateTime6 = mutableDateTime5.toDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '4', (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsShortText(20140, locale9);
        java.util.Locale locale13 = null;
        try {
            long long14 = delegatedDateTimeField4.set(52L, "20140", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20140 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20140" + "'", str10.equals("20140"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-1));
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime9.toMutableDateTime(dateTimeZone10);
        mutableDateTime11.setDayOfYear(24);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone5);
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime6.withDate(20152, 299, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 299 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1002 + "'", int4 == 1002);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 20142);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = mutableDateTime0.toDateTime(dateTimeZone2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            int int5 = dateTime3.get(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(335);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-335) + "'", int1 == (-335));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(20143365, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20143367 + "'", int2 == 20143367);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int5 = delegatedDateTimeField4.getMaximumValue();
        try {
            long long8 = delegatedDateTimeField4.set((long) 20143367, "20143");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20143 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 335, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1);
        dateTimeParserBucket4.setPivotYear((java.lang.Integer) 4);
        dateTimeParserBucket4.setOffset((java.lang.Integer) 1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        mutableDateTime0.setWeekyear(0);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime0.secondOfMinute();
//        try {
//            mutableDateTime0.setMillisOfSecond(90695);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 90695 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4:42:58 PM -07:52:58" + "'", str8.equals("4:42:58 PM -07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond((int) 'a', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 20143367);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
//        org.joda.time.DateTime.Property property8 = dateTime6.year();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime6.plusHours(0);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime12.withZone(dateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        org.joda.time.DateTime.Property property19 = dateTime17.year();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime17.minus(readablePeriod20);
//        org.joda.time.DateTime.Property property22 = dateTime17.dayOfWeek();
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime((long) (short) 1);
//        mutableDateTime26.addYears(24);
//        mutableDateTime26.addMonths((-24));
//        int int31 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) mutableDateTime26);
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = dateTimeZone1.getName((long) (-24), locale33);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(localTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Pacific Standard Time" + "'", str34.equals("Pacific Standard Time"));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) (short) 1);
//        mutableDateTime13.addYears(24);
//        mutableDateTime13.addMonths((-24));
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 1);
//        mutableDateTime13.setRounding(dateTimeField19);
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) mutableDateTime13);
//        org.joda.time.MutableDateTime.Property property24 = mutableDateTime0.weekyear();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4:42:58 PM -07:52:58" + "'", str8.equals("4:42:58 PM -07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property24);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfDay((int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendTimeZoneOffset("5:35:42 AM PDT", true, 20143365, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 335, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1);
        dateTimeParserBucket4.setPivotYear((java.lang.Integer) 4);
        long long9 = dateTimeParserBucket4.computeMillis(false, "5:35:45 AM PDT");
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800335L + "'", long9 == 28800335L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) 4);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType7, (int) '#', 881, 20150);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            mutableDateTime3.add(durationFieldType4, 20150);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withPivotYear((java.lang.Integer) (-24));
        try {
            org.joda.time.Instant instant6 = org.joda.time.Instant.parse("5:35:39 AM PDT", dateTimeFormatter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5:35:39 AM PDT\" is malformed at \" AM PDT\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-24));
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) 20153497);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        long long6 = offsetDateTimeField3.add((long) 282, 0L);
        boolean boolean8 = offsetDateTimeField3.isLeap((long) (short) -1);
        long long10 = offsetDateTimeField3.roundFloor((long) 4);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localTime13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'year' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 282L + "'", long6 == 282L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(localTime13);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        try {
//            int int10 = dateTime1.get(dateTimeFieldType9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("12");
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = dateTime2.minusSeconds(7);
        org.joda.time.Chronology chronology6 = dateTime5.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfCentury();
        java.lang.String str6 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("4:42:57 PM -07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '4:42:57 PM -07:52:58' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        mutableDateTime0.add(readableDuration1, 0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        boolean boolean5 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withEarlierOffsetAtOverlap();
//        int int7 = dateTime5.getMillisOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 275 + "'", int3 == 275);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 60180275 + "'", int7 == 60180275);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime1.dayOfWeek();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) instant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-209306417041603L) + "'", long1 == (-209306417041603L));
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.Chronology chronology7 = julianChronology6.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology6);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.yearOfCentury();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        mutableDateTime8.add(readableDuration10, 5);
//        boolean boolean13 = buddhistChronology5.equals((java.lang.Object) 5);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfDay();
        org.joda.time.DateTime.Property property9 = dateTime1.hourOfDay();
        try {
            org.joda.time.DateTime dateTime11 = property9.setCopy("Property[minuteOfDay]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[minuteOfDay]\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", (java.lang.Number) 881, (java.lang.Number) (byte) -1, (java.lang.Number) 2);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "881" + "'", str6.equals("881"));
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime2.add(readableDuration4, 5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
        org.joda.time.DateTime dateTime8 = mutableDateTime2.toDateTimeISO();
        mutableDateTime2.setTime((long) 2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime1.dayOfWeek();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        long long15 = delegatedDateTimeField12.add((long) 1, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.secondOfMinute();
        org.joda.time.DurationField durationField19 = gregorianChronology16.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
        int[] intArray24 = gregorianChronology16.get((org.joda.time.ReadablePartial) localTime22, (long) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.secondOfMinute();
        org.joda.time.DurationField durationField28 = gregorianChronology25.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
        int[] intArray33 = gregorianChronology25.get((org.joda.time.ReadablePartial) localTime31, (long) '#');
        int int34 = delegatedDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) localTime22, intArray33);
        try {
            int int35 = property6.compareTo((org.joda.time.ReadablePartial) localTime22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 36000001L + "'", long15 == 36000001L);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(localTime31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
//        int int5 = dateTime3.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime10 = dateTime3.toDateTime((org.joda.time.Chronology) gregorianChronology6);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 730 + "'", int5 == 730);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-20140L), 365);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7351100L) + "'", long2 == (-7351100L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) localTime6, 20143, locale8);
        java.util.Locale locale10 = null;
        int int11 = offsetDateTimeField3.getMaximumTextLength(locale10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "20143" + "'", str9.equals("20143"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.centuryOfEra();
//        java.lang.String str7 = buddhistChronology5.toString();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology5.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str7.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap15 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTimeZoneName(strMap15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder18.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendWeekyear(1, (-1));
        boolean boolean24 = dateTimeFormatterBuilder23.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendMillisOfSecond(20142);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.append(dateTimeFormatter29);
        org.joda.time.format.DateTimePrinter dateTimePrinter31 = dateTimeFormatter29.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendWeekyear(1, (-1));
        boolean boolean36 = dateTimeFormatterBuilder35.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder35.appendWeekyear(24, (int) (byte) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter40 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder41.appendWeekyear(1, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder41.appendDayOfMonth(0);
        org.joda.time.format.DateTimeParser dateTimeParser47 = dateTimeFormatterBuilder46.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray48 = new org.joda.time.format.DateTimeParser[] { dateTimeParser47 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.append(dateTimePrinter40, dateTimeParserArray48);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder26.append(dateTimePrinter31, dateTimeParserArray48);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder18.append(dateTimePrinter31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder7.append(dateTimePrinter31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(strMap15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimePrinter31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeParser47);
        org.junit.Assert.assertNotNull(dateTimeParserArray48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime5 = property3.addToCopy((int) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(377, 20143367);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20143744 + "'", int2 == 20143744);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("5:35:48 AM PDT", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"5:35:48 AM PDT/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        java.lang.String str3 = dateTimeZone1.getName((long) '4');
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime5 = instant4.toMutableDateTimeISO();
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendWeekyear(24, (int) (byte) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendWeekyear(1, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendDayOfMonth(0);
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatterBuilder14.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray16 = new org.joda.time.format.DateTimeParser[] { dateTimeParser15 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder3.append(dateTimePrinter8, dateTimeParserArray16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeParserArray16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-1));
        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime12 = property10.addWrapFieldToCopy(20150);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.DateTime.Property property14 = dateTime12.property(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology1, locale6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        java.util.Locale locale10 = null;
        try {
            dateTimeParserBucket7.saveField(dateTimeFieldType8, "335", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.DateTime dateTime7 = property3.setCopy("Wed", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Wed\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.centuryOfEra();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4:43:03 PM -07:52:58" + "'", str8.equals("4:43:03 PM -07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-24), 20153497, (int) 'a', 282, 24, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 282 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.centuryOfEra();
//        java.lang.String str7 = buddhistChronology5.toString();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        long long11 = buddhistChronology5.add(readablePeriod8, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField12 = buddhistChronology5.seconds();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str7.equals("BuddhistChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long7 = delegatedDateTimeField4.add((long) 1, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.secondOfMinute();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        int[] intArray16 = gregorianChronology8.get((org.joda.time.ReadablePartial) localTime14, (long) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.secondOfMinute();
        org.joda.time.DurationField durationField20 = gregorianChronology17.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localTime23, (long) '#');
        int int26 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime14, intArray25);
        long long29 = delegatedDateTimeField4.addWrapField((-1L), 0);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone32);
        org.joda.time.LocalDate localDate35 = dateTime34.toLocalDate();
        int[] intArray37 = null;
        try {
            int[] intArray39 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) localDate35, (-23), intArray37, 21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36000001L + "'", long7 == 36000001L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertNotNull(localDate35);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        org.joda.time.DateTime.Property property6 = dateTime1.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((-24));
//        org.joda.time.DateTime dateTime9 = dateTime1.withZoneRetainFields(dateTimeZone8);
//        int int10 = dateTime9.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
        long long10 = delegatedDateTimeField4.roundFloor((long) 377);
        try {
            long long13 = delegatedDateTimeField4.set((long) 216, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withMillisOfSecond((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(20143744, 27117805);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47261549 + "'", int2 == 47261549);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField3 = mutableDateTime1.getRoundingField();
//        org.joda.time.Chronology chronology4 = mutableDateTime1.getChronology();
//        mutableDateTime1.addWeekyears(0);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime1.dayOfMonth();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withZone(dateTimeZone9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
//        org.joda.time.DateTime.Property property14 = dateTime12.year();
//        java.lang.String str15 = dateTimeFormatter8.print((org.joda.time.ReadableInstant) dateTime12);
//        mutableDateTime1.setDate((org.joda.time.ReadableInstant) dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(localTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4:43:03 PM -07:52:58" + "'", str15.equals("4:43:03 PM -07:52:58"));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond((int) 'a', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendClockhourOfDay(372);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder8.appendHourOfHalfday(372);
        boolean boolean16 = buddhistChronology0.equals((java.lang.Object) 372);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(strMap5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField4 = julianChronology0.years();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendWeekyear(24, (int) (byte) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendWeekyear(1, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendDayOfMonth(0);
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatterBuilder14.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray16 = new org.joda.time.format.DateTimeParser[] { dateTimeParser15 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder3.append(dateTimePrinter8, dateTimeParserArray16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTwoDigitYear(372, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeParserArray16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology1, locale6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.weekyearOfCentury();
        try {
            long long13 = gregorianChronology1.getDateTimeMillis(0, 0, 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        java.util.Locale locale7 = null;
        java.lang.String str8 = delegatedDateTimeField5.getAsText(12, locale7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getRangeDurationField();
        int int11 = delegatedDateTimeField5.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = delegatedDateTimeField5.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12" + "'", str8.equals("12"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        try {
//            java.lang.String str27 = unsupportedDateTimeField25.getAsShortText((long) 27117805);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime2.add(readableDuration4, 5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundFloor();
        java.util.Locale locale10 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = property7.set("+00:00:00.010", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.010\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "4:43:01 PM -07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = delegatedDateTimeField30.getAsText(12, locale32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology34);
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.secondOfMinute();
//        org.joda.time.DurationField durationField37 = gregorianChronology34.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology38);
//        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
//        int[] intArray42 = gregorianChronology34.get((org.joda.time.ReadablePartial) localTime40, (long) '#');
//        int[] intArray43 = null;
//        int int44 = delegatedDateTimeField30.getMaximumValue((org.joda.time.ReadablePartial) localTime40, intArray43);
//        int int46 = delegatedDateTimeField30.getMaximumValue((long) 335);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology47.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50);
//        java.util.Locale locale52 = null;
//        int int53 = delegatedDateTimeField51.getMaximumTextLength(locale52);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology54.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField57);
//        long long61 = delegatedDateTimeField58.add((long) 1, (long) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology62);
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology62.secondOfMinute();
//        org.joda.time.DurationField durationField65 = gregorianChronology62.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology66);
//        org.joda.time.LocalTime localTime68 = dateTime67.toLocalTime();
//        int[] intArray70 = gregorianChronology62.get((org.joda.time.ReadablePartial) localTime68, (long) '#');
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology71);
//        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology71.secondOfMinute();
//        org.joda.time.DurationField durationField74 = gregorianChronology71.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology75);
//        org.joda.time.LocalTime localTime77 = dateTime76.toLocalTime();
//        int[] intArray79 = gregorianChronology71.get((org.joda.time.ReadablePartial) localTime77, (long) '#');
//        int int80 = delegatedDateTimeField58.getMinimumValue((org.joda.time.ReadablePartial) localTime68, intArray79);
//        java.util.Locale locale82 = null;
//        java.lang.String str83 = delegatedDateTimeField51.getAsText((org.joda.time.ReadablePartial) localTime68, 20142, locale82);
//        int[] intArray84 = null;
//        int int85 = delegatedDateTimeField30.getMaximumValue((org.joda.time.ReadablePartial) localTime68, intArray84);
//        java.util.Locale locale86 = null;
//        try {
//            java.lang.String str87 = unsupportedDateTimeField25.getAsText((org.joda.time.ReadablePartial) localTime68, locale86);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(localTime40);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 12 + "'", int44 == 12);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2 + "'", int53 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 36000001L + "'", long61 == 36000001L);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(localTime68);
//        org.junit.Assert.assertNotNull(intArray70);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField73);
//        org.junit.Assert.assertNotNull(durationField74);
//        org.junit.Assert.assertNotNull(gregorianChronology75);
//        org.junit.Assert.assertNotNull(localTime77);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "20142" + "'", str83.equals("20142"));
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 12 + "'", int85 == 12);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        java.util.Locale locale27 = null;
//        try {
//            java.lang.String str28 = unsupportedDateTimeField25.getAsText((int) ' ', locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        long long6 = offsetDateTimeField3.roundHalfFloor((long) 20152);
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        int[] intArray9 = null;
//        try {
//            int[] intArray11 = offsetDateTimeField3.add(readablePartial7, 37, intArray9, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.secondOfMinute();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        int[] intArray16 = gregorianChronology8.get((org.joda.time.ReadablePartial) localTime14, (long) '#');
        int[] intArray17 = null;
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localTime14, intArray17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField23.getAsText(12, locale25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.secondOfMinute();
        org.joda.time.DurationField durationField30 = gregorianChronology27.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology31);
        org.joda.time.LocalTime localTime33 = dateTime32.toLocalTime();
        int[] intArray35 = gregorianChronology27.get((org.joda.time.ReadablePartial) localTime33, (long) '#');
        int[] intArray36 = null;
        int int37 = delegatedDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localTime33, intArray36);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.LocalTime localTime40 = dateTime39.toLocalTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology41);
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.secondOfMinute();
        org.joda.time.DurationField durationField44 = gregorianChronology41.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology45);
        org.joda.time.LocalTime localTime47 = dateTime46.toLocalTime();
        int[] intArray49 = gregorianChronology41.get((org.joda.time.ReadablePartial) localTime47, (long) '#');
        int int50 = delegatedDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) localTime40, intArray49);
        int[] intArray57 = new int[] { (short) 0, 20150, 935, 299, 377, 10 };
        int int58 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime40, intArray57);
        try {
            long long61 = delegatedDateTimeField4.set(10L, "GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "12" + "'", str26.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(localTime33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(localTime40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(localTime47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-7351100L), (org.joda.time.Chronology) buddhistChronology1);
        boolean boolean4 = dateTime3.isAfterNow();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int5 = delegatedDateTimeField4.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsText(12, locale12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.secondOfMinute();
        org.joda.time.DurationField durationField17 = gregorianChronology14.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
        int[] intArray22 = gregorianChronology14.get((org.joda.time.ReadablePartial) localTime20, (long) '#');
        int[] intArray23 = null;
        int int24 = delegatedDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime20, intArray23);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.secondOfMinute();
        org.joda.time.DurationField durationField31 = gregorianChronology28.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.LocalTime localTime34 = dateTime33.toLocalTime();
        int[] intArray36 = gregorianChronology28.get((org.joda.time.ReadablePartial) localTime34, (long) '#');
        int int37 = delegatedDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localTime27, intArray36);
        int int38 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime27);
        int int40 = delegatedDateTimeField4.getMinimumValue((long) 9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12" + "'", str13.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(localTime20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(localTime27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(localTime34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 297);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        java.lang.String str4 = property3.getName();
        java.lang.String str5 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "year" + "'", str4.equals("year"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withYearOfEra(24);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime7, (java.lang.Object) dateTimeFormatter8);
//        java.lang.StringBuffer stringBuffer10 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.minus(readableDuration14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
//        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
//        org.joda.time.DateTime dateTime20 = dateTime18.plusHours((-24));
//        try {
//            dateTimeFormatter8.printTo(stringBuffer10, (org.joda.time.ReadableInstant) dateTime18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(localTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = mutableDateTime1.getRoundingField();
        org.joda.time.Chronology chronology4 = mutableDateTime1.getChronology();
        mutableDateTime1.addWeekyears(0);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime1.dayOfMonth();
        mutableDateTime1.setSecondOfDay(0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(20140, 935, 935);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("12");
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.Interval interval4 = property3.toInterval();
        org.joda.time.DateTime dateTime5 = property3.roundHalfEvenCopy();
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withMonthOfYear(570);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 570 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(interval4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime1.dayOfWeek();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval7);
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(readableInterval8);
        org.junit.Assert.assertNotNull(readableInterval9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 335, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfMonth();
        try {
            long long13 = gregorianChronology1.getDateTimeMillis(20143367, (int) 'a', 572, 20143365, 7, 372, (-24));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20143365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 335, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1);
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.LocalTime localTime5 = dateTime4.toLocalTime();
//        org.joda.time.DateTime.Property property6 = dateTime4.year();
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//        java.lang.StringBuffer stringBuffer8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = delegatedDateTimeField13.getAsText(12, locale15);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.secondOfMinute();
//        org.joda.time.DurationField durationField20 = gregorianChronology17.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
//        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localTime23, (long) '#');
//        int[] intArray26 = null;
//        int int27 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localTime23, intArray26);
//        int int29 = delegatedDateTimeField13.getMaximumValue((long) 335);
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.secondOfMinute();
//        org.joda.time.DurationField durationField33 = gregorianChronology30.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology34);
//        org.joda.time.LocalTime localTime36 = dateTime35.toLocalTime();
//        int[] intArray38 = gregorianChronology30.get((org.joda.time.ReadablePartial) localTime36, (long) '#');
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = delegatedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localTime36, (-1), locale40);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer8, (org.joda.time.ReadablePartial) localTime36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(localTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12:36:04 PM UTC" + "'", str7.equals("12:36:04 PM UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "12" + "'", str16.equals("12"));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(localTime23);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(localTime36);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "-1" + "'", str41.equals("-1"));
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundFloor();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            mutableDateTime1.add(durationFieldType3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendMillisOfSecond(20142);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = delegatedDateTimeField30.getAsText(12, locale32);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = delegatedDateTimeField30.getAsShortText(20140, locale35);
//        int int38 = delegatedDateTimeField30.getMaximumValue(100L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology39.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = delegatedDateTimeField43.getAsText(12, locale45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology47);
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.secondOfMinute();
//        org.joda.time.DurationField durationField50 = gregorianChronology47.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology51);
//        org.joda.time.LocalTime localTime53 = dateTime52.toLocalTime();
//        int[] intArray55 = gregorianChronology47.get((org.joda.time.ReadablePartial) localTime53, (long) '#');
//        int[] intArray56 = null;
//        int int57 = delegatedDateTimeField43.getMaximumValue((org.joda.time.ReadablePartial) localTime53, intArray56);
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology58);
//        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology61);
//        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology61.secondOfMinute();
//        org.joda.time.DurationField durationField64 = gregorianChronology61.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology65);
//        org.joda.time.LocalTime localTime67 = dateTime66.toLocalTime();
//        int[] intArray69 = gregorianChronology61.get((org.joda.time.ReadablePartial) localTime67, (long) '#');
//        int int70 = delegatedDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localTime60, intArray69);
//        java.util.Locale locale71 = null;
//        java.lang.String str72 = delegatedDateTimeField30.getAsText((org.joda.time.ReadablePartial) localTime60, locale71);
//        int[] intArray78 = new int[] { 20152, 689, 1, 100 };
//        try {
//            int[] intArray80 = unsupportedDateTimeField25.add((org.joda.time.ReadablePartial) localTime60, 10, intArray78, (-292275054));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12" + "'", str33.equals("12"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "20140" + "'", str36.equals("20140"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "12" + "'", str46.equals("12"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(durationField50);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(localTime53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 12 + "'", int57 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(localTime60);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(localTime67);
//        org.junit.Assert.assertNotNull(intArray69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "12" + "'", str72.equals("12"));
//        org.junit.Assert.assertNotNull(intArray78);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        try {
//            long long27 = unsupportedDateTimeField25.roundHalfCeiling((long) 19);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        boolean boolean2 = property1.isLeap();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField8.getAsText(12, locale10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField8.getRangeDurationField();
        int int14 = delegatedDateTimeField8.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = delegatedDateTimeField8.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField21.getAsText(12, locale23);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.secondOfMinute();
        org.joda.time.DurationField durationField28 = gregorianChronology25.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
        int[] intArray33 = gregorianChronology25.get((org.joda.time.ReadablePartial) localTime31, (long) '#');
        int[] intArray34 = null;
        int int35 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localTime31, intArray34);
        int int37 = delegatedDateTimeField21.getMaximumValue((long) 335);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.secondOfMinute();
        org.joda.time.DurationField durationField41 = gregorianChronology38.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology42);
        org.joda.time.LocalTime localTime44 = dateTime43.toLocalTime();
        int[] intArray46 = gregorianChronology38.get((org.joda.time.ReadablePartial) localTime44, (long) '#');
        java.util.Locale locale48 = null;
        java.lang.String str49 = delegatedDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localTime44, (-1), locale48);
        int[] intArray54 = new int[] { (-1), 10, 12 };
        try {
            int[] intArray56 = delegatedDateTimeField16.addWrapField((org.joda.time.ReadablePartial) localTime44, (int) '4', intArray54, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "12" + "'", str11.equals("12"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "12" + "'", str24.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(localTime31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 12 + "'", int35 == 12);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(localTime44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "-1" + "'", str49.equals("-1"));
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-24));
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        long long6 = offsetDateTimeField3.add((long) 282, 0L);
        boolean boolean8 = offsetDateTimeField3.isLeap((long) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField13.getAsText(12, locale15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.secondOfMinute();
        org.joda.time.DurationField durationField20 = gregorianChronology17.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localTime23, (long) '#');
        int[] intArray26 = null;
        int int27 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localTime23, intArray26);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        long long36 = delegatedDateTimeField33.add((long) 1, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology37);
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.secondOfMinute();
        org.joda.time.DurationField durationField40 = gregorianChronology37.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology41);
        org.joda.time.LocalTime localTime43 = dateTime42.toLocalTime();
        int[] intArray45 = gregorianChronology37.get((org.joda.time.ReadablePartial) localTime43, (long) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology46);
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.secondOfMinute();
        org.joda.time.DurationField durationField49 = gregorianChronology46.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology50);
        org.joda.time.LocalTime localTime52 = dateTime51.toLocalTime();
        int[] intArray54 = gregorianChronology46.get((org.joda.time.ReadablePartial) localTime52, (long) '#');
        int int55 = delegatedDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localTime43, intArray54);
        java.util.Locale locale57 = null;
        try {
            int[] intArray58 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localTime23, (int) (short) 100, intArray54, "5:35:47 AM PDT", locale57);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"5:35:47 AM PDT\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 282L + "'", long6 == 282L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "12" + "'", str16.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 36000001L + "'", long36 == 36000001L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(localTime43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(localTime52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendMinuteOfHour(182);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendMinuteOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendMinuteOfHour(292278994);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(20140);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField12 = julianChronology11.months();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.Chronology chronology14 = julianChronology11.withUTC();
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime8.toMutableDateTime(chronology14);
        try {
            org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(0, 1, (int) (byte) 0, 162, 0, 47261549, 0, chronology14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 162 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        int int12 = cachedDateTimeZone9.getStandardOffset((long) 216);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (short) -1, 297, 24, 3, 21, 0, (org.joda.time.DateTimeZone) cachedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 297 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
//        int int15 = dateTime13.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime((org.joda.time.Chronology) gregorianChronology16);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime22 = dateTime10.toDateTime(chronology21);
//        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withZone(dateTimeZone27);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
//        org.joda.time.DateTime.Property property32 = dateTime30.year();
//        java.lang.String str33 = dateTimeFormatter26.print((org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime35 = dateTime30.withDayOfYear((int) '4');
//        mutableDateTime25.setMillis((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime dateTime38 = dateTime35.plusDays(12);
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology39 = org.joda.time.chrono.LimitChronology.getInstance(chronology21, (org.joda.time.ReadableDateTime) mutableDateTime23, (org.joda.time.ReadableDateTime) dateTime35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:07 PM UTC" + "'", str8.equals("12:36:07 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(localTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 14 + "'", int15 == 14);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(localTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "12:36:07 PM UTC" + "'", str33.equals("12:36:07 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime38);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1971", (-292275054), (int) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for 1971 must be in the range [35,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone2);
        int int5 = dateTime4.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("12");
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.DateTime dateTime5 = property3.setCopy((int) (short) 10);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
        org.joda.time.MutableDateTime mutableDateTime5 = property2.add((long) 20143);
        org.joda.time.Interval interval6 = property2.toInterval();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval6);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.Chronology chronology10 = iSOChronology8.withZone(dateTimeZone9);
//        java.lang.String str11 = iSOChronology8.toString();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
//        org.joda.time.DateTime.Property property21 = dateTime19.year();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.minus(readablePeriod22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime23.plus(readablePeriod24);
//        int int26 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.Chronology chronology27 = iSOChronology8.withZone(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(localTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(chronology27);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfWeek();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        try {
            mutableDateTime0.setRounding((org.joda.time.DateTimeField) delegatedDateTimeField13, 20153497);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 20153497");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("4:42:58 PM -07:52:58");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale2 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 335, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1);
//        dateTimeParserBucket4.setPivotYear((java.lang.Integer) 0);
//        long long9 = dateTimeParserBucket4.computeMillis(false, "Pacific Standard Time");
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 335L + "'", long9 == 335L);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        try {
//            long long28 = unsupportedDateTimeField25.add((-210866760000000L), 0L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        int int5 = cachedDateTimeZone3.getStandardOffset((long) 100);
//        java.lang.String str7 = cachedDateTimeZone3.getName(0L);
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField3 = mutableDateTime1.getRoundingField();
        org.joda.time.Chronology chronology4 = mutableDateTime1.getChronology();
        mutableDateTime1.addWeekyears(0);
        mutableDateTime1.addMinutes(365);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = property5.roundHalfFloorCopy();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime2.add(readableDuration4, 5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.hourOfDay();
        mutableDateTime2.setMillisOfSecond(689);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) '#');
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime5.copy();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
//        mutableDateTime1.addYears(24);
//        mutableDateTime1.addMonths((-24));
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        mutableDateTime1.setRounding(dateTimeField7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.minus(readableDuration14);
//        int int16 = dateTime12.getDayOfMonth();
//        org.joda.time.DateTime dateTime18 = dateTime12.withYearOfEra(24);
//        int int19 = dateTime18.getYear();
//        org.joda.time.ReadableDuration readableDuration20 = null;
//        org.joda.time.DateTime dateTime22 = dateTime18.withDurationAdded(readableDuration20, 372);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime1, (org.joda.time.ReadableInstant) dateTime22);
//        try {
//            mutableDateTime1.setDate(689, 100, 935);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(localTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 12);
        java.io.Writer writer5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) localTime12, 20143, locale14);
        try {
            dateTimeFormatter2.printTo(writer5, (org.joda.time.ReadablePartial) localTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "20143" + "'", str15.equals("20143"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) (byte) 10, (-24));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
//        mutableDateTime1.addSeconds((int) (short) -1);
//        mutableDateTime1.addYears(216);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfYear();
//        boolean boolean8 = property7.isLeap();
//        org.joda.time.DateTimeField dateTimeField9 = property7.getField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = delegatedDateTimeField14.getAsText(12, locale16);
//        org.joda.time.DurationField durationField18 = delegatedDateTimeField14.getRangeDurationField();
//        int int20 = delegatedDateTimeField14.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType21);
//        int int23 = mutableDateTime1.get(dateTimeFieldType21);
//        int int24 = mutableDateTime1.getRoundingMode();
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "12" + "'", str17.equals("12"));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime9 = instant8.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.monthOfYear();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.yearOfEra();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) mutableDateTime9);
        mutableDateTime9.setDayOfYear(37);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-1));
        org.joda.time.DateTime dateTime10 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withMillis((long) (byte) 1);
        java.lang.String str14 = dateTime9.toString("12");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "12" + "'", str14.equals("12"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime1.add(readableDuration3, 20143);
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime7.addYears(24);
        mutableDateTime7.addMonths((-24));
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) 1);
        mutableDateTime7.setRounding(dateTimeField13);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime7.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime18 = property17.getMutableDateTime();
        mutableDateTime1.setTime((org.joda.time.ReadableInstant) mutableDateTime18);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        boolean boolean26 = unsupportedDateTimeField25.isSupported();
//        try {
//            int int27 = unsupportedDateTimeField25.getMaximumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
//        java.lang.String str2 = gregorianChronology0.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-24));
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfHour();
        org.joda.time.Instant instant4 = gJChronology2.getGregorianCutover();
        try {
            long long9 = gJChronology2.getDateTimeMillis((-335), 0, 20143367, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        org.joda.time.ReadableInstant readableInstant2 = null;
        mutableDateTime0.setTime(readableInstant2);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        long long6 = offsetDateTimeField3.getDifferenceAsLong((long) 'a', (-23L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        boolean boolean10 = gregorianChronology4.equals((java.lang.Object) 10);
//        try {
//            long long15 = gregorianChronology4.getDateTimeMillis(2019, 0, 390, 4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 384 + "'", int3 == 384);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
        org.joda.time.MutableDateTime mutableDateTime5 = property2.add((long) 20143);
        org.joda.time.DurationField durationField6 = property2.getLeapDurationField();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime6 = property3.withMaximumValue();
        try {
            org.joda.time.DateTime dateTime8 = property3.setCopy(216);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 216 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime1.withPeriodAdded(readablePeriod4, (int) (short) 10);
//        int int7 = dateTime1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 899 + "'", int3 == 899);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        boolean boolean5 = dateTime1.isSupported(dateTimeFieldType4);
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendWeekyear(24, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendWeekyear(1, (-1));
        boolean boolean12 = dateTimeFormatterBuilder11.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendMillisOfSecond(20142);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.append(dateTimeFormatter17);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder20.appendWeekyear(1, (-1));
        boolean boolean24 = dateTimeFormatterBuilder23.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder23.appendWeekyear(24, (int) (byte) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendWeekyear(1, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder29.appendDayOfMonth(0);
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatterBuilder34.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray36 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder23.append(dateTimePrinter28, dateTimeParserArray36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder14.append(dateTimePrinter19, dateTimeParserArray36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder39.appendWeekyear(1, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder39.appendDayOfMonth(0);
        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatterBuilder44.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder7.append(dateTimePrinter19, dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimeParserArray36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeParser45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone8);
//        int int11 = dateTime7.getWeekOfWeekyear();
//        boolean boolean13 = dateTime7.isEqual(10L);
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime7.withZone(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(24, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendLiteral('4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant0.minus(readableDuration2);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-1));
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime9.toMutableDateTime(dateTimeZone10);
//        mutableDateTime11.setSecondOfMinute(7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.minus(readableDuration17);
//        int int19 = dateTime15.getDayOfMonth();
//        org.joda.time.DateTime dateTime21 = dateTime15.withYearOfEra(24);
//        mutableDateTime11.setDate((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
//        org.joda.time.LocalTime localTime24 = dateTime21.toLocalTime();
//        org.joda.time.DateTime.Property property25 = dateTime21.centuryOfEra();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(localTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(localTime24);
//        org.junit.Assert.assertNotNull(property25);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        boolean boolean26 = unsupportedDateTimeField25.isSupported();
//        try {
//            java.lang.String str28 = unsupportedDateTimeField25.getAsText((-20140L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        mutableDateTime2.setTime((long) 365);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        java.lang.String str3 = gregorianChronology0.toString();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
//        java.util.Locale locale10 = null;
//        int int11 = delegatedDateTimeField9.getMaximumTextLength(locale10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
//        long long19 = delegatedDateTimeField16.add((long) 1, (long) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.secondOfMinute();
//        org.joda.time.DurationField durationField23 = gregorianChronology20.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology24);
//        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
//        int[] intArray28 = gregorianChronology20.get((org.joda.time.ReadablePartial) localTime26, (long) '#');
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.secondOfMinute();
//        org.joda.time.DurationField durationField32 = gregorianChronology29.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology33);
//        org.joda.time.LocalTime localTime35 = dateTime34.toLocalTime();
//        int[] intArray37 = gregorianChronology29.get((org.joda.time.ReadablePartial) localTime35, (long) '#');
//        int int38 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localTime26, intArray37);
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = delegatedDateTimeField9.getAsText((org.joda.time.ReadablePartial) localTime26, 20142, locale40);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology42);
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.secondOfMinute();
//        org.joda.time.DurationField durationField45 = gregorianChronology42.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology46);
//        org.joda.time.LocalTime localTime48 = dateTime47.toLocalTime();
//        int[] intArray50 = gregorianChronology42.get((org.joda.time.ReadablePartial) localTime48, (long) '#');
//        gregorianChronology0.validate((org.joda.time.ReadablePartial) localTime26, intArray50);
//        org.joda.time.Chronology chronology52 = gregorianChronology0.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.Locale locale55 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket57 = new org.joda.time.format.DateTimeParserBucket((long) 335, (org.joda.time.Chronology) gregorianChronology54, locale55, (java.lang.Integer) 1);
//        dateTimeParserBucket57.setPivotYear((java.lang.Integer) 4);
//        org.joda.time.Chronology chronology60 = dateTimeParserBucket57.getChronology();
//        try {
//            org.joda.time.MutableDateTime mutableDateTime61 = new org.joda.time.MutableDateTime((java.lang.Object) chronology52, chronology60);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 36000001L + "'", long19 == 36000001L);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(localTime26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(localTime35);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "20142" + "'", str41.equals("20142"));
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(localTime48);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(chronology60);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        int int5 = property3.getMinimumValue();
        int int6 = property3.getMinimumValueOverall();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property3.getAsText(locale7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-292275054) + "'", int5 == (-292275054));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-292275054) + "'", int6 == (-292275054));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology(chronology1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withZoneUTC();
        int int6 = dateTimeFormatter5.getDefaultYear();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter5.withLocale(locale7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.withSecondOfMinute(12);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:10 PM UTC" + "'", str8.equals("12:36:10 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 10, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.parse("Wed", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Wed\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsText(12, locale7);
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField5.getRangeDurationField();
//        int int11 = delegatedDateTimeField5.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = delegatedDateTimeField5.getType();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone14.getShortName((long) 'a', locale16);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.centuryOfEra();
//        java.lang.String str20 = buddhistChronology18.toString();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        long long24 = buddhistChronology18.add(readablePeriod21, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField25 = buddhistChronology18.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField25);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12" + "'", str8.equals("12"));
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "BuddhistChronology[UTC]" + "'", str20.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-1));
        org.joda.time.DateTime dateTime11 = dateTime9.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime9.plusSeconds((int) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime1);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 'a', chronology1);
        try {
            mutableDateTime2.setSecondOfMinute(299);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 299 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        int int4 = property3.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property3.addToCopy((long) 4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone8);
        boolean boolean12 = dateTime10.isBefore((-20140L));
        org.joda.time.DateTime.Property property13 = dateTime10.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.LocalTime localTime5 = dateTime4.toLocalTime();
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.minus(readablePeriod7);
        org.joda.time.DateTime dateTime10 = dateTime4.plusHours(0);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((-1));
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime12.toMutableDateTime(dateTimeZone13);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 20142);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20142 + "'", int1 == 20142);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds((int) (short) 10);
//        int int4 = dateTime3.getDayOfWeek();
//        int int5 = dateTime3.getMillisOfDay();
//        java.util.GregorianCalendar gregorianCalendar6 = dateTime3.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 45362942 + "'", int5 == 45362942);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.year();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        mutableDateTime0.setWeekyear(0);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime0.secondOfMinute();
//        try {
//            mutableDateTime0.setHourOfDay(390);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 390 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:13 PM UTC" + "'", str8.equals("12:36:13 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property14);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime1.copy();
        mutableDateTime4.addYears(2);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withYearOfEra(24);
//        int int8 = dateTime7.getYear();
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded(readableDuration9, 372);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime7.withDurationAdded(readableDuration12, 0);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 20143744, 20, 20143);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20143744 for  must be in the range [20,20143]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("37");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime6 = instant5.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.monthOfYear();
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime6.add(readableDuration8, 20143);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
        org.joda.time.DurationField durationField13 = gJChronology11.minutes();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.DurationField durationField26 = unsupportedDateTimeField25.getLeapDurationField();
//        java.util.Locale locale27 = null;
//        try {
//            int int28 = unsupportedDateTimeField25.getMaximumTextLength(locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNull(durationField26);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-23), 'a', 20143367, (-335), 570, true, 570);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder8.toDateTimeZone("4:42:58 PM -07:52:58", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder8.setFixedSavings("5:35:45 AM PDT", (int) (byte) 100);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder8.addCutover(47261549, '#', (-24), 2019, 0, false, 311);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withYearOfEra(24);
//        int int8 = dateTime7.getYear();
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime7.withDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 335, (org.joda.time.Chronology) gregorianChronology1, locale2, (java.lang.Integer) 1);
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        org.joda.time.DurationField durationField6 = gregorianChronology1.millis();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField8 = gregorianChronology1.millis();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", (java.lang.Number) 881, (java.lang.Number) (byte) -1, (java.lang.Number) 2);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField4 = gregorianChronology0.months();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        int int6 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-24));
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.year();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.secondOfMinute();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        int[] intArray16 = gregorianChronology8.get((org.joda.time.ReadablePartial) localTime14, (long) '#');
        int[] intArray17 = null;
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localTime14, intArray17);
        int int20 = delegatedDateTimeField4.getMaximumValue((long) 335);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.secondOfMinute();
        org.joda.time.DurationField durationField24 = gregorianChronology21.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
        int[] intArray29 = gregorianChronology21.get((org.joda.time.ReadablePartial) localTime27, (long) '#');
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime27, (-1), locale31);
        java.util.Locale locale35 = null;
        try {
            long long36 = delegatedDateTimeField4.set((long) (short) 0, "clockhourOfHalfday", locale35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"clockhourOfHalfday\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(localTime27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-1" + "'", str32.equals("-1"));
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
//        org.joda.time.DurationField durationField4 = offsetDateTimeField3.getDurationField();
//        long long6 = offsetDateTimeField3.roundHalfFloor(52L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = buddhistChronology5.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology5.minuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        mutableDateTime1.add(readablePeriod4);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        int int12 = cachedDateTimeZone9.getStandardOffset((long) 216);
        java.lang.String str14 = cachedDateTimeZone9.getNameKey((long) 100);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (short) -1, 20150, 689, 390, 162, 935, (org.joda.time.DateTimeZone) cachedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 390 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = delegatedDateTimeField4.getAsShortText(20140, locale9);
//        int int12 = delegatedDateTimeField4.getMaximumValue(100L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology13);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = delegatedDateTimeField17.getAsText(12, locale19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.secondOfMinute();
//        org.joda.time.DurationField durationField24 = gregorianChronology21.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        int[] intArray29 = gregorianChronology21.get((org.joda.time.ReadablePartial) localTime27, (long) '#');
//        int[] intArray30 = null;
//        int int31 = delegatedDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localTime27, intArray30);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.LocalTime localTime34 = dateTime33.toLocalTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology35);
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.secondOfMinute();
//        org.joda.time.DurationField durationField38 = gregorianChronology35.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.LocalTime localTime41 = dateTime40.toLocalTime();
//        int[] intArray43 = gregorianChronology35.get((org.joda.time.ReadablePartial) localTime41, (long) '#');
//        int int44 = delegatedDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) localTime34, intArray43);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localTime34, locale45);
//        boolean boolean47 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime34);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20140" + "'", str10.equals("20140"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "12" + "'", str20.equals("12"));
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(localTime34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(localTime41);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "12" + "'", str46.equals("12"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
//        int int5 = dateTime1.getDayOfMonth();
//        int int6 = dateTime1.getCenturyOfEra();
//        org.joda.time.DateTime dateTime7 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(28800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 21 + "'", int6 == 21);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.plusDays(12);
//        org.joda.time.DateTime.Property property14 = dateTime10.secondOfDay();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:14 PM UTC" + "'", str8.equals("12:36:14 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withZone(dateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
//        org.joda.time.DateTime.Property property18 = dateTime16.year();
//        java.lang.String str19 = dateTimeFormatter12.print((org.joda.time.ReadableInstant) dateTime16);
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime16);
//        mutableDateTime0.setSecondOfDay(299);
//        mutableDateTime0.setWeekyear(572);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        try {
//            org.joda.time.MutableDateTime.Property property26 = mutableDateTime0.property(dateTimeFieldType25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:15 PM UTC" + "'", str8.equals("12:36:15 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12:36:15 PM UTC" + "'", str19.equals("12:36:15 PM UTC"));
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        mutableDateTime0.setWeekyear(0);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime0.secondOfMinute();
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime0.minuteOfHour();
//        try {
//            mutableDateTime0.setDayOfYear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,366]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:15 PM UTC" + "'", str8.equals("12:36:15 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.addToCopy(52L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField4.getAsShortText(20140, locale9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localTime17, 20143, locale19);
        int[] intArray22 = null;
        try {
            int[] intArray24 = delegatedDateTimeField4.add((org.joda.time.ReadablePartial) localTime17, 372, intArray22, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20140" + "'", str10.equals("20140"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "20143" + "'", str20.equals("20143"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-1));
        org.joda.time.DateTime dateTime10 = dateTime9.withTimeAtStartOfDay();
        boolean boolean11 = dateTime9.isBeforeNow();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.minus(readablePeriod15);
        org.joda.time.DateTime.Property property17 = dateTime12.dayOfWeek();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime20 = dateTime10.plusHours(0);
        try {
            org.joda.time.DateTime dateTime22 = dateTime20.withSecondOfMinute((-275423));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -275423 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(localTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 572);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210817339200000L) + "'", long1 == (-210817339200000L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 689, (java.lang.Number) (-1), (java.lang.Number) 127);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfEra((int) (byte) 100);
//        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfEra(26);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 591 + "'", int3 == 591);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
//        int int4 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.minusYears(5);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 756 + "'", int4 == 756);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 591, (long) 182);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 409L + "'", long2 == 409L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        try {
            java.lang.String str2 = dateTime0.toString("BuddhistChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: B");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.Instant instant8 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime9 = instant8.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.monthOfYear();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime9.yearOfEra();
        boolean boolean12 = dateTime6.isAfter((org.joda.time.ReadableInstant) mutableDateTime9);
        boolean boolean14 = mutableDateTime9.isAfter((-1L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("12:36:12 PM UTC");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"12:36:12 PM UTC/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", (java.lang.Number) 881, (java.lang.Number) (byte) -1, (java.lang.Number) 2);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "881" + "'", str6.equals("881"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) -1 + "'", number7.equals((byte) -1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.Chronology chronology8 = dateTimeFormatter7.getChronology();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter7.withZone(dateTimeZone11);
        try {
            org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(476, 20153497, 4, 0, 20143, 282, 4, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20143 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        long long6 = offsetDateTimeField3.add((long) 282, 0L);
        boolean boolean8 = offsetDateTimeField3.isLeap((long) (short) -1);
        org.joda.time.DurationField durationField9 = offsetDateTimeField3.getLeapDurationField();
        java.lang.String str10 = offsetDateTimeField3.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 282L + "'", long6 == 282L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "year" + "'", str10.equals("year"));
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
//        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
//        org.joda.time.DateTime dateTime11 = property9.roundHalfEvenCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
//        org.joda.time.DateTime.Property property15 = dateTime13.year();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime13.minus(readablePeriod16);
//        org.joda.time.DateTime dateTime19 = dateTime13.plusHours(0);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = dateTime19.withZone(dateTimeZone20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology23);
//        org.joda.time.LocalTime localTime25 = dateTime24.toLocalTime();
//        org.joda.time.DateTime.Property property26 = dateTime24.year();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime24.minus(readablePeriod27);
//        org.joda.time.DateTime.Property property29 = dateTime24.dayOfWeek();
//        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime22, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime32 = dateTime22.plusHours(0);
//        int int33 = property9.compareTo((org.joda.time.ReadableInstant) dateTime32);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 227 + "'", int3 == 227);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(localTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(localTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond((int) 'a', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendWeekyear(69, 2019);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        try {
//            long long28 = unsupportedDateTimeField25.addWrapField((long) 216, 20143);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology1, locale6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology1.weekyearOfCentury();
        int int9 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("Wed");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Wed\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        try {
            long long4 = dateTimeFormatter2.parseMillis("12:36:10 PM UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12:36:10 PM UTC\" is malformed at \" PM UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.DurationField durationField26 = unsupportedDateTimeField25.getLeapDurationField();
//        try {
//            long long29 = unsupportedDateTimeField25.addWrapField((long) 37, 182);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNull(durationField26);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        int int5 = property3.getMinimumValue();
        try {
            org.joda.time.DateTime dateTime7 = property3.addToCopy(292278994);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292281013 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-292275054) + "'", int5 == (-292275054));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", (java.lang.Number) 881, (java.lang.Number) (byte) -1, (java.lang.Number) 2);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        illegalFieldValueException4.prependMessage("20140");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
//        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
//        org.joda.time.DateTime.Property property14 = dateTime12.year();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime12.minus(readablePeriod15);
//        org.joda.time.DateTime.Property property17 = dateTime12.dayOfWeek();
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime20 = dateTime12.plusDays(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.secondOfMinute();
//        org.joda.time.DurationField durationField24 = gregorianChronology21.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        int[] intArray29 = gregorianChronology21.get((org.joda.time.ReadablePartial) localTime27, (long) '#');
//        org.joda.time.DurationField durationField30 = gregorianChronology21.weeks();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = dateTimeZone32.getShortName((long) 'a', locale34);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology36.minuteOfDay();
//        org.joda.time.DurationField durationField39 = buddhistChronology36.millis();
//        boolean boolean40 = gregorianChronology21.equals((java.lang.Object) buddhistChronology36);
//        org.joda.time.DateTime dateTime41 = dateTime12.withChronology((org.joda.time.Chronology) gregorianChronology21);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(localTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "UTC" + "'", str35.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTime41);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-1));
        org.joda.time.DateTime dateTime11 = dateTime9.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime11.toMutableDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime11.plusYears(19);
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime1.addYears(24);
        mutableDateTime1.addMonths((-24));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
        mutableDateTime1.setRounding(dateTimeField7);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime1.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(12, locale18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getRangeDurationField();
        int int22 = delegatedDateTimeField16.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime1.property(dateTimeFieldType23);
        try {
            mutableDateTime1.setDate(12, (-275423), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -275423 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12" + "'", str19.equals("12"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField4 = gregorianChronology0.months();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean6 = gregorianChronology0.equals((java.lang.Object) gJChronology5);
        try {
            long long11 = gJChronology5.getDateTimeMillis(182, 0, (int) (byte) 1, 299);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        boolean boolean26 = unsupportedDateTimeField25.isSupported();
//        try {
//            long long28 = unsupportedDateTimeField25.roundFloor((long) 390);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.secondOfMinute();
//        org.joda.time.DurationField durationField29 = gregorianChronology26.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
//        int[] intArray34 = gregorianChronology26.get((org.joda.time.ReadablePartial) localTime32, (long) '#');
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology26.millisOfSecond();
//        org.joda.time.DurationField durationField36 = gregorianChronology26.years();
//        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance();
//        org.joda.time.DurationField durationField38 = julianChronology37.months();
//        org.joda.time.DurationField durationField39 = julianChronology37.seconds();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField40 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType11, durationField36, durationField39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(localTime32);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(julianChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(durationField39);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime1.addYears(24);
        mutableDateTime1.addMonths((-24));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
        mutableDateTime1.setRounding(dateTimeField7);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime1.dayOfWeek();
        int int12 = property11.getMaximumValueOverall();
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = property11.set("4:43:01 PM -07:52:58");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"4:43:01 PM -07:52:58\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 7 + "'", int12 == 7);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("12");
        org.joda.time.DateTime dateTime4 = dateTime2.plusMonths(282);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        mutableDateTime0.setWeekyear(0);
//        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime0.copy();
//        mutableDateTime14.addMillis(127);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:17 PM UTC" + "'", str8.equals("12:36:17 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime12 = dateTime7.withWeekyear(20143365);
        org.joda.time.DateTime.Property property13 = dateTime12.hourOfDay();
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withDayOfMonth(37);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 37 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfDay(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendMinuteOfHour(182);
        boolean boolean11 = dateTimeFormatterBuilder10.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
        long long10 = delegatedDateTimeField4.roundFloor((long) 377);
        int int13 = delegatedDateTimeField4.getDifference((-991526399701L), (long) 10);
        long long15 = delegatedDateTimeField4.roundFloor((long) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-275423) + "'", int13 == (-275423));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(335L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500003877d + "'", double1 == 2440587.500003877d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = iSOChronology8.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology8.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readableDuration3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.DurationField durationField12 = gregorianChronology9.minutes();
        org.joda.time.DurationField durationField13 = gregorianChronology9.months();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        boolean boolean15 = gregorianChronology9.equals((java.lang.Object) gJChronology14);
        org.joda.time.DateTime dateTime16 = dateTime6.toDateTime((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay(299);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime.Property property6 = dateTime1.dayOfWeek();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime1.addYears(24);
        mutableDateTime1.addMonths((-24));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
        mutableDateTime1.setRounding(dateTimeField7);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime1.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(12, locale18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getRangeDurationField();
        int int22 = delegatedDateTimeField16.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime1.property(dateTimeFieldType23);
        org.joda.time.Interval interval25 = property24.toInterval();
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12" + "'", str19.equals("12"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(interval25);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        try {
            org.joda.time.LocalTime localTime4 = dateTimeFormatter2.parseLocalTime("20142");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20142\" is malformed at \"142\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfYear();
        boolean boolean3 = property2.isLeap();
        org.joda.time.DateTimeField dateTimeField4 = property2.getField();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        java.util.Locale locale11 = null;
        java.lang.String str12 = delegatedDateTimeField9.getAsText(12, locale11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField9.getRangeDurationField();
        int int15 = delegatedDateTimeField9.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = delegatedDateTimeField9.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType16);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12" + "'", str12.equals("12"));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfDay();
        org.joda.time.DurationField durationField9 = property8.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", (java.lang.Number) 881, (java.lang.Number) (byte) -1, (java.lang.Number) 2);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "881" + "'", str6.equals("881"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.Instant instant3 = instant0.plus((long) 335);
        org.joda.time.Instant instant4 = instant3.toInstant();
        org.joda.time.Instant instant6 = instant3.minus(1560342939905L);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localTime6, (long) '#');
//        org.joda.time.DurationField durationField9 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone11.getShortName((long) 'a', locale13);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.minuteOfDay();
//        org.joda.time.DurationField durationField18 = buddhistChronology15.millis();
//        boolean boolean19 = gregorianChronology0.equals((java.lang.Object) buddhistChronology15);
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology0.getZone();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "UTC" + "'", str14.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        int int3 = dateTime1.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime8 = dateTime1.toDateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfSecond(0);
//        org.joda.time.DateTime dateTime12 = dateTime10.minus((long) (short) 1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 257 + "'", int3 == 257);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = gJChronology0.halfdays();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(705, 20143744, (-335), 2019, 572, 127, 20152);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZone(dateTimeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = offsetDateTimeField3.getAsText((long) 2000, locale5);
//        long long8 = offsetDateTimeField3.roundHalfFloor((long) 365);
//        long long11 = offsetDateTimeField3.set((long) 377, 216);
//        long long14 = offsetDateTimeField3.set(335L, "20143");
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1971" + "'", str6.equals("1971"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-55382486399623L) + "'", long11 == (-55382486399623L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 573452956800335L + "'", long14 == 573452956800335L);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.DateTime dateTime4 = property3.roundHalfFloorCopy();
        org.joda.time.DurationField durationField5 = property3.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime1.addYears(24);
        mutableDateTime1.addMonths((-24));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
        mutableDateTime1.setRounding(dateTimeField7);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime1.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(12, locale18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getRangeDurationField();
        int int22 = delegatedDateTimeField16.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime1.property(dateTimeFieldType23);
        org.joda.time.MutableDateTime mutableDateTime25 = property24.roundFloor();
        java.util.Locale locale27 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime28 = property24.set("Pacific Standard Time", locale27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12" + "'", str19.equals("12"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
//        java.util.Locale locale31 = null;
//        int int32 = delegatedDateTimeField30.getMaximumTextLength(locale31);
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.secondOfMinute();
//        org.joda.time.DurationField durationField39 = gregorianChronology36.minutes();
//        org.joda.time.DurationField durationField40 = gregorianChronology36.months();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology36, locale41);
//        org.joda.time.Chronology chronology43 = dateTimeParserBucket42.getChronology();
//        java.util.Locale locale44 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket((long) 881, chronology43, locale44);
//        java.util.Locale locale46 = dateTimeParserBucket45.getLocale();
//        java.lang.String str47 = delegatedDateTimeField30.getAsText((long) (short) 1, locale46);
//        try {
//            int int48 = unsupportedDateTimeField25.getMaximumTextLength(locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(locale46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "12" + "'", str47.equals("12"));
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        boolean boolean26 = unsupportedDateTimeField25.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology32.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
//        long long39 = delegatedDateTimeField36.add((long) 1, (long) (short) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.secondOfMinute();
//        org.joda.time.DurationField durationField43 = gregorianChronology40.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology44);
//        org.joda.time.LocalTime localTime46 = dateTime45.toLocalTime();
//        int[] intArray48 = gregorianChronology40.get((org.joda.time.ReadablePartial) localTime46, (long) '#');
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology49);
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.secondOfMinute();
//        org.joda.time.DurationField durationField52 = gregorianChronology49.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology53);
//        org.joda.time.LocalTime localTime55 = dateTime54.toLocalTime();
//        int[] intArray57 = gregorianChronology49.get((org.joda.time.ReadablePartial) localTime55, (long) '#');
//        int int58 = delegatedDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) localTime46, intArray57);
//        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology59);
//        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology59.secondOfMinute();
//        org.joda.time.DurationField durationField62 = gregorianChronology59.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology63);
//        org.joda.time.LocalTime localTime65 = dateTime64.toLocalTime();
//        int[] intArray67 = gregorianChronology59.get((org.joda.time.ReadablePartial) localTime65, (long) '#');
//        int int68 = delegatedDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localTime46, intArray67);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology70);
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology70.secondOfMinute();
//        org.joda.time.DurationField durationField73 = gregorianChronology70.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology74 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology74);
//        org.joda.time.LocalTime localTime76 = dateTime75.toLocalTime();
//        int[] intArray78 = gregorianChronology70.get((org.joda.time.ReadablePartial) localTime76, (long) '#');
//        try {
//            int[] intArray80 = unsupportedDateTimeField25.add((org.joda.time.ReadablePartial) localTime46, 372, intArray78, 20152);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 36000001L + "'", long39 == 36000001L);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(localTime46);
//        org.junit.Assert.assertNotNull(intArray48);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertNotNull(localTime55);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(gregorianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(durationField62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(localTime65);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 12 + "'", int68 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(gregorianChronology74);
//        org.junit.Assert.assertNotNull(localTime76);
//        org.junit.Assert.assertNotNull(intArray78);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("-1", (java.lang.Number) 292278994, (java.lang.Number) 1L, (java.lang.Number) 299);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 299 + "'", number5.equals(299));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-23));
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = dateTime2.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        java.lang.Class<?> wildcardClass2 = illegalInstantException1.getClass();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("-1", (java.lang.Number) 292278994, (java.lang.Number) 1L, (java.lang.Number) 299);
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-23));
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withZone(dateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
//        org.joda.time.DateTime.Property property18 = dateTime16.year();
//        java.lang.String str19 = dateTimeFormatter12.print((org.joda.time.ReadableInstant) dateTime16);
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime16);
//        mutableDateTime0.setSecondOfDay(299);
//        mutableDateTime0.setWeekyear(572);
//        java.lang.String str25 = mutableDateTime0.toString();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:22 PM UTC" + "'", str8.equals("12:36:22 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12:36:22 PM UTC" + "'", str19.equals("12:36:22 PM UTC"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0572-02-20T00:04:59.366Z" + "'", str25.equals("0572-02-20T00:04:59.366Z"));
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendCenturyOfEra(935, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHourOfDay(20143367);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendTwoDigitYear(335, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone2);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        long long7 = delegatedDateTimeField4.add((long) 1, (long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.secondOfMinute();
        org.joda.time.DurationField durationField11 = gregorianChronology8.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        int[] intArray16 = gregorianChronology8.get((org.joda.time.ReadablePartial) localTime14, (long) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.secondOfMinute();
        org.joda.time.DurationField durationField20 = gregorianChronology17.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        int[] intArray25 = gregorianChronology17.get((org.joda.time.ReadablePartial) localTime23, (long) '#');
        int int26 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime14, intArray25);
        long long29 = delegatedDateTimeField4.addWrapField((-1L), 0);
        boolean boolean30 = delegatedDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36000001L + "'", long7 == 36000001L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        boolean boolean2 = property1.isLeap();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology4.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField8.getAsText(12, locale10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField8.getRangeDurationField();
        int int14 = delegatedDateTimeField8.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = delegatedDateTimeField8.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = delegatedDateTimeField21.getAsText(12, locale23);
        org.joda.time.DurationField durationField25 = delegatedDateTimeField21.getRangeDurationField();
        int int27 = delegatedDateTimeField21.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField21.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType28, 162);
        long long33 = delegatedDateTimeField16.add((long) 216, 0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "12" + "'", str11.equals("12"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "12" + "'", str24.equals("12"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 216L + "'", long33 == 216L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(570);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        boolean boolean26 = unsupportedDateTimeField25.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology27);
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.secondOfMinute();
//        org.joda.time.DurationField durationField30 = gregorianChronology27.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.LocalTime localTime33 = dateTime32.toLocalTime();
//        int[] intArray35 = gregorianChronology27.get((org.joda.time.ReadablePartial) localTime33, (long) '#');
//        try {
//            int int36 = unsupportedDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) localTime33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(localTime33);
//        org.junit.Assert.assertNotNull(intArray35);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.era();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology5.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
//        mutableDateTime1.addYears(24);
//        mutableDateTime1.addMonths((-24));
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        mutableDateTime1.setRounding(dateTimeField7);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime1.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime12 = property11.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.roundHalfEven();
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
//        int int17 = dateTime15.getMillisOfSecond();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology18);
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.clockhourOfHalfday();
//        org.joda.time.DateTime dateTime22 = dateTime15.toDateTime((org.joda.time.Chronology) gregorianChronology18);
//        mutableDateTime13.setMillis((org.joda.time.ReadableInstant) dateTime22);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(localTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 991 + "'", int17 == 991);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-1));
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime9.toMutableDateTime(dateTimeZone10);
//        mutableDateTime11.setSecondOfMinute(7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
//        org.joda.time.ReadableDuration readableDuration17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.minus(readableDuration17);
//        int int19 = dateTime15.getDayOfMonth();
//        org.joda.time.DateTime dateTime21 = dateTime15.withYearOfEra(24);
//        mutableDateTime11.setDate((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        mutableDateTime11.setZoneRetainFields(dateTimeZone23);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(localTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendFractionOfDay(335, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendTwoDigitYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
//        org.joda.time.DateTime.Property property3 = dateTime1.year();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
//        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.DateTime.Property property10 = dateTime7.dayOfYear();
//        java.lang.String str11 = property10.getAsText();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(localTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "163" + "'", str11.equals("163"));
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendCenturyOfEra(935, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHourOfDay(20143367);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendFractionOfHour(390, 45357245);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        boolean boolean4 = property3.isLeap();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(10, 867, 227, 0, 20143365, 935, 390, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20143365 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfMonth();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        mutableDateTime1.add(readablePeriod4);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime6 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime7 = property3.roundFloorCopy();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfDay();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime1.minus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime1.withMillisOfSecond(299);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withEra(372);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 372 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = gJChronology1.withUTC();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 100, (org.joda.time.Chronology) gJChronology1, locale3, (java.lang.Integer) (-28378000));
        java.lang.Integer int6 = dateTimeParserBucket5.getPivotYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-28378000) + "'", int6.equals((-28378000)));
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        boolean boolean26 = unsupportedDateTimeField25.isSupported();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField25.getType();
//        try {
//            int int28 = unsupportedDateTimeField25.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
        org.joda.time.Instant instant3 = instant0.plus((long) 335);
        org.joda.time.Instant instant4 = instant3.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant3.plus(readableDuration5);
        org.joda.time.MutableDateTime mutableDateTime7 = instant6.toMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime1.add(readableDuration3, 20143);
//        int int6 = mutableDateTime1.getDayOfYear();
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 163 + "'", int6 == 163);
//    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone2);
//        int int5 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime7 = dateTime4.plusWeeks(2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendWeekyear(1, (-1));
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTimeZoneName(strMap12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendMonthOfYearShortText();
//        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((long) (short) 1);
//        mutableDateTime16.addSeconds((int) (short) -1);
//        mutableDateTime16.addYears(216);
//        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.dayOfYear();
//        boolean boolean23 = property22.isLeap();
//        org.joda.time.DateTimeField dateTimeField24 = property22.getField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology25.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = delegatedDateTimeField29.getAsText(12, locale31);
//        org.joda.time.DurationField durationField33 = delegatedDateTimeField29.getRangeDurationField();
//        int int35 = delegatedDateTimeField29.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField29.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType36);
//        int int38 = mutableDateTime16.get(dateTimeFieldType36);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder14.appendFixedSignedDecimal(dateTimeFieldType36, 3);
//        org.joda.time.DateTime.Property property41 = dateTime7.property(dateTimeFieldType36);
//        org.joda.time.DateTime dateTime43 = property41.addToCopy((long) 591);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(strMap12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "12" + "'", str32.equals("12"));
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 12 + "'", int35 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 11 + "'", int38 == 11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime43);
//    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.DurationField durationField26 = unsupportedDateTimeField25.getLeapDurationField();
//        try {
//            java.lang.String str28 = unsupportedDateTimeField25.getAsText((long) 26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNull(durationField26);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-210817339200000L), (long) 12621);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210817339187379L) + "'", long2 == (-210817339187379L));
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime5 = property3.add((int) '#');
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
//        long long12 = offsetDateTimeField9.add((long) 282, 0L);
//        boolean boolean14 = offsetDateTimeField9.isLeap((long) (short) -1);
//        mutableDateTime5.setRounding((org.joda.time.DateTimeField) offsetDateTimeField9);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime5.dayOfMonth();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        org.joda.time.DateTime.Property property20 = dateTime18.year();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime18.minus(readablePeriod21);
//        org.joda.time.DateTime dateTime24 = dateTime18.plusHours(0);
//        org.joda.time.DateTime.Property property25 = dateTime18.minuteOfDay();
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime18.minus(readableDuration26);
//        int int28 = property16.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.MutableDateTime mutableDateTime30 = property16.addWrapField(0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 282L + "'", long12 == 282L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12621 + "'", int28 == 12621);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZone(dateTimeZone3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology5);
//        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
//        org.joda.time.DateTime.Property property8 = dateTime6.year();
//        java.lang.String str9 = dateTimeFormatter2.print((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime11 = dateTime6.withDayOfYear((int) '4');
//        mutableDateTime1.setMillis((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) (short) 1);
//        mutableDateTime14.addYears(24);
//        mutableDateTime14.addMonths((-24));
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 1);
//        mutableDateTime14.setRounding(dateTimeField20);
//        mutableDateTime1.setTime((org.joda.time.ReadableInstant) mutableDateTime14);
//        int int27 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime14, "ISOChronology[UTC]", (-335));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(localTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "12:36:25 PM UTC" + "'", str9.equals("12:36:25 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-335) + "'", int27 == (-335));
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) julianChronology0);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime2.add(readableDuration4, 5);
        mutableDateTime2.setMillisOfDay(297);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.DurationField durationField26 = unsupportedDateTimeField25.getLeapDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (byte) 1);
//        long long34 = offsetDateTimeField31.add((long) 282, 0L);
//        org.joda.time.DurationField durationField35 = offsetDateTimeField31.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField31.getType();
//        int int39 = offsetDateTimeField31.getDifference((long) (-28378000), (long) 19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology40);
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField43);
//        int int45 = delegatedDateTimeField44.getMaximumValue();
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology46);
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology46.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField49);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = delegatedDateTimeField50.getAsText(12, locale52);
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology54);
//        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.secondOfMinute();
//        org.joda.time.DurationField durationField57 = gregorianChronology54.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology58);
//        org.joda.time.LocalTime localTime60 = dateTime59.toLocalTime();
//        int[] intArray62 = gregorianChronology54.get((org.joda.time.ReadablePartial) localTime60, (long) '#');
//        int[] intArray63 = null;
//        int int64 = delegatedDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) localTime60, intArray63);
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology65);
//        org.joda.time.LocalTime localTime67 = dateTime66.toLocalTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology68);
//        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology68.secondOfMinute();
//        org.joda.time.DurationField durationField71 = gregorianChronology68.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology72);
//        org.joda.time.LocalTime localTime74 = dateTime73.toLocalTime();
//        int[] intArray76 = gregorianChronology68.get((org.joda.time.ReadablePartial) localTime74, (long) '#');
//        int int77 = delegatedDateTimeField50.getMinimumValue((org.joda.time.ReadablePartial) localTime67, intArray76);
//        int int78 = delegatedDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) localTime67);
//        int int79 = offsetDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localTime67);
//        org.joda.time.ReadableInstant readableInstant80 = null;
//        org.joda.time.Chronology chronology81 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant80);
//        org.joda.time.MutableDateTime mutableDateTime82 = new org.joda.time.MutableDateTime(chronology81);
//        org.joda.time.MutableDateTime.Property property83 = mutableDateTime82.era();
//        org.joda.time.chrono.GregorianChronology gregorianChronology86 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime87 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology86);
//        org.joda.time.DateTimeField dateTimeField88 = gregorianChronology86.secondOfMinute();
//        org.joda.time.DurationField durationField89 = gregorianChronology86.minutes();
//        org.joda.time.DurationField durationField90 = gregorianChronology86.months();
//        java.util.Locale locale91 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket92 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology86, locale91);
//        org.joda.time.Chronology chronology93 = dateTimeParserBucket92.getChronology();
//        java.util.Locale locale94 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket95 = new org.joda.time.format.DateTimeParserBucket((long) 881, chronology93, locale94);
//        java.util.Locale locale96 = dateTimeParserBucket95.getLocale();
//        int int97 = property83.getMaximumTextLength(locale96);
//        int int98 = offsetDateTimeField31.getMaximumShortTextLength(locale96);
//        try {
//            java.lang.String str99 = unsupportedDateTimeField25.getAsShortText((long) (byte) -1, locale96);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNull(durationField26);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 282L + "'", long34 == 282L);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "12" + "'", str53.equals("12"));
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(gregorianChronology58);
//        org.junit.Assert.assertNotNull(localTime60);
//        org.junit.Assert.assertNotNull(intArray62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 12 + "'", int64 == 12);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(localTime67);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(gregorianChronology72);
//        org.junit.Assert.assertNotNull(localTime74);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 292278994 + "'", int79 == 292278994);
//        org.junit.Assert.assertNotNull(chronology81);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertNotNull(gregorianChronology86);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//        org.junit.Assert.assertNotNull(durationField89);
//        org.junit.Assert.assertNotNull(durationField90);
//        org.junit.Assert.assertNotNull(chronology93);
//        org.junit.Assert.assertNotNull(locale96);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 2 + "'", int97 == 2);
//        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 9 + "'", int98 == 9);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("12:36:10 PM UTC", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"12:36:10 PM UTC/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone4.isLocalDateTimeGap(localDateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(2000, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTimeZoneOffset("4:42:58 PM -07:52:58", "12:36:12 PM UTC", false, (int) (byte) 100, 216);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime1.addYears(24);
        mutableDateTime1.addMonths((-24));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 1);
        mutableDateTime1.setRounding(dateTimeField7);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime1.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsText(12, locale18);
        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getRangeDurationField();
        int int22 = delegatedDateTimeField16.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime1.property(dateTimeFieldType23);
        org.joda.time.MutableDateTime mutableDateTime25 = property24.roundFloor();
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12" + "'", str19.equals("12"));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        java.lang.String str4 = property3.getName();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsText(locale5);
        org.joda.time.DurationField durationField7 = property3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "year" + "'", str4.equals("year"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime1.addYears(24);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.secondOfMinute();
        int int5 = mutableDateTime1.getYear();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1994 + "'", int5 == 1994);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.year();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.minus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusHours(0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime7.withZone(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.minus(readablePeriod15);
        org.joda.time.DateTime.Property property17 = dateTime12.dayOfWeek();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime20 = dateTime10.minusHours(689);
        try {
            org.joda.time.DateTime dateTime22 = dateTime20.withDayOfWeek(9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(localTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        try {
//            int int27 = unsupportedDateTimeField25.getMinimumValue(readablePartial26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865118400000L) + "'", long1 == (-210865118400000L));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology0.minutes();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        int[] intArray8 = gregorianChronology0.get((org.joda.time.ReadablePartial) localTime6, (long) '#');
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField10 = gregorianChronology0.years();
        long long13 = durationField10.subtract((long) (-1), (long) 689);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-21742646400001L) + "'", long13 == (-21742646400001L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        boolean boolean11 = dateTimeFormatterBuilder10.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendWeekOfWeekyear(689);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = delegatedDateTimeField4.getAsText(12, locale6);
//        org.joda.time.DurationField durationField8 = delegatedDateTimeField4.getRangeDurationField();
//        int int10 = delegatedDateTimeField4.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField4.getType();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 'a', locale15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone13);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        java.lang.String str19 = buddhistChronology17.toString();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        long long23 = buddhistChronology17.add(readablePeriod20, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField24 = buddhistChronology17.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField24);
//        org.joda.time.Instant instant27 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime28 = instant27.toMutableDateTimeISO();
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime30 = property29.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime32 = property29.add((long) 20143);
//        org.joda.time.Interval interval33 = property29.toInterval();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology36);
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology36.secondOfMinute();
//        org.joda.time.DurationField durationField39 = gregorianChronology36.minutes();
//        org.joda.time.DurationField durationField40 = gregorianChronology36.months();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology36, locale41);
//        org.joda.time.Chronology chronology43 = dateTimeParserBucket42.getChronology();
//        java.util.Locale locale44 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket45 = new org.joda.time.format.DateTimeParserBucket((long) 881, chronology43, locale44);
//        java.util.Locale locale46 = dateTimeParserBucket45.getLocale();
//        java.lang.String str47 = property29.getAsShortText(locale46);
//        try {
//            java.lang.String str48 = unsupportedDateTimeField25.getAsText(20140, locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: clockhourOfHalfday field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12" + "'", str7.equals("12"));
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "BuddhistChronology[UTC]" + "'", str19.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField25);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertNotNull(interval33);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(locale46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Jan" + "'", str47.equals("Jan"));
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology1, locale6);
        org.joda.time.Chronology chronology8 = dateTimeParserBucket7.getChronology();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            dateTimeParserBucket7.saveField(dateTimeFieldType9, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getShortName((long) 'a', locale3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.centuryOfEra();
//        java.lang.String str7 = buddhistChronology5.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.secondOfMinute();
//        boolean boolean11 = buddhistChronology5.equals((java.lang.Object) dateTimeField10);
//        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology5.hourOfHalfday();
//        org.joda.time.DurationField durationField13 = buddhistChronology5.weeks();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[UTC]" + "'", str7.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfMonth();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
//        org.joda.time.DurationField durationField6 = gregorianChronology3.minutes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.LocalTime localTime9 = dateTime8.toLocalTime();
//        int[] intArray11 = gregorianChronology3.get((org.joda.time.ReadablePartial) localTime9, (long) '#');
//        long long13 = iSOChronology1.set((org.joda.time.ReadablePartial) localTime9, 335L);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(localTime9);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 45388779L + "'", long13 == 45388779L);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((-7351100L), (org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField4 = buddhistChronology1.months();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("12");
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfDay();
        org.joda.time.Interval interval4 = property3.toInterval();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(interval4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfMinute();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        long long7 = durationField4.subtract((-181504797841603L), (long) 1994);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-181504797843597L) + "'", long7 == (-181504797843597L));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.secondOfMinute();
//        org.joda.time.DurationField durationField4 = gregorianChronology1.minutes();
//        org.joda.time.DurationField durationField5 = gregorianChronology1.months();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology1.weekyear();
//        java.util.Locale locale8 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket(0L, (org.joda.time.Chronology) gregorianChronology1, locale8, (java.lang.Integer) 0, (-28378000));
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology12);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.clockhourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField16.getAsText(12, locale18);
//        org.joda.time.DurationField durationField20 = delegatedDateTimeField16.getRangeDurationField();
//        int int22 = delegatedDateTimeField16.getMaximumValue((long) 37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField16.getType();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getShortName((long) 'a', locale27);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology29.centuryOfEra();
//        java.lang.String str31 = buddhistChronology29.toString();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        long long35 = buddhistChronology29.add(readablePeriod32, (long) (short) 10, (int) (short) 1);
//        org.joda.time.DurationField durationField36 = buddhistChronology29.hours();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField36);
//        dateTimeParserBucket11.saveField(dateTimeFieldType23, 20140);
//        java.lang.Object obj40 = dateTimeParserBucket11.saveState();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12" + "'", str19.equals("12"));
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
//        org.junit.Assert.assertNotNull(buddhistChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BuddhistChronology[UTC]" + "'", str31.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
//        org.junit.Assert.assertNotNull(obj40);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-23), 'a', 20143367, (-335), 570, true, 570);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder8.toDateTimeZone("4:42:58 PM -07:52:58", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder8.setFixedSavings("5:35:45 AM PDT", (int) (byte) 100);
        java.io.OutputStream outputStream16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("Coordinated Universal Time", outputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekShortText();
        dateTimeFormatterBuilder11.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalTime localTime2 = dateTime1.toLocalTime();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(localTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendFractionOfDay(335, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendTwoDigitYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        boolean boolean1 = dateTimeFormatter0.isPrinter();
//        java.lang.String str3 = dateTimeFormatter0.print(0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "12:00:00 AM UTC" + "'", str3.equals("12:00:00 AM UTC"));
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendHourOfDay(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap15 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTimeZoneName(strMap15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTwoDigitYear(24, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatterBuilder24.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder10.appendOptional(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(strMap15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 1);
        long long6 = offsetDateTimeField3.add((long) 282, 0L);
        int int9 = offsetDateTimeField3.getDifference((-991526399701L), 0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.secondOfMinute();
        org.joda.time.DurationField durationField17 = gregorianChronology14.minutes();
        org.joda.time.DurationField durationField18 = gregorianChronology14.months();
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) gregorianChronology14, locale19);
        org.joda.time.Chronology chronology21 = dateTimeParserBucket20.getChronology();
        java.util.Locale locale22 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) 881, chronology21, locale22);
        java.util.Locale locale24 = dateTimeParserBucket23.getLocale();
        try {
            long long25 = offsetDateTimeField3.set(573452956800335L, "4:43:01 PM -07:52:58", locale24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"4:43:01 PM -07:52:58\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 282L + "'", long6 == 282L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-31) + "'", int9 == (-31));
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(locale24);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZone(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.joda.time.DateTime.Property property7 = dateTime5.year();
//        java.lang.String str8 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime10 = dateTime5.withDayOfYear((int) '4');
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withZone(dateTimeZone13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology15);
//        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
//        org.joda.time.DateTime.Property property18 = dateTime16.year();
//        java.lang.String str19 = dateTimeFormatter12.print((org.joda.time.ReadableInstant) dateTime16);
//        mutableDateTime0.setTime((org.joda.time.ReadableInstant) dateTime16);
//        mutableDateTime0.setSecondOfDay(299);
//        mutableDateTime0.setMinuteOfDay(0);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(localTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "12:36:29 PM UTC" + "'", str8.equals("12:36:29 PM UTC"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(localTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12:36:29 PM UTC" + "'", str19.equals("12:36:29 PM UTC"));
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        int int6 = cachedDateTimeZone3.getStandardOffset((long) 216);
        java.lang.String str8 = cachedDateTimeZone3.getNameKey((long) 100);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        int int11 = cachedDateTimeZone3.getOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendCenturyOfEra(935, (int) (short) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder7.appendTimeZoneOffset("12:00:00 AM UTC", "", false, 20, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear(1, (-1));
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMillisOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond((int) 'a', (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendClockhourOfDay(372);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder7.appendHourOfHalfday(372);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendMonthOfYear(390);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(strMap4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 182);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (short) 1);
        mutableDateTime1.addSeconds((int) (short) -1);
        mutableDateTime1.addYears(216);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.dayOfYear();
        boolean boolean8 = property7.isLeap();
        org.joda.time.DateTimeField dateTimeField9 = property7.getField();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField14.getAsText(12, locale16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField14.getRangeDurationField();
        int int20 = delegatedDateTimeField14.getMaximumValue((long) 37);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField14.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType21);
        int int23 = mutableDateTime1.get(dateTimeFieldType21);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) (byte) 1);
        long long30 = offsetDateTimeField27.set((long) 756, 90695);
        try {
            mutableDateTime1.setRounding((org.joda.time.DateTimeField) offsetDateTimeField27, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 365");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "12" + "'", str17.equals("12"));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2799859046400756L + "'", long30 == 2799859046400756L);
    }
}

