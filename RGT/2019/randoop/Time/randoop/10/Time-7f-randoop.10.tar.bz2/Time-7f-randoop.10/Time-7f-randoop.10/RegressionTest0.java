import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 1, 0, (int) (byte) 1, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(10L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime0.withField(dateTimeFieldType5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        try {
            mutableDateTime5.setDayOfMonth(52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.yearOfCentury();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.millisOfSecond();
        try {
            mutableDateTime2.setRounding(dateTimeField6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            long long6 = buddhistChronology2.set(readablePartial4, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = dateTime4.toString("Property[year]", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test019");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getWeekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        java.util.Date date7 = dateTime6.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime6.toMutableDateTime((org.joda.time.Chronology) buddhistChronology8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) 10, 0, (int) (short) -1, (int) (short) -1, 10, (int) (short) 100, (org.joda.time.Chronology) buddhistChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField2 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 'a');
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, 0, 1970, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.millisOfSecond();
        try {
            mutableDateTime2.setRounding(dateTimeField6, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean10 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(10L, chronology12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.yearOfCentury();
        java.util.Locale locale15 = null;
        int int16 = property14.getMaximumTextLength(locale15);
        int int17 = property14.getLeapAmount();
        org.joda.time.DurationField durationField18 = property14.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property14.getFieldType();
        try {
            mutableDateTime2.set(dateTimeFieldType19, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 60097L + "'", long9 == 60097L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        mutableDateTime2.addMinutes(0);
        try {
            mutableDateTime2.setMillisOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        try {
            java.lang.String str5 = mutableDateTime3.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withTime((int) 'a', (int) (short) -1, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 1560342881341L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.Chronology chronology8 = null;
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) property3, chronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes(10);
        try {
            org.joda.time.DateTime dateTime8 = dateTime2.withDayOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            long long2 = dateTimeFormatter0.parseMillis("69");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"69\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("69");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType8 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList10 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList10, dateTimeFieldTypeArray9);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList10, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No valid format for fields: [yearOfCentury]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) (short) 1, 2, (int) (short) 10, (-1), 1969, (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.withMillis(52L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = instant2.toDateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds(0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType8 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList10 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList10, dateTimeFieldTypeArray9);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList10, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No valid format for fields: [yearOfCentury]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(57660097, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 57660097");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        mutableDateTime2.addMinutes(0);
        try {
            mutableDateTime2.setMinuteOfHour(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = buddhistChronology10.weeks();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.millisOfSecond();
        long long17 = buddhistChronology12.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology12.clockhourOfDay();
        org.joda.time.DurationField durationField20 = buddhistChronology12.days();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField21 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField11, durationField20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 200L + "'", long17 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = buddhistChronology2.weeks();
        try {
            org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) buddhistChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        int int6 = property3.getLeapAmount();
//        org.joda.time.DurationField durationField7 = property3.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
//        long long9 = property3.remainder();
//        long long10 = property3.remainder();
//        int int11 = property3.getMaximumValue();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31507200010L + "'", long9 == 31507200010L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31507200010L + "'", long10 == 31507200010L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
//        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
//        org.joda.time.DateTime dateTime10 = dateTime6.plus((long) (byte) -1);
//        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12L + "'", long11 == 12L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DurationField durationField9 = buddhistChronology0.days();
        org.joda.time.DateTimeField dateTimeField10 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("1969-12-31T16:00:00.010-08:00", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 1969-12-31T16:00:00.010-08:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.millisOfSecond();
        long long13 = buddhistChronology8.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.monthOfYear();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology8, dateTimeField16, (int) (byte) 1);
        try {
            mutableDateTime2.setRounding((org.joda.time.DateTimeField) skipDateTimeField18, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 200L + "'", long13 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) '4', 0, (-1), 0, (int) 'a', (int) '#', dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronology();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("69", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"69\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) 3);
        java.util.Locale locale10 = null;
        try {
            org.joda.time.DateTime dateTime11 = property5.setCopy("1969-12-31T16:00:00.100-08:00", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16:00:00.100-08:00\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        try {
            long long16 = buddhistChronology0.getDateTimeMillis((long) 0, 2, (int) (byte) -1, 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            int int4 = dateTime0.compareTo(readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) mutableDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) (short) 10, dateTimeZone1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DurationField durationField9 = buddhistChronology0.days();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = null;
        try {
            buddhistChronology0.validate(readablePartial10, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType8 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList10 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList10, dateTimeFieldTypeArray9);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList10, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No valid format for fields: [yearOfCentury]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        try {
            long long13 = skipDateTimeField10.set((long) 3, "69");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes(1);
        boolean boolean8 = dateTime4.isBefore((long) 1);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.centuryOfEra();
        mutableDateTime11.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        mutableDateTime11.setZoneRetainFields(dateTimeZone15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime11.dayOfYear();
        try {
            org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, (org.joda.time.ReadableDateTime) dateTime4, (org.joda.time.ReadableDateTime) mutableDateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withTime((int) (byte) -1, (int) (short) 0, 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis(0);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.weeks();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.addMinutes(99);
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime2.copy();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.withYear(1970);
        boolean boolean11 = buddhistChronology7.equals((java.lang.Object) 1970);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = buddhistChronology7.add(readablePeriod12, (long) (short) 0, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology17 = buddhistChronology7.withZone(dateTimeZone16);
        try {
            org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((int) (short) 10, (int) (short) -1, 52, (int) (short) -1, (int) '#', 57660097, (int) (short) 1, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(1970);
        boolean boolean4 = buddhistChronology0.equals((java.lang.Object) 1970);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = buddhistChronology0.add(readablePeriod5, (long) (short) 0, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = buddhistChronology0.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = dateTime4.toString("GregorianChronology[America/Los_Angeles]", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        try {
            org.joda.time.DateTime dateTime8 = property5.setCopy(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 100, 1560342881506L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 156034288150600");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 1969, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969-12-31T16:00:00.010-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969-12-31T16:00:00.010-08:00' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant4 = null;
        try {
            int int5 = property3.compareTo(readableInstant4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        int int8 = property7.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        try {
            mutableDateTime5.setDayOfMonth((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.DateTimeField dateTimeField3 = null;
//        mutableDateTime2.setRounding(dateTimeField3);
//        int int5 = mutableDateTime2.getWeekyear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean10 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        mutableDateTime2.setYear(0);
//        int int13 = mutableDateTime2.getMonthOfYear();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 60097L + "'", long9 == 60097L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.withYear(1970);
        boolean boolean12 = buddhistChronology8.equals((java.lang.Object) 1970);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = buddhistChronology8.add(readablePeriod13, (long) (short) 0, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology18 = buddhistChronology8.withZone(dateTimeZone17);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(0L, dateTimeZone17);
        try {
            org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((int) (byte) 1, 3, (int) (byte) 0, (int) ' ', 86399, 0, (int) ' ', dateTimeZone17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.withMillis(52L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = instant2.toDateTime((org.joda.time.Chronology) buddhistChronology3);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withCenturyOfEra((-5));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = buddhistChronology1.weeks();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str5 = dateTimeZone3.getName(0L);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) durationField2, dateTimeZone3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.LimitChronology$LimitDurationField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 961, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-961L) + "'", long2 == (-961L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(100, (int) (byte) -1, (int) (byte) 0, 0, (int) ' ', 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        java.util.Locale locale17 = null;
        try {
            long long18 = skipDateTimeField10.set((long) '#', "100", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(24, 99, (int) (short) 10, (int) '4', (int) '#', (int) '4', 0, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYearOfCentury(2, 961);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendTimeZoneOffset("1969-12-31T16:00:00.010-08:00", "Property[year]", true, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendPattern("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        org.joda.time.MutableDateTime mutableDateTime6 = property3.roundHalfEven();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType15, 86399, 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendClockhourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(10L, chronology3);
        org.joda.time.DateTimeField dateTimeField5 = null;
        mutableDateTime4.setRounding(dateTimeField5);
        int int7 = mutableDateTime4.getWeekyear();
        mutableDateTime4.setTime((long) (short) 0);
        mutableDateTime4.addMinutes(99);
        int int14 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "1969-12-31T16:00:00.100-08:00", 3);
        try {
            org.joda.time.LocalTime localTime16 = dateTimeFormatter0.parseLocalTime("86399");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"86399\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-5) + "'", int14 == (-5));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("1969-12-31T16:00:00.100-08:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.100-08:00\" is malformed at \"69-12-31T16:00:00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        mutableDateTime2.addSeconds((int) (short) -1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (byte) -1, (int) 'a', (-1), 2, (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType8, (int) '4', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for yearOfCentury must be in the range [0,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        int int6 = property3.getLeapAmount();
//        org.joda.time.DurationField durationField7 = property3.getDurationField();
//        long long10 = durationField7.subtract((long) 'a', 0L);
//        long long13 = durationField7.subtract((long) '#', 961);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-30326227621965L) + "'", long13 == (-30326227621965L));
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekOfWeekyear();
        mutableDateTime2.setWeekyear(2019);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 1, (int) (byte) 0, (int) (byte) -1, 100, 0, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1001L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 991L + "'", long2 == 991L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.millisOfSecond();
        long long22 = buddhistChronology17.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.monthOfYear();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology23.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology17, dateTimeField25, (int) (byte) 1);
        long long29 = skipDateTimeField27.roundHalfCeiling(0L);
        long long31 = skipDateTimeField27.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray37 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int38 = skipDateTimeField27.getMaximumValue(readablePartial32, intArray37);
        try {
            int[] intArray40 = skipDateTimeField10.addWrapPartial(readablePartial15, 10, intArray37, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 200L + "'", long22 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 59 + "'", int38 == 59);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            long long4 = buddhistChronology0.set(readablePartial2, 9223372017129600096L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        boolean boolean21 = skipDateTimeField10.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.yearOfCentury();
        try {
            mutableDateTime2.setSecondOfMinute(961);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 961 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = iSOChronology6.months();
        org.joda.time.DurationField durationField8 = iSOChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.minuteOfHour();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((-5), (int) (byte) 10, (int) ' ', 12, 2, (int) (byte) 100, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        mutableDateTime3.addYears(99);
        try {
            mutableDateTime3.setDateTime((-1), 1, 99, 2019, 961, 366, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        long long11 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            int int13 = property8.compareTo(readablePartial12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-719523L) + "'", long11 == (-719523L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DurationField durationField9 = buddhistChronology0.days();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfSecond();
        long long16 = buddhistChronology11.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology11.clockhourOfDay();
        org.joda.time.DurationField durationField19 = buddhistChronology11.days();
        org.joda.time.DurationField durationField20 = buddhistChronology11.weekyears();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology11.millisOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField21);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        long long4 = durationField1.subtract((long) (-1), (long) (byte) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-263001600001L) + "'", long4 == (-263001600001L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(0);
        java.util.Date date7 = dateTime4.toDate();
        org.joda.time.DateTime dateTime9 = dateTime4.minus((long) 57660097);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(10L, chronology11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.yearOfCentury();
        java.util.Locale locale14 = null;
        int int15 = property13.getMaximumTextLength(locale14);
        int int16 = property13.getLeapAmount();
        org.joda.time.DurationField durationField17 = property13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime23 = dateTime4.withField(dateTimeFieldType18, (int) '4');
        int int24 = dateTime4.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.ReadablePartial readablePartial3 = null;
        int[] intArray4 = new int[] {};
        try {
            iSOChronology0.validate(readablePartial3, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 52L, (java.lang.Number) 1035L, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1969-12-31T16:00:00.010-08:00", 1969, (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for 1969-12-31T16:00:00.010-08:00 must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DurationFieldType durationFieldType3 = null;
//        try {
//            mutableDateTime2.add(durationFieldType3, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plus(1560342881341L);
        try {
            org.joda.time.DateTime dateTime11 = dateTime2.withTime((int) '#', 100, 59, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 60097L + "'", long3 == 60097L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(0);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.joda.time.DurationField durationField10 = property9.getRangeDurationField();
        long long13 = durationField10.subtract((long) 19, (long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-604799981L) + "'", long13 == (-604799981L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology0.hourOfDay();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean10 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime8);
        mutableDateTime2.setYear(0);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime2.dayOfMonth();
        int int14 = property13.getMinimumValue();
        java.util.Locale locale16 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime17 = property13.set("", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 60097L + "'", long9 == 60097L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("-5");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"-5/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.addMinutes(99);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.centuryOfEra();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime4.minusMinutes(1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Instant instant6 = dateTime4.toInstant();
        int int7 = dateTime4.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        java.lang.String str6 = property5.toString();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = property5.getAsText(locale7);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        int int6 = property3.getLeapAmount();
//        org.joda.time.DurationField durationField7 = property3.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
//        long long9 = property3.remainder();
//        long long10 = property3.remainder();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property3.getAsText(locale11);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31507200010L + "'", long9 == 31507200010L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 31507200010L + "'", long10 == 31507200010L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "69" + "'", str12.equals("69"));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(19, 0, (int) (short) 10, 59);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-5), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47 + "'", int2 == 47);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) 'a', (int) (byte) -1, (int) ' ', 99, (int) '4', 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        try {
            long long11 = buddhistChronology0.getDateTimeMillis(47, 10, 1969, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(57660097, 4, 3, (-1), (int) (byte) 10, 366, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str1 = gregorianChronology0.toString();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(1);
//        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime4.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime9 = dateTime4.toLocalDateTime();
//        int[] intArray11 = new int[] { (short) 1 };
//        try {
//            gregorianChronology0.validate((org.joda.time.ReadablePartial) localDateTime9, intArray11);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 60097L + "'", long5 == 60097L);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertNotNull(intArray11);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1969-12-31T16:01:00.097-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean10 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime8);
        mutableDateTime2.setYear(0);
        try {
            mutableDateTime2.setMinuteOfHour(57660097);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57660097 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 60097L + "'", long9 == 60097L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1001L, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59059L + "'", long2 == 59059L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        try {
            long long22 = skipDateTimeField10.set(0L, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for secondOfMinute must be in the range [-1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 99, "Coordinated Universal Time");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType8, (int) (short) 0, 366, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [366,2019]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(100, 1969, (int) (short) 0, 0, (int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(0L);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        boolean boolean5 = dateTimeZone0.isStandardOffset((long) 24);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (-1.0d), (java.lang.Number) 2, (java.lang.Number) (byte) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value -1.0 for hi! must be in the range [2,100]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value -1.0 for hi! must be in the range [2,100]"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.copy();
        try {
            mutableDateTime6.setTime((int) 'a', (int) (short) 100, 19, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        java.lang.String str8 = property3.toString();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = property3.set("GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[yearOfCentury]" + "'", str8.equals("Property[yearOfCentury]"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.millisOfSecond();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        mutableDateTime5.add(readablePeriod8);
        mutableDateTime5.setHourOfDay((int) (byte) 0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        long long23 = skipDateTimeField10.add((long) '#', (int) (byte) 1);
        boolean boolean24 = skipDateTimeField10.isLenient();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1035L + "'", long23 == 1035L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(2019, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendDayOfWeek(86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendMillisOfDay(86399);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getRoundingMode();
        try {
            mutableDateTime2.setDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        int int7 = property5.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(0);
        java.util.Date date7 = dateTime4.toDate();
        org.joda.time.DateTime dateTime9 = dateTime4.minus((long) 57660097);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(10L, chronology11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.yearOfCentury();
        java.util.Locale locale14 = null;
        int int15 = property13.getMaximumTextLength(locale14);
        int int16 = property13.getLeapAmount();
        org.joda.time.DurationField durationField17 = property13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime23 = dateTime4.withField(dateTimeFieldType18, (int) '4');
        org.joda.time.DurationField durationField24 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField25 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTime23);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withCenturyOfEra((int) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.tTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withDefaultYear(3);
//        java.lang.String str10 = dateTime6.toString(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "T16:00:00.097-08:00" + "'", str10.equals("T16:00:00.097-08:00"));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (short) -1, (java.lang.Number) 200L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        mutableDateTime2.addSeconds((int) (short) 100);
        boolean boolean8 = mutableDateTime2.isEqual((long) '#');
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("Property[year]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: Property[year]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        java.util.Locale locale6 = null;
        int int7 = property3.getMaximumTextLength(locale6);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-30326227621965L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2089589.4951161458d + "'", double1 == 2089589.4951161458d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plus(1560342881341L);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, 57660097);
        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((-1));
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 60097L + "'", long3 == 60097L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeParser1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder$Composite");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
//        mutableDateTime2.setWeekyear(0);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
//        int int9 = property8.getMaximumValueOverall();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.getMutableDateTime();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfSecond();
//        long long16 = buddhistChronology11.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology11);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology11.clockhourOfDay();
//        org.joda.time.DurationField durationField19 = buddhistChronology11.days();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology11.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology11.weekyear();
//        org.joda.time.DateTime dateTime22 = mutableDateTime10.toDateTime((org.joda.time.Chronology) buddhistChronology11);
//        int int23 = dateTime22.getMinuteOfDay();
//        int int24 = dateTime22.getEra();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 366 + "'", int9 == 366);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1432 + "'", int23 == 1432);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYearOfCentury(2, 961);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendLiteral(' ');
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.append(dateTimePrinter9, dateTimeParser11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMillisOfDay(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(1970);
        boolean boolean4 = buddhistChronology0.equals((java.lang.Object) 1970);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = buddhistChronology0.add(readablePeriod5, (long) (short) 0, (int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 2);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(3);
        try {
            long long4 = dateTimeFormatter2.parseMillis("1969-12-31T00:00:01.010-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T00:00:01.010-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.copy();
        mutableDateTime2.setWeekyear(100);
        try {
            mutableDateTime2.setDate(86399, 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(10L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.yearOfCentury();
        java.util.Locale locale6 = null;
        int int7 = property5.getMaximumTextLength(locale6);
        int int8 = property5.getLeapAmount();
        org.joda.time.DurationField durationField9 = property5.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property5.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder1.appendText(dateTimeFieldType10);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType10, 19, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (short) -1, (java.lang.Number) 200L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(19);
        java.lang.Appendable appendable3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes(1);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime10 = dateTime6.plusHours(1969);
        org.joda.time.LocalDateTime localDateTime11 = dateTime6.toLocalDateTime();
        try {
            dateTimeFormatter2.printTo(appendable3, (org.joda.time.ReadablePartial) localDateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 60097L + "'", long7 == 60097L);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDateTime11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfMonth((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        boolean boolean6 = dateTimeFormatter5.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str9 = dateTimeZone7.getName(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter5.withZone(dateTimeZone7);
//        long long13 = dateTimeZone7.convertLocalToUTC((long) '4', true);
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(0, 0, (int) (short) 100, 2, (int) '#', dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordinated Universal Time" + "'", str9.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        try {
            mutableDateTime5.setMonthOfYear((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.addYears((int) (short) -1);
        org.joda.time.DateTimeField dateTimeField6 = null;
        mutableDateTime2.setRounding(dateTimeField6, 2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("Property[dayOfWeek]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfWeek]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        long long17 = skipDateTimeField10.addWrapField(1L, 1);
        try {
            long long20 = skipDateTimeField10.set(0L, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for secondOfMinute must be in the range [-1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1001L + "'", long17 == 1001L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (-604799981L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        mutableDateTime3.addYears(99);
        try {
            java.lang.String str7 = mutableDateTime3.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        mutableDateTime7.setRounding(dateTimeField8);
//        int int10 = mutableDateTime7.getWeekyear();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        mutableDateTime7.setYear(0);
//        long long18 = mutableDateTime7.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
//        java.lang.String str20 = gJChronology19.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral("1969-12-31T16:00:00.010-08:00");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendHourOfDay(100);
//        boolean boolean28 = gJChronology19.equals((java.lang.Object) 100);
//        try {
//            long long33 = gJChronology19.getDateTimeMillis((int) 'a', 12, (int) (byte) -1, 99);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 60097L + "'", long14 == 60097L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135597221990L) + "'", long18 == (-62135597221990L));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]" + "'", str20.equals("GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DurationField durationField9 = buddhistChronology0.days();
        org.joda.time.DurationField durationField10 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.weekOfWeekyear();
        java.lang.String str12 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[UTC]" + "'", str12.equals("BuddhistChronology[UTC]"));
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
//        int int7 = dateTime6.getMonthOfYear();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        int int6 = dateTime4.getYearOfEra();
//        org.joda.time.DurationFieldType durationFieldType7 = null;
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime4.withFieldAdded(durationFieldType7, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        java.lang.String str6 = property5.toString();
//        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
//        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.secondOfDay();
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime7.withDurationAdded(1560342881506L, 19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 9223372017129600096 + 29646514748614");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372017129600096L + "'", long8 == 9223372017129600096L);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(2440588L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        org.joda.time.DateTime.Property property6 = dateTime0.millisOfDay();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        java.util.Locale locale8 = null;
        int int9 = property6.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.withYear(1970);
        boolean boolean11 = buddhistChronology7.equals((java.lang.Object) 1970);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = buddhistChronology7.add(readablePeriod12, (long) (short) 0, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology17 = buddhistChronology7.withZone(dateTimeZone16);
        mutableDateTime6.setZone(dateTimeZone16);
        try {
            mutableDateTime6.setMonthOfYear(99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(readablePartial13, 961, locale15);
        long long19 = skipDateTimeField10.getDifferenceAsLong(2440588L, (long) (-5));
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime22 = dateTime20.plusMinutes(1);
        org.joda.time.DateTime dateTime24 = dateTime22.plusMinutes(52);
        org.joda.time.DateTime.Property property25 = dateTime24.dayOfWeek();
        java.lang.String str26 = property25.toString();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis(86399);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime31 = dateTime29.plusMinutes(1);
        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime.Property property33 = dateTime31.secondOfMinute();
        org.joda.time.DateTime dateTime35 = dateTime31.plusHours(1969);
        org.joda.time.LocalDateTime localDateTime36 = dateTime31.toLocalDateTime();
        boolean boolean37 = dateTimeZone28.isLocalDateTimeGap(localDateTime36);
        int int38 = property25.compareTo((org.joda.time.ReadablePartial) localDateTime36);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.millisOfSecond();
        long long45 = buddhistChronology40.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology46.monthOfYear();
        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField48, (int) (byte) 1);
        long long52 = skipDateTimeField50.roundHalfCeiling(0L);
        long long54 = skipDateTimeField50.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial55 = null;
        int[] intArray60 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int61 = skipDateTimeField50.getMaximumValue(readablePartial55, intArray60);
        java.util.Locale locale63 = null;
        try {
            int[] intArray64 = skipDateTimeField10.set((org.joda.time.ReadablePartial) localDateTime36, 2, intArray60, "961", locale63);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 961 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "961" + "'", str16.equals("961"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2440L + "'", long19 == 2440L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfWeek]" + "'", str26.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 60097L + "'", long32 == 60097L);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 200L + "'", long45 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 59 + "'", int61 == 59);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.withMillis(52L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime4 = instant2.toDateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withChronology(chronology5);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        try {
            long long6 = julianChronology1.getDateTimeMillis((int) '4', 0, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = iSOChronology0.add(readablePeriod3, (long) 0, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.DateTimeField dateTimeField3 = null;
//        mutableDateTime2.setRounding(dateTimeField3);
//        int int5 = mutableDateTime2.getWeekyear();
//        int int6 = mutableDateTime2.getYear();
//        java.lang.String str7 = mutableDateTime2.toString();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.monthOfYear();
//        mutableDateTime2.setSecondOfDay((int) (byte) 1);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(10L, chronology12);
//        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.centuryOfEra();
//        mutableDateTime13.setWeekyear(0);
//        org.joda.time.MutableDateTime mutableDateTime17 = mutableDateTime13.copy();
//        mutableDateTime2.setMillis((org.joda.time.ReadableInstant) mutableDateTime13);
//        mutableDateTime13.setSecondOfMinute(12);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str7.equals("1969-12-31T16:00:00.010-08:00"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-719523L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) (-1.0d), (java.lang.Number) 2, (java.lang.Number) (byte) 100);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value -1.0 for hi! must be in the range [2,100]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value -1.0 for hi! must be in the range [2,100]"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes(52);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusHours(1969);
        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds(0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 60097L + "'", long3 == 60097L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfYear(3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.millisOfSecond();
        long long13 = buddhistChronology8.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.monthOfYear();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology8, dateTimeField16, (int) (byte) 1);
        long long20 = skipDateTimeField18.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipDateTimeField18.getAsShortText(readablePartial21, 961, locale23);
        boolean boolean26 = skipDateTimeField18.isLeap((long) 1);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = skipDateTimeField18.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipDateTimeField18.getType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendFraction(dateTimeFieldType29, (int) (byte) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 200L + "'", long13 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "961" + "'", str24.equals("961"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(0);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = dateTime6.toString("1969-12-31T16:01:00.097-08:00", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) (-1.0d), (java.lang.Number) 86399);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(12, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(0);
        java.util.Date date7 = dateTime4.toDate();
        org.joda.time.DateTime dateTime9 = dateTime4.minus((long) 57660097);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(10L, chronology11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.yearOfCentury();
        java.util.Locale locale14 = null;
        int int15 = property13.getMaximumTextLength(locale14);
        int int16 = property13.getLeapAmount();
        org.joda.time.DurationField durationField17 = property13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime23 = dateTime4.withField(dateTimeFieldType18, (int) '4');
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[yearOfCentury]");
        java.lang.String str26 = illegalFieldValueException25.getIllegalStringValue();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[yearOfCentury]" + "'", str26.equals("Property[yearOfCentury]"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "69", "1969-12-31T16:00:00.010-08:00");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10, 0, 2019, 19, 99, 100, 47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(0);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime11 = property9.setCopy((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "961", "69");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "Property[yearOfCentury]", "4:00:00 PM");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "4:00:00 PM", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("4:00:00 PM");
        java.lang.String str2 = illegalInstantException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.joda.time.IllegalInstantException: 4:00:00 PM" + "'", str2.equals("org.joda.time.IllegalInstantException: 4:00:00 PM"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime27 = dateTime25.plusMinutes(1);
        org.joda.time.DateTime dateTime29 = dateTime25.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis(0);
        org.joda.time.DateTime dateTime33 = dateTime31.minus((-1L));
        org.joda.time.DateTime.Property property34 = dateTime33.centuryOfEra();
        java.util.Locale locale36 = null;
        org.joda.time.DateTime dateTime37 = property34.setCopy("86399", locale36);
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.millisOfSecond();
        long long45 = buddhistChronology40.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology46.monthOfYear();
        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField48, (int) (byte) 1);
        long long52 = skipDateTimeField50.roundHalfCeiling(0L);
        long long54 = skipDateTimeField50.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial55 = null;
        int[] intArray60 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int61 = skipDateTimeField50.getMaximumValue(readablePartial55, intArray60);
        java.util.Locale locale63 = null;
        try {
            int[] intArray64 = offsetDateTimeField21.set((org.joda.time.ReadablePartial) localDateTime38, (int) '#', intArray60, "org.joda.time.IllegalInstantException: 4:00:00 PM", locale63);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalInstantException: 4:00:00 PM\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 200L + "'", long45 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 59 + "'", int61 == 59);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.millisOfSecond();
        long long6 = buddhistChronology1.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology1.days();
        org.joda.time.DurationField durationField10 = buddhistChronology1.weekyears();
        org.joda.time.DurationField durationField11 = buddhistChronology1.days();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(200L, (org.joda.time.Chronology) buddhistChronology1, locale12, (java.lang.Integer) (-1), 2);
        java.lang.Integer int16 = dateTimeParserBucket15.getPivotYear();
        java.lang.Integer int17 = dateTimeParserBucket15.getPivotYear();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16.equals((-1)));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17.equals((-1)));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        mutableDateTime3.addYears(99);
        mutableDateTime3.addHours(961);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField10.getAsText(86399, locale18);
        long long21 = skipDateTimeField10.remainder((long) 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "86399" + "'", str19.equals("86399"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.monthOfYear();
        org.joda.time.DurationField durationField13 = buddhistChronology11.halfdays();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(10L, chronology15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.yearOfCentury();
        java.util.Locale locale18 = null;
        int int19 = property17.getMaximumTextLength(locale18);
        int int20 = property17.getLeapAmount();
        org.joda.time.DurationField durationField21 = property17.getDurationField();
        long long24 = durationField21.subtract((long) 'a', 0L);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField25 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType9, durationField13, durationField21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.DateTime dateTime2 = instant1.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        long long27 = offsetDateTimeField21.add((long) (short) -1, (-5));
        int int29 = offsetDateTimeField21.getMaximumValue(1560342881341L);
        int int31 = offsetDateTimeField21.get((-719523L));
        java.lang.String str32 = offsetDateTimeField21.toString();
        java.util.Locale locale33 = null;
        int int34 = offsetDateTimeField21.getMaximumTextLength(locale33);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5001L) + "'", long27 == (-5001L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1020 + "'", int29 == 1020);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 960 + "'", int31 == 960);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str32.equals("DateTimeField[secondOfMinute]"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(2019, (int) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.append(dateTimeFormatter9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No formatter supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        boolean boolean2 = instant0.isBefore((long) 1969);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant5 = instant0.withDurationAdded(readableDuration3, 1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = iSOChronology6.months();
        org.joda.time.DurationField durationField8 = iSOChronology6.seconds();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(961, 960, (-5), (int) '#', (int) (byte) 0, 960, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField10.getType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.millisOfSecond();
        long long6 = buddhistChronology1.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology1.yearOfCentury();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((-604799981L), (org.joda.time.Chronology) buddhistChronology1, locale9, (java.lang.Integer) 4);
        dateTimeParserBucket11.setOffset(0);
        org.joda.time.Chronology chronology14 = dateTimeParserBucket11.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("4:00:00 PM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 4:00:00 PM");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime5 = dateTime0.withMinuteOfHour((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime9 = dateTime0.withDate(31, 31, 47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.ReadableInstant readableInstant0 = null;
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        int int20 = skipDateTimeField10.getDifference(97L, (long) 57660097);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-57660) + "'", int20 == (-57660));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfDay(100);
        dateTimeFormatterBuilder3.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendFractionOfHour(0, 4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.DateTimeField dateTimeField3 = null;
//        mutableDateTime2.setRounding(dateTimeField3);
//        int int5 = mutableDateTime2.getWeekyear();
//        int int6 = mutableDateTime2.getYear();
//        java.lang.String str7 = mutableDateTime2.toString();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.set(1);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfWeek();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str7.equals("1969-12-31T16:00:00.010-08:00"));
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3, 1969);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            mutableDateTime2.add(durationFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.100-08:00\" is malformed at \"-12-31T16:00:00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((-1));
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(readablePartial13, 961, locale15);
        int int18 = skipDateTimeField10.get((long) 1970);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "961" + "'", str16.equals("961"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
//        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
//        org.joda.time.DateTime dateTime10 = dateTime6.plus((long) (byte) -1);
//        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        java.util.Locale locale12 = null;
//        int int13 = property5.getMaximumShortTextLength(locale12);
//        java.lang.String str14 = property5.getAsText();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12L + "'", long11 == 12L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "December" + "'", str14.equals("December"));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("97");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime2.plusHours(1969);
        org.joda.time.LocalDateTime localDateTime7 = dateTime2.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.minus(readableDuration8);
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = dateTime9.toString("JulianChronology[UTC]", locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 60097L + "'", long3 == 60097L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("December");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'December' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear((int) 'a', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(1970, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendTwoDigitYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTwoDigitYear(10, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis(86399);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime29 = dateTime27.plusMinutes(1);
        long long30 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime.Property property31 = dateTime29.secondOfMinute();
        org.joda.time.DateTime dateTime33 = dateTime29.plusHours(1969);
        org.joda.time.LocalDateTime localDateTime34 = dateTime29.toLocalDateTime();
        boolean boolean35 = dateTimeZone26.isLocalDateTimeGap(localDateTime34);
        int[] intArray39 = new int[] { 59, (-57660) };
        java.util.Locale locale41 = null;
        try {
            int[] intArray42 = offsetDateTimeField21.set((org.joda.time.ReadablePartial) localDateTime34, 19, intArray39, "", locale41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 60097L + "'", long30 == 60097L);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis(0);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withMonthOfYear(31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.withCenturyOfEra((int) '4');
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.plus(readablePeriod11);
        try {
            org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime5, (org.joda.time.ReadableDateTime) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("DateTimeField[secondOfMinute]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[secondOfMinute]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        mutableDateTime7.setRounding(dateTimeField8);
//        int int10 = mutableDateTime7.getWeekyear();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        mutableDateTime7.setYear(0);
//        long long18 = mutableDateTime7.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology19.getZone();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis(86399);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime25 = dateTime23.plusMinutes(1);
//        long long26 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.DateTime.Property property27 = dateTime25.secondOfMinute();
//        org.joda.time.DateTime dateTime29 = dateTime25.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime30 = dateTime25.toLocalDateTime();
//        boolean boolean31 = dateTimeZone22.isLocalDateTimeGap(localDateTime30);
//        int[] intArray34 = new int[] { 1020, 'a' };
//        try {
//            gJChronology19.validate((org.joda.time.ReadablePartial) localDateTime30, intArray34);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must not be larger than 12");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 60097L + "'", long14 == 60097L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135597221990L) + "'", long18 == (-62135597221990L));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 60097L + "'", long26 == 60097L);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10.0f, (java.lang.Number) (short) 100, (java.lang.Number) (-263001600001L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) '#', 0, (int) (short) -1, 5, 1952, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1952 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (short) -1, (java.lang.Number) 200L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(durationFieldType6);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        int int6 = property5.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 7 + "'", int6 == 7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay(366);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder6.toFormatter();
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.append(dateTimePrinter8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '4');
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        int int7 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.DateTimeFormat.mediumTime();
//        java.lang.String str9 = dateTime6.toString(dateTimeFormatter8);
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime6.withDate(57660097, 366, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4:00:00 PM" + "'", str9.equals("4:00:00 PM"));
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = iSOChronology7.months();
//        org.joda.time.DurationField durationField9 = iSOChronology7.seconds();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology11 = iSOChronology7.withZone(dateTimeZone10);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(10L, chronology13);
//        org.joda.time.DateTimeField dateTimeField15 = null;
//        mutableDateTime14.setRounding(dateTimeField15);
//        int int17 = mutableDateTime14.getWeekyear();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
//        long long21 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime20);
//        boolean boolean22 = mutableDateTime14.isAfter((org.joda.time.ReadableInstant) dateTime20);
//        mutableDateTime14.setYear(0);
//        long long25 = mutableDateTime14.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) mutableDateTime14);
//        java.lang.String str27 = gJChronology26.toString();
//        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology26.millisOfSecond();
//        try {
//            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(59, (int) ' ', 59, (-5), 99, 52, 1020, (org.joda.time.Chronology) gJChronology26);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -5 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 60052L + "'", long21 == 60052L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62135597221990L) + "'", long25 == (-62135597221990L));
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]" + "'", str27.equals("GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]"));
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        int int8 = property7.get();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1969-12-31T16:01:00.097-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1969-12-31T16:01:00.097-08:00' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.withYear(1970);
        boolean boolean11 = buddhistChronology7.equals((java.lang.Object) 1970);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = buddhistChronology7.add(readablePeriod12, (long) (short) 0, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology17 = buddhistChronology7.withZone(dateTimeZone16);
        mutableDateTime6.setZone(dateTimeZone16);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime6.monthOfYear();
        org.joda.time.ReadableDuration readableDuration20 = null;
        mutableDateTime6.add(readableDuration20, 100);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Instant instant6 = dateTime4.toInstant();
        long long7 = instant6.getMillis();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 51L + "'", long7 == 51L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0, (java.lang.Number) 1035L, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("org.joda.time.IllegalInstantException: 4:00:00 PM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: org.joda.time.IllegalInstantException: 4:00:00 PM");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        java.lang.String str6 = property5.toString();
//        int int7 = property5.get();
//        org.joda.time.DateTimeField dateTimeField8 = property5.getField();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfWeek]" + "'", str6.equals("Property[dayOfWeek]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 2513);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        java.lang.String str16 = skipDateTimeField10.getAsShortText(10L);
        org.joda.time.DurationField durationField17 = skipDateTimeField10.getLeapDurationField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.millisOfSecond();
        long long23 = buddhistChronology18.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.monthOfYear();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology24.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology18, dateTimeField26, (int) (byte) 1);
        long long30 = skipDateTimeField28.roundHalfCeiling(0L);
        long long32 = skipDateTimeField28.roundHalfEven(0L);
        int int34 = skipDateTimeField28.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField28.getAsShortText(readablePartial35, (-5), locale37);
        long long41 = skipDateTimeField28.add((long) '#', (int) (byte) 1);
        boolean boolean43 = skipDateTimeField28.isLeap((-263001600001L));
        java.util.Locale locale44 = null;
        int int45 = skipDateTimeField28.getMaximumShortTextLength(locale44);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime48 = dateTime46.plusMinutes(1);
        org.joda.time.DateTime dateTime50 = dateTime46.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime52 = dateTime50.minusMillis(0);
        java.util.Date date53 = dateTime50.toDate();
        org.joda.time.DateTime dateTime55 = dateTime50.minus((long) 57660097);
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.MutableDateTime mutableDateTime58 = new org.joda.time.MutableDateTime(10L, chronology57);
        org.joda.time.MutableDateTime.Property property59 = mutableDateTime58.yearOfCentury();
        java.util.Locale locale60 = null;
        int int61 = property59.getMaximumTextLength(locale60);
        int int62 = property59.getLeapAmount();
        org.joda.time.DurationField durationField63 = property59.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property59.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException67 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime69 = dateTime50.withField(dateTimeFieldType64, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, dateTimeFieldType64, 47, (int) (short) 1, 0);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField74 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 200L + "'", long23 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-5" + "'", str38.equals("-5"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1035L + "'", long41 == 1035L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(dateTime69);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        boolean boolean8 = dateTimeFormatter7.isOffsetParsed();
//        java.lang.String str9 = dateTime4.toString(dateTimeFormatter7);
//        org.joda.time.DateTime dateTime11 = dateTime4.minusYears((int) (short) -1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "12/31/69 4:00 PM" + "'", str9.equals("12/31/69 4:00 PM"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.withYear(1970);
//        boolean boolean10 = buddhistChronology6.equals((java.lang.Object) 1970);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        long long14 = buddhistChronology6.add(readablePeriod11, (long) (short) 0, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology16 = buddhistChronology6.withZone(dateTimeZone15);
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(0L, dateTimeZone15);
//        java.lang.String str19 = dateTimeZone15.getName((long) (-5));
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        try {
//            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((int) 'a', (int) 'a', 0, 4, 2019, dateTimeZone20);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordinated Universal Time" + "'", str19.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        boolean boolean5 = dateTime4.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(99);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        long long27 = offsetDateTimeField21.add((long) (short) -1, (-5));
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime30 = dateTime28.plusMinutes(1);
        org.joda.time.DateTime dateTime32 = dateTime30.plusMinutes(52);
        org.joda.time.DateTime.Property property33 = dateTime32.dayOfWeek();
        java.lang.String str34 = property33.toString();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis(86399);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime39 = dateTime37.plusMinutes(1);
        long long40 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime.Property property41 = dateTime39.secondOfMinute();
        org.joda.time.DateTime dateTime43 = dateTime39.plusHours(1969);
        org.joda.time.LocalDateTime localDateTime44 = dateTime39.toLocalDateTime();
        boolean boolean45 = dateTimeZone36.isLocalDateTimeGap(localDateTime44);
        int int46 = property33.compareTo((org.joda.time.ReadablePartial) localDateTime44);
        int[] intArray54 = new int[] { ' ', (short) 10, 31, 57600, 24, 57600 };
        try {
            int[] intArray56 = offsetDateTimeField21.addWrapField((org.joda.time.ReadablePartial) localDateTime44, 86399, intArray54, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 86399");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5001L) + "'", long27 == (-5001L));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Property[dayOfWeek]" + "'", str34.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 60052L + "'", long40 == 60052L);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDateTime44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray54);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        java.lang.String str6 = property5.toString();
//        int int7 = property5.getLeapAmount();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property5.getAsText(locale8);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfWeek]" + "'", str6.equals("Property[dayOfWeek]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wednesday" + "'", str9.equals("Wednesday"));
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean10 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean11 = mutableDateTime2.isBeforeNow();
        mutableDateTime2.addMinutes(4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 60052L + "'", long9 == 60052L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        long long23 = skipDateTimeField10.add((long) '#', (int) (byte) 1);
        boolean boolean25 = skipDateTimeField10.isLeap((-263001600001L));
        java.util.Locale locale26 = null;
        int int27 = skipDateTimeField10.getMaximumShortTextLength(locale26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime30 = dateTime28.plusMinutes(1);
        org.joda.time.DateTime dateTime32 = dateTime28.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime34 = dateTime32.minusMillis(0);
        java.util.Date date35 = dateTime32.toDate();
        org.joda.time.DateTime dateTime37 = dateTime32.minus((long) 57660097);
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime(10L, chronology39);
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime40.yearOfCentury();
        java.util.Locale locale42 = null;
        int int43 = property41.getMaximumTextLength(locale42);
        int int44 = property41.getLeapAmount();
        org.joda.time.DurationField durationField45 = property41.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property41.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime51 = dateTime32.withField(dateTimeFieldType46, (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType46, 47, (int) (short) 1, 0);
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime58 = dateTime56.plusMinutes(1);
        org.joda.time.DateTime dateTime60 = dateTime56.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime62 = dateTime60.minusMillis(0);
        org.joda.time.DateTime dateTime64 = dateTime62.minus((-1L));
        org.joda.time.DateTime.Property property65 = dateTime64.centuryOfEra();
        java.util.Locale locale67 = null;
        org.joda.time.DateTime dateTime68 = property65.setCopy("86399", locale67);
        org.joda.time.LocalDateTime localDateTime69 = dateTime68.toLocalDateTime();
        int int70 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDateTime69);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1035L + "'", long23 == 1035L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(localDateTime69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1969-12-31");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        long long11 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = property8.add((-1));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-719523L) + "'", long11 == (-719523L));
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        int int6 = property3.getLeapAmount();
//        org.joda.time.DurationField durationField7 = property3.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
//        java.util.Locale locale13 = null;
//        int int14 = property12.getMaximumTextLength(locale13);
//        int int15 = property12.getLeapAmount();
//        org.joda.time.DurationField durationField16 = property12.getDurationField();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.plusMinutes(1);
//        org.joda.time.DateTime dateTime21 = dateTime17.plus((long) (byte) -1);
//        org.joda.time.DateTime.Property property22 = dateTime21.year();
//        java.lang.String str23 = property22.toString();
//        org.joda.time.DateTime dateTime24 = property22.withMaximumValue();
//        org.joda.time.DateTime dateTime26 = property22.setCopy("86399");
//        org.joda.time.DurationField durationField27 = property22.getLeapDurationField();
//        long long30 = durationField27.subtract(0L, 86399);
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField31 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField16, durationField27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[year]" + "'", str23.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-7464874022000L) + "'", long30 == (-7464874022000L));
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.Chronology chronology2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
//        java.util.Locale locale5 = null;
//        int int6 = property4.getMaximumTextLength(locale5);
//        int int7 = property4.getLeapAmount();
//        org.joda.time.DurationField durationField8 = property4.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
//        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
//        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
//        java.util.Date date25 = dateTime22.toDate();
//        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
//        java.util.Locale locale32 = null;
//        int int33 = property31.getMaximumTextLength(locale32);
//        int int34 = property31.getLeapAmount();
//        org.joda.time.DurationField durationField35 = property31.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
//        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatterBuilder47.toFormatter();
//        java.lang.StringBuffer stringBuffer49 = null;
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.MutableDateTime mutableDateTime52 = new org.joda.time.MutableDateTime(10L, chronology51);
//        org.joda.time.DateTimeField dateTimeField53 = null;
//        mutableDateTime52.setRounding(dateTimeField53);
//        int int55 = mutableDateTime52.getWeekyear();
//        int int56 = mutableDateTime52.getYear();
//        java.lang.String str57 = mutableDateTime52.toString();
//        org.joda.time.MutableDateTime.Property property58 = mutableDateTime52.monthOfYear();
//        mutableDateTime52.setSecondOfDay((int) (byte) 1);
//        java.lang.String str61 = mutableDateTime52.toString();
//        try {
//            dateTimeFormatter48.printTo(stringBuffer49, (org.joda.time.ReadableInstant) mutableDateTime52);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1970 + "'", int55 == 1970);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1969 + "'", int56 == 1969);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1969-12-31T16:00:00.010-08:00" + "'", str57.equals("1969-12-31T16:00:00.010-08:00"));
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "1969-12-31T00:00:01.010-08:00" + "'", str61.equals("1969-12-31T00:00:01.010-08:00"));
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray20 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int21 = skipDateTimeField10.getMaximumValue(readablePartial15, intArray20);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = skipDateTimeField10.getMaximumValue(readablePartial22);
        org.joda.time.DurationField durationField24 = skipDateTimeField10.getDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 59 + "'", int23 == 59);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        long long24 = offsetDateTimeField21.add((-5001L), 52);
        int int27 = offsetDateTimeField21.getDifference(0L, 1L);
        boolean boolean29 = offsetDateTimeField21.isLeap((long) 1969);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 46999L + "'", long24 == 46999L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
//        mutableDateTime2.addMinutes(0);
//        int int6 = mutableDateTime2.getDayOfMonth();
//        try {
//            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) int6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        long long22 = zeroIsMaxDateTimeField19.roundHalfEven(100L);
        try {
            long long25 = zeroIsMaxDateTimeField19.set((long) 24, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [1,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.append(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.millisOfSecond();
        long long6 = buddhistChronology1.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology1.days();
        org.joda.time.DurationField durationField10 = buddhistChronology1.weekyears();
        org.joda.time.DurationField durationField11 = buddhistChronology1.days();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(200L, (org.joda.time.Chronology) buddhistChronology1, locale12, (java.lang.Integer) (-1), 2);
        dateTimeParserBucket15.setOffset(100);
        java.lang.Integer int18 = dateTimeParserBucket15.getPivotYear();
        org.joda.time.Chronology chronology19 = dateTimeParserBucket15.getChronology();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18.equals((-1)));
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.millisOfSecond();
        long long6 = buddhistChronology1.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology1.days();
        org.joda.time.DurationField durationField10 = buddhistChronology1.weekyears();
        org.joda.time.DurationField durationField11 = buddhistChronology1.days();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket(200L, (org.joda.time.Chronology) buddhistChronology1, locale12, (java.lang.Integer) (-1), 2);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField3 = iSOChronology2.months();
//        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology6 = iSOChronology2.withZone(dateTimeZone5);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(10L, chronology8);
//        org.joda.time.DateTimeField dateTimeField10 = null;
//        mutableDateTime9.setRounding(dateTimeField10);
//        int int12 = mutableDateTime9.getWeekyear();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(1);
//        long long16 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
//        boolean boolean17 = mutableDateTime9.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        mutableDateTime9.setYear(0);
//        long long20 = mutableDateTime9.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
//        java.lang.String str22 = gJChronology21.toString();
//        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendLiteral("1969-12-31T16:00:00.010-08:00");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendDayOfWeekText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendHourOfDay(100);
//        boolean boolean30 = gJChronology21.equals((java.lang.Object) 100);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology21);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560342912531L + "'", long16 == 1560342912531L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62135597221990L) + "'", long20 == (-62135597221990L));
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]" + "'", str22.equals("GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]"));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes(10);
//        java.lang.String str7 = dateTime2.toString();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime8.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths((int) (short) -1);
//        boolean boolean15 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime.Property property16 = dateTime2.millisOfDay();
//        java.util.Locale locale18 = null;
//        try {
//            org.joda.time.DateTime dateTime19 = property16.setCopy("", locale18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019-06-12T05:35:12.722-07:00" + "'", str7.equals("2019-06-12T05:35:12.722-07:00"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(property16);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.weekOfWeekyear();
        try {
            java.lang.String str7 = dateTime4.toString("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: oo");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        int int5 = dateTime2.getMinuteOfDay();
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime2.withYearOfCentury(1952);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1952 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560342912974L + "'", long3 == 1560342912974L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 335 + "'", int5 == 335);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 1432);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print(10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.withCenturyOfEra((int) '4');
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withPeriodAdded(readablePeriod7, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, (int) (short) 100);
        org.joda.time.Instant instant5 = instant4.toInstant();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866500800000L) + "'", long1 == (-210866500800000L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = iSOChronology2.months();
        org.joda.time.DurationField durationField4 = iSOChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = iSOChronology2.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology7 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology2.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(10L, chronology12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.yearOfCentury();
        java.util.Locale locale15 = null;
        int int16 = property14.getMaximumTextLength(locale15);
        int int17 = property14.getLeapAmount();
        org.joda.time.DurationField durationField18 = property14.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property14.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder10.appendText(dateTimeFieldType19);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField21 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType19);
        org.joda.time.DurationField durationField22 = zeroIsMaxDateTimeField21.getLeapDurationField();
        long long24 = zeroIsMaxDateTimeField21.roundHalfEven(100L);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime27 = dateTime25.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.plus(readablePeriod28);
        org.joda.time.DateTime.Property property30 = dateTime25.weekyear();
        org.joda.time.DateTime dateTime32 = property30.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime34 = property30.addToCopy(0);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime37 = dateTime35.withYear(1970);
        org.joda.time.DateTime dateTime39 = dateTime37.plusMinutes(52);
        org.joda.time.DateTime dateTime41 = dateTime39.minusDays((int) ' ');
        int int42 = property30.compareTo((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.LocalDateTime localDateTime43 = dateTime39.toLocalDateTime();
        int[] intArray46 = new int[] { (short) -1, 57660097 };
        int int47 = zeroIsMaxDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDateTime43, intArray46);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (short) -1, (java.lang.Number) 200L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        mutableDateTime7.setRounding(dateTimeField8);
//        int int10 = mutableDateTime7.getWeekyear();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        mutableDateTime7.setYear(0);
//        long long18 = mutableDateTime7.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
//        try {
//            long long27 = gJChronology19.getDateTimeMillis(24, (int) (byte) -1, 12, 12, 31, (int) (byte) 0, 31);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560342913552L + "'", long14 == 1560342913552L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135597221990L) + "'", long18 == (-62135597221990L));
//        org.junit.Assert.assertNotNull(gJChronology19);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("December");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"December\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        int int6 = property3.getLeapAmount();
//        org.joda.time.DurationField durationField7 = property3.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
//        long long9 = property3.remainder();
//        java.lang.String str10 = property3.getAsString();
//        org.joda.time.MutableDateTime mutableDateTime12 = property3.add((int) '4');
//        try {
//            mutableDateTime12.setDayOfMonth((int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31507200010L + "'", long9 == 31507200010L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69" + "'", str10.equals("69"));
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime dateTime6 = dateTime4.plusMillis(960);
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withCenturyOfEra((-57660));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57660 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(0);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTime dateTime11 = property9.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
//        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
//        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
//        long long14 = skipDateTimeField10.roundHalfEven(0L);
//        int int16 = skipDateTimeField10.get((long) (short) 10);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.plusMinutes(1);
//        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.secondOfMinute();
//        org.joda.time.DateTime dateTime23 = dateTime19.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime24 = dateTime19.toLocalDateTime();
//        int int25 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDateTime24);
//        try {
//            int int28 = skipDateTimeField10.getDifference((-30326227621965L), (long) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -30326227622");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560342913939L + "'", long20 == 1560342913939L);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        int int4 = property3.getLeapAmount();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.year();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        int int9 = property7.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
//        java.util.Locale locale4 = null;
//        int int5 = property3.getMaximumTextLength(locale4);
//        int int6 = property3.getLeapAmount();
//        org.joda.time.DurationField durationField7 = property3.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property3.getAsText(locale9);
//        java.util.Locale locale12 = null;
//        try {
//            org.joda.time.MutableDateTime mutableDateTime13 = property3.set("16:00", locale12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"16:00\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69" + "'", str10.equals("69"));
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(0);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField10 = property9.getField();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        org.joda.time.ReadableDuration readableDuration9 = null;
        mutableDateTime2.add(readableDuration9, (-5));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[America/Los_Angeles]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        mutableDateTime7.setRounding(dateTimeField8);
//        int int10 = mutableDateTime7.getWeekyear();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        mutableDateTime7.setYear(0);
//        long long18 = mutableDateTime7.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
//        java.lang.String str20 = gJChronology19.toString();
//        org.joda.time.Chronology chronology21 = gJChronology19.withUTC();
//        org.joda.time.Instant instant22 = gJChronology19.getGregorianCutover();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560342914515L + "'", long14 == 1560342914515L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135597221990L) + "'", long18 == (-62135597221990L));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]" + "'", str20.equals("GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(instant22);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
//        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
//        int int8 = dateTime6.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 334 + "'", int8 == 334);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        java.util.Locale locale11 = null;
        int int12 = skipDateTimeField10.getMaximumShortTextLength(locale11);
        int int14 = skipDateTimeField10.getMaximumValue((long) 960);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 100);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.millisOfSecond();
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime dateTime6 = dateTime4.withHourOfDay(0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("JulianChronology[UTC]", (int) (byte) 0, 57600, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for JulianChronology[UTC] must be in the range [57600,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.yearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = iSOChronology5.months();
        org.joda.time.DurationField durationField7 = iSOChronology5.seconds();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology9 = iSOChronology5.withZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology5.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(10L, chronology15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.yearOfCentury();
        java.util.Locale locale18 = null;
        int int19 = property17.getMaximumTextLength(locale18);
        int int20 = property17.getLeapAmount();
        org.joda.time.DurationField durationField21 = property17.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder13.appendText(dateTimeFieldType22);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType22);
        try {
            mutableDateTime2.set(dateTimeFieldType22, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(0);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        int int10 = dateTime8.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(8, 0, 2, 19, (int) (byte) 0, 366);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        java.util.Locale locale21 = null;
        int int22 = skipDateTimeField10.getMaximumShortTextLength(locale21);
        long long24 = skipDateTimeField10.remainder(97L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        mutableDateTime7.setRounding(dateTimeField8);
//        int int10 = mutableDateTime7.getWeekyear();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        mutableDateTime7.setYear(0);
//        long long18 = mutableDateTime7.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.DateTimeZone dateTimeZone20 = mutableDateTime7.getZone();
//        boolean boolean22 = mutableDateTime7.isAfter(51L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560342915854L + "'", long14 == 1560342915854L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135597221990L) + "'", long18 == (-62135597221990L));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTimeISO();
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        mutableDateTime7.setRounding(dateTimeField8);
//        int int10 = mutableDateTime7.getWeekyear();
//        mutableDateTime7.setTime((long) (short) 0);
//        mutableDateTime7.setMinuteOfHour((int) (byte) 10);
//        mutableDateTime7.setSecondOfMinute(52);
//        mutableDateTime7.addWeeks(52);
//        boolean boolean19 = dateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560342915917L + "'", long3 == 1560342915917L);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 366);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500004236d + "'", double1 == 2440587.500004236d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Instant instant6 = dateTime4.toInstant();
        org.joda.time.DateTime dateTime7 = instant6.toDateTime();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.withYear(1970);
//        boolean boolean5 = buddhistChronology1.equals((java.lang.Object) 1970);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        long long9 = buddhistChronology1.add(readablePeriod6, (long) (short) 0, (int) (byte) 10);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology11 = buddhistChronology1.withZone(dateTimeZone10);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(0L, dateTimeZone10);
//        java.lang.String str14 = dateTimeZone10.getName((long) (-5));
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordinated Universal Time" + "'", str14.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) (short) 100, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfEra();
        try {
            mutableDateTime3.setDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        try {
            long long10 = iSOChronology0.getDateTimeMillis((-1L), (int) (byte) -1, 57600, (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 57660097, (-7464874022000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7464931682097L + "'", long2 == 7464931682097L);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        java.lang.String str6 = property5.toString();
//        int int7 = property5.get();
//        try {
//            org.joda.time.DateTime dateTime9 = property5.setCopy((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfWeek]" + "'", str6.equals("Property[dayOfWeek]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.plus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime9 = property7.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime11 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime14 = dateTime12.withYear(1970);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMinutes(52);
        org.joda.time.DateTime dateTime18 = dateTime16.minusDays((int) ' ');
        int int19 = property7.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.LocalDateTime localDateTime20 = dateTime16.toLocalDateTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.millisOfSecond();
        long long26 = buddhistChronology21.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.monthOfYear();
        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology27.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology21, dateTimeField29, (int) (byte) 1);
        long long33 = skipDateTimeField31.roundHalfCeiling(0L);
        long long35 = skipDateTimeField31.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int[] intArray41 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int42 = skipDateTimeField31.getMaximumValue(readablePartial36, intArray41);
        try {
            buddhistChronology0.validate((org.joda.time.ReadablePartial) localDateTime20, intArray41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57660097 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 200L + "'", long26 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 59 + "'", int42 == 59);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.withYear(1970);
//        boolean boolean6 = buddhistChronology0.equals((java.lang.Object) 1970);
//        org.joda.time.DurationField durationField7 = buddhistChronology0.hours();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(0L);
//        org.joda.time.DateTime dateTime16 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology17.getZone();
//        try {
//            long long26 = zonedChronology17.getDateTimeMillis(4, (int) (byte) 1, 5, (int) (byte) 100, 334, (int) (short) 10, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 100);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.millisOfDay();
        int int3 = property2.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DurationField durationField7 = buddhistChronology0.years();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = buddhistChronology0.get(readablePeriod8, (-100L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        try {
            mutableDateTime2.setWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DurationField durationField9 = buddhistChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        int int9 = property8.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.getMutableDateTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfSecond();
        long long16 = buddhistChronology11.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology11.clockhourOfDay();
        org.joda.time.DurationField durationField19 = buddhistChronology11.days();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology11.weekyear();
        org.joda.time.DateTime dateTime22 = mutableDateTime10.toDateTime((org.joda.time.Chronology) buddhistChronology11);
        mutableDateTime10.setSecondOfDay(24);
        try {
            mutableDateTime10.setTime((int) (short) 0, 1969, (-57660), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 366 + "'", int9 == 366);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = buddhistChronology0.millis();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = iSOChronology4.months();
        org.joda.time.DurationField durationField6 = iSOChronology4.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology8 = iSOChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField9, 52);
        java.util.Locale locale14 = null;
        try {
            long long15 = skipDateTimeField11.set(0L, "hi!", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMinutes(52);
        boolean boolean7 = dateTime6.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
//        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
//        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
//        long long14 = skipDateTimeField10.roundHalfEven(0L);
//        int int16 = skipDateTimeField10.get((long) (short) 10);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime19 = dateTime17.plusMinutes(1);
//        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.secondOfMinute();
//        org.joda.time.DateTime dateTime23 = dateTime19.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime24 = dateTime19.toLocalDateTime();
//        int int25 = skipDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDateTime24);
//        java.util.Locale locale26 = null;
//        int int27 = skipDateTimeField10.getMaximumShortTextLength(locale26);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560342917903L + "'", long20 == 1560342917903L);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime.Property property4 = dateTime0.secondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime0.hourOfDay();
        try {
            org.joda.time.DateTime dateTime7 = property5.setCopy(961);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 961 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        int int9 = property8.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.getMutableDateTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfSecond();
        long long16 = buddhistChronology11.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology11.clockhourOfDay();
        org.joda.time.DurationField durationField19 = buddhistChronology11.days();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology11.weekyear();
        org.joda.time.DateTime dateTime22 = mutableDateTime10.toDateTime((org.joda.time.Chronology) buddhistChronology11);
        mutableDateTime10.setSecondOfDay(24);
        mutableDateTime10.addMinutes(8);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 366 + "'", int9 == 366);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.getMutableDateTime();
        try {
            mutableDateTime5.setDate(961, (int) (byte) 1, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "70" + "'", str4.equals("70"));
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.millisOfSecond();
        int int8 = mutableDateTime5.getMonthOfYear();
        mutableDateTime5.setWeekyear(59);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.DateTimeField dateTimeField3 = null;
//        mutableDateTime2.setRounding(dateTimeField3);
//        int int5 = mutableDateTime2.getWeekyear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean10 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean11 = mutableDateTime2.isBeforeNow();
//        mutableDateTime2.setMillisOfDay(7);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560342919200L + "'", long9 == 1560342919200L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(readablePartial13, 961, locale15);
        boolean boolean18 = skipDateTimeField10.isLeap((long) 1);
        java.util.Locale locale19 = null;
        int int20 = skipDateTimeField10.getMaximumShortTextLength(locale19);
        boolean boolean22 = skipDateTimeField10.isLeap((long) 961);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "961" + "'", str16.equals("961"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology7.secondOfMinute();
        org.joda.time.DurationField durationField10 = buddhistChronology7.millis();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = iSOChronology11.months();
        org.joda.time.DurationField durationField13 = iSOChronology11.seconds();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology15 = iSOChronology11.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology7, dateTimeField16, 52);
        try {
            org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(1, 4, 2513, (int) (byte) 1, 86399, 3, 366, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2513 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 57660097);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.yearOfCentury();
        mutableDateTime2.setYear((int) '#');
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        long long27 = offsetDateTimeField21.add((long) (short) -1, (-5));
        boolean boolean28 = offsetDateTimeField21.isLenient();
        org.joda.time.DurationField durationField29 = offsetDateTimeField21.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5001L) + "'", long27 == (-5001L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(durationField29);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(0);
        java.util.Date date7 = dateTime4.toDate();
        org.joda.time.DateTime dateTime9 = dateTime4.minus((long) 57660097);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(10L, chronology11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.yearOfCentury();
        java.util.Locale locale14 = null;
        int int15 = property13.getMaximumTextLength(locale14);
        int int16 = property13.getLeapAmount();
        org.joda.time.DurationField durationField17 = property13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime23 = dateTime4.withField(dateTimeFieldType18, (int) '4');
        org.joda.time.DateTime dateTime25 = dateTime23.plusHours(99);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime28 = dateTime26.plusMinutes(1);
        org.joda.time.DateTime dateTime30 = dateTime28.plusMinutes(52);
        org.joda.time.DateTime.Property property31 = dateTime28.weekOfWeekyear();
        org.joda.time.DateTime dateTime32 = property31.withMaximumValue();
        org.joda.time.DateTime dateTime34 = dateTime32.minusMillis(0);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.YearMonthDay yearMonthDay36 = dateTime34.toYearMonthDay();
        org.joda.time.DateTime dateTime37 = dateTime23.withFields((org.joda.time.ReadablePartial) yearMonthDay36);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(yearMonthDay36);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.millisOfSecond();
        boolean boolean9 = mutableDateTime5.isEqual(0L);
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime5.add(readableDuration10, 52);
        mutableDateTime5.addDays((int) '#');
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime5.monthOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        mutableDateTime2.addSeconds((int) (short) 100);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
        try {
            mutableDateTime2.setDayOfYear((-5));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -5 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.shortDateTime();
        boolean boolean8 = dateTimeFormatter7.isOffsetParsed();
        java.lang.String str9 = dateTime4.toString(dateTimeFormatter7);
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter7.withLocale(locale10);
        java.lang.StringBuffer stringBuffer12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime13.plus(readablePeriod16);
        org.joda.time.DateTime.Property property18 = dateTime13.weekyear();
        org.joda.time.DateTime dateTime20 = property18.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime22 = property18.addToCopy(0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime25 = dateTime23.withYear(1970);
        org.joda.time.DateTime dateTime27 = dateTime25.plusMinutes(52);
        org.joda.time.DateTime dateTime29 = dateTime27.minusDays((int) ' ');
        int int30 = property18.compareTo((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.LocalDateTime localDateTime31 = dateTime27.toLocalDateTime();
        try {
            dateTimeFormatter11.printTo(stringBuffer12, (org.joda.time.ReadablePartial) localDateTime31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1/1/70 4:01 PM" + "'", str9.equals("1/1/70 4:01 PM"));
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(localDateTime31);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(10L, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 69L + "'", long2 == 69L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime7.plusDays(52);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223371985651260096L + "'", long8 == 9223371985651260096L);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        mutableDateTime2.addSeconds((int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.toMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.withYear(1970);
        boolean boolean5 = buddhistChronology1.equals((java.lang.Object) 1970);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = buddhistChronology1.add(readablePeriod6, (long) (short) 0, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology11 = buddhistChronology1.withZone(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(0L, dateTimeZone10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.Instant instant14 = dateTime13.toInstant();
        int int15 = dateTime13.getMillisOfSecond();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.millisOfSecond();
        int int8 = mutableDateTime5.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.minuteOfHour();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = property9.set("BuddhistChronology[UTC]", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"BuddhistChronology[UTC]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.withYear(1970);
//        boolean boolean6 = buddhistChronology0.equals((java.lang.Object) 1970);
//        org.joda.time.DurationField durationField7 = buddhistChronology0.hours();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(0L);
//        org.joda.time.DateTime dateTime16 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone13);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField19 = iSOChronology18.months();
//        org.joda.time.DurationField durationField20 = iSOChronology18.seconds();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology22 = iSOChronology18.withZone(dateTimeZone21);
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime(10L, chronology24);
//        org.joda.time.DateTimeField dateTimeField26 = null;
//        mutableDateTime25.setRounding(dateTimeField26);
//        int int28 = mutableDateTime25.getWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime31 = dateTime29.plusMinutes(1);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime31);
//        boolean boolean33 = mutableDateTime25.isAfter((org.joda.time.ReadableInstant) dateTime31);
//        mutableDateTime25.setYear(0);
//        long long36 = mutableDateTime25.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) mutableDateTime25);
//        org.joda.time.Chronology chronology38 = zonedChronology17.withZone(dateTimeZone21);
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = iSOChronology39.months();
//        org.joda.time.DurationField durationField41 = iSOChronology39.seconds();
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology43 = iSOChronology39.withZone(dateTimeZone42);
//        org.joda.time.Chronology chronology44 = iSOChronology39.withUTC();
//        org.joda.time.DateTimeField dateTimeField45 = iSOChronology39.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField46 = iSOChronology39.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.Chronology chronology49 = null;
//        org.joda.time.MutableDateTime mutableDateTime50 = new org.joda.time.MutableDateTime(10L, chronology49);
//        org.joda.time.MutableDateTime.Property property51 = mutableDateTime50.yearOfCentury();
//        java.util.Locale locale52 = null;
//        int int53 = property51.getMaximumTextLength(locale52);
//        int int54 = property51.getLeapAmount();
//        org.joda.time.DurationField durationField55 = property51.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = property51.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder47.appendText(dateTimeFieldType56);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField58 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField46, dateTimeFieldType56);
//        org.joda.time.DurationField durationField59 = zeroIsMaxDateTimeField58.getLeapDurationField();
//        long long61 = zeroIsMaxDateTimeField58.roundHalfEven(100L);
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime64 = dateTime62.plusMinutes(1);
//        org.joda.time.ReadablePeriod readablePeriod65 = null;
//        org.joda.time.DateTime dateTime66 = dateTime62.plus(readablePeriod65);
//        org.joda.time.DateTime.Property property67 = dateTime62.weekyear();
//        org.joda.time.DateTime dateTime69 = property67.addWrapFieldToCopy(1969);
//        org.joda.time.DateTime dateTime71 = property67.addToCopy(0);
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime74 = dateTime72.withYear(1970);
//        org.joda.time.DateTime dateTime76 = dateTime74.plusMinutes(52);
//        org.joda.time.DateTime dateTime78 = dateTime76.minusDays((int) ' ');
//        int int79 = property67.compareTo((org.joda.time.ReadableInstant) dateTime76);
//        org.joda.time.LocalDateTime localDateTime80 = dateTime76.toLocalDateTime();
//        int[] intArray83 = new int[] { (short) -1, 57660097 };
//        int int84 = zeroIsMaxDateTimeField58.getMaximumValue((org.joda.time.ReadablePartial) localDateTime80, intArray83);
//        boolean boolean85 = dateTimeZone21.isLocalDateTimeGap(localDateTime80);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1970 + "'", int28 == 1970);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 57720097L + "'", long32 == 57720097L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62167219199990L) + "'", long36 == (-62167219199990L));
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2 + "'", int53 == 2);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeFieldType56);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
//        org.junit.Assert.assertNull(durationField59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//        org.junit.Assert.assertNotNull(localDateTime80);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 2 + "'", int84 == 2);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime(dateTimeZone5);
//        org.joda.time.DateTime.Property property9 = dateTime2.dayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) '#');
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 2513);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatterBuilder47.toFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder47.appendYearOfCentury((-5), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime4.monthOfYear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
        org.joda.time.DateTime dateTime10 = dateTime6.plus((long) (byte) -1);
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = property5.setCopy(1);
        try {
            org.joda.time.DateTime dateTime15 = property5.setCopy("8639969-12-31T16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"8639969-12-31T16:00:00-08:00\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(0L);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        try {
//            long long8 = gJChronology3.getDateTimeMillis(86399, 1432, 1969, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1432 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(gJChronology3);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        try {
            long long24 = offsetDateTimeField21.set(57660000L, "T16:00:00.097-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T16:00:00.097-08:00\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(1);
//        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str8 = dateTimeZone6.getName(0L);
//        org.joda.time.DateTime dateTime9 = dateTime5.withZoneRetainFields(dateTimeZone6);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) iSOChronology10, locale11, (java.lang.Integer) 8, (int) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DurationField durationField17 = julianChronology16.millis();
//        java.lang.String str18 = julianChronology16.toString();
//        boolean boolean19 = dateTimeParserBucket14.restoreState((java.lang.Object) str18);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(julianChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JulianChronology[UTC]" + "'", str18.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        long long22 = zeroIsMaxDateTimeField19.roundHalfEven(100L);
        long long24 = zeroIsMaxDateTimeField19.remainder((long) 5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfHalfday((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        int int9 = property8.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.getMutableDateTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfSecond();
        long long16 = buddhistChronology11.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology11.clockhourOfDay();
        org.joda.time.DurationField durationField19 = buddhistChronology11.days();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology11.weekyear();
        org.joda.time.DateTime dateTime22 = mutableDateTime10.toDateTime((org.joda.time.Chronology) buddhistChronology11);
        mutableDateTime10.setSecondOfDay(24);
        mutableDateTime10.setDayOfYear(4);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 366 + "'", int9 == 366);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DurationField durationField9 = buddhistChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology0.millisOfDay();
        org.joda.time.DurationField durationField11 = buddhistChronology0.millis();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-7464874022000L));
        try {
            mutableDateTime1.setDayOfWeek(47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 47 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("961", "1969-12-31T16:00:00.100-08:00");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str4.equals("1969-12-31T16:00:00.100-08:00"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DurationField durationField9 = buddhistChronology0.weekyears();
        org.joda.time.DurationField durationField10 = buddhistChronology0.days();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("4:00:00 PM", (int) (byte) -1, 47, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for 4:00:00 PM must be in the range [47,960]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendYearOfCentury(2, 961);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(99);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendYear(12, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendMinuteOfHour(2513);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYear((int) (byte) 10, 961);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        java.lang.String str17 = skipDateTimeField10.getName();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        org.joda.time.DateTime dateTime26 = dateTime24.minus((-1L));
        org.joda.time.DateTime.Property property27 = dateTime26.centuryOfEra();
        java.util.Locale locale29 = null;
        org.joda.time.DateTime dateTime30 = property27.setCopy("100", locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property27.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType31, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 60097L, "19");
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "secondOfMinute" + "'", str17.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 99, "Coordinated Universal Time");
        java.lang.String str12 = illegalFieldValueException11.getFieldName();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "yearOfCentury" + "'", str12.equals("yearOfCentury"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.millisOfSecond();
        int int8 = mutableDateTime5.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.minuteOfHour();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime5.weekOfWeekyear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        long long22 = zeroIsMaxDateTimeField19.roundHalfEven(100L);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime25 = dateTime23.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime23.plus(readablePeriod26);
        org.joda.time.DateTime.Property property28 = dateTime23.weekyear();
        org.joda.time.DateTime dateTime30 = property28.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime32 = property28.addToCopy(0);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime35 = dateTime33.withYear(1970);
        org.joda.time.DateTime dateTime37 = dateTime35.plusMinutes(52);
        org.joda.time.DateTime dateTime39 = dateTime37.minusDays((int) ' ');
        int int40 = property28.compareTo((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.LocalDateTime localDateTime41 = dateTime37.toLocalDateTime();
        int[] intArray44 = new int[] { (short) -1, 57660097 };
        int int45 = zeroIsMaxDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) localDateTime41, intArray44);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime48 = dateTime46.plusMinutes(1);
        org.joda.time.DateTime dateTime50 = dateTime48.plusMinutes(52);
        org.joda.time.DateTime.Property property51 = dateTime50.dayOfWeek();
        java.lang.String str52 = property51.toString();
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis(86399);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime57 = dateTime55.plusMinutes(1);
        long long58 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime57);
        org.joda.time.DateTime.Property property59 = dateTime57.secondOfMinute();
        org.joda.time.DateTime dateTime61 = dateTime57.plusHours(1969);
        org.joda.time.LocalDateTime localDateTime62 = dateTime57.toLocalDateTime();
        boolean boolean63 = dateTimeZone54.isLocalDateTimeGap(localDateTime62);
        int int64 = property51.compareTo((org.joda.time.ReadablePartial) localDateTime62);
        int[] intArray65 = null;
        int int66 = zeroIsMaxDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) localDateTime62, intArray65);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(localDateTime41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Property[dayOfWeek]" + "'", str52.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 57720097L + "'", long58 == 57720097L);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDateTime62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2 + "'", int66 == 2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withFieldAdded(durationFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.shortDateTime();
        boolean boolean8 = dateTimeFormatter7.isOffsetParsed();
        java.lang.String str9 = dateTime4.toString(dateTimeFormatter7);
        boolean boolean10 = dateTime4.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1/1/70 4:01 PM" + "'", str9.equals("1/1/70 4:01 PM"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMinutes(52);
        int int7 = dateTime6.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        int int9 = property8.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.getMutableDateTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfSecond();
        long long16 = buddhistChronology11.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology11.clockhourOfDay();
        org.joda.time.DurationField durationField19 = buddhistChronology11.days();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology11.weekyear();
        org.joda.time.DateTime dateTime22 = mutableDateTime10.toDateTime((org.joda.time.Chronology) buddhistChronology11);
        int int23 = dateTime22.getMinuteOfDay();
        org.joda.time.DateTime.Property property24 = dateTime22.centuryOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 366 + "'", int9 == 366);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.millisOfSecond();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set(0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime0.withDayOfYear((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withYear(1970);
        boolean boolean4 = buddhistChronology0.equals((java.lang.Object) 1970);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = buddhistChronology0.add(readablePeriod5, (long) (short) 0, (int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology10 = buddhistChronology0.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.era();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime5 = dateTime2.withYearOfCentury(1);
        org.joda.time.DateTime dateTime6 = dateTime2.withTimeAtStartOfDay();
        int int7 = dateTime6.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 57720097L + "'", long3 == 57720097L);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(0);
        java.util.Date date7 = dateTime4.toDate();
        org.joda.time.DateTime dateTime9 = dateTime4.minus((long) 57660097);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(10L, chronology11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.yearOfCentury();
        java.util.Locale locale14 = null;
        int int15 = property13.getMaximumTextLength(locale14);
        int int16 = property13.getLeapAmount();
        org.joda.time.DurationField durationField17 = property13.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime23 = dateTime4.withField(dateTimeFieldType18, (int) '4');
        int int24 = dateTime23.getYearOfEra();
        org.joda.time.LocalTime localTime25 = dateTime23.toLocalTime();
        boolean boolean26 = dateTime23.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1952 + "'", int24 == 1952);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("GJChronology[UTC,cutover=0000-12-31T23:52:58.010Z]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[UTC,cutover=0000-12...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        java.util.Locale locale21 = null;
        int int22 = skipDateTimeField10.getMaximumShortTextLength(locale21);
        java.util.Locale locale23 = null;
        int int24 = skipDateTimeField10.getMaximumTextLength(locale23);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
        org.joda.time.DateTime dateTime10 = dateTime6.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        java.lang.String str12 = property11.toString();
        org.joda.time.DateTime dateTime13 = property11.withMaximumValue();
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime13);
        mutableDateTime2.addHours((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[year]" + "'", str12.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (short) -1, (java.lang.Number) 200L);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(10L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.yearOfCentury();
        java.util.Locale locale11 = null;
        int int12 = property10.getMaximumTextLength(locale11);
        int int13 = property10.getLeapAmount();
        org.joda.time.DurationField durationField14 = property10.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, (java.lang.Number) 99, "Coordinated Universal Time");
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
        java.lang.String str6 = property5.toString();
        int int7 = property5.get();
        org.joda.time.DateTime dateTime8 = property5.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[dayOfWeek]" + "'", str6.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        java.lang.String str17 = skipDateTimeField10.getName();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        org.joda.time.DateTime dateTime26 = dateTime24.minus((-1L));
        org.joda.time.DateTime.Property property27 = dateTime26.centuryOfEra();
        java.util.Locale locale29 = null;
        org.joda.time.DateTime dateTime30 = property27.setCopy("100", locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property27.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType31, (int) ' ');
        try {
            long long35 = dividedDateTimeField33.roundHalfEven((long) 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for secondOfMinute must be in the range [-1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "secondOfMinute" + "'", str17.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime23 = dateTime21.plusMinutes(1);
        long long24 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime.Property property25 = dateTime23.secondOfMinute();
        org.joda.time.DateTime dateTime27 = dateTime23.plusHours(1969);
        org.joda.time.LocalDateTime localDateTime28 = dateTime23.toLocalDateTime();
        java.util.Locale locale29 = null;
        java.lang.String str30 = zeroIsMaxDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) localDateTime28, locale29);
        int int32 = zeroIsMaxDateTimeField19.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 57720097L + "'", long24 == 57720097L);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDateTime28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "70" + "'", str30.equals("70"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2 + "'", int32 == 2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        org.joda.time.DurationField durationField9 = buddhistChronology0.days();
        org.joda.time.DurationField durationField10 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        int int5 = dateTime4.getYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withChronology((org.joda.time.Chronology) buddhistChronology7);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(10L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.yearOfCentury();
        boolean boolean11 = dateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime9.copy();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) mutableDateTime9, (java.lang.Object) buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime9 = property5.setCopy("86399");
        org.joda.time.DurationField durationField10 = property5.getLeapDurationField();
        org.joda.time.DateTime dateTime11 = property5.roundFloorCopy();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(0);
        org.joda.time.DateTime dateTime8 = dateTime6.minus((-1L));
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        java.util.Locale locale11 = null;
        org.joda.time.DateTime dateTime12 = property9.setCopy("100", locale11);
        int int13 = property9.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        int int7 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillis((long) '#');
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime9 = dateTime7.plusMinutes(1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(52);
        org.joda.time.DateTime.Property property12 = dateTime9.weekOfWeekyear();
        org.joda.time.DateTime dateTime13 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime15 = dateTime13.minusMillis(0);
        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
        org.joda.time.DateTime dateTime17 = property16.withMinimumValue();
        org.joda.time.DateTime dateTime19 = dateTime17.withMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = buddhistChronology21.weeks();
        org.joda.time.DateTime dateTime23 = dateTime17.withChronology((org.joda.time.Chronology) buddhistChronology21);
        try {
            org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(961, 57660097, 97, 1, 366, (int) (byte) -1, 10, (org.joda.time.Chronology) buddhistChronology21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57660097 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMinutes(52);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay(1969);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        org.joda.time.DurationField durationField21 = zeroIsMaxDateTimeField19.getRangeDurationField();
        try {
            long long24 = zeroIsMaxDateTimeField19.add((long) 366, 1560342917903L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1560342917903 * 43200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        java.lang.String str22 = skipDateTimeField10.getAsShortText(97L);
        boolean boolean24 = skipDateTimeField10.isLeap(2440588L);
        org.joda.time.DurationField durationField25 = skipDateTimeField10.getLeapDurationField();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime28 = dateTime26.plusMinutes(1);
        org.joda.time.DateTime dateTime30 = dateTime28.plusMinutes(52);
        org.joda.time.DateTime.Property property31 = dateTime30.dayOfWeek();
        java.lang.String str32 = property31.toString();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis(86399);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime37 = dateTime35.plusMinutes(1);
        long long38 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime.Property property39 = dateTime37.secondOfMinute();
        org.joda.time.DateTime dateTime41 = dateTime37.plusHours(1969);
        org.joda.time.LocalDateTime localDateTime42 = dateTime37.toLocalDateTime();
        boolean boolean43 = dateTimeZone34.isLocalDateTimeGap(localDateTime42);
        int int44 = property31.compareTo((org.joda.time.ReadablePartial) localDateTime42);
        int[] intArray51 = new int[] { 366, 1020, 31, 334, 0 };
        try {
            int[] intArray53 = skipDateTimeField10.addWrapField((org.joda.time.ReadablePartial) localDateTime42, 67, intArray51, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 67");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Property[dayOfWeek]" + "'", str32.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 57720097L + "'", long38 == 57720097L);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(localDateTime42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray51);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            java.lang.String str3 = dateTimeFormatter0.print(readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = iSOChronology3.months();
        org.joda.time.DurationField durationField5 = iSOChronology3.seconds();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology7 = iSOChronology3.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(10L, chronology9);
        org.joda.time.DateTimeField dateTimeField11 = null;
        mutableDateTime10.setRounding(dateTimeField11);
        int int13 = mutableDateTime10.getWeekyear();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime16 = dateTime14.plusMinutes(1);
        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
        boolean boolean18 = mutableDateTime10.isAfter((org.joda.time.ReadableInstant) dateTime16);
        mutableDateTime10.setYear(0);
        long long21 = mutableDateTime10.getMillis();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime10);
        java.lang.String str23 = gJChronology22.toString();
        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology22.getZone();
        org.joda.time.Chronology chronology25 = gregorianChronology0.withZone(dateTimeZone24);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = iSOChronology26.months();
        org.joda.time.DurationField durationField28 = iSOChronology26.seconds();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology30 = iSOChronology26.withZone(dateTimeZone29);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime(10L, chronology32);
        org.joda.time.DateTimeField dateTimeField34 = null;
        mutableDateTime33.setRounding(dateTimeField34);
        int int36 = mutableDateTime33.getWeekyear();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime39 = dateTime37.plusMinutes(1);
        long long40 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime39);
        boolean boolean41 = mutableDateTime33.isAfter((org.joda.time.ReadableInstant) dateTime39);
        mutableDateTime33.setYear(0);
        long long44 = mutableDateTime33.getMillis();
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) mutableDateTime33);
        org.joda.time.DateTimeZone dateTimeZone46 = gJChronology45.getZone();
        long long48 = dateTimeZone24.getMillisKeepLocal(dateTimeZone46, 1560342913175L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 57720097L + "'", long17 == 57720097L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62167219199990L) + "'", long21 == (-62167219199990L));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]" + "'", str23.equals("GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]"));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1970 + "'", int36 == 1970);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 57720097L + "'", long40 == 57720097L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62167219199990L) + "'", long44 == (-62167219199990L));
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560342913175L + "'", long48 == 1560342913175L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 0L, (java.lang.Number) (short) -1, (java.lang.Number) 200L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.withCenturyOfEra((int) '4');
        org.joda.time.Instant instant7 = dateTime4.toInstant();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.joda.time.MutableDateTime mutableDateTime3 = instant2.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        try {
            long long23 = zeroIsMaxDateTimeField19.set(1560342915854L, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for yearOfCentury must be in the range [1,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
        org.joda.time.DateTimeField dateTimeField8 = null;
        mutableDateTime7.setRounding(dateTimeField8);
        int int10 = mutableDateTime7.getWeekyear();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
        mutableDateTime7.setYear(0);
        long long18 = mutableDateTime7.getMillis();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology19.getZone();
        java.lang.String str21 = dateTimeZone20.getID();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 57720097L + "'", long14 == 57720097L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167219199990L) + "'", long18 == (-62167219199990L));
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray20 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int21 = skipDateTimeField10.getMaximumValue(readablePartial15, intArray20);
        org.joda.time.DurationField durationField22 = skipDateTimeField10.getDurationField();
        long long24 = skipDateTimeField10.remainder((-5001L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 999L + "'", long24 == 999L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatterBuilder47.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.appendLiteral("T16:00:00.097-08:00");
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.joda.time.DurationField durationField3 = buddhistChronology0.centuries();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223371985651260096L + "'", long8 == 9223371985651260096L);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField((int) '#');
        int int6 = mutableDateTime5.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.millisOfSecond();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfSecond();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumShortTextLength(locale9);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 100);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        java.lang.String str4 = mutableDateTime3.toString();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
        org.joda.time.DateTimeField dateTimeField8 = null;
        mutableDateTime7.setRounding(dateTimeField8);
        int int10 = mutableDateTime7.getWeekyear();
        mutableDateTime7.setTime((long) (short) 0);
        mutableDateTime3.setTime((org.joda.time.ReadableInstant) mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.100Z" + "'", str4.equals("1970-01-01T00:00:00.100Z"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.MutableDateTime mutableDateTime6 = mutableDateTime2.copy();
        int int7 = mutableDateTime2.getYearOfEra();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((-1));
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.minus(readablePeriod9);
        org.joda.time.DateTime.Property property11 = dateTime10.hourOfDay();
        try {
            org.joda.time.DateTime dateTime13 = property11.setCopy("Property[year]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[year]\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHourOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
        org.joda.time.DateTimeField dateTimeField8 = null;
        mutableDateTime7.setRounding(dateTimeField8);
        int int10 = mutableDateTime7.getWeekyear();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
        mutableDateTime7.setYear(0);
        long long18 = mutableDateTime7.getMillis();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology19.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        mutableDateTime22.add(readablePeriod23, 1969);
        mutableDateTime22.setSecondOfDay((int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 57720097L + "'", long14 == 57720097L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167219199990L) + "'", long18 == (-62167219199990L));
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = buddhistChronology1.centuries();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear((int) 'a', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((-1), true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendClockhourOfHalfday(0);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(10L, chronology15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.yearOfCentury();
        java.util.Locale locale18 = null;
        int int19 = property17.getMaximumTextLength(locale18);
        int int20 = property17.getLeapAmount();
        org.joda.time.DurationField durationField21 = property17.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType22, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder6.appendFixedSignedDecimal(dateTimeFieldType22, 12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis(0);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(57660097);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.withDurationAdded(readableDuration9, (int) (byte) -1);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis(2);
        int int14 = dateTime13.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.minusYears(1);
        org.joda.time.DateTime.Property property9 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((int) 'a');
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "97");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        java.util.Date date1 = dateTime0.toDate();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime0.toMutableDateTime((org.joda.time.Chronology) buddhistChronology2);
        mutableDateTime3.addYears(99);
        mutableDateTime3.setDate((long) (byte) 10);
        org.joda.time.ReadableInstant readableInstant8 = null;
        try {
            int int9 = mutableDateTime3.compareTo(readableInstant8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime7 = property5.addToCopy(60097L);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(86399);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.withYear(1970);
//        boolean boolean6 = buddhistChronology0.equals((java.lang.Object) 1970);
//        org.joda.time.DurationField durationField7 = buddhistChronology0.hours();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(0L);
//        org.joda.time.DateTime dateTime16 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology17.getZone();
//        boolean boolean20 = dateTimeZone18.isStandardOffset((long) (byte) 100);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        int int6 = mutableDateTime2.getYear();
        java.lang.String str7 = mutableDateTime2.toString();
        java.lang.Object obj8 = mutableDateTime2.clone();
        int int9 = mutableDateTime2.getMinuteOfHour();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            mutableDateTime2.add(durationFieldType10, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str7.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        try {
            long long75 = unsupportedDateTimeField73.remainder(51L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
        org.joda.time.DateTimeField dateTimeField8 = null;
        mutableDateTime7.setRounding(dateTimeField8);
        int int10 = mutableDateTime7.getWeekyear();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
        mutableDateTime7.setYear(0);
        long long18 = mutableDateTime7.getMillis();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
        java.lang.String str20 = gJChronology19.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology19.millisOfSecond();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField22, 99, 12, 2019);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 57720097L + "'", long14 == 57720097L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167219199990L) + "'", long18 == (-62167219199990L));
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]" + "'", str20.equals("GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("JulianChronology[UTC]", (int) (short) 0, (int) (byte) 0, 960, '4', (int) (short) 1, 0, 57600, false, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendSecondOfMinute(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(99);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendTimeZoneOffset("70", "JulianChronology[UTC]", false, 3, 1952);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
//        org.joda.time.DurationField durationField8 = buddhistChronology6.halfdays();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime11 = dateTime9.withYear(1970);
//        boolean boolean12 = buddhistChronology6.equals((java.lang.Object) 1970);
//        org.joda.time.DurationField durationField13 = buddhistChronology6.hours();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime16 = dateTime14.plusMinutes(1);
//        org.joda.time.DateTime dateTime18 = dateTime14.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str21 = dateTimeZone19.getName(0L);
//        org.joda.time.DateTime dateTime22 = dateTime18.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology6, dateTimeZone19);
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(dateTimeZone19);
//        org.joda.time.Chronology chronology25 = iSOChronology0.withZone(dateTimeZone19);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(zonedChronology23);
//        org.junit.Assert.assertNotNull(chronology25);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes(1);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMillis(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minus((-1L));
        org.joda.time.DateTime.Property property10 = dateTime9.centuryOfEra();
        java.util.Locale locale12 = null;
        org.joda.time.DateTime dateTime13 = property10.setCopy("86399", locale12);
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        int int15 = dateTime13.getDayOfMonth();
        java.lang.String str16 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime13);
        try {
            org.joda.time.DateTime dateTime18 = dateTime13.withDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "8639970-01-01T16:01:00Z" + "'", str16.equals("8639970-01-01T16:01:00Z"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        mutableDateTime2.setRounding(dateTimeField3);
        int int5 = mutableDateTime2.getWeekyear();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.yearOfCentury();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology0.era();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "GregorianChronology[America/Los_Angeles]", "GregorianChronology[America/Los_Angeles]");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes(10);
        try {
            org.joda.time.DateTime dateTime10 = dateTime2.withDate((-5), 1952, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1952 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.withYear(1970);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) (short) 10);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime((org.joda.time.Chronology) iSOChronology7);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime7 = property5.addToCopy(60097L);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(10L, chronology3);
        org.joda.time.DateTimeField dateTimeField5 = null;
        mutableDateTime4.setRounding(dateTimeField5);
        int int7 = mutableDateTime4.getWeekyear();
        mutableDateTime4.setTime((long) (short) 0);
        mutableDateTime4.addMinutes(99);
        int int14 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "1969-12-31T16:00:00.100-08:00", 3);
        try {
            org.joda.time.LocalDate localDate16 = dateTimeFormatter0.parseLocalDate("100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"100\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-5) + "'", int14 == (-5));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
        org.joda.time.DateTime.Property property5 = dateTime2.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 57720097L + "'", long3 == 57720097L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1007", "-5", 1952, 1969);
        long long6 = fixedDateTimeZone4.previousTransition(1560342915917L);
        long long8 = fixedDateTimeZone4.previousTransition((-62135597221990L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560342915917L + "'", long6 == 1560342915917L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62135597221990L) + "'", long8 == (-62135597221990L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear((int) 'a', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((-1), true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendClockhourOfDay((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property3.getFieldType();
        long long9 = property3.remainder();
        long long10 = property3.remainder();
        java.util.Locale locale11 = null;
        int int12 = property3.getMaximumShortTextLength(locale11);
        org.joda.time.MutableDateTime mutableDateTime14 = property3.set((int) (short) 10);
        java.util.Locale locale15 = null;
        int int16 = property3.getMaximumTextLength(locale15);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long20 = skipDateTimeField10.addWrapField((-62167219199990L), (int) ' ');
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62167219167990L) + "'", long20 == (-62167219167990L));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = iSOChronology8.months();
        org.joda.time.DurationField durationField10 = iSOChronology8.seconds();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology12 = iSOChronology8.withZone(dateTimeZone11);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(10L, chronology14);
        org.joda.time.DateTimeField dateTimeField16 = null;
        mutableDateTime15.setRounding(dateTimeField16);
        int int18 = mutableDateTime15.getWeekyear();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime21 = dateTime19.plusMinutes(1);
        long long22 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime21);
        boolean boolean23 = mutableDateTime15.isAfter((org.joda.time.ReadableInstant) dateTime21);
        mutableDateTime15.setYear(0);
        long long26 = mutableDateTime15.getMillis();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) mutableDateTime15);
        java.lang.String str28 = gJChronology27.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology27.getZone();
        org.joda.time.Chronology chronology30 = gJChronology7.withZone(dateTimeZone29);
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        try {
            org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime((int) (byte) 1, (int) ' ', (int) (short) 1, 2, 86399, (int) '#', 8, dateTimeZone29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 57720097L + "'", long22 == 57720097L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62167219199990L) + "'", long26 == (-62167219199990L));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]" + "'", str28.equals("GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(julianChronology31);
    }
}

