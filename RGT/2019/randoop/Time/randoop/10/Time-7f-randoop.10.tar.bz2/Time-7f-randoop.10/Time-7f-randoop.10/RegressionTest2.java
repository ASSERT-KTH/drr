import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(readablePartial13, 961, locale15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(10L, chronology18);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.yearOfCentury();
        java.util.Locale locale21 = null;
        int int22 = property20.getMaximumTextLength(locale21);
        int int23 = property20.getLeapAmount();
        org.joda.time.DurationField durationField24 = property20.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property20.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType25, 67);
        boolean boolean28 = remainderDateTimeField27.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "961" + "'", str16.equals("961"));
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeField dateTimeField8 = property3.getField();
        org.joda.time.MutableDateTime mutableDateTime9 = property3.roundHalfEven();
        int int10 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 99 + "'", int10 == 99);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.millisOfSecond();
        long long6 = buddhistChronology1.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology1.clockhourOfDay();
        org.joda.time.DurationField durationField9 = buddhistChronology1.days();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology1.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.weekyear();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 1, (org.joda.time.Chronology) buddhistChronology1, locale12);
        int int14 = dateTimeParserBucket13.getOffset();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.util.Locale locale4 = null;
        int int5 = property3.getMaximumTextLength(locale4);
        int int6 = property3.getLeapAmount();
        org.joda.time.DurationField durationField7 = property3.getDurationField();
        org.joda.time.DateTimeField dateTimeField8 = property3.getField();
        org.joda.time.MutableDateTime mutableDateTime9 = property3.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime10 = property3.getMutableDateTime();
        java.lang.String str11 = property3.toString();
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = property3.set("ZonedChronology[BuddhistChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[BuddhistChronology[UTC], UTC]\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[yearOfCentury]" + "'", str11.equals("Property[yearOfCentury]"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((-1));
        org.joda.time.DateTime.Property property9 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime11 = property9.addWrapFieldToCopy((-5));
        org.joda.time.DateTime dateTime13 = dateTime11.minusMinutes(17);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        java.lang.String str6 = property5.toString();
//        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
//        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372013718489816L + "'", long8 == 9223372013718489816L);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((-1));
        org.joda.time.DateTime.Property property9 = dateTime6.secondOfMinute();
        org.joda.time.DateTime dateTime11 = property9.addWrapFieldToCopy((-5));
        try {
            org.joda.time.DateTime dateTime13 = property9.setCopy(1020);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1020 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(86399);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(1);
//        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.secondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime4.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime9 = dateTime4.toLocalDateTime();
//        boolean boolean10 = dateTimeZone1.isLocalDateTimeGap(localDateTime9);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 31");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-5904531050096L) + "'", long5 == (-5904531050096L));
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.millisOfSecond();
        long long6 = buddhistChronology1.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology1.yearOfCentury();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((-604799981L), (org.joda.time.Chronology) buddhistChronology1, locale9, (java.lang.Integer) 4);
        dateTimeParserBucket11.setOffset(0);
        long long16 = dateTimeParserBucket11.computeMillis(true, "8639969-12-31T16:00:00-08:00");
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-604799981L) + "'", long16 == (-604799981L));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        boolean boolean21 = zeroIsMaxDateTimeField19.isLeap(1560342881506L);
        int int22 = zeroIsMaxDateTimeField19.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendFractionOfHour(2019, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.appendDayOfWeek(86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime(10L, chronology17);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.yearOfCentury();
        java.util.Locale locale20 = null;
        int int21 = property19.getMaximumTextLength(locale20);
        int int22 = property19.getLeapAmount();
        org.joda.time.DurationField durationField23 = property19.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property19.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime35 = dateTime33.plusMinutes(1);
        org.joda.time.DateTime dateTime37 = dateTime33.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime39 = dateTime37.minusMillis(0);
        java.util.Date date40 = dateTime37.toDate();
        org.joda.time.DateTime dateTime42 = dateTime37.minus((long) 57660097);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime(10L, chronology44);
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime45.yearOfCentury();
        java.util.Locale locale47 = null;
        int int48 = property46.getMaximumTextLength(locale47);
        int int49 = property46.getLeapAmount();
        org.joda.time.DurationField durationField50 = property46.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property46.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType51, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime56 = dateTime37.withField(dateTimeFieldType51, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder32.appendSignedDecimal(dateTimeFieldType51, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType51, 59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder9.appendText(dateTimeFieldType51);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField65 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType51, 1432);
        long long68 = dividedDateTimeField65.getDifferenceAsLong((long) 44949578, 58999L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2 + "'", int48 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test013");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
//        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes(10);
//        java.lang.String str7 = dateTime2.toString();
//        org.joda.time.DateTime dateTime9 = dateTime2.withMinuteOfHour(31);
//        org.joda.time.DateTime dateTime10 = dateTime2.withLaterOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1782-11-22T12:29:10.259Z" + "'", str7.equals("1782-11-22T12:29:10.259Z"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.DateTime.Property property9 = dateTime8.monthOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMinuteOfHour((int) (short) 1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("1007", "-5", 1952, 1969);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime8.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(3);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter0.parseLocalDate("9/25/72 4:01 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"9/25/72 4:01 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 47);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test017");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.DateTimeField dateTimeField3 = null;
//        mutableDateTime2.setRounding(dateTimeField3);
//        int int5 = mutableDateTime2.getWeekyear();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes(1);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean10 = mutableDateTime2.isAfter((org.joda.time.ReadableInstant) dateTime8);
//        mutableDateTime2.setYear(0);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime2.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
//        org.joda.time.MutableDateTime mutableDateTime15 = property13.roundHalfCeiling();
//        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime15.toMutableDateTime();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560342972542L + "'", long9 == 1560342972542L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        java.lang.String str74 = unsupportedDateTimeField73.getName();
        long long77 = unsupportedDateTimeField73.getDifferenceAsLong((long) 32, (-587L));
        try {
            long long80 = unsupportedDateTimeField73.set((-5904531055257L), "+00:01:26.399");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "yearOfCentury" + "'", str74.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        java.lang.String str74 = unsupportedDateTimeField73.getName();
        long long77 = unsupportedDateTimeField73.add((long) 12, 1020);
        java.util.Locale locale78 = null;
        try {
            int int79 = unsupportedDateTimeField73.getMaximumTextLength(locale78);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "yearOfCentury" + "'", str74.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1020012L + "'", long77 == 1020012L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfMinute();
        org.joda.time.DurationField durationField3 = buddhistChronology0.millis();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField5 = iSOChronology4.months();
        org.joda.time.DurationField durationField6 = iSOChronology4.seconds();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology8 = iSOChronology4.withZone(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField9, 52);
        long long13 = skipDateTimeField11.roundHalfFloor((-62135597149601L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62135597150000L) + "'", long13 == (-62135597150000L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("1970-01-01T00:00:00.005Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(10L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.centuryOfEra();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) property5);
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(0);
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime9.add(readableDuration10, 100);
        mutableDateTime9.setWeekyear(2019);
        int int15 = mutableDateTime9.getWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("2019-06-12", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-12\" is malformed at \"-06-12\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1007", "-5", 1952, 1969);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 2);
        long long8 = fixedDateTimeZone4.previousTransition((long) '#');
        int int10 = fixedDateTimeZone4.getStandardOffset(1560342917903L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-5" + "'", str6.equals("-5"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.millisOfSecond();
        long long8 = buddhistChronology3.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        boolean boolean12 = iSOChronology0.equals((java.lang.Object) dateTime10);
        try {
            org.joda.time.DateTime dateTime17 = dateTime10.withTime(97, 19, 46, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 200L + "'", long8 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test026");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        java.lang.String str6 = property5.toString();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) 3);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusDays((int) 'a');
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTime10.toString("69", locale12);
//        org.joda.time.DateTime dateTime15 = dateTime10.minusSeconds(86399);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        java.lang.String str17 = dateTime15.toString(dateTimeFormatter16);
//        java.lang.StringBuffer stringBuffer18 = null;
//        org.joda.time.Chronology chronology20 = null;
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime(10L, chronology20);
//        org.joda.time.DateTimeField dateTimeField22 = null;
//        mutableDateTime21.setRounding(dateTimeField22);
//        int int24 = mutableDateTime21.getWeekyear();
//        int int25 = mutableDateTime21.getYear();
//        java.lang.String str26 = mutableDateTime21.toString();
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime21.era();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime30 = dateTime28.plusMinutes(1);
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        org.joda.time.DateTime dateTime32 = dateTime28.plus(readablePeriod31);
//        org.joda.time.DateTime.Property property33 = dateTime28.weekyear();
//        boolean boolean34 = mutableDateTime21.isEqual((org.joda.time.ReadableInstant) dateTime28);
//        try {
//            dateTimeFormatter16.printTo(stringBuffer18, (org.joda.time.ReadableInstant) mutableDateTime21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "69" + "'", str13.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3/6/22 12:35 PM" + "'", str17.equals("3/6/22 12:35 PM"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1970 + "'", int24 == 1970);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str26.equals("1970-01-01T00:00:00.010Z"));
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test027");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
//        mutableDateTime2.setWeekyear(0);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        long long11 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        long long12 = property8.remainder();
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-737582L) + "'", long11 == (-737582L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test028");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.lang.String str2 = gregorianChronology1.toString();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.weekOfWeekyear();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField5 = iSOChronology4.months();
//        org.joda.time.DurationField durationField6 = iSOChronology4.seconds();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology8 = iSOChronology4.withZone(dateTimeZone7);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
//        org.joda.time.DateTimeField dateTimeField12 = null;
//        mutableDateTime11.setRounding(dateTimeField12);
//        int int14 = mutableDateTime11.getWeekyear();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime17 = dateTime15.plusMinutes(1);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime17);
//        boolean boolean19 = mutableDateTime11.isAfter((org.joda.time.ReadableInstant) dateTime17);
//        mutableDateTime11.setYear(0);
//        long long22 = mutableDateTime11.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime11);
//        java.lang.String str24 = gJChronology23.toString();
//        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology23.getZone();
//        org.joda.time.Chronology chronology26 = gregorianChronology1.withZone(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(961L, dateTimeZone25);
//        org.joda.time.DateTime.Property property28 = dateTime27.minuteOfDay();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560342972886L + "'", long18 == 1560342972886L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62167219199990L) + "'", long22 == (-62167219199990L));
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]" + "'", str24.equals("GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]"));
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(property28);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendMinuteOfHour(24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        long long76 = unsupportedDateTimeField73.add(31507200010L, 0L);
        int int79 = unsupportedDateTimeField73.getDifference((long) (short) -1, 19L);
        try {
            int int80 = unsupportedDateTimeField73.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 31507200010L + "'", long76 == 31507200010L);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.millisOfSecond();
//        long long10 = buddhistChronology5.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology5, dateTimeField13, (int) (byte) 1);
//        long long17 = skipDateTimeField15.roundHalfCeiling(0L);
//        long long19 = skipDateTimeField15.roundHalfEven(0L);
//        int int21 = skipDateTimeField15.get((long) (short) 10);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime24 = dateTime22.plusMinutes(1);
//        long long25 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime.Property property26 = dateTime24.secondOfMinute();
//        org.joda.time.DateTime dateTime28 = dateTime24.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime29 = dateTime24.toLocalDateTime();
//        int int30 = skipDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDateTime29);
//        boolean boolean31 = dateTimeZone3.isLocalDateTimeGap(localDateTime29);
//        org.joda.time.Chronology chronology33 = null;
//        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime(10L, chronology33);
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
//        mutableDateTime34.setWeekyear(0);
//        org.joda.time.MutableDateTime mutableDateTime38 = mutableDateTime34.copy();
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime38, 1);
//        mutableDateTime38.add((long) 8);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 200L + "'", long10 == 200L);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560342973118L + "'", long25 == 1560342973118L);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(gJChronology40);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test032");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.withYear(1970);
//        boolean boolean6 = buddhistChronology0.equals((java.lang.Object) 1970);
//        org.joda.time.DurationField durationField7 = buddhistChronology0.hours();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(0L);
//        org.joda.time.DateTime dateTime16 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology17.getZone();
//        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology17.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19, 3);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant22);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(gJChronology23);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        java.lang.String str12 = cachedDateTimeZone10.getNameKey((long) 4);
//        int int14 = cachedDateTimeZone10.getStandardOffset(1560342916848L);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(10L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.yearOfCentury();
        boolean boolean11 = dateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime9.copy();
        boolean boolean14 = mutableDateTime12.isAfter((-20000L));
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '#', 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1820L + "'", long2 == 1820L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfYear(3);
        java.lang.Class<?> wildcardClass8 = dateTimeFormatterBuilder7.getClass();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendMinuteOfDay(57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendMillisOfDay(1969);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(10L, chronology19);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.yearOfCentury();
        java.util.Locale locale22 = null;
        int int23 = property21.getMaximumTextLength(locale22);
        int int24 = property21.getLeapAmount();
        org.joda.time.DurationField durationField25 = property21.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder17.appendText(dateTimeFieldType26);
        boolean boolean28 = dateTimeFormatterBuilder27.canBuildPrinter();
        org.joda.time.format.DateTimePrinter dateTimePrinter29 = dateTimeFormatterBuilder27.toPrinter();
        org.joda.time.format.DateTimePrinter dateTimePrinter30 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter30, dateTimeParser32);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.appendYear((int) 'a', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder37.appendTwoDigitWeekyear((-1), true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder40.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser42 = dateTimeFormatterBuilder40.toParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray43 = new org.joda.time.format.DateTimeParser[] { dateTimeParser32, dateTimeParser42 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder13.append(dateTimePrinter29, dateTimeParserArray43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder45.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser49 = dateTimeFormatter48.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder47.append(dateTimeParser49);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter29, dateTimeParser49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder10.appendOptional(dateTimeParser49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTimePrinter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeParser42);
        org.junit.Assert.assertNotNull(dateTimeParserArray43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertNotNull(dateTimeParser49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(60780);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 60780");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        long long24 = offsetDateTimeField21.add((-5001L), 52);
        int int27 = offsetDateTimeField21.getDifference(0L, 1L);
        int int28 = offsetDateTimeField21.getMaximumValue();
        long long30 = offsetDateTimeField21.roundHalfFloor(2000L);
        int int31 = offsetDateTimeField21.getOffset();
        int int32 = offsetDateTimeField21.getOffset();
        long long34 = offsetDateTimeField21.roundCeiling(57660097L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 46999L + "'", long24 == 46999L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1020 + "'", int28 == 1020);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2000L + "'", long30 == 2000L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 961 + "'", int31 == 961);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 961 + "'", int32 == 961);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 57661000L + "'", long34 == 57661000L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        long long76 = unsupportedDateTimeField73.add(31507200010L, 0L);
        try {
            int int78 = unsupportedDateTimeField73.getLeapAmount(1035L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 31507200010L + "'", long76 == 31507200010L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Instant instant6 = dateTime4.toInstant();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.plus(readableDuration7);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        boolean boolean18 = skipDateTimeField10.isLenient();
        int int19 = skipDateTimeField10.getMinimumValue();
        int int21 = skipDateTimeField10.get((-62135597221000L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 46");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.yearOfCentury();
        java.lang.String str4 = property3.getAsText();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "70" + "'", str4.equals("70"));
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        int int9 = property8.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime11 = property8.addWrapField((int) (short) 1);
        mutableDateTime11.setTime(0L);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 366 + "'", int9 == 366);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        long long22 = zeroIsMaxDateTimeField19.roundHalfEven(100L);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime25 = dateTime23.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime23.plus(readablePeriod26);
        org.joda.time.DateTime.Property property28 = dateTime23.weekyear();
        org.joda.time.DateTime dateTime30 = property28.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime32 = property28.addToCopy(0);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime35 = dateTime33.withYear(1970);
        org.joda.time.DateTime dateTime37 = dateTime35.plusMinutes(52);
        org.joda.time.DateTime dateTime39 = dateTime37.minusDays((int) ' ');
        int int40 = property28.compareTo((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.LocalDateTime localDateTime41 = dateTime37.toLocalDateTime();
        int[] intArray44 = new int[] { (short) -1, 57660097 };
        int int45 = zeroIsMaxDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) localDateTime41, intArray44);
        int int47 = zeroIsMaxDateTimeField19.getMaximumValue(97L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(localDateTime41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        long long27 = offsetDateTimeField21.add((long) (short) -1, (-5));
        int int29 = offsetDateTimeField21.getMaximumValue(1560342881341L);
        int int31 = offsetDateTimeField21.get((-719523L));
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField21.getAsShortText(46999L, locale33);
        long long36 = offsetDateTimeField21.roundHalfFloor(2440L);
        int int37 = offsetDateTimeField21.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5001L) + "'", long27 == (-5001L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1020 + "'", int29 == 1020);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 960 + "'", int31 == 960);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1007" + "'", str34.equals("1007"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2000L + "'", long36 == 2000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 960 + "'", int37 == 960);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        long long76 = unsupportedDateTimeField73.add(31507200010L, 0L);
        try {
            long long78 = unsupportedDateTimeField73.roundHalfFloor((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 31507200010L + "'", long76 == 31507200010L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField8 = buddhistChronology0.days();
        try {
            long long11 = durationField8.subtract((-719523L), 1560342919200L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -1560342919200 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(10L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.centuryOfEra();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) property5);
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(0);
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime9.add(readableDuration10, 100);
        java.util.GregorianCalendar gregorianCalendar13 = mutableDateTime9.toGregorianCalendar();
        mutableDateTime9.setSecondOfDay(19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        long long23 = skipDateTimeField10.roundHalfEven((long) 1020);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1000L + "'", long23 == 1000L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime1.minusMonths(960);
        int int4 = dateTime1.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(10L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.centuryOfEra();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) property5);
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(0);
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime9.add(readableDuration10, 100);
        java.lang.Object obj13 = mutableDateTime9.clone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.months();
        org.joda.time.DurationField durationField3 = iSOChronology1.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology5 = iSOChronology1.withZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = iSOChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.secondOfDay();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket(961L, (org.joda.time.Chronology) iSOChronology1, locale8);
        long long13 = iSOChronology1.add(0L, (long) (short) -1, 31);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31L) + "'", long13 == (-31L));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        long long26 = offsetDateTimeField21.remainder((-719523L));
        int int27 = offsetDateTimeField21.getOffset();
        long long29 = offsetDateTimeField21.roundHalfEven(97L);
        int int31 = offsetDateTimeField21.getMinimumValue((-1L));
        int int33 = offsetDateTimeField21.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 477L + "'", long26 == 477L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 961 + "'", int27 == 961);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 960 + "'", int31 == 960);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test056");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plusHours(1969);
//        int int7 = dateTime6.getYear();
//        org.joda.time.DateTime.Property property8 = dateTime6.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = dateTime6.plusDays(19);
//        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560342974878L + "'", long3 == 1560342974878L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateMidnight11);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1/1/70 4:02 PM", (java.lang.Number) 8, (java.lang.Number) (-62167219199990L), (java.lang.Number) (short) -1);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.hourOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime(10L, chronology22);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.yearOfCentury();
        java.util.Locale locale25 = null;
        int int26 = property24.getMaximumTextLength(locale25);
        int int27 = property24.getLeapAmount();
        org.joda.time.DurationField durationField28 = property24.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder20.appendText(dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType29, (int) 'a');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType29, 187);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray20 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int21 = skipDateTimeField10.getMaximumValue(readablePartial15, intArray20);
        org.joda.time.DurationField durationField22 = skipDateTimeField10.getDurationField();
        org.joda.time.DateTimeField dateTimeField23 = skipDateTimeField10.getWrappedField();
        org.joda.time.DurationField durationField24 = skipDateTimeField10.getDurationField();
        org.joda.time.DurationField durationField25 = skipDateTimeField10.getRangeDurationField();
        int int27 = skipDateTimeField10.get(2440L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 991L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        long long22 = zeroIsMaxDateTimeField19.roundFloor((long) 5);
        java.lang.String str24 = zeroIsMaxDateTimeField19.getAsShortText((long) 961);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2" + "'", str24.equals("2"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test063");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str7 = dateTimeZone5.getName(0L);
//        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        java.lang.String str12 = cachedDateTimeZone10.getNameKey((long) 4);
//        int int14 = cachedDateTimeZone10.getStandardOffset((long) 962);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-62135597221990L), 57660097L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135539561893L) + "'", long2 == (-62135539561893L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        long long23 = skipDateTimeField10.add((long) '#', (int) (byte) 1);
        boolean boolean25 = skipDateTimeField10.isLeap((-263001600001L));
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipDateTimeField10.getAsText(9223372017129600096L, locale27);
        org.joda.time.DateTimeField dateTimeField29 = skipDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1035L + "'", long23 == 1035L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTimeZoneShortName(strMap12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendMillisOfDay(3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(strMap12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(0);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.yearOfCentury();
        java.util.Locale locale9 = null;
        int int10 = property8.getMaximumTextLength(locale9);
        int int11 = property8.getLeapAmount();
        org.joda.time.DurationField durationField12 = property8.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder17.appendTimeZoneOffset("1970-01-01", "December", true, (int) '#', 86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendYearOfCentury((int) (byte) 10, 17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(31507200010L);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay(334);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        int int21 = zeroIsMaxDateTimeField19.get(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(readablePartial13, 961, locale15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(10L, chronology18);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.yearOfCentury();
        java.util.Locale locale21 = null;
        int int22 = property20.getMaximumTextLength(locale21);
        int int23 = property20.getLeapAmount();
        org.joda.time.DurationField durationField24 = property20.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property20.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType25, 67);
        int int29 = remainderDateTimeField27.get(2440588L);
        long long32 = remainderDateTimeField27.getDifferenceAsLong(200L, (long) 31);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "961" + "'", str16.equals("961"));
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 40 + "'", int29 == 40);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        java.lang.String str17 = skipDateTimeField10.getName();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        org.joda.time.DateTime dateTime26 = dateTime24.minus((-1L));
        org.joda.time.DateTime.Property property27 = dateTime26.centuryOfEra();
        java.util.Locale locale29 = null;
        org.joda.time.DateTime dateTime30 = property27.setCopy("100", locale29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property27.getFieldType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType31, (int) ' ');
        long long36 = dividedDateTimeField33.add((long) 961, (long) (-1));
        long long39 = dividedDateTimeField33.add((long) (-57660), 0);
        try {
            long long41 = dividedDateTimeField33.remainder((long) (-5));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -5 for secondOfMinute must be in the range [-1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "secondOfMinute" + "'", str17.equals("secondOfMinute"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-31039L) + "'", long36 == (-31039L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-57660L) + "'", long39 == (-57660L));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("4:00:00 PM", "960", (-719522), 0);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = julianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.hourOfDay();
        try {
            long long8 = julianChronology1.getDateTimeMillis(9, (int) (short) 100, 1952, 1783);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        java.lang.String str22 = skipDateTimeField10.getAsShortText(97L);
        boolean boolean24 = skipDateTimeField10.isLeap(2440588L);
        org.joda.time.DurationField durationField25 = skipDateTimeField10.getLeapDurationField();
        boolean boolean26 = skipDateTimeField10.isLenient();
        long long28 = skipDateTimeField10.roundCeiling((-62167219167990L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62167219167000L) + "'", long28 == (-62167219167000L));
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test076");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.secondOfMinute();
//        org.joda.time.DateTime dateTime6 = dateTime2.plus(1560342881341L);
//        int int7 = dateTime6.getYear();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (byte) -1);
//        org.joda.time.DateTime dateTime14 = dateTime12.minusMillis(0);
//        java.util.Date date15 = dateTime12.toDate();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime12.toDateTime(dateTimeZone16);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.millisOfSecond();
//        long long24 = buddhistChronology19.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology19.clockhourOfDay();
//        org.joda.time.DurationField durationField27 = buddhistChronology19.days();
//        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology19.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology19.weekyear();
//        java.util.Locale locale30 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 1, (org.joda.time.Chronology) buddhistChronology19, locale30);
//        long long33 = dateTimeParserBucket31.computeMillis(true);
//        long long35 = dateTimeParserBucket31.computeMillis(false);
//        long long38 = dateTimeParserBucket31.computeMillis(true, "JulianChronology[UTC]");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology39.millisOfSecond();
//        long long44 = buddhistChronology39.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology45.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology39, dateTimeField47, (int) (byte) 1);
//        dateTimeParserBucket31.saveField((org.joda.time.DateTimeField) skipDateTimeField49, 0);
//        java.util.Locale locale52 = dateTimeParserBucket31.getLocale();
//        java.util.Calendar calendar53 = dateTime17.toCalendar(locale52);
//        java.util.Calendar calendar54 = dateTime6.toCalendar(locale52);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560342975700L + "'", long3 == 1560342975700L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2068 + "'", int7 == 2068);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 200L + "'", long24 == 200L);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 200L + "'", long44 == 200L);
//        org.junit.Assert.assertNotNull(buddhistChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(locale52);
//        org.junit.Assert.assertNotNull(calendar53);
//        org.junit.Assert.assertNotNull(calendar54);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("1007", "-5", 1952, 1969);
        java.lang.String str7 = fixedDateTimeZone5.getNameKey((long) 2);
        mutableDateTime0.setZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-5" + "'", str7.equals("-5"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("19");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        boolean boolean2 = instant0.isBefore((long) 1969);
        org.joda.time.DateTime dateTime3 = instant0.toDateTime();
        org.joda.time.Instant instant4 = instant0.toInstant();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.plus(readableDuration5);
        boolean boolean8 = instant4.isBefore(19L);
        org.joda.time.Instant instant10 = instant4.plus((long) '4');
        org.joda.time.Instant instant11 = instant4.toInstant();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfYear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime5 = dateTime2.toDateTimeISO();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560342976264L + "'", long3 == 1560342976264L);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        java.util.Locale locale21 = null;
        int int22 = skipDateTimeField10.getMaximumShortTextLength(locale21);
        org.joda.time.DurationField durationField23 = skipDateTimeField10.getRangeDurationField();
        long long26 = skipDateTimeField10.set((-1L), 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58001L) + "'", long26 == (-58001L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray20 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int21 = skipDateTimeField10.getMaximumValue(readablePartial15, intArray20);
        org.joda.time.DurationField durationField22 = skipDateTimeField10.getDurationField();
        long long25 = durationField22.subtract((long) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-10001L) + "'", long25 == (-10001L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes(1);
        org.joda.time.DateTime dateTime9 = dateTime5.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMillis(0);
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.DateTime dateTime14 = dateTime9.minus((long) 57660097);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(10L, chronology16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.yearOfCentury();
        java.util.Locale locale19 = null;
        int int20 = property18.getMaximumTextLength(locale19);
        int int21 = property18.getLeapAmount();
        org.joda.time.DurationField durationField22 = property18.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property18.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime28 = dateTime9.withField(dateTimeFieldType23, (int) '4');
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "1969-12-31");
        int int31 = dateTime0.get(dateTimeFieldType23);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) 1, "1/1/70 4:01 PM");
        java.lang.Number number35 = illegalFieldValueException34.getLowerBound();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 19 + "'", int31 == 19);
        org.junit.Assert.assertNull(number35);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        long long22 = zeroIsMaxDateTimeField19.roundHalfEven(100L);
        int int24 = zeroIsMaxDateTimeField19.getLeapAmount((long) 4);
        int int26 = zeroIsMaxDateTimeField19.getMinimumValue((long) 'a');
        long long28 = zeroIsMaxDateTimeField19.roundHalfFloor((long) 8);
        int int31 = zeroIsMaxDateTimeField19.getDifference((-5904531057759L), 2440L);
        long long34 = zeroIsMaxDateTimeField19.add((long) (byte) 100, (long) 47);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-136678) + "'", int31 == (-136678));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2030400100L + "'", long34 == 2030400100L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        long long22 = zeroIsMaxDateTimeField19.roundFloor((long) 5);
        long long25 = zeroIsMaxDateTimeField19.getDifferenceAsLong((-31039L), (long) 961);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime4.plus(1560343937903L);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
//        org.joda.time.DurationField durationField8 = buddhistChronology6.halfdays();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime11 = dateTime9.withYear(1970);
//        boolean boolean12 = buddhistChronology6.equals((java.lang.Object) 1970);
//        org.joda.time.DurationField durationField13 = buddhistChronology6.hours();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime16 = dateTime14.plusMinutes(1);
//        org.joda.time.DateTime dateTime18 = dateTime14.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str21 = dateTimeZone19.getName(0L);
//        org.joda.time.DateTime dateTime22 = dateTime18.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology6, dateTimeZone19);
//        try {
//            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(1, (-1), (-20000), (int) (short) 0, (int) (byte) 10, 22, (org.joda.time.Chronology) zonedChronology23);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordinated Universal Time" + "'", str21.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(zonedChronology23);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.lang.String str2 = gregorianChronology0.toString();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((int) (byte) 0, 47, 0, 2, (-20000), 1, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -20000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test090");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.withYear(1970);
//        boolean boolean6 = buddhistChronology0.equals((java.lang.Object) 1970);
//        org.joda.time.DurationField durationField7 = buddhistChronology0.hours();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(0L);
//        org.joda.time.DateTime dateTime16 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology17.getZone();
//        org.joda.time.DateTimeField dateTimeField19 = zonedChronology17.dayOfMonth();
//        try {
//            long long27 = zonedChronology17.getDateTimeMillis(0, 961, 0, 86399, (-719522), 0, 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 961 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test091");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
//        java.util.Locale locale13 = null;
//        int int14 = property12.getMaximumTextLength(locale13);
//        int int15 = property12.getLeapAmount();
//        org.joda.time.DurationField durationField16 = property12.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
//        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime23 = dateTime21.plusMinutes(1);
//        long long24 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime.Property property25 = dateTime23.secondOfMinute();
//        org.joda.time.DateTime dateTime27 = dateTime23.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime28 = dateTime23.toLocalDateTime();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = zeroIsMaxDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) localDateTime28, locale29);
//        int int33 = zeroIsMaxDateTimeField19.getDifference((long) 1, 0L);
//        long long35 = zeroIsMaxDateTimeField19.roundCeiling(1L);
//        long long38 = zeroIsMaxDateTimeField19.set(0L, (int) (short) 1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560342976756L + "'", long24 == 1560342976756L);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDateTime28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "19" + "'", str30.equals("19"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43200000L + "'", long35 == 43200000L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43200000L + "'", long38 == 43200000L);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths((int) (short) -1);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusWeeks((-1));
//        org.joda.time.DateTime.Property property9 = dateTime6.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = property9.addWrapFieldToCopy((-5));
//        int int12 = dateTime11.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 45311 + "'", int12 == 45311);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(961, (int) (byte) -1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 43 + "'", int3 == 43);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        java.lang.String str16 = skipDateTimeField10.getAsShortText(10L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, 100, locale19);
        java.lang.String str22 = skipDateTimeField10.getAsText((long) 9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        java.lang.String str74 = unsupportedDateTimeField73.getName();
        boolean boolean75 = unsupportedDateTimeField73.isSupported();
        try {
            int int77 = unsupportedDateTimeField73.getMinimumValue(52L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "yearOfCentury" + "'", str74.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.getDateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        java.lang.String str10 = property9.getAsText();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20" + "'", str10.equals("20"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        java.lang.String str74 = unsupportedDateTimeField73.getName();
        long long77 = unsupportedDateTimeField73.add((long) 12, 1020);
        try {
            long long79 = unsupportedDateTimeField73.roundHalfCeiling((-719523L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "yearOfCentury" + "'", str74.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1020012L + "'", long77 == 1020012L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        long long24 = offsetDateTimeField21.add((-5001L), 52);
        long long26 = offsetDateTimeField21.roundHalfFloor((long) 67);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 46999L + "'", long24 == 46999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        java.lang.String str74 = unsupportedDateTimeField73.getName();
        try {
            long long77 = unsupportedDateTimeField73.addWrapField(1560342916207L, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "yearOfCentury" + "'", str74.equals("yearOfCentury"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder0.appendFractionOfHour((-1), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1/1/70 4:02 PM", (java.lang.Number) 8, (java.lang.Number) (-62167219199990L), (java.lang.Number) (short) -1);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) -1 + "'", number5.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 8 for 1/1/70 4:02 PM must be in the range [-62167219199990,-1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 8 for 1/1/70 4:02 PM must be in the range [-62167219199990,-1]"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test103");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        java.lang.String str6 = property5.toString();
//        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) 3);
//        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
//        int int10 = dateTime8.getMinuteOfDay();
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime8.withDate(960, (int) '4', 44949578);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianCalendar9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 755 + "'", int10 == 755);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        boolean boolean18 = skipDateTimeField10.isLenient();
        int int19 = skipDateTimeField10.getMinimumValue();
        boolean boolean20 = skipDateTimeField10.isLenient();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test105");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        mutableDateTime7.setRounding(dateTimeField8);
//        int int10 = mutableDateTime7.getWeekyear();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        mutableDateTime7.setYear(0);
//        long long18 = mutableDateTime7.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
//        java.lang.String str20 = gJChronology19.toString();
//        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField22 = gJChronology19.millisOfSecond();
//        org.joda.time.Instant instant23 = gJChronology19.getGregorianCutover();
//        try {
//            long long31 = gJChronology19.getDateTimeMillis(10, (int) '4', 70, 57600, 59, 79, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560342977295L + "'", long14 == 1560342977295L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167219199990L) + "'", long18 == (-62167219199990L));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]" + "'", str20.equals("GJChronology[UTC,cutover=0000-01-01T00:00:00.010Z]"));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(instant23);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(24, 97, (int) (short) 0, 40, 82, 46);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 40 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test107");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
//        java.util.Locale locale13 = null;
//        int int14 = property12.getMaximumTextLength(locale13);
//        int int15 = property12.getLeapAmount();
//        org.joda.time.DurationField durationField16 = property12.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
//        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime23 = dateTime21.plusMinutes(1);
//        long long24 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime.Property property25 = dateTime23.secondOfMinute();
//        org.joda.time.DateTime dateTime27 = dateTime23.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime28 = dateTime23.toLocalDateTime();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = zeroIsMaxDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) localDateTime28, locale29);
//        int int33 = zeroIsMaxDateTimeField19.getDifference((long) 1, 0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.millisOfSecond();
//        long long39 = buddhistChronology34.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology40.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology34, dateTimeField42, (int) (byte) 1);
//        long long46 = skipDateTimeField44.roundHalfCeiling(0L);
//        long long48 = skipDateTimeField44.roundHalfEven(0L);
//        int int50 = skipDateTimeField44.get((long) (short) 10);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime53 = dateTime51.plusMinutes(1);
//        long long54 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime53);
//        org.joda.time.DateTime.Property property55 = dateTime53.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateTime53.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime58 = dateTime53.toLocalDateTime();
//        int int59 = skipDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) localDateTime58);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology60 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField61 = buddhistChronology60.millisOfSecond();
//        long long65 = buddhistChronology60.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology66 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField67 = buddhistChronology66.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField68 = buddhistChronology66.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField70 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology60, dateTimeField68, (int) (byte) 1);
//        long long72 = skipDateTimeField70.roundHalfCeiling(0L);
//        long long74 = skipDateTimeField70.roundHalfEven(0L);
//        org.joda.time.ReadablePartial readablePartial75 = null;
//        int[] intArray80 = new int[] { (short) -1, 57660097, 10, (-5) };
//        int int81 = skipDateTimeField70.getMaximumValue(readablePartial75, intArray80);
//        int int82 = zeroIsMaxDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) localDateTime58, intArray80);
//        boolean boolean84 = zeroIsMaxDateTimeField19.isLeap(10L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560342977356L + "'", long24 == 1560342977356L);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(localDateTime28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "19" + "'", str30.equals("19"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 200L + "'", long39 == 200L);
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560342977359L + "'", long54 == 1560342977359L);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDateTime58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 200L + "'", long65 == 200L);
//        org.junit.Assert.assertNotNull(buddhistChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 0L + "'", long74 == 0L);
//        org.junit.Assert.assertNotNull(intArray80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 59 + "'", int81 == 59);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2 + "'", int82 == 2);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        long long23 = skipDateTimeField10.add((long) '#', (int) (byte) 1);
        boolean boolean25 = skipDateTimeField10.isLeap((-263001600001L));
        java.util.Locale locale26 = null;
        int int27 = skipDateTimeField10.getMaximumShortTextLength(locale26);
        long long29 = skipDateTimeField10.roundHalfEven(1560342914640L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1035L + "'", long23 == 1035L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560342915000L + "'", long29 == 1560342915000L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.addYears((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        mutableDateTime2.add(readablePeriod6);
        int int8 = mutableDateTime2.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipDateTimeField10.getAsShortText((long) '#', locale16);
        long long19 = skipDateTimeField10.roundFloor((-11L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1000L) + "'", long19 == (-1000L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        int int9 = property8.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.getMutableDateTime();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.millisOfSecond();
        long long16 = buddhistChronology11.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology11.clockhourOfDay();
        org.joda.time.DurationField durationField19 = buddhistChronology11.days();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology11.weekyear();
        org.joda.time.DateTime dateTime22 = mutableDateTime10.toDateTime((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withPeriodAdded(readablePeriod23, (-719522));
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 366 + "'", int9 == 366);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(readablePartial13, 961, locale15);
        java.lang.String str17 = skipDateTimeField10.getName();
        int int19 = skipDateTimeField10.get(0L);
        int int20 = skipDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "961" + "'", str16.equals("961"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "secondOfMinute" + "'", str17.equals("secondOfMinute"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime2.dayOfMonth();
        org.joda.time.MutableDateTime mutableDateTime13 = property12.roundHalfFloor();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes(52);
        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMillis(0);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
        org.joda.time.DateTime dateTime10 = property9.withMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes(1);
        org.joda.time.DateTime dateTime16 = dateTime12.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime18 = dateTime16.minusMillis(0);
        java.util.Date date19 = dateTime16.toDate();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime16.toDateTime(dateTimeZone20);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.millisOfSecond();
        long long28 = buddhistChronology23.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime29 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology23);
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology23.clockhourOfDay();
        org.joda.time.DurationField durationField31 = buddhistChronology23.days();
        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology23.yearOfEra();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology23.weekyear();
        java.util.Locale locale34 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 1, (org.joda.time.Chronology) buddhistChronology23, locale34);
        long long37 = dateTimeParserBucket35.computeMillis(true);
        long long39 = dateTimeParserBucket35.computeMillis(false);
        long long42 = dateTimeParserBucket35.computeMillis(true, "JulianChronology[UTC]");
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.millisOfSecond();
        long long48 = buddhistChronology43.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.monthOfYear();
        org.joda.time.DateTimeField dateTimeField51 = buddhistChronology49.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField53 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology43, dateTimeField51, (int) (byte) 1);
        dateTimeParserBucket35.saveField((org.joda.time.DateTimeField) skipDateTimeField53, 0);
        java.util.Locale locale56 = dateTimeParserBucket35.getLocale();
        java.util.Calendar calendar57 = dateTime21.toCalendar(locale56);
        int int58 = property9.getMaximumTextLength(locale56);
        org.joda.time.Interval interval59 = property9.toInterval();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 200L + "'", long28 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 200L + "'", long48 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(locale56);
        org.junit.Assert.assertNotNull(calendar57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 9 + "'", int58 == 9);
        org.junit.Assert.assertNotNull(interval59);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test116");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
//        java.lang.String str2 = dateTimeFormatter0.print((-11L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "December 31, 1969 11:59:59 PM UTC" + "'", str2.equals("December 31, 1969 11:59:59 PM UTC"));
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        java.lang.String str74 = unsupportedDateTimeField73.getName();
        try {
            long long77 = unsupportedDateTimeField73.add((long) (short) 0, (-5904531059697L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "yearOfCentury" + "'", str74.equals("yearOfCentury"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-30326227621965L), 57660097L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-30326169961868L) + "'", long2 == (-30326169961868L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.addWrapField(59);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.MutableDateTime.Property property7 = mutableDateTime5.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.halfdayOfDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(10L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumTextLength(locale13);
        int int15 = property12.getLeapAmount();
        org.joda.time.DurationField durationField16 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType17);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField19 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType17);
        org.joda.time.DurationField durationField20 = zeroIsMaxDateTimeField19.getLeapDurationField();
        long long22 = zeroIsMaxDateTimeField19.roundHalfEven(100L);
        int int24 = zeroIsMaxDateTimeField19.getLeapAmount((long) 4);
        int int26 = zeroIsMaxDateTimeField19.getMinimumValue((long) 'a');
        long long28 = zeroIsMaxDateTimeField19.roundHalfFloor((long) 8);
        int int31 = zeroIsMaxDateTimeField19.getDifference((-5904531057759L), 2440L);
        long long33 = zeroIsMaxDateTimeField19.roundCeiling((-62167218206990L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-136678) + "'", int31 == (-136678));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62167176000000L) + "'", long33 == (-62167176000000L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        boolean boolean11 = dateTimeFormatterBuilder10.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        long long27 = offsetDateTimeField21.add((long) (short) -1, (-5));
        int int28 = offsetDateTimeField21.getOffset();
        int int30 = offsetDateTimeField21.getMaximumValue((long) 1970);
        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField21.getWrappedField();
        long long34 = offsetDateTimeField21.add(100L, (int) ' ');
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5001L) + "'", long27 == (-5001L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 961 + "'", int28 == 961);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1020 + "'", int30 == 1020);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 32100L + "'", long34 == 32100L);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test123");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.months();
//        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(10L, chronology6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        mutableDateTime7.setRounding(dateTimeField8);
//        int int10 = mutableDateTime7.getWeekyear();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes(1);
//        long long14 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime13);
//        boolean boolean15 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        mutableDateTime7.setYear(0);
//        long long18 = mutableDateTime7.getMillis();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.millisOfSecond();
//        long long25 = buddhistChronology20.add((long) 100, (long) (byte) 100, 1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology26.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology20, dateTimeField28, (int) (byte) 1);
//        long long32 = skipDateTimeField30.roundHalfCeiling(0L);
//        long long34 = skipDateTimeField30.roundHalfEven(0L);
//        int int36 = skipDateTimeField30.get((long) (short) 10);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime39 = dateTime37.plusMinutes(1);
//        long long40 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime.Property property41 = dateTime39.secondOfMinute();
//        org.joda.time.DateTime dateTime43 = dateTime39.plusHours(1969);
//        org.joda.time.LocalDateTime localDateTime44 = dateTime39.toLocalDateTime();
//        int int45 = skipDateTimeField30.getMinimumValue((org.joda.time.ReadablePartial) localDateTime44);
//        long long47 = gJChronology19.set((org.joda.time.ReadablePartial) localDateTime44, (-31039L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560342978676L + "'", long14 == 1560342978676L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62167219199990L) + "'", long18 == (-62167219199990L));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 200L + "'", long25 == 200L);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560342978679L + "'", long40 == 1560342978679L);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(localDateTime44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560342978679L + "'", long47 == 1560342978679L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.lang.String str23 = offsetDateTimeField21.getAsText((long) 40);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "960" + "'", str23.equals("960"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYear((int) 'a', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfCentury(1970, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime dateTime4 = dateTime0.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (byte) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMinutes(5);
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds(1970);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(3);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer4, 1560342916848000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.millisOfSecond();
        long long6 = buddhistChronology1.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology1.yearOfCentury();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((-604799981L), (org.joda.time.Chronology) buddhistChronology1, locale9, (java.lang.Integer) 4);
        dateTimeParserBucket11.setOffset(0);
        int int14 = dateTimeParserBucket11.getOffset();
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(10L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.centuryOfEra();
        org.joda.time.DurationField durationField6 = property5.getDurationField();
        boolean boolean7 = gregorianChronology0.equals((java.lang.Object) property5);
        org.joda.time.MutableDateTime mutableDateTime9 = property5.set(0);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test130");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getName(0L);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        int int5 = gregorianChronology4.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(10L, chronology2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.yearOfCentury();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getLeapAmount();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property4.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendLiteral("1969-12-31T16:00:00.010-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendClockhourOfHalfday(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMinuteOfDay(366);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes(1);
        org.joda.time.DateTime dateTime22 = dateTime18.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMillis(0);
        java.util.Date date25 = dateTime22.toDate();
        org.joda.time.DateTime dateTime27 = dateTime22.minus((long) 57660097);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(10L, chronology29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.yearOfCentury();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        int int34 = property31.getLeapAmount();
        org.joda.time.DurationField durationField35 = property31.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 99, "Coordinated Universal Time");
        org.joda.time.DateTime dateTime41 = dateTime22.withField(dateTimeFieldType36, (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType36, 4, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType36, 59, 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology48 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = buddhistChronology48.millisOfSecond();
        long long53 = buddhistChronology48.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology54 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology54.monthOfYear();
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology54.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology48, dateTimeField56, (int) (byte) 1);
        long long60 = skipDateTimeField58.roundHalfCeiling(0L);
        long long62 = skipDateTimeField58.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial63 = null;
        int[] intArray68 = new int[] { (short) -1, 57660097, 10, (-5) };
        int int69 = skipDateTimeField58.getMaximumValue(readablePartial63, intArray68);
        org.joda.time.DurationField durationField70 = skipDateTimeField58.getDurationField();
        org.joda.time.DateTimeField dateTimeField71 = skipDateTimeField58.getWrappedField();
        org.joda.time.DurationField durationField72 = skipDateTimeField58.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType36, durationField72);
        java.lang.String str74 = unsupportedDateTimeField73.getName();
        long long77 = unsupportedDateTimeField73.add((long) 12, 1020);
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = unsupportedDateTimeField73.getType();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(buddhistChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 200L + "'", long53 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 59 + "'", int69 == 59);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "yearOfCentury" + "'", str74.equals("yearOfCentury"));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1020012L + "'", long77 == 1020012L);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(10L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.centuryOfEra();
        mutableDateTime2.setWeekyear(0);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime2.dayOfYear();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.centuryOfEra();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDate((long) (byte) 10);
        mutableDateTime2.addDays((int) '#');
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipDateTimeField10.getAsText(86399, locale18);
        long long22 = skipDateTimeField10.set((-5904531052319L), "19");
        org.joda.time.DateTimeField dateTimeField23 = skipDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "86399" + "'", str19.equals("86399"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-5904531040319L) + "'", long22 == (-5904531040319L));
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test134");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = buddhistChronology0.halfdays();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.withYear(1970);
//        boolean boolean6 = buddhistChronology0.equals((java.lang.Object) 1970);
//        org.joda.time.DurationField durationField7 = buddhistChronology0.hours();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes(1);
//        org.joda.time.DateTime dateTime12 = dateTime8.plus((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str15 = dateTimeZone13.getName(0L);
//        org.joda.time.DateTime dateTime16 = dateTime12.withZoneRetainFields(dateTimeZone13);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology0, dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology17.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.Chronology chronology21 = zonedChronology17.withZone(dateTimeZone20);
//        java.lang.String str22 = zonedChronology17.toString();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder26 = dateTimeZoneBuilder23.setFixedSavings("1969-12-31T16:00:00.100-08:00", 97);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder28 = dateTimeZoneBuilder26.setStandardOffset(0);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder31 = dateTimeZoneBuilder26.setFixedSavings("86399", 57120097);
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder33 = dateTimeZoneBuilder31.setStandardOffset(43);
//        boolean boolean34 = zonedChronology17.equals((java.lang.Object) 43);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(zonedChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], UTC]" + "'", str22.equals("ZonedChronology[BuddhistChronology[UTC], UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeZoneBuilder33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        long long14 = skipDateTimeField10.roundHalfEven(0L);
        int int16 = skipDateTimeField10.get((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText(readablePartial17, (-5), locale19);
        java.util.Locale locale21 = null;
        int int22 = skipDateTimeField10.getMaximumShortTextLength(locale21);
        org.joda.time.DurationField durationField23 = skipDateTimeField10.getRangeDurationField();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime27 = dateTime25.plusMinutes(1);
        org.joda.time.DateTime dateTime29 = dateTime25.plus((long) (byte) -1);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis(0);
        java.util.Date date32 = dateTime29.toDate();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = dateTime29.toDateTime(dateTimeZone33);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.millisOfSecond();
        long long41 = buddhistChronology36.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.MutableDateTime mutableDateTime42 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) buddhistChronology36);
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology36.clockhourOfDay();
        org.joda.time.DurationField durationField44 = buddhistChronology36.days();
        org.joda.time.DateTimeField dateTimeField45 = buddhistChronology36.yearOfEra();
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology36.weekyear();
        java.util.Locale locale47 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket48 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 1, (org.joda.time.Chronology) buddhistChronology36, locale47);
        long long50 = dateTimeParserBucket48.computeMillis(true);
        long long52 = dateTimeParserBucket48.computeMillis(false);
        long long55 = dateTimeParserBucket48.computeMillis(true, "JulianChronology[UTC]");
        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField57 = buddhistChronology56.millisOfSecond();
        long long61 = buddhistChronology56.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology62 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField63 = buddhistChronology62.monthOfYear();
        org.joda.time.DateTimeField dateTimeField64 = buddhistChronology62.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology56, dateTimeField64, (int) (byte) 1);
        dateTimeParserBucket48.saveField((org.joda.time.DateTimeField) skipDateTimeField66, 0);
        java.util.Locale locale69 = dateTimeParserBucket48.getLocale();
        java.util.Calendar calendar70 = dateTime34.toCalendar(locale69);
        java.lang.String str71 = skipDateTimeField10.getAsText((-57660), locale69);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-5" + "'", str20.equals("-5"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 200L + "'", long41 == 200L);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
        org.junit.Assert.assertNotNull(buddhistChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 200L + "'", long61 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(locale69);
        org.junit.Assert.assertNotNull(calendar70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "-57660" + "'", str71.equals("-57660"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes(1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readablePeriod3);
        org.joda.time.DateTime.Property property5 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime7 = property5.addWrapFieldToCopy(1969);
        org.joda.time.DateTime dateTime8 = property5.roundHalfFloorCopy();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property5.getAsShortText(locale9);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.millisOfSecond();
        long long5 = buddhistChronology0.add((long) 100, (long) (byte) 100, 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.monthOfYear();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField8, (int) (byte) 1);
        long long12 = skipDateTimeField10.roundHalfCeiling(0L);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField10.getMaximumShortTextLength(locale13);
        long long17 = skipDateTimeField10.add((long) '4', (int) (short) 0);
        long long19 = skipDateTimeField10.roundHalfFloor((long) 57660097);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, 961);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField21.getAsShortText((int) 'a', locale23);
        long long27 = offsetDateTimeField21.add((long) (short) -1, (-5));
        int int28 = offsetDateTimeField21.getOffset();
        int int30 = offsetDateTimeField21.getMaximumValue((long) 1970);
        int int31 = offsetDateTimeField21.getOffset();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 200L + "'", long5 == 200L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 57660000L + "'", long19 == 57660000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "97" + "'", str24.equals("97"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-5001L) + "'", long27 == (-5001L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 961 + "'", int28 == 961);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1020 + "'", int30 == 1020);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 961 + "'", int31 == 961);
    }
}

