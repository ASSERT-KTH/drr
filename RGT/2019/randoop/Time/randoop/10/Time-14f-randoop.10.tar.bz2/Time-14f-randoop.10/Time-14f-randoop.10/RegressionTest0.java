import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(100L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
        try {
            org.joda.time.LocalDateTime localDateTime5 = dateTimeFormatter0.parseLocalDateTime("����0101T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����0101T������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0101T������.000" + "'", str3.equals("����0101T������.000"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) -1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.MonthDay monthDay11 = monthDay9.minusMonths((int) (byte) 1);
        int[] intArray15 = new int[] { (short) 1, 100 };
        try {
            int[] intArray17 = delegatedDateTimeField7.set((org.joda.time.ReadablePartial) monthDay9, (-1), intArray15, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", (int) (byte) 100, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hi! must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        int int2 = monthDay1.getMonthOfYear();
        try {
            org.joda.time.MonthDay monthDay4 = monthDay1.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        boolean boolean6 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime5.toMutableDateTime();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test019");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        java.util.Locale locale13 = null;
//        try {
//            java.lang.String str14 = dateTime7.toString("hi!", locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.DateTimeField dateTimeField14 = delegatedDateTimeField10.getWrappedField();
        long long17 = delegatedDateTimeField10.addWrapField((long) 6, (int) '#');
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35006L + "'", long17 == 35006L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("����0101T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����0101T������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        try {
//            java.lang.String str7 = monthDay2.toString("hi!");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology2);
//        java.lang.String str4 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) monthDay3);
//        try {
//            org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "����0615T������.000" + "'", str4.equals("����0615T������.000"));
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology3);
//        java.lang.String str5 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) monthDay4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = monthDay4.getFieldType(0);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "����0615T������.000" + "'", str5.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        try {
            org.joda.time.DateTime dateTime4 = property2.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        org.joda.time.DateTimeField dateTimeField11 = delegatedDateTimeField10.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology13);
//        java.lang.String str15 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) monthDay14);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay14.getFieldType(0);
//        int int18 = delegatedDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) monthDay14);
//        int[] intArray19 = new int[] {};
//        try {
//            gregorianChronology2.validate((org.joda.time.ReadablePartial) monthDay14, intArray19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "����0615T������.000" + "'", str15.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399 + "'", int18 == 86399);
//        org.junit.Assert.assertNotNull(intArray19);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology8);
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (short) 10, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must not be larger than 31");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime7.withPeriodAdded(readablePeriod12, 1);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        java.lang.String str16 = property15.getAsText();
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology21 = copticChronology17.withZone(dateTimeZone20);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) property15, dateTimeZone20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = gregorianChronology2.get(readablePeriod3, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology3);
        try {
            long long23 = gregorianChronology3.getDateTimeMillis(86399, 1, (int) 'a', 0, 6, 20, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (long) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(10L, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        try {
            long long10 = offsetDateTimeField7.set((long) (byte) 10, "--12-01");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"--12-01\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("--06-15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: --06-15");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "����0101T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) 'a', (int) ' ', 10, 6, (int) (short) 10, (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 10, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        boolean boolean6 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime.Property property7 = dateTime3.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        boolean boolean12 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime11);
//        long long13 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime9.withPeriodAdded(readablePeriod14, 1);
//        org.joda.time.DateTime.Property property17 = dateTime16.yearOfCentury();
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
//        int int7 = dateTime3.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology14);
        int int16 = monthDay15.getMonthOfYear();
        int[] intArray18 = null;
        int[] intArray20 = delegatedDateTimeField10.add((org.joda.time.ReadablePartial) monthDay15, (int) '#', intArray18, 0);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay15.getFieldType((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNull(intArray20);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) 97000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-10L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        try {
            int[] intArray19 = gregorianChronology3.get(readablePeriod16, (long) 6, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withEra((int) (short) 1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime4.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        boolean boolean13 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime12);
//        long long14 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime10.withPeriodAdded(readablePeriod15, 1);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(chronology3);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withDayOfMonth((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int8 = offsetDateTimeField7.getOffset();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText((int) (short) 10, locale10);
        java.util.Locale locale14 = null;
        try {
            long long15 = offsetDateTimeField7.set((long) '4', "", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("����0615T������.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"����0615T������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('#');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendFractionOfSecond((-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 20);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.centuryOfEra();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded(readableDuration11, 2019);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime8);
        try {
            long long22 = gJChronology14.getDateTimeMillis(4, 1, (int) (byte) 100, (int) '#', (int) (short) -1, (-1), 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("--12-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--12-01\" is malformed at \"-12-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("10");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"10/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfCentury();
        org.joda.time.Chronology chronology5 = gregorianChronology2.withUTC();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(chronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField8, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType13);
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField14.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology17);
        java.lang.String str19 = dateTimeFormatter16.print((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType(0);
        int int22 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay18);
        boolean boolean23 = monthDay6.isAfter((org.joda.time.ReadablePartial) monthDay18);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "����0101T������.000" + "'", str19.equals("����0101T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 86399 + "'", int22 == 86399);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.withDurationAdded(readableDuration6, (int) (short) 10);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
        org.joda.time.ReadableInstant readableInstant11 = null;
        long long12 = property10.getDifferenceAsLong(readableInstant11);
        org.joda.time.DurationField durationField13 = property10.getLeapDurationField();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("+100:35");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+100:35\" is malformed at \":35\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withTime(1, (int) (short) -1, (int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField13, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType18);
        int int21 = delegatedDateTimeField19.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField19.getDurationField();
        org.joda.time.DurationField durationField23 = delegatedDateTimeField19.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.MonthDay monthDay27 = monthDay25.minusMonths((int) (byte) 1);
        int int28 = delegatedDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) monthDay27);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField31, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 1);
        int int40 = offsetDateTimeField37.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone41);
        org.joda.time.DateTime.Property property43 = dateTime42.weekyear();
        org.joda.time.YearMonthDay yearMonthDay44 = dateTime42.toYearMonthDay();
        int[] intArray50 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray52 = offsetDateTimeField37.add((org.joda.time.ReadablePartial) yearMonthDay44, (int) 'a', intArray50, (int) (short) 0);
        try {
            int[] intArray54 = offsetDateTimeField7.add((org.joda.time.ReadablePartial) monthDay27, 10, intArray50, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86399 + "'", int21 == 86399);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86399 + "'", int28 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(yearMonthDay44);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', (int) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) 'a');
        org.joda.time.DateTime dateTime8 = dateTime6.plusDays((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withTime((int) (short) 10, (-1), (int) (short) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int10 = offsetDateTimeField7.getDifference((long) (byte) 1, (long) 0);
        java.util.Locale locale13 = null;
        try {
            long long14 = offsetDateTimeField7.set(0L, "hi!", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType(0);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField11, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11, dateTimeFieldType16);
        int int19 = delegatedDateTimeField17.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeField) delegatedDateTimeField17);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = delegatedDateTimeField17.getType();
        try {
            org.joda.time.MonthDay monthDay23 = monthDay4.withField(dateTimeFieldType21, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 86399 + "'", int19 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((int) '#', (int) (short) 10, (int) (short) 100, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property3.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.yearOfEra();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (byte) 100, 20, (int) '4', 0, (int) (byte) -1, (int) (short) 10, 86399, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            long long2 = dateTimeFormatter0.parseMillis("--12-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--12-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) monthDay3);
        try {
            org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.parse("JulianChronology[UTC]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "����0101T������.000" + "'", str4.equals("����0101T������.000"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, (int) (byte) 10, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.MonthDay monthDay11 = monthDay9.minusMonths((int) (byte) 1);
        int[] intArray19 = new int[] { 0, 'a', ' ', 100, 20, 16500020 };
        java.util.Locale locale21 = null;
        try {
            int[] intArray22 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) monthDay9, 4, intArray19, "hi!", locale21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "+100:35");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime7.withPeriodAdded(readablePeriod12, 1);
        try {
            org.joda.time.DateTime dateTime16 = dateTime14.withEra((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology10);
        java.lang.String str12 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = monthDay11.getFieldType(0);
        int int15 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay11);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.MonthDay monthDay18 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology17);
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = monthDay11.toString("hi!", locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����0101T������.000" + "'", str12.equals("����0101T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime9);
        int int14 = dateTime9.getMinuteOfDay();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 275 + "'", int14 == 275);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 35006L, (java.lang.Number) 0.0f, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTimeZoneShortName();
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.append(dateTimeParser11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) (byte) 1, (int) (byte) 1, (-1), 20, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray6 = gregorianChronology0.get(readablePeriod4, (long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
        java.lang.String str20 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        try {
            long long30 = copticChronology22.getDateTimeMillis((int) '4', 6, (int) (byte) 100, (int) (byte) 100, (int) (byte) 0, 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(copticChronology22);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime7.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        boolean boolean16 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime15);
        long long17 = property11.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.withPeriodAdded(readablePeriod18, 1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime20);
        java.lang.String str22 = dateTimeZone5.getID();
        org.joda.time.Chronology chronology23 = julianChronology2.withZone(dateTimeZone5);
        try {
            org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(16500020, (int) '4', (org.joda.time.Chronology) julianChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16500020 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+100:35" + "'", str22.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType11);
        org.joda.time.DateTimeField dateTimeField13 = delegatedDateTimeField12.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology15);
        java.lang.String str17 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = monthDay16.getFieldType(0);
        int int20 = delegatedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
        boolean boolean21 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField23, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23, dateTimeFieldType28);
        org.joda.time.DateTimeField dateTimeField30 = delegatedDateTimeField29.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology32);
        java.lang.String str34 = dateTimeFormatter31.print((org.joda.time.ReadablePartial) monthDay33);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = monthDay33.getFieldType(0);
        int int37 = delegatedDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) monthDay33);
        int int38 = monthDay16.compareTo((org.joda.time.ReadablePartial) monthDay33);
        try {
            org.joda.time.MonthDay monthDay40 = monthDay16.withDayOfMonth((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����0101T������.000" + "'", str17.equals("����0101T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 86399 + "'", int20 == 86399);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "����0101T������.000" + "'", str34.equals("����0101T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 86399 + "'", int37 == 86399);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendCenturyOfEra(6, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
        long long10 = delegatedDateTimeField7.remainder((long) (byte) 100);
        java.lang.String str12 = delegatedDateTimeField7.getAsText(2019000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        int int16 = skipDateTimeField15.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        boolean boolean12 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property13 = dateTime9.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology14);
        int int16 = monthDay15.getMonthOfYear();
        int int17 = property13.compareTo((org.joda.time.ReadablePartial) monthDay15);
        java.lang.String str18 = monthDay15.toString();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay15, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "--01-01" + "'", str18.equals("--01-01"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("+100:35");
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        boolean boolean7 = dateTimeFormatterBuilder5.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) 'a');
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (byte) 0);
        boolean boolean10 = dateTime8.isAfter((long) 2019);
        try {
            java.lang.String str12 = dateTime8.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField7.getDurationField();
        org.joda.time.DurationField durationField11 = delegatedDateTimeField7.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.MonthDay monthDay15 = monthDay13.minusMonths((int) (byte) 1);
        int int16 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray19 = monthDay18.getFieldTypes();
        boolean boolean20 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField23, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 1);
        int int32 = offsetDateTimeField29.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.DateTime.Property property35 = dateTime34.weekyear();
        org.joda.time.YearMonthDay yearMonthDay36 = dateTime34.toYearMonthDay();
        int[] intArray42 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray44 = offsetDateTimeField29.add((org.joda.time.ReadablePartial) yearMonthDay36, (int) 'a', intArray42, (int) (short) 0);
        try {
            int[] intArray46 = delegatedDateTimeField7.set((org.joda.time.ReadablePartial) monthDay18, 16500020, intArray42, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16500020");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86399 + "'", int16 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(yearMonthDay36);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfMinute((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType11);
        org.joda.time.DateTimeField dateTimeField13 = delegatedDateTimeField12.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology15);
        java.lang.String str17 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = monthDay16.getFieldType(0);
        int int20 = delegatedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
        boolean boolean21 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField26, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType31);
        int int34 = delegatedDateTimeField32.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology24, (org.joda.time.DateTimeField) delegatedDateTimeField32);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField32.getType();
        try {
            org.joda.time.MonthDay monthDay38 = monthDay4.withField(dateTimeFieldType36, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����0101T������.000" + "'", str17.equals("����0101T������.000"));
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 86399 + "'", int20 == 86399);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 86399 + "'", int34 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
        int int7 = property6.getMaximumValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 999 + "'", int7 == 999);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.withDurationAdded(readableDuration6, (int) (short) 10);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
        org.joda.time.ReadableInstant readableInstant11 = null;
        long long12 = property10.getDifferenceAsLong(readableInstant11);
        int int13 = property10.getMinimumValueOverall();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime7.withPeriodAdded(readablePeriod12, 1);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime17 = dateTime14.withYearOfCentury((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("--06-15");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--06-15\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTime();
        org.joda.time.DateTime.Property property9 = dateTime6.millisOfSecond();
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = dateTime6.minusYears(20);
        org.joda.time.DateTime.Property property14 = dateTime6.dayOfMonth();
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
        long long10 = delegatedDateTimeField7.remainder((long) (byte) 100);
        long long12 = delegatedDateTimeField7.roundHalfFloor(2000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2000L + "'", long12 == 2000L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral("+100:35");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra((-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getLeapAmount((long) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 20L + "'", long0 == 20L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        int int14 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField15 = gregorianChronology2.halfdays();
        try {
            long long23 = gregorianChronology2.getDateTimeMillis(1, (int) '#', 1, 97, (int) (byte) 0, (int) ' ', 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
        java.lang.String str20 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology23 = copticChronology22.withUTC();
        try {
            long long31 = copticChronology22.getDateTimeMillis(16500020, (int) (short) 1, 6, (int) (byte) -1, 16500020, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("--06-15", 0, (int) ' ', 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for --06-15 must be in the range [32,6]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (short) 100, 2019, (int) (byte) 0, 0, (-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) 'a');
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.plusMonths(0);
        org.joda.time.DateTime dateTime12 = dateTime10.withCenturyOfEra(6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(0L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField7.getDurationField();
        boolean boolean11 = delegatedDateTimeField7.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        try {
            long long14 = offsetDateTimeField7.set((long) 20, "CopticChronology[+100:35]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[+100:35]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType7);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField8.getWrappedField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField9);
        java.lang.String str11 = skipUndoDateTimeField10.getName();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "secondOfDay" + "'", str11.equals("secondOfDay"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology12 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone11);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField21, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType26);
        int int29 = delegatedDateTimeField27.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, (org.joda.time.DateTimeField) delegatedDateTimeField27);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = delegatedDateTimeField27.getType();
        try {
            org.joda.time.MonthDay.Property property32 = monthDay16.property(dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86399 + "'", int29 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 1);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        java.util.Locale locale25 = null;
//        try {
//            java.lang.String str26 = unsupportedDateTimeField20.getAsShortText((int) (byte) 0, locale25);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        try {
            org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        try {
//            long long22 = unsupportedDateTimeField20.roundHalfFloor(97000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField18, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType23);
        int int26 = delegatedDateTimeField24.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, (org.joda.time.DateTimeField) delegatedDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField24.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType28, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399 + "'", int26 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime1.withDurationAdded(readableDuration6, (int) (short) 10);
//        org.joda.time.TimeOfDay timeOfDay9 = dateTime8.toTimeOfDay();
//        int int10 = dateTime8.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(timeOfDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4539 + "'", int10 == 4539);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, (int) ' ');
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        boolean boolean12 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property13 = dateTime9.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        boolean boolean18 = dateTime15.isBefore((org.joda.time.ReadableInstant) dateTime17);
        long long19 = property13.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime22 = dateTime15.withPeriodAdded(readablePeriod20, 1);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime22);
        java.lang.String str24 = dateTimeZone7.getID();
        org.joda.time.Chronology chronology25 = julianChronology4.withZone(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime26 = instant3.toMutableDateTime(dateTimeZone7);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+100:35" + "'", str24.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("ZonedChronology[GregorianChronology[UTC], +100:35]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'ZonedChronology[GregorianChronology[UTC], +100:35]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("--12-01");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("secondOfDay", (int) (short) 1, 4, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for secondOfDay must be in the range [4,2019]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int8 = offsetDateTimeField7.getOffset();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText((int) (short) 10, locale10);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField7.getMaximumTextLength(locale12);
        java.util.Locale locale16 = null;
        try {
            long long17 = offsetDateTimeField7.set(0L, "20190615T134023.343-0700", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"20190615T134023.343-0700\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        try {
//            int int25 = unsupportedDateTimeField20.getMinimumValue((long) 16500020);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 171);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) 'a');
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (byte) 0);
        boolean boolean10 = dateTime8.isAfter((long) 2019);
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfSecond(86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
//        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
//        java.lang.String str20 = dateTimeZone3.getID();
//        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
//        java.lang.String str22 = julianChronology0.toString();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.Chronology chronology24 = julianChronology0.withZone(dateTimeZone23);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JulianChronology[UTC]" + "'", str22.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology24);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.junit.Assert.assertNotNull(monthDay0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean5 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime4.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        boolean boolean11 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.centuryOfEra();
        org.joda.time.DateTime dateTime13 = dateTime10.toDateTime();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime4, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (-1), chronology14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
//        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendClockhourOfDay(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology11);
//        java.lang.String str13 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.append(dateTimeFormatter10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter10.withOffsetParsed();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "����0615T������.000" + "'", str13.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
        try {
            long long19 = skipUndoDateTimeField13.set((long) (-1), (-98));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = monthDay22.getFieldTypes();
//        java.util.Locale locale24 = null;
//        try {
//            java.lang.String str25 = unsupportedDateTimeField20.getAsText((org.joda.time.ReadablePartial) monthDay22, locale24);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-362100010L), (java.lang.Number) (-11957290L), (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        int int8 = gregorianChronology3.getMinimumDaysInFirstWeek();
        try {
            long long13 = gregorianChronology3.getDateTimeMillis(20, 275, 0, 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 275 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (short) 0, 2019, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for  must be in the range [2019,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendTimeZoneOffset("19", false, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean5 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime4.toMutableDateTime();
//        org.joda.time.DateTime.Property property7 = dateTime4.millisOfSecond();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property9 = dateTime4.hourOfDay();
//        java.util.Locale locale10 = null;
//        java.util.Calendar calendar11 = dateTime4.toCalendar(locale10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "20190620T011543.328+10035" + "'", str8.equals("20190620T011543.328+10035"));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(calendar11);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(100, 171, 0, 4, 0, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        boolean boolean6 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minus((long) 'a');
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime12 = dateTime8.plusMonths(0);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField8, (int) '#');
        java.lang.String str12 = delegatedDateTimeField8.getAsText((long) (byte) -1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "86399" + "'", str12.equals("86399"));
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        try {
//            long long26 = unsupportedDateTimeField20.set((long) (byte) 10, 999);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("--12-01");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = monthDay4.getFieldType(0);
        try {
            int int8 = monthDay4.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property2.getFieldType();
        java.lang.String str4 = property2.getAsShortText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        try {
//            org.joda.time.MonthDay monthDay12 = monthDay7.withField(dateTimeFieldType10, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField7.getAsText((int) (short) 1, locale15);
        int int17 = offsetDateTimeField7.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        try {
//            long long27 = unsupportedDateTimeField20.set((long) (short) 10, "20190620T011543.328+10035");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime8 = dateTime3.minusHours((int) '#');
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10", "(\"org.joda.time.JodaTimePermission\" \"--12-01\")");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(durationFieldType4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology2.hours();
        long long7 = durationField4.subtract((long) ' ', 1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+100:35,mdfw=1]" + "'", str3.equals("GregorianChronology[+100:35,mdfw=1]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599968L) + "'", long7 == (-3599968L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+100:35,mdfw=1]" + "'", str3.equals("GregorianChronology[+100:35,mdfw=1]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((int) (byte) 10);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        int int12 = dateTime7.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4544 + "'", int12 == 4544);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 0, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType10, 86399, 86400);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder6.appendYearOfCentury((-98), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        java.util.Locale locale26 = null;
//        try {
//            java.lang.String str27 = unsupportedDateTimeField20.getAsText(0L, locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded(readableDuration11, 2019);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime16 = dateTime8.withHourOfDay((int) (short) 1);
//        int int17 = dateTime8.getMillisOfDay();
//        try {
//            org.joda.time.Instant instant18 = new org.joda.time.Instant((java.lang.Object) int17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4545348 + "'", int17 == 4545348);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime4.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        boolean boolean13 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime12);
        long long14 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime10.withPeriodAdded(readablePeriod15, 1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.minuteOfHour();
        try {
            long long24 = gJChronology18.getDateTimeMillis((int) '#', (int) (byte) -1, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int10 = offsetDateTimeField7.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        int[] intArray20 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray22 = offsetDateTimeField7.add((org.joda.time.ReadablePartial) yearMonthDay14, (int) 'a', intArray20, (int) (short) 0);
        boolean boolean24 = offsetDateTimeField7.isLeap((long) 86399);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("GJChronology[+100:35,cutover=2019-06-15T20:40:44.906Z]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[+100:35,cutover=201...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        int int2 = copticChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology1.getZone();
        org.joda.time.Chronology chronology4 = iSOChronology0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded(readableDuration11, 2019);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property15 = dateTime8.dayOfYear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        long long7 = cachedDateTimeZone3.convertLocalToUTC(100L, false);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-362099900L) + "'", long7 == (-362099900L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        try {
            long long17 = delegatedDateTimeField10.set((long) 6, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('#');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYear(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10.0f, (java.lang.Number) 100L, (java.lang.Number) 4539);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-98), (int) (short) 100, 275, 0, (int) (byte) 100, 171, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology21);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = monthDay22.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.yearOfCentury();
//        org.joda.time.Chronology chronology27 = gregorianChronology24.withUTC();
//        org.joda.time.MonthDay monthDay28 = monthDay22.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology24);
//        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology33 = copticChronology29.withZone(dateTimeZone32);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
//        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology24, dateTimeZone32);
//        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay(dateTimeZone32);
//        try {
//            int int38 = unsupportedDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) monthDay37);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(copticChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(zonedChronology36);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) 'a');
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (byte) 0);
//        org.joda.time.DateTime dateTime10 = dateTime6.plusMonths(0);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560631246626L + "'", long12 == 1560631246626L);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime7.toMutableDateTime();
//        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "UTC", (int) 'a');
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology17 = copticChronology13.withZone(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        boolean boolean22 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime.Property property23 = dateTime21.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.DateTime dateTime26 = dateTime21.withDurationAdded(readableDuration24, 2019);
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.MutableDateTime mutableDateTime28 = mutableDateTime9.toMutableDateTime(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-98) + "'", int12 == (-98));
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        long long15 = offsetDateTimeField7.roundHalfEven((long) 16500020);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField7.getAsText(97, locale17);
        long long20 = offsetDateTimeField7.roundHalfFloor((long) 2019);
        org.joda.time.DurationField durationField21 = offsetDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16500000L + "'", long15 == 16500000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2000L + "'", long20 == 2000L);
        org.junit.Assert.assertNull(durationField21);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        try {
//            org.joda.time.MonthDay.Property property7 = monthDay2.property(dateTimeFieldType6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        try {
//            int int26 = unsupportedDateTimeField20.getLeapAmount((long) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "--12-01");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType22);
//        int int25 = zeroIsMaxDateTimeField23.getLeapAmount((long) 86399);
//        long long27 = zeroIsMaxDateTimeField23.roundCeiling((long) 5);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1000L + "'", long27 == 1000L);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology12 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone11);
        try {
            long long20 = gregorianChronology3.getDateTimeMillis(15, 0, 97, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(zonedChronology15);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Appendable appendable2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = monthDay4.getFieldTypes();
        org.joda.time.LocalDate localDate7 = monthDay4.toLocalDate((int) (byte) 1);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime7.toMutableDateTime();
        int int12 = dateTimeFormatter3.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "1", 20);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-21) + "'", int12 == (-21));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendClockhourOfDay(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.append(dateTimePrinter10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10", "(\"org.joda.time.JodaTimePermission\" \"--12-01\")");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        java.lang.String str5 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"(\"org.joda.time.JodaTimePermission\" \"--12-01\")\" for 10 is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"(\"org.joda.time.JodaTimePermission\" \"--12-01\")\" for 10 is not supported"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean5 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime4.toMutableDateTime();
        int int7 = mutableDateTime6.getCenturyOfEra();
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime6, "", 275);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-276) + "'", int10 == (-276));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int10 = offsetDateTimeField7.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        int[] intArray20 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray22 = offsetDateTimeField7.add((org.joda.time.ReadablePartial) yearMonthDay14, (int) 'a', intArray20, (int) (short) 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsShortText((long) '#', locale24);
        long long28 = offsetDateTimeField7.add(0L, 2019);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField7.getMaximumTextLength(locale29);
        int int32 = offsetDateTimeField7.getLeapAmount((long) 86399);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019000L + "'", long28 == 2019000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        try {
//            java.lang.String str25 = unsupportedDateTimeField20.getAsShortText((long) 20);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
//        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology10);
//        java.lang.String str12 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = monthDay11.getFieldType(0);
//        int int15 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, 5);
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology26 = copticChronology22.withZone(dateTimeZone25);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone25);
//        long long30 = dateTimeZone25.convertLocalToUTC((-10L), true);
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay(dateTimeZone25);
//        int int32 = monthDay21.compareTo((org.joda.time.ReadablePartial) monthDay31);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����0615T������.000" + "'", str12.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-362100010L) + "'", long30 == (-362100010L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10", "(\"org.joda.time.JodaTimePermission\" \"--12-01\")");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"(\"org.joda.time.JodaTimePermission\" \"--12-01\")\" for 10 is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"(\"org.joda.time.JodaTimePermission\" \"--12-01\")\" for 10 is not supported"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendYear(275, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology14);
        int int16 = monthDay15.getMonthOfYear();
        int[] intArray18 = null;
        int[] intArray20 = delegatedDateTimeField10.add((org.joda.time.ReadablePartial) monthDay15, (int) '#', intArray18, 0);
        int int22 = delegatedDateTimeField10.getLeapAmount((long) 86399);
        org.joda.time.DurationField durationField23 = delegatedDateTimeField10.getLeapDurationField();
        boolean boolean24 = delegatedDateTimeField10.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNull(intArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            long long3 = gregorianChronology0.set(readablePartial1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology12 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone11);
        org.joda.time.DurationField durationField16 = zonedChronology15.centuries();
        java.lang.String str17 = zonedChronology15.toString();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology15.secondOfMinute();
        try {
            long long26 = zonedChronology15.getDateTimeMillis(4, (int) (short) 100, (-1), (int) (byte) -1, (-276), 20, 86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +100:35]" + "'", str17.equals("ZonedChronology[GregorianChronology[UTC], +100:35]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = dateTime3.minusYears(20);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
        org.joda.time.DateTime dateTime14 = dateTime3.withZone(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) 'a');
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (byte) 0);
//        try {
//            org.joda.time.DateTime dateTime12 = dateTime8.withDate(10, 0, (-21));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMillisOfDay(10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField13, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType18);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField24, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType29);
        int int32 = delegatedDateTimeField30.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, (org.joda.time.DateTimeField) delegatedDateTimeField30);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = delegatedDateTimeField30.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType34);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType34, 0, (-98), (int) ' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder11.appendSignedDecimal(dateTimeFieldType34, 0, (-98));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86399 + "'", int32 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime7.withPeriodAdded(readablePeriod12, 1);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        java.lang.String str16 = property15.getAsText();
//        java.util.Locale locale17 = null;
//        int int18 = property15.getMaximumShortTextLength(locale17);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology25);
//        int[] intArray30 = new int[] { 97, 4546 };
//        java.util.Locale locale32 = null;
//        try {
//            int[] intArray33 = unsupportedDateTimeField20.set((org.joda.time.ReadablePartial) monthDay26, 2019, intArray30, "UTC", locale32);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(intArray30);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.MonthDay monthDay9 = monthDay1.minusMonths(0);
        org.joda.time.MonthDay monthDay11 = monthDay1.plusMonths((int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
//        java.lang.String str3 = monthDay1.toString();
//        org.joda.time.MonthDay.Property property4 = monthDay1.dayOfMonth();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField9, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType14);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField20, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType25);
//        int int28 = delegatedDateTimeField26.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology18, (org.joda.time.DateTimeField) delegatedDateTimeField26);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField26.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder7.appendText(dateTimeFieldType30);
//        try {
//            int int33 = monthDay1.get(dateTimeFieldType30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86399 + "'", int28 == 86399);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        try {
//            long long25 = unsupportedDateTimeField20.roundHalfEven((long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType22);
//        long long25 = zeroIsMaxDateTimeField23.roundHalfFloor((long) 97);
//        java.lang.String str27 = zeroIsMaxDateTimeField23.getAsShortText((long) 5);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "86400" + "'", str27.equals("86400"));
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) 1, dateTimeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.withDurationAdded(readableDuration6, (int) (short) 10);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTime.Property property10 = dateTime8.millisOfSecond();
        int int11 = property10.getMinimumValueOverall();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendWeekyear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendTimeZoneShortName();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property16.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendDecimal(dateTimeFieldType17, 86399, 86400);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType17, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        try {
//            int int25 = unsupportedDateTimeField20.getMinimumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10", "(\"org.joda.time.JodaTimePermission\" \"--12-01\")");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"--12-01\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"--12-01\")"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.yearOfEra();
        java.lang.String str4 = gregorianChronology0.toString();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((long) 171, (int) '#', (int) (byte) -1, 4546, 86400);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendWeekyear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField7.getDurationField();
        org.joda.time.DurationField durationField11 = delegatedDateTimeField7.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.MonthDay monthDay15 = monthDay13.minusMonths((int) (byte) 1);
        int int16 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay15);
        int int17 = delegatedDateTimeField7.getMinimumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField7.getAsText(97000L, locale19);
        org.joda.time.DurationField durationField21 = delegatedDateTimeField7.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86399 + "'", int16 == 86399);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "97" + "'", str20.equals("97"));
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime8 = dateTime3.minusHours((int) '#');
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTime.Property property10 = dateTime8.year();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(durationField11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 20);
        try {
            org.joda.time.Instant instant4 = org.joda.time.Instant.parse("weekyear", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"weekyear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("--12-01");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(6);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.append(dateTimePrinter11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int10 = offsetDateTimeField7.getDifference((long) (byte) 1, (long) 0);
        long long12 = offsetDateTimeField7.roundHalfCeiling(0L);
        long long15 = offsetDateTimeField7.add((long) 97, (-10L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9903L) + "'", long15 == (-9903L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneName();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.minusMinutes((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField18, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType23);
        int int26 = delegatedDateTimeField24.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, (org.joda.time.DateTimeField) delegatedDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField24.getType();
        boolean boolean29 = dateTime13.isSupported(dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder10.appendSignedDecimal(dateTimeFieldType28, 86399, (int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendFractionOfDay((-1), 4546);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399 + "'", int26 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(10, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField18, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType23);
        int int26 = delegatedDateTimeField24.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, (org.joda.time.DateTimeField) delegatedDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField24.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType28, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder32.appendYear((int) (byte) 0, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendYearOfEra((int) '4', 16500020);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399 + "'", int26 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology25);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray27 = monthDay26.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.yearOfCentury();
//        org.joda.time.Chronology chronology31 = gregorianChronology28.withUTC();
//        org.joda.time.MonthDay monthDay32 = monthDay26.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology28);
//        org.joda.time.MonthDay monthDay34 = monthDay26.minusMonths(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField37, (int) (short) 1, 1, 6);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 1);
//        int int46 = offsetDateTimeField43.getDifference((long) (byte) 1, (long) 0);
//        org.joda.time.DateTimeZone dateTimeZone47 = null;
//        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone47);
//        org.joda.time.DateTime.Property property49 = dateTime48.weekyear();
//        org.joda.time.YearMonthDay yearMonthDay50 = dateTime48.toYearMonthDay();
//        int[] intArray56 = new int[] { (short) 1, 2019, 2019, (short) 1 };
//        int[] intArray58 = offsetDateTimeField43.add((org.joda.time.ReadablePartial) yearMonthDay50, (int) 'a', intArray56, (int) (short) 0);
//        try {
//            int[] intArray60 = unsupportedDateTimeField20.set((org.joda.time.ReadablePartial) monthDay26, 86400, intArray58, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray27);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(yearMonthDay50);
//        org.junit.Assert.assertNotNull(intArray56);
//        org.junit.Assert.assertNotNull(intArray58);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, 999, 10, 20, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumDate();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("1", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        long long15 = offsetDateTimeField7.roundHalfEven((long) 16500020);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField7.getAsText(97, locale17);
        long long20 = offsetDateTimeField7.roundHalfFloor((long) 2019);
        long long22 = offsetDateTimeField7.roundCeiling((long) (short) 0);
        org.joda.time.DurationField durationField23 = offsetDateTimeField7.getLeapDurationField();
        long long25 = offsetDateTimeField7.roundFloor((long) 86399);
        java.lang.String str27 = offsetDateTimeField7.getAsShortText((long) 2019);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16500000L + "'", long15 == 16500000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2000L + "'", long20 == 2000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86000L + "'", long25 == 86000L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "3" + "'", str27.equals("3"));
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime7.withPeriodAdded(readablePeriod12, 1);
//        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
//        org.joda.time.DateTime dateTime16 = dateTime14.withTimeAtStartOfDay();
//        org.joda.time.DateTime.Property property17 = dateTime14.weekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        org.joda.time.DurationField durationField24 = unsupportedDateTimeField20.getLeapDurationField();
//        try {
//            long long27 = unsupportedDateTimeField20.addWrapField(2000L, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNull(durationField24);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        java.io.Writer writer2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        boolean boolean13 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime.Property property14 = dateTime12.centuryOfEra();
//        org.joda.time.DateTime dateTime15 = dateTime12.toDateTime();
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray19 = monthDay18.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.yearOfCentury();
//        org.joda.time.Chronology chronology23 = gregorianChronology20.withUTC();
//        org.joda.time.MonthDay monthDay24 = monthDay18.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology29 = copticChronology25.withZone(dateTimeZone28);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone28);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone28);
//        org.joda.time.chrono.ZonedChronology zonedChronology32 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone28);
//        org.joda.time.DateTime dateTime33 = dateTime12.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology35);
//        java.lang.String str37 = dateTimeFormatter34.print((org.joda.time.ReadablePartial) monthDay36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = monthDay36.getFieldType(0);
//        org.joda.time.MonthDay monthDay41 = monthDay36.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime42 = dateTime12.withFields((org.joda.time.ReadablePartial) monthDay36);
//        try {
//            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) monthDay36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(zonedChronology32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "����0615T������.000" + "'", str37.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(monthDay41);
//        org.junit.Assert.assertNotNull(dateTime42);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond(97);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readableDuration18);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        java.lang.Class<?> wildcardClass3 = property2.getClass();
        org.joda.time.DurationField durationField4 = property2.getDurationField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType22);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType22, 16500020, 4539, (-276));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16500020 for monthOfYear must be in the range [4539,-276]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        int int8 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology3.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYear(0, 16500020);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendSecondOfMinute(4539);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
        long long11 = delegatedDateTimeField7.addWrapField(0L, (int) (short) 0);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField7.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendHourOfDay(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property2.getFieldType();
        org.joda.time.Interval interval4 = property2.toInterval();
        org.joda.time.DurationField durationField5 = property2.getDurationField();
        long long8 = durationField5.subtract((long) 15, (long) 4546);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology14 = copticChronology10.withZone(dateTimeZone13);
        java.lang.String str15 = dateTimeZone13.toString();
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone13);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) 15, dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFieldType3);
        org.junit.Assert.assertNotNull(interval4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-143457955199985L) + "'", long8 == (-143457955199985L));
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+100:35" + "'", str15.equals("+100:35"));
        org.junit.Assert.assertNotNull(iSOChronology16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            int[] intArray9 = gregorianChronology6.get(readablePartial7, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        java.lang.String str15 = gregorianChronology3.toString();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) 6, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField17 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[+100:35,mdfw=1]" + "'", str15.equals("GregorianChronology[+100:35,mdfw=1]"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        try {
//            java.lang.String str7 = monthDay2.toString("UnsupportedDateTimeField");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField8, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType13);
//        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField14.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology17);
//        java.lang.String str19 = dateTimeFormatter16.print((org.joda.time.ReadablePartial) monthDay18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType(0);
//        int int22 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay18);
//        boolean boolean23 = property5.equals((java.lang.Object) monthDay18);
//        org.joda.time.DateTime dateTime24 = property5.withMinimumValue();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "����0615T������.000" + "'", str19.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 86399 + "'", int22 == 86399);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime3.minusYears(20);
//        org.joda.time.DateTime.Property property11 = dateTime3.dayOfMonth();
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = property11.getAsText(locale12);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "20" + "'", str13.equals("20"));
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTimeISO();
        int int15 = dateTime14.getYearOfCentury();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime3.minusHours((int) '#');
//        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
//        org.joda.time.DateTime dateTime11 = dateTime8.withEra(0);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(1);
//        int int14 = dateTime11.getDayOfYear();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 169 + "'", int14 == 169);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded(readableDuration11, 2019);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime8);
//        java.lang.String str15 = gJChronology14.toString();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.Chronology chronology17 = gJChronology14.withZone(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.clockhourOfDay();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GJChronology[+100:35,cutover=2019-06-15T20:40:57.002Z]" + "'", str15.equals("GJChronology[+100:35,cutover=2019-06-15T20:40:57.002Z]"));
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear(275);
//        java.lang.StringBuffer stringBuffer5 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology7);
//        java.lang.String str9 = dateTimeFormatter6.print((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = monthDay8.getFieldType(0);
//        org.joda.time.MonthDay monthDay13 = monthDay8.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray14 = monthDay13.getFieldTypes();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer5, (org.joda.time.ReadablePartial) monthDay13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "����0615T������.000" + "'", str9.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray14);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        try {
//            java.lang.String str25 = unsupportedDateTimeField20.getAsText((long) 86400);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology14);
        int int16 = monthDay15.getMonthOfYear();
        int[] intArray18 = null;
        int[] intArray20 = delegatedDateTimeField10.add((org.joda.time.ReadablePartial) monthDay15, (int) '#', intArray18, 0);
        int int22 = delegatedDateTimeField10.getLeapAmount((long) 86399);
        long long24 = delegatedDateTimeField10.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNull(intArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        boolean boolean28 = dateTime25.isBefore((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.MutableDateTime mutableDateTime29 = dateTime27.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        boolean boolean34 = dateTime31.isBefore((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime.Property property35 = dateTime33.centuryOfEra();
//        org.joda.time.DateTime dateTime36 = dateTime33.toDateTime();
//        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime27, (org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology38);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray40 = monthDay39.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.yearOfCentury();
//        org.joda.time.Chronology chronology44 = gregorianChronology41.withUTC();
//        org.joda.time.MonthDay monthDay45 = monthDay39.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology41);
//        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology50 = copticChronology46.withZone(dateTimeZone49);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone49);
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone49);
//        org.joda.time.chrono.ZonedChronology zonedChronology53 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology41, dateTimeZone49);
//        org.joda.time.DateTime dateTime54 = dateTime33.withZoneRetainFields(dateTimeZone49);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology56);
//        java.lang.String str58 = dateTimeFormatter55.print((org.joda.time.ReadablePartial) monthDay57);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = monthDay57.getFieldType(0);
//        org.joda.time.MonthDay monthDay62 = monthDay57.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime63 = dateTime33.withFields((org.joda.time.ReadablePartial) monthDay57);
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay66 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology65);
//        org.joda.time.MonthDay monthDay68 = monthDay66.minusMonths((int) (byte) 1);
//        int[] intArray69 = monthDay66.getValues();
//        try {
//            int[] intArray71 = unsupportedDateTimeField20.add((org.joda.time.ReadablePartial) monthDay57, (-98), intArray69, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray40);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(monthDay45);
//        org.junit.Assert.assertNotNull(copticChronology46);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(zonedChronology53);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(dateTimeFormatter55);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(monthDay57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "����0615T������.000" + "'", str58.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertNotNull(monthDay62);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(monthDay66);
//        org.junit.Assert.assertNotNull(monthDay68);
//        org.junit.Assert.assertNotNull(intArray69);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "GJChronology[+100:35,cutover=2019-06-15T20:40:50.352Z]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("GJChronology[+100:35,cutover=2019-06-15T20:40:57.002Z]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[+100:35,cutover=201...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
        java.lang.String str20 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
        java.lang.String str22 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology0.getZone();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JulianChronology[UTC]" + "'", str22.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology12 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone11);
        org.joda.time.DurationField durationField16 = zonedChronology15.centuries();
        java.lang.String str17 = zonedChronology15.toString();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology15.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +100:35]" + "'", str17.equals("ZonedChronology[GregorianChronology[UTC], +100:35]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        java.lang.String str3 = gregorianChronology2.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology2.hours();
        long long7 = durationField4.subtract((long) (-21), 4);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+100:35,mdfw=1]" + "'", str3.equals("GregorianChronology[+100:35,mdfw=1]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14400021L) + "'", long7 == (-14400021L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField7.getAsText((int) 'a', locale10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97" + "'", str11.equals("97"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology10 = copticChronology6.withZone(dateTimeZone9);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
        org.joda.time.Chronology chronology16 = gregorianChronology12.withZone(dateTimeZone15);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(4, (int) (short) 0, 5, 0, 20, 74458, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 74458 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) 'a');
//        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (byte) 0);
//        org.joda.time.DateTime dateTime10 = dateTime6.plusMonths(0);
//        org.joda.time.LocalDate localDate11 = dateTime10.toLocalDate();
//        int int12 = dateTime10.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4559 + "'", int12 == 4559);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTimeISO();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        java.lang.String str25 = unsupportedDateTimeField20.toString();
//        try {
//            long long27 = unsupportedDateTimeField20.roundHalfCeiling(1560631246626L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDateTimeField" + "'", str25.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int9 = offsetDateTimeField7.getLeapAmount((long) (byte) -1);
        boolean boolean11 = offsetDateTimeField7.isLeap(16500000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10", "(\"org.joda.time.JodaTimePermission\" \"--12-01\")");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay(100);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField8, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField19, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType24);
        int int27 = delegatedDateTimeField25.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, (org.joda.time.DateTimeField) delegatedDateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField25.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType29);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (byte) 1, "86399");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException34);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 86399 + "'", int27 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("--12-01");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.Object obj3 = null;
        boolean boolean4 = jodaTimePermission1.equals(obj3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"--12-01\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"--12-01\")"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        java.util.Locale locale21 = null;
//        try {
//            int int22 = unsupportedDateTimeField20.getMaximumShortTextLength(locale21);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("GregorianChronology[+100:35,mdfw=1]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[+100:35,mdfw=1]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        java.lang.String str4 = dateTimeZone3.toString();
        try {
            org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, 171);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 171");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) 100);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime8 = dateTime3.minusHours((int) '#');
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTime.Property property10 = dateTime8.year();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.minus(readableDuration11);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        long long15 = offsetDateTimeField7.roundHalfEven((long) 16500020);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField7.getAsText(97, locale17);
        long long20 = offsetDateTimeField7.roundHalfFloor((long) 2019);
        long long22 = offsetDateTimeField7.roundCeiling((long) (short) 0);
        org.joda.time.DurationField durationField23 = offsetDateTimeField7.getLeapDurationField();
        long long25 = offsetDateTimeField7.roundFloor((long) 86399);
        int int26 = offsetDateTimeField7.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16500000L + "'", long15 == 16500000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2000L + "'", long20 == 2000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86000L + "'", long25 == 86000L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.centuryOfEra();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology7 = copticChronology3.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((-10L), true);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone6);
        org.joda.time.Chronology chronology13 = julianChronology0.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-362100010L) + "'", long11 == (-362100010L));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("--12-01");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.Class<?> wildcardClass4 = jodaTimePermission1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"--12-01\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"--12-01\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        long long7 = dateTimeZone3.convertUTCToLocal((long) 5);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 362100005L + "'", long7 == 362100005L);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = monthDay15.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.yearOfCentury();
//        org.joda.time.Chronology chronology20 = gregorianChronology17.withUTC();
//        org.joda.time.MonthDay monthDay21 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology26 = copticChronology22.withZone(dateTimeZone25);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone25);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone25);
//        org.joda.time.DateTime dateTime30 = dateTime9.withZoneRetainFields(dateTimeZone25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology32);
//        java.lang.String str34 = dateTimeFormatter31.print((org.joda.time.ReadablePartial) monthDay33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = monthDay33.getFieldType(0);
//        org.joda.time.MonthDay monthDay38 = monthDay33.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime39 = dateTime9.withFields((org.joda.time.ReadablePartial) monthDay33);
//        org.joda.time.DateTime dateTime40 = dateTime9.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime41 = dateTime9.toDateTime();
//        try {
//            java.lang.String str43 = dateTime41.toString("����0101T������.000");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "����0615T������.000" + "'", str34.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean5 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime4.toMutableDateTime();
//        org.joda.time.DateTime.Property property7 = dateTime4.millisOfSecond();
//        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeFormatter0.getZone();
//        try {
//            org.joda.time.LocalTime localTime11 = dateTimeFormatter0.parseLocalTime("2019");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "20190620T011600.601+10035" + "'", str8.equals("20190620T011600.601+10035"));
//        org.junit.Assert.assertNull(dateTimeZone9);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField10, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType15);
//        boolean boolean17 = delegatedDateTimeField16.isSupported();
//        int int18 = dateTime3.get((org.joda.time.DateTimeField) delegatedDateTimeField16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology20);
//        java.lang.String str22 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) monthDay21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = monthDay21.getFieldType(0);
//        org.joda.time.MonthDay monthDay26 = monthDay21.withMonthOfYear((int) (short) 1);
//        int[] intArray30 = new int[] { 20, 86399 };
//        try {
//            int[] intArray32 = delegatedDateTimeField16.addWrapField((org.joda.time.ReadablePartial) monthDay26, 0, intArray30, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 116");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 74460 + "'", int18 == 74460);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "����0615T������.000" + "'", str22.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(intArray30);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        try {
//            int int26 = unsupportedDateTimeField20.getMinimumValue(readablePartial25);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-276), 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded(readableDuration11, 2019);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean16 = dateTime8.isEqual((long) (short) 1);
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean21 = dateTime18.isBefore((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime23 = dateTime20.minus((long) 'a');
//        org.joda.time.DateTime dateTime25 = dateTime20.withSecondOfMinute(2);
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime8, (org.joda.time.ReadableInstant) dateTime25);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(chronology26);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTime dateTime10 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property5.getDateTime();
//        boolean boolean12 = dateTime11.isAfterNow();
//        int int13 = dateTime11.getMinuteOfHour();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "20");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime4.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
//        boolean boolean13 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime12);
//        long long14 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime10.withPeriodAdded(readablePeriod15, 1);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology24 = copticChronology20.withZone(dateTimeZone23);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone23);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
//        org.joda.time.Chronology chronology28 = gregorianChronology19.withZone(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(buddhistChronology27);
//        org.junit.Assert.assertNotNull(chronology28);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology6 = copticChronology2.withZone(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        boolean boolean11 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime10.withDurationAdded(readableDuration13, 2019);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime10);
//        java.lang.String str17 = gJChronology16.toString();
//        org.joda.time.Instant instant18 = gJChronology16.getGregorianCutover();
//        try {
//            org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(0, 19, (org.joda.time.Chronology) gJChronology16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "GJChronology[+100:35,cutover=2019-06-15T20:41:02.014Z]" + "'", str17.equals("GJChronology[+100:35,cutover=2019-06-15T20:41:02.014Z]"));
//        org.junit.Assert.assertNotNull(instant18);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
//        boolean boolean6 = property5.isLeap();
//        org.joda.time.DurationField durationField7 = property5.getLeapDurationField();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNull(durationField7);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
//        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology10);
//        java.lang.String str12 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = monthDay11.getFieldType(0);
//        int int15 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
//        org.joda.time.MonthDay monthDay18 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, 5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withPivotYear((java.lang.Integer) 20);
//        java.lang.String str25 = monthDay18.toString(dateTimeFormatter24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology26);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray28 = monthDay27.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.yearOfCentury();
//        org.joda.time.Chronology chronology32 = gregorianChronology29.withUTC();
//        org.joda.time.MonthDay monthDay33 = monthDay27.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology29);
//        boolean boolean34 = monthDay18.isBefore((org.joda.time.ReadablePartial) monthDay27);
//        java.util.Locale locale36 = null;
//        try {
//            java.lang.String str37 = monthDay18.toString("20190615T134023.343-0700", locale36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "����0615T������.000" + "'", str12.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str25.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("20190615T134023.343-0700", (java.lang.Number) (-98), (java.lang.Number) (-3L), (java.lang.Number) 169);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType22);
//        long long25 = zeroIsMaxDateTimeField23.roundHalfFloor((long) 97);
//        int int27 = zeroIsMaxDateTimeField23.getMaximumValue((long) (short) 0);
//        int int30 = zeroIsMaxDateTimeField23.getDifference((long) '#', 0L);
//        long long32 = zeroIsMaxDateTimeField23.roundCeiling(2019010L);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 86400 + "'", int27 == 86400);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2020000L + "'", long32 == 2020000L);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-21), (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-42L) + "'", long2 == (-42L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        int int14 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology2.monthOfYear();
        org.joda.time.DurationField durationField16 = gregorianChronology2.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        int int5 = dateTime3.getYear();
//        int int6 = dateTime3.getMonthOfYear();
//        int int7 = dateTime3.getMillisOfDay();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4563003 + "'", int7 == 4563003);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType22);
//        long long25 = zeroIsMaxDateTimeField23.roundHalfFloor((long) 97);
//        int int27 = zeroIsMaxDateTimeField23.getLeapAmount(86399015L);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        try {
            long long17 = delegatedDateTimeField10.set(0L, "20190615T134023.343-0700");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"20190615T134023.343-0700\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        try {
//            boolean boolean25 = unsupportedDateTimeField20.isLeap((long) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.plus(1001L);
//        int int3 = dateTime0.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.io.Writer writer2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime6.minus((long) 'a');
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(readableDuration10, 0);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded(readableDuration11, 2019);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime16 = dateTime8.withHourOfDay((int) (short) 1);
//        int int17 = dateTime8.getMillisOfDay();
//        int int18 = dateTime8.getWeekyear();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4563941 + "'", int17 == 4563941);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2019, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20190 + "'", int2 == 20190);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
        java.lang.String str20 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
        java.lang.String str22 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology0.getZone();
        int int24 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JulianChronology[UTC]" + "'", str22.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime8 = dateTime3.minusHours((int) '#');
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withFieldAdded(durationFieldType11, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType22);
//        long long25 = zeroIsMaxDateTimeField23.roundHalfFloor((long) 97);
//        long long27 = zeroIsMaxDateTimeField23.roundCeiling(86399015L);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 86400000L + "'", long27 == 86400000L);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        try {
            long long2 = dateTimeFormatter0.parseMillis("97");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"97\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField18, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType23);
        int int26 = delegatedDateTimeField24.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, (org.joda.time.DateTimeField) delegatedDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField24.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType28, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder32.appendYear((int) (byte) 0, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendShortText(dateTimeFieldType37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399 + "'", int26 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        int int15 = delegatedDateTimeField10.getMinimumValue(2000L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField10.getAsText((long) 275, locale17);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 4539, (long) 169);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4708L + "'", long2 == 4708L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
        java.lang.String str20 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology22);
        try {
            long long31 = copticChronology22.getDateTimeMillis((-98), (int) '#', 30, 0, 4546, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4546 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime4.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        boolean boolean13 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime12);
        long long14 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime10.withPeriodAdded(readablePeriod15, 1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        java.lang.String str20 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime3.minusHours((int) '#');
//        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
//        org.joda.time.DateTime dateTime11 = dateTime8.withEra(0);
//        org.joda.time.DateTime dateTime13 = dateTime11.plusWeeks(1);
//        int int14 = dateTime13.getMinuteOfHour();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        java.lang.String str6 = dateTimeZone4.toString();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone4);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+100:35" + "'", str6.equals("+100:35"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateMidnight9);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendText(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        java.lang.String str25 = unsupportedDateTimeField20.toString();
//        java.util.Locale locale26 = null;
//        try {
//            int int27 = unsupportedDateTimeField20.getMaximumTextLength(locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDateTimeField" + "'", str25.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("--12-01");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendFractionOfSecond((-98), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = gregorianChronology6.withZone(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray13 = gregorianChronology6.get(readablePeriod11, (long) 4559);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        int int9 = dateTimeZone3.getOffsetFromLocal((long) 86400);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 362100000 + "'", int9 == 362100000);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((-3599968L));
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTime dateTime10 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property5.getDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
//        int int13 = dateTime11.getWeekyear();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(86399);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("2019", 0, 4539, 4565, '#', (-98), (int) ' ', 4544, true, (-21));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.MonthDay monthDay9 = monthDay1.minusMonths(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay1.minus(readablePeriod10);
        org.joda.time.DateTimeField[] dateTimeFieldArray12 = monthDay11.getFields();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeFieldArray12);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.centuryOfEra();
//        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime.Property property8 = dateTime4.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology9);
//        int int11 = monthDay10.getMonthOfYear();
//        int int12 = property8.compareTo((org.joda.time.ReadablePartial) monthDay10);
//        org.joda.time.DateTime dateTime13 = property8.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime14 = property8.getDateTime();
//        boolean boolean15 = dateTime14.isAfterNow();
//        boolean boolean16 = julianChronology0.equals((java.lang.Object) dateTime14);
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime14.withDate((int) (byte) 0, 169, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 169 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
//        java.lang.String str3 = monthDay1.toString();
//        org.joda.time.MonthDay.Property property4 = monthDay1.dayOfMonth();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfDay(100);
//        boolean boolean8 = dateTimeFormatterBuilder5.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendFractionOfSecond(0, 86400);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField24, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType29);
//        int int32 = delegatedDateTimeField30.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField33 = delegatedDateTimeField30.getDurationField();
//        long long36 = durationField33.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField33);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType22);
//        try {
//            org.joda.time.MonthDay monthDay40 = monthDay1.withField(dateTimeFieldType22, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86399 + "'", int32 == 86399);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        long long27 = unsupportedDateTimeField20.getDifferenceAsLong(1560631246626L, 10L);
//        try {
//            long long30 = unsupportedDateTimeField20.set(86000L, "");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560631246L + "'", long27 == 1560631246L);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        int int17 = skipDateTimeField15.get((long) (byte) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray20 = monthDay19.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.secondOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.yearOfCentury();
        org.joda.time.Chronology chronology24 = gregorianChronology21.withUTC();
        org.joda.time.MonthDay monthDay25 = monthDay19.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology21);
        org.joda.time.MonthDay monthDay27 = monthDay19.minusMonths(0);
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = skipDateTimeField15.getAsText((org.joda.time.ReadablePartial) monthDay27, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay27);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560631267217L + "'", long1 == 1560631267217L);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        java.lang.String str10 = monthDay7.toString();
//        boolean boolean11 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.MonthDay monthDay13 = monthDay7.plus(readablePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "--06-15" + "'", str10.equals("--06-15"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(monthDay13);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        java.util.Locale locale25 = null;
//        try {
//            int int26 = unsupportedDateTimeField20.getMaximumShortTextLength(locale25);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendWeekyear(10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField18, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType23);
        int int26 = delegatedDateTimeField24.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, (org.joda.time.DateTimeField) delegatedDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField24.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType28, (int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder32.appendYear((int) (byte) 0, (int) (short) 100);
        boolean boolean37 = dateTimeFormatterBuilder36.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 86399 + "'", int26 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.MonthDay monthDay9 = monthDay1.minusMonths(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay1.minus(readablePeriod10);
        org.joda.time.MonthDay monthDay13 = monthDay11.withMonthOfYear((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField15, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField26, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType31);
        int int34 = delegatedDateTimeField32.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology24, (org.joda.time.DateTimeField) delegatedDateTimeField32);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField32.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType36);
        try {
            org.joda.time.MonthDay.Property property38 = monthDay11.property(dateTimeFieldType36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 86399 + "'", int34 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
//        boolean boolean29 = dateTime26.isBefore((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime.Property property30 = dateTime26.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration31 = null;
//        org.joda.time.DateTime dateTime33 = dateTime26.withDurationAdded(readableDuration31, (int) (short) 10);
//        org.joda.time.DateTime dateTime35 = dateTime33.withMillis(2019000L);
//        org.joda.time.TimeOfDay timeOfDay36 = dateTime35.toTimeOfDay();
//        try {
//            int int37 = unsupportedDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay36);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(timeOfDay36);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property2.getFieldType();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology10);
//        int int12 = monthDay11.getMonthOfYear();
//        int int13 = property9.compareTo((org.joda.time.ReadablePartial) monthDay11);
//        org.joda.time.DateTime dateTime14 = property9.roundHalfFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology17);
//        java.lang.String str19 = dateTimeFormatter16.print((org.joda.time.ReadablePartial) monthDay18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.yearOfCentury();
//        org.joda.time.Chronology chronology25 = gregorianChronology22.withUTC();
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(chronology25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = monthDay26.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.yearOfCentury();
//        org.joda.time.Chronology chronology32 = gregorianChronology29.withUTC();
//        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(chronology32);
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = monthDay33.getFieldType(0);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField40, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40, dateTimeFieldType45);
//        int int48 = delegatedDateTimeField46.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology38, (org.joda.time.DateTimeField) delegatedDateTimeField46);
//        long long52 = skipUndoDateTimeField49.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay55 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology54);
//        java.lang.String str56 = dateTimeFormatter53.print((org.joda.time.ReadablePartial) monthDay55);
//        org.joda.time.DateTimeFieldType dateTimeFieldType58 = monthDay55.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField59 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField49, dateTimeFieldType58);
//        org.joda.time.DateTimeZone dateTimeZone60 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone60, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField64, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField70 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField64, dateTimeFieldType69);
//        int int72 = delegatedDateTimeField70.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology62, (org.joda.time.DateTimeField) delegatedDateTimeField70);
//        org.joda.time.DateTimeFieldType dateTimeFieldType74 = delegatedDateTimeField70.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException78 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType74, (java.lang.Number) 4559, (java.lang.Number) 10L, (java.lang.Number) 1001L);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray79 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType3, dateTimeFieldType15, dateTimeFieldType21, dateTimeFieldType28, dateTimeFieldType35, dateTimeFieldType58, dateTimeFieldType74 };
//        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList80 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
//        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList80, dateTimeFieldTypeArray79);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter84 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList80, false, false);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType3);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "����0615T������.000" + "'", str19.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 86399 + "'", int48 == 86399);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 97000L + "'", long52 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(gregorianChronology54);
//        org.junit.Assert.assertNotNull(monthDay55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "����0615T������.000" + "'", str56.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType58);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 86399 + "'", int72 == 86399);
//        org.junit.Assert.assertNotNull(dateTimeFieldType74);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray79);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter84);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = monthDay15.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.yearOfCentury();
//        org.joda.time.Chronology chronology20 = gregorianChronology17.withUTC();
//        org.joda.time.MonthDay monthDay21 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology26 = copticChronology22.withZone(dateTimeZone25);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone25);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone25);
//        org.joda.time.DateTime dateTime30 = dateTime9.withZoneRetainFields(dateTimeZone25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology32);
//        java.lang.String str34 = dateTimeFormatter31.print((org.joda.time.ReadablePartial) monthDay33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = monthDay33.getFieldType(0);
//        org.joda.time.MonthDay monthDay38 = monthDay33.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime39 = dateTime9.withFields((org.joda.time.ReadablePartial) monthDay33);
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.DateTime dateTime41 = dateTime39.minus(readablePeriod40);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "����0615T������.000" + "'", str34.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.DateTime.Property property6 = dateTime1.yearOfCentury();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology5 = copticChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded(readableDuration12, 2019);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((java.lang.Object) (-11957290L), (org.joda.time.Chronology) gJChronology15);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfSecond(97);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
        org.junit.Assert.assertNotNull(dateTime19);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        java.lang.String str25 = unsupportedDateTimeField20.toString();
//        java.util.Locale locale27 = null;
//        try {
//            java.lang.String str28 = unsupportedDateTimeField20.getAsShortText(0, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UnsupportedDateTimeField" + "'", str25.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfCentury();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.MonthDay monthDay7 = monthDay1.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology12 = copticChronology8.withZone(dateTimeZone11);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone11);
        org.joda.time.DurationField durationField16 = zonedChronology15.centuries();
        java.lang.String str17 = zonedChronology15.toString();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology15.secondOfMinute();
        org.joda.time.DurationField durationField19 = zonedChronology15.minutes();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        boolean boolean27 = dateTime24.isBefore((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime.Property property28 = dateTime24.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
        boolean boolean33 = dateTime30.isBefore((org.joda.time.ReadableInstant) dateTime32);
        long long34 = property28.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime37 = dateTime30.withPeriodAdded(readablePeriod35, 1);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) dateTime37);
        java.lang.String str39 = dateTimeZone22.getID();
        java.util.Locale locale41 = null;
        java.lang.String str42 = dateTimeZone22.getShortName(0L, locale41);
        org.joda.time.Chronology chronology43 = zonedChronology15.withZone(dateTimeZone22);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now(chronology43);
        try {
            org.joda.time.DateTime dateTime48 = dateTime44.withDate(1, 275, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 275 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +100:35]" + "'", str17.equals("ZonedChronology[GregorianChronology[UTC], +100:35]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "+100:35" + "'", str39.equals("+100:35"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+100:35" + "'", str42.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTime44);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime6.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime6.withDurationAdded(readableDuration11, (int) (short) 10);
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime13.toTimeOfDay();
//        long long16 = copticChronology0.set((org.joda.time.ReadablePartial) timeOfDay14, (long) 2019);
//        java.lang.String str17 = copticChronology0.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-11930742L) + "'", long16 == (-11930742L));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "CopticChronology[+100:35]" + "'", str17.equals("CopticChronology[+100:35]"));
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int10 = offsetDateTimeField7.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        int[] intArray20 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray22 = offsetDateTimeField7.add((org.joda.time.ReadablePartial) yearMonthDay14, (int) 'a', intArray20, (int) (short) 0);
        int int24 = offsetDateTimeField7.getMinimumValue((long) (-1));
        long long27 = offsetDateTimeField7.add((long) 'a', (long) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10097L + "'", long27 == 10097L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        long long15 = offsetDateTimeField7.roundHalfEven((long) 16500020);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField7.getAsText(97, locale17);
        long long20 = offsetDateTimeField7.roundHalfFloor((long) 2019);
        long long22 = offsetDateTimeField7.roundCeiling((long) (short) 0);
        int int24 = offsetDateTimeField7.getLeapAmount((long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16500000L + "'", long15 == 16500000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2000L + "'", long20 == 2000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
//        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendClockhourOfDay(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology11);
//        java.lang.String str13 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.append(dateTimeFormatter10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder9.appendFractionOfSecond(362100000, 5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "����0615T������.000" + "'", str13.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField15, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType20);
//        int int23 = delegatedDateTimeField21.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeField) delegatedDateTimeField21);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField21.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType25);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder2.appendText(dateTimeFieldType25);
//        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
//        boolean boolean36 = dateTime33.isBefore((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime.Property property37 = dateTime33.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime(dateTimeZone40);
//        boolean boolean42 = dateTime39.isBefore((org.joda.time.ReadableInstant) dateTime41);
//        long long43 = property37.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.DateTime dateTime46 = dateTime39.withPeriodAdded(readablePeriod44, 1);
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (org.joda.time.ReadableInstant) dateTime46);
//        java.lang.String str48 = dateTimeZone31.getID();
//        org.joda.time.Chronology chronology49 = julianChronology28.withZone(dateTimeZone31);
//        try {
//            org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder27, (org.joda.time.Chronology) julianChronology28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 86399 + "'", int23 == 86399);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(julianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "+100:35" + "'", str48.equals("+100:35"));
//        org.junit.Assert.assertNotNull(chronology49);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField15, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15, dateTimeFieldType20);
        int int23 = delegatedDateTimeField21.getMaximumValue((long) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology24);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray26 = monthDay25.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.secondOfDay();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.yearOfCentury();
        org.joda.time.Chronology chronology30 = gregorianChronology27.withUTC();
        org.joda.time.MonthDay monthDay31 = monthDay25.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology27);
        int int32 = delegatedDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) monthDay25);
        int[] intArray37 = new int[] { 4559, 4566035, (byte) 10 };
        try {
            int[] intArray39 = delegatedDateTimeField10.add((org.joda.time.ReadablePartial) monthDay25, (int) '4', intArray37, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 86399 + "'", int23 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86399 + "'", int32 == 86399);
        org.junit.Assert.assertNotNull(intArray37);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType22);
//        long long25 = zeroIsMaxDateTimeField23.roundHalfFloor((long) 97);
//        long long27 = zeroIsMaxDateTimeField23.roundFloor((long) (byte) 0);
//        int int29 = zeroIsMaxDateTimeField23.get((long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField23, dateTimeFieldType30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86400 + "'", int29 == 86400);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("ISOChronology[+100:35]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[+100:35]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int8 = offsetDateTimeField7.getOffset();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsText((int) (short) 10, locale10);
        int int12 = offsetDateTimeField7.getMinimumValue();
        try {
            long long15 = offsetDateTimeField7.set((long) 4539, 4563941);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4563941 for secondOfDay must be in the range [1,86400]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = delegatedDateTimeField11.getType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType15, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 4559);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 442223 + "'", int2 == 442223);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime6.monthOfYear();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime6.withDurationAdded(readableDuration11, (int) (short) 10);
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime13.toTimeOfDay();
//        long long16 = copticChronology0.set((org.joda.time.ReadablePartial) timeOfDay14, (long) 2019);
//        org.joda.time.JodaTimePermission jodaTimePermission18 = new org.joda.time.JodaTimePermission("hi!");
//        boolean boolean19 = copticChronology0.equals((java.lang.Object) jodaTimePermission18);
//        boolean boolean21 = jodaTimePermission18.equals((java.lang.Object) "86399");
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-11928942L) + "'", long16 == (-11928942L));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        try {
//            long long23 = unsupportedDateTimeField20.remainder(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField7.getDurationField();
        org.joda.time.DurationField durationField11 = delegatedDateTimeField7.getLeapDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.MonthDay monthDay15 = monthDay13.minusMonths((int) (byte) 1);
        int int16 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay15);
        int int17 = delegatedDateTimeField7.getMinimumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = delegatedDateTimeField7.getAsText(97000L, locale19);
        long long23 = delegatedDateTimeField7.add((long) '#', (long) 442223);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86399 + "'", int16 == 86399);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "97" + "'", str20.equals("97"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 442223035L + "'", long23 == 442223035L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = monthDay8.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.yearOfCentury();
        org.joda.time.Chronology chronology13 = gregorianChronology10.withUTC();
        org.joda.time.MonthDay monthDay14 = monthDay8.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology10);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(999, 4559, 0, (-98), 74466, (-276), (int) (short) 1, (org.joda.time.Chronology) gregorianChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(monthDay14);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
        java.lang.String str20 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
        java.lang.String str22 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology0.getZone();
        java.lang.Object obj24 = null;
        boolean boolean25 = julianChronology0.equals(obj24);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JulianChronology[UTC]" + "'", str22.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("--12-01");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.String str4 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"--12-01\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"--12-01\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "--12-01" + "'", str4.equals("--12-01"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "10");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTime dateTime10 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property5.getDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
//        boolean boolean13 = dateTime11.isEqualNow();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        java.lang.String str10 = monthDay7.toString();
//        boolean boolean11 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay7);
//        try {
//            org.joda.time.DateTimeField dateTimeField13 = monthDay7.getField(4565);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 4565");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "--06-15" + "'", str10.equals("--06-15"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
        java.lang.String str20 = dateTimeZone3.getID();
        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3);
        long long25 = dateTimeZone3.adjustOffset((-10L), false);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-10L) + "'", long25 == (-10L));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
//        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendClockhourOfDay(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology11);
//        java.lang.String str13 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder9.append(dateTimeFormatter10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder9.appendMonthOfYearShortText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder9.appendMillisOfSecond((int) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "����0615T������.000" + "'", str13.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray2 = monthDay1.getFieldTypes();
//        java.lang.String str3 = monthDay1.toString();
//        org.joda.time.MonthDay.Property property4 = monthDay1.dayOfMonth();
//        int int5 = property4.getMinimumValue();
//        java.lang.String str6 = property4.getAsShortText();
//        try {
//            org.joda.time.MonthDay monthDay8 = property4.setCopy("ZonedChronology[GregorianChronology[UTC], +100:35]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[GregorianChronology[UTC], +100:35]\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "--06-15" + "'", str3.equals("--06-15"));
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.centuryOfEra();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology7 = copticChronology3.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((-10L), true);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone6);
        org.joda.time.Chronology chronology13 = julianChronology0.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology0.era();
        try {
            long long19 = julianChronology0.getDateTimeMillis(10, 4539, 442223, 4546);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4539 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-362100010L) + "'", long11 == (-362100010L));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        int int23 = unsupportedDateTimeField20.getDifference((long) 999, 100L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.yearOfCentury();
//        org.joda.time.Chronology chronology27 = gregorianChronology24.withUTC();
//        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
//        boolean boolean33 = dateTime30.isBefore((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime.Property property34 = dateTime30.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
//        boolean boolean39 = dateTime36.isBefore((org.joda.time.ReadableInstant) dateTime38);
//        long long40 = property34.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime36);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.DateTime dateTime43 = dateTime36.withPeriodAdded(readablePeriod41, 1);
//        org.joda.time.DateMidnight dateMidnight44 = dateTime43.toDateMidnight();
//        org.joda.time.DateTime dateTime45 = monthDay28.toDateTime((org.joda.time.ReadableInstant) dateMidnight44);
//        java.util.Locale locale46 = null;
//        try {
//            java.lang.String str47 = unsupportedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) monthDay28, locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateMidnight44);
//        org.junit.Assert.assertNotNull(dateTime45);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.yearOfCentury();
        org.joda.time.Chronology chronology11 = gregorianChronology8.withUTC();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(chronology11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField17, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType22);
        int int25 = delegatedDateTimeField23.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, (org.joda.time.DateTimeField) delegatedDateTimeField23);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = delegatedDateTimeField23.getType();
        long long29 = delegatedDateTimeField23.roundFloor((long) (short) 1);
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField(chronology11, (org.joda.time.DateTimeField) delegatedDateTimeField23);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField32, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType37);
        int int40 = delegatedDateTimeField38.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField41 = delegatedDateTimeField38.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, (org.joda.time.DateTimeField) delegatedDateTimeField38);
        boolean boolean43 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatterBuilder0, (java.lang.Object) chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 86399 + "'", int25 == 86399);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 86399 + "'", int40 == 86399);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property2.getFieldType();
//        org.joda.time.DateTime dateTime4 = property2.roundHalfEvenCopy();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField9, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, dateTimeFieldType14);
//        int int17 = delegatedDateTimeField15.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeField) delegatedDateTimeField15);
//        long long21 = skipUndoDateTimeField18.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology23);
//        java.lang.String str25 = dateTimeFormatter22.print((org.joda.time.ReadablePartial) monthDay24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = monthDay24.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField28 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField18, dateTimeFieldType27);
//        try {
//            org.joda.time.DateTime dateTime30 = dateTime4.withField(dateTimeFieldType27, 15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86399 + "'", int17 == 86399);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97000L + "'", long21 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "����0615T������.000" + "'", str25.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        long long15 = offsetDateTimeField7.roundHalfEven((long) 16500020);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField7.getAsText(97, locale17);
        long long20 = offsetDateTimeField7.roundHalfFloor((long) 2019);
        java.lang.String str22 = offsetDateTimeField7.getAsShortText((long) 15);
        long long25 = offsetDateTimeField7.add(10L, 2019);
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField7.getAsShortText(1547152848626L, locale27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16500000L + "'", long15 == 16500000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2000L + "'", long20 == 2000L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019010L + "'", long25 == 2019010L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "74449" + "'", str28.equals("74449"));
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField8, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType13);
//        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField14.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology17);
//        java.lang.String str19 = dateTimeFormatter16.print((org.joda.time.ReadablePartial) monthDay18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = monthDay18.getFieldType(0);
//        int int22 = delegatedDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay18);
//        boolean boolean23 = property5.equals((java.lang.Object) monthDay18);
//        org.joda.time.Instant instant24 = new org.joda.time.Instant();
//        org.joda.time.ReadableDuration readableDuration25 = null;
//        org.joda.time.Instant instant27 = instant24.withDurationAdded(readableDuration25, (int) ' ');
//        org.joda.time.DateTime dateTime28 = monthDay18.toDateTime((org.joda.time.ReadableInstant) instant24);
//        org.joda.time.Chronology chronology29 = instant24.getChronology();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "����0615T������.000" + "'", str19.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 86399 + "'", int22 == 86399);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(instant27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(chronology29);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTime dateTime10 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property5.getDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
//        int int13 = property12.getMaximumValue();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1439 + "'", int13 == 1439);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        java.util.Locale locale4 = null;
        org.joda.time.DateTime dateTime5 = property2.setCopy("19", locale4);
        java.lang.String str6 = property2.getName();
        try {
            org.joda.time.DateTime dateTime8 = property2.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "weekyear" + "'", str6.equals("weekyear"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.joda.time.Instant instant4 = instant2.plus(1560631000L);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 19, (java.lang.Number) 0.0f, (java.lang.Number) (-276L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(86399);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder4.addCutover(0, 'a', (int) '#', 362100000, 442223, true, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        long long7 = cachedDateTimeZone3.previousTransition(2000L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2000L + "'", long7 == 2000L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        int int15 = delegatedDateTimeField10.getMinimumValue(2000L);
        boolean boolean17 = delegatedDateTimeField10.isLeap(0L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.ReadableDuration readableDuration1 = null;
//        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
//        org.joda.time.Instant instant3 = instant0.toInstant();
//        long long4 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(instant3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560631273789L + "'", long4 == 1560631273789L);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        java.util.Locale locale26 = null;
//        try {
//            java.lang.String str27 = unsupportedDateTimeField20.getAsText(readablePartial25, locale26);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        boolean boolean8 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime5.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        boolean boolean14 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime13);
//        long long15 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime11.withPeriodAdded(readablePeriod16, 1);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime18);
//        java.lang.String str20 = dateTimeZone3.getID();
//        org.joda.time.Chronology chronology21 = julianChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology0.getZone();
//        java.lang.String str23 = dateTimeZone22.toString();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone22);
//        java.lang.String str25 = cachedDateTimeZone24.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+100:35" + "'", str20.equals("+100:35"));
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UTC" + "'", str23.equals("UTC"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "UTC" + "'", str25.equals("UTC"));
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean5 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = monthDay8.getMonthOfYear();
//        int int10 = property6.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.DateTime dateTime11 = property6.roundHalfFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property6.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType12);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType12, (java.lang.Number) 169, "����0101T������.000");
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 19, (long) 171);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3249 + "'", int2 == 3249);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology4, (org.joda.time.DateTimeField) delegatedDateTimeField12);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology4);
        java.lang.String str17 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86399 + "'", int14 == 86399);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "043500+10035" + "'", str17.equals("043500+10035"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        long long11 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.LocalTime localTime12 = dateTime7.toLocalTime();
        org.joda.time.DateTime.Property property13 = dateTime7.yearOfEra();
        org.joda.time.Interval interval14 = property13.toInterval();
        java.lang.String str15 = property13.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(interval14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "yearOfEra" + "'", str15.equals("yearOfEra"));
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        long long27 = unsupportedDateTimeField20.add(1547152846626L, (long) 2);
//        long long30 = unsupportedDateTimeField20.add((long) 4563941, (long) 2019);
//        try {
//            int int32 = unsupportedDateTimeField20.getMinimumValue((long) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1547152848626L + "'", long27 == 1547152848626L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 6582941L + "'", long30 == 6582941L);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) -1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendHourOfDay(30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        long long15 = offsetDateTimeField7.roundHalfEven((long) 16500020);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField7.getAsText(97, locale17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField22, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 1);
        int int31 = offsetDateTimeField28.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        org.joda.time.DateTime.Property property34 = dateTime33.weekyear();
        org.joda.time.YearMonthDay yearMonthDay35 = dateTime33.toYearMonthDay();
        int[] intArray41 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray43 = offsetDateTimeField28.add((org.joda.time.ReadablePartial) yearMonthDay35, (int) 'a', intArray41, (int) (short) 0);
        try {
            int[] intArray45 = offsetDateTimeField7.addWrapField(readablePartial19, 171, intArray41, 86400);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 171");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16500000L + "'", long15 == 16500000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(yearMonthDay35);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField7.getDurationField();
        long long13 = durationField10.subtract(10L, (int) (short) 0);
        long long16 = durationField10.subtract((long) 171, 86000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-85999829L) + "'", long16 == (-85999829L));
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology14);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = monthDay15.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.yearOfCentury();
//        org.joda.time.Chronology chronology20 = gregorianChronology17.withUTC();
//        org.joda.time.MonthDay monthDay21 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology17);
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology26 = copticChronology22.withZone(dateTimeZone25);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone25);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone25);
//        org.joda.time.DateTime dateTime30 = dateTime9.withZoneRetainFields(dateTimeZone25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology32);
//        java.lang.String str34 = dateTimeFormatter31.print((org.joda.time.ReadablePartial) monthDay33);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = monthDay33.getFieldType(0);
//        org.joda.time.MonthDay monthDay38 = monthDay33.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime39 = dateTime9.withFields((org.joda.time.ReadablePartial) monthDay33);
//        org.joda.time.DateTime dateTime40 = dateTime9.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime41 = dateTime9.toDateTime();
//        try {
//            org.joda.time.DateTime dateTime43 = dateTime41.withMinuteOfHour((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "����0615T������.000" + "'", str34.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime41);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusMinutes((int) (short) 10);
        org.joda.time.DateMidnight dateMidnight3 = dateTime0.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateMidnight3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("UTC", 20190, 169, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20190 for UTC must be in the range [169,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        long long27 = unsupportedDateTimeField20.add(1547152846626L, (long) 2);
//        int int30 = unsupportedDateTimeField20.getDifference((long) 86399, (long) 4563003);
//        try {
//            int int32 = unsupportedDateTimeField20.getMinimumValue((long) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1547152848626L + "'", long27 == 1547152848626L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-4476) + "'", int30 == (-4476));
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime3.dayOfYear();
//        java.util.Locale locale8 = null;
//        try {
//            org.joda.time.DateTime dateTime9 = property6.setCopy("ZonedChronology[GregorianChronology[UTC], +100:35]", locale8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[GregorianChronology[UTC], +100:35]\" for dayOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        long long16 = skipUndoDateTimeField13.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology18);
//        java.lang.String str20 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) monthDay19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = monthDay19.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType22);
//        long long25 = zeroIsMaxDateTimeField23.roundHalfFloor((long) 97);
//        long long27 = zeroIsMaxDateTimeField23.roundFloor((long) (byte) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.yearOfCentury();
//        org.joda.time.Chronology chronology31 = gregorianChronology28.withUTC();
//        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(chronology31);
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField34, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34, dateTimeFieldType39);
//        org.joda.time.DateTimeField dateTimeField41 = delegatedDateTimeField40.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology43);
//        java.lang.String str45 = dateTimeFormatter42.print((org.joda.time.ReadablePartial) monthDay44);
//        org.joda.time.DateTimeFieldType dateTimeFieldType47 = monthDay44.getFieldType(0);
//        int int48 = delegatedDateTimeField40.getMaximumValue((org.joda.time.ReadablePartial) monthDay44);
//        boolean boolean49 = monthDay32.isAfter((org.joda.time.ReadablePartial) monthDay44);
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField51, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType56 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51, dateTimeFieldType56);
//        org.joda.time.DateTimeField dateTimeField58 = delegatedDateTimeField57.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay61 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology60);
//        java.lang.String str62 = dateTimeFormatter59.print((org.joda.time.ReadablePartial) monthDay61);
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = monthDay61.getFieldType(0);
//        int int65 = delegatedDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) monthDay61);
//        int int66 = monthDay44.compareTo((org.joda.time.ReadablePartial) monthDay61);
//        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay68 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology67);
//        org.joda.time.MonthDay monthDay70 = monthDay68.minusMonths((int) (byte) 1);
//        int[] intArray71 = monthDay68.getValues();
//        int int72 = zeroIsMaxDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) monthDay44, intArray71);
//        long long74 = zeroIsMaxDateTimeField23.roundHalfCeiling(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97000L + "'", long16 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "����0615T������.000" + "'", str20.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(monthDay44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "����0615T������.000" + "'", str45.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 86399 + "'", int48 == 86399);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(dateTimeFormatter59);
//        org.junit.Assert.assertNotNull(gregorianChronology60);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "����0615T������.000" + "'", str62.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 86399 + "'", int65 == 86399);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology67);
//        org.junit.Assert.assertNotNull(monthDay68);
//        org.junit.Assert.assertNotNull(monthDay70);
//        org.junit.Assert.assertNotNull(intArray71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 86400 + "'", int72 == 86400);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 0L + "'", long74 == 0L);
//    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTime dateTime10 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property5.getDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        boolean boolean17 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime16.minus((long) 'a');
//        org.joda.time.DateTime dateTime21 = dateTime16.withSecondOfMinute(2);
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime16);
//        java.lang.String str23 = dateTime16.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019-06-20T01:16:14.663+100:35" + "'", str23.equals("2019-06-20T01:16:14.663+100:35"));
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.joda.time.Chronology chronology6 = copticChronology5.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendClockhourOfHalfday(1439);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property6 = dateTime3.era();
        org.joda.time.DateTime.Property property7 = dateTime3.weekyear();
        int int8 = property7.getMinimumValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275054) + "'", int8 == (-292275054));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.withDurationAdded(readableDuration6, 2019);
        int int9 = dateTime8.getYearOfEra();
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withDate(2, 0, (-276));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        int int9 = delegatedDateTimeField7.getMaximumValue((long) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = monthDay11.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfCentury();
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.MonthDay monthDay17 = monthDay11.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology13);
        int int18 = delegatedDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay11);
        java.lang.String str19 = delegatedDateTimeField7.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399 + "'", int18 == 86399);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "secondOfDay" + "'", str19.equals("secondOfDay"));
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.MonthDay monthDay7 = monthDay2.withMonthOfYear((int) (short) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMinuteOfDay(100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendWeekyear(10, 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendTimeZoneShortName();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.DateTime.Property property17 = dateTime16.weekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType18, 86399, 86400);
//        try {
//            org.joda.time.MonthDay.Property property22 = monthDay2.property(dateTimeFieldType18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekyear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField10.getLeapDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        boolean boolean16 = skipDateTimeField14.isLeap((-1L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property6 = dateTime3.era();
        org.joda.time.DateTime dateTime8 = dateTime3.withYear((int) '4');
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        long long18 = skipDateTimeField15.set((long) (short) 1, 1);
        int int19 = skipDateTimeField15.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1001L + "'", long18 == 1001L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType6);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField7.getWrappedField();
        long long11 = delegatedDateTimeField7.addWrapField(0L, (int) (short) 0);
        int int13 = delegatedDateTimeField7.getLeapAmount((-143457955199985L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.date();
        boolean boolean8 = dateTimeFormatter7.isOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.append(dateTimeFormatter7);
        boolean boolean10 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
//        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = dateTime3.minusYears(20);
//        org.joda.time.DateTime.Property property11 = dateTime3.dayOfMonth();
//        org.joda.time.DateTime.Property property12 = dateTime3.minuteOfDay();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 4563003, (-11947654L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16510657L + "'", long2 == 16510657L);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        long long27 = unsupportedDateTimeField20.add(1547152846626L, (long) 2);
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField20.getDurationField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology29);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray31 = monthDay30.getFieldTypes();
//        java.lang.String str32 = monthDay30.toString();
//        java.util.Locale locale33 = null;
//        try {
//            java.lang.String str34 = unsupportedDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) monthDay30, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1547152848626L + "'", long27 == 1547152848626L);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "--06-15" + "'", str32.equals("--06-15"));
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 100, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("--12-01");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYearOfEra(10, 86399);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        boolean boolean6 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.minus((long) 'a');
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime12 = dateTime8.plusMonths(0);
        org.joda.time.LocalDate localDate13 = dateTime12.toLocalDate();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDate13);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField10.getLeapDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        boolean boolean19 = dateTime16.isBefore((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.minus((long) 'a');
        boolean boolean22 = copticChronology0.equals((java.lang.Object) dateTime18);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        java.lang.String str5 = dateTimeZone3.toString();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField8, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType13);
        int int16 = delegatedDateTimeField14.getMaximumValue((long) (short) 100);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField14.getDurationField();
        org.joda.time.DateTimeField dateTimeField18 = delegatedDateTimeField14.getWrappedField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) iSOChronology6, dateTimeField18);
        long long21 = skipDateTimeField19.roundHalfCeiling(2020000L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+100:35" + "'", str5.equals("+100:35"));
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86399 + "'", int16 == 86399);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2020000L + "'", long21 == 2020000L);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTime dateTime10 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime11 = property5.getDateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        boolean boolean17 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime19 = dateTime16.minus((long) 'a');
//        org.joda.time.DateTime dateTime21 = dateTime16.withSecondOfMinute(2);
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime.Property property23 = dateTime16.weekyear();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(property23);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.MonthDay monthDay3 = monthDay1.minusMonths((int) (byte) 1);
//        int[] intArray4 = monthDay1.getValues();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType11);
//        org.joda.time.DateTimeField dateTimeField13 = delegatedDateTimeField12.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology15);
//        java.lang.String str17 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) monthDay16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = monthDay16.getFieldType(0);
//        int int20 = delegatedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.MonthDay monthDay23 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology22);
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.MonthDay monthDay26 = monthDay23.withPeriodAdded(readablePeriod24, 5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withPivotYear((java.lang.Integer) 20);
//        java.lang.String str30 = monthDay23.toString(dateTimeFormatter29);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology31);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray33 = monthDay32.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfCentury();
//        org.joda.time.Chronology chronology37 = gregorianChronology34.withUTC();
//        org.joda.time.MonthDay monthDay38 = monthDay32.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology34);
//        boolean boolean39 = monthDay23.isBefore((org.joda.time.ReadablePartial) monthDay32);
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfCentury();
//        org.joda.time.Chronology chronology43 = gregorianChronology40.withUTC();
//        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(chronology43);
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = monthDay44.getFieldType(0);
//        int int47 = monthDay23.indexOf(dateTimeFieldType46);
//        try {
//            org.joda.time.MonthDay monthDay49 = monthDay1.withField(dateTimeFieldType46, 74466);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 74466 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����0615T������.000" + "'", str17.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 86399 + "'", int20 == 86399);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(monthDay26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str30.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray33);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add(0L, 0L);
//        long long27 = unsupportedDateTimeField20.add(1547152846626L, (long) 2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = unsupportedDateTimeField20.getType();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology30);
//        java.lang.String str32 = dateTimeFormatter29.print((org.joda.time.ReadablePartial) monthDay31);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = monthDay31.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology35);
//        org.joda.time.MonthDay monthDay38 = monthDay36.minusMonths((int) (byte) 1);
//        boolean boolean39 = monthDay31.isBefore((org.joda.time.ReadablePartial) monthDay38);
//        org.joda.time.Chronology chronology40 = monthDay31.getChronology();
//        try {
//            int int41 = unsupportedDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) monthDay31);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1547152848626L + "'", long27 == 1547152848626L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "����0615T������.000" + "'", str32.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(chronology40);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField8, (int) '#');
        org.joda.time.DateTimeField dateTimeField11 = julianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (byte) -1, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute((int) (short) 100, 6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfMinute(275);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int10 = offsetDateTimeField7.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        int[] intArray20 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray22 = offsetDateTimeField7.add((org.joda.time.ReadablePartial) yearMonthDay14, (int) 'a', intArray20, (int) (short) 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsShortText((long) '#', locale24);
        long long27 = offsetDateTimeField7.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.centuryOfEra();
//        org.joda.time.ReadableDuration readableDuration11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.withDurationAdded(readableDuration11, 2019);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime16 = dateTime8.withHourOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime18 = dateTime16.plusYears((int) '#');
//        org.joda.time.DateTime.Property property19 = dateTime16.yearOfCentury();
//        int int20 = dateTime16.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 585 + "'", int20 == 585);
//    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
//        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
//        long long17 = skipUndoDateTimeField14.set((long) 0, (int) 'a');
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = skipUndoDateTimeField14.getAsShortText(1001L, locale19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
//        boolean boolean25 = dateTime22.isBefore((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime.Property property26 = dateTime22.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology27);
//        int int29 = monthDay28.getMonthOfYear();
//        int int30 = property26.compareTo((org.joda.time.ReadablePartial) monthDay28);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = skipUndoDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) monthDay28, (int) ' ', locale32);
//        java.lang.String str34 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 97000L + "'", long17 == 97000L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "32" + "'", str33.equals("32"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "��:��:��.000" + "'", str34.equals("��:��:��.000"));
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int10 = offsetDateTimeField7.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.weekyear();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        int[] intArray20 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray22 = offsetDateTimeField7.add((org.joda.time.ReadablePartial) yearMonthDay14, (int) 'a', intArray20, (int) (short) 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsShortText((long) '#', locale24);
        long long28 = offsetDateTimeField7.add(0L, 2019);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField7.getMaximumTextLength(locale29);
        long long32 = offsetDateTimeField7.roundHalfCeiling(1560631246L);
        org.joda.time.DateTimeField dateTimeField33 = offsetDateTimeField7.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019000L + "'", long28 == 2019000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560631000L + "'", long32 == 1560631000L);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        long long15 = offsetDateTimeField7.roundHalfEven((long) 16500020);
        long long17 = offsetDateTimeField7.roundCeiling((-276L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16500000L + "'", long15 == 16500000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfSecond(97);
        boolean boolean18 = dateTime17.isBeforeNow();
        org.joda.time.DateTime.Property property19 = dateTime17.dayOfMonth();
        boolean boolean20 = property19.isLeap();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology1);
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay2);
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = monthDay2.getFieldType(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType12);
//        int int15 = delegatedDateTimeField13.getMaximumValue((long) (short) 100);
//        org.joda.time.DurationField durationField16 = delegatedDateTimeField13.getDurationField();
//        long long19 = durationField16.subtract(10L, (int) (short) 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField20 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType5, durationField16);
//        org.joda.time.DurationField durationField21 = unsupportedDateTimeField20.getDurationField();
//        long long24 = unsupportedDateTimeField20.add((long) (byte) 10, 0);
//        long long27 = unsupportedDateTimeField20.getDifferenceAsLong(1560631246626L, 10L);
//        java.util.Locale locale30 = null;
//        try {
//            long long31 = unsupportedDateTimeField20.set((long) (-292275054), "043500+10035", locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "����0615T������.000" + "'", str3.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 86399 + "'", int15 == 86399);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560631246L + "'", long27 == 1560631246L);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        int int8 = offsetDateTimeField7.getOffset();
        long long10 = offsetDateTimeField7.roundHalfEven((-143457955199985L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-143457955200000L) + "'", long10 == (-143457955200000L));
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
//        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField11);
//        int int17 = skipDateTimeField15.get((long) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        boolean boolean22 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.MutableDateTime mutableDateTime23 = dateTime21.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        boolean boolean28 = dateTime25.isBefore((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTime.Property property29 = dateTime27.centuryOfEra();
//        org.joda.time.DateTime dateTime30 = dateTime27.toDateTime();
//        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime21, (org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology32);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray34 = monthDay33.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.yearOfCentury();
//        org.joda.time.Chronology chronology38 = gregorianChronology35.withUTC();
//        org.joda.time.MonthDay monthDay39 = monthDay33.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology35);
//        org.joda.time.chrono.CopticChronology copticChronology40 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
//        org.joda.time.Chronology chronology44 = copticChronology40.withZone(dateTimeZone43);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone43);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone43);
//        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology35, dateTimeZone43);
//        org.joda.time.DateTime dateTime48 = dateTime27.withZoneRetainFields(dateTimeZone43);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology50);
//        java.lang.String str52 = dateTimeFormatter49.print((org.joda.time.ReadablePartial) monthDay51);
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = monthDay51.getFieldType(0);
//        org.joda.time.MonthDay monthDay56 = monthDay51.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTime dateTime57 = dateTime27.withFields((org.joda.time.ReadablePartial) monthDay51);
//        int[] intArray64 = new int[] { 16, 74458, 362100000, 4, 19 };
//        try {
//            int[] intArray66 = skipDateTimeField15.set((org.joda.time.ReadablePartial) monthDay51, 4563941, intArray64, (-21));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -21 for secondOfDay must be in the range [0,86399]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertNotNull(copticChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(zonedChronology47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "����0615T������.000" + "'", str52.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(monthDay56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(intArray64);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        boolean boolean9 = dateTime6.isBefore((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime6.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        boolean boolean15 = dateTime12.isBefore((org.joda.time.ReadableInstant) dateTime14);
        long long16 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime19 = dateTime12.withPeriodAdded(readablePeriod17, 1);
        org.joda.time.DateMidnight dateMidnight20 = dateTime19.toDateMidnight();
        org.joda.time.DateTime dateTime21 = monthDay4.toDateTime((org.joda.time.ReadableInstant) dateMidnight20);
        org.joda.time.MonthDay.Property property22 = monthDay4.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateMidnight20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10", "(\"org.joda.time.JodaTimePermission\" \"--12-01\")");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property2.getFieldType();
        org.joda.time.Interval interval4 = property2.toInterval();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone9.getUncachedZone();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) chronology5, (org.joda.time.DateTimeZone) cachedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFieldType3);
        org.junit.Assert.assertNotNull(interval4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
        boolean boolean9 = offsetDateTimeField7.isLeap((long) (byte) 0);
        int int11 = offsetDateTimeField7.get((long) (byte) 1);
        int int13 = offsetDateTimeField7.getMinimumValue(10L);
        long long15 = offsetDateTimeField7.roundHalfEven((long) 16500020);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField7.getAsText(97, locale17);
        long long20 = offsetDateTimeField7.roundHalfFloor((long) 2019);
        int int21 = offsetDateTimeField7.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 16500000L + "'", long15 == 16500000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2000L + "'", long20 == 2000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86400 + "'", int21 == 86400);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("19700105T043500.020+10035", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19700105T043500.020+10035\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTime.Property property6 = dateTime3.millisOfSecond();
        org.joda.time.DateTime.Property property7 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property2.getFieldType();
        org.joda.time.Interval interval4 = property2.toInterval();
        org.joda.time.DurationField durationField5 = property2.getDurationField();
        org.joda.time.DateTime dateTime7 = property2.setCopy((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime7.plusMinutes((int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        boolean boolean17 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property18 = dateTime14.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        boolean boolean23 = dateTime20.isBefore((org.joda.time.ReadableInstant) dateTime22);
        long long24 = property18.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime27 = dateTime20.withPeriodAdded(readablePeriod25, 1);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime9.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone29);
        try {
            org.joda.time.DateTime dateTime32 = dateTime9.withYearOfCentury((-21));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -21 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeFieldType3);
        org.junit.Assert.assertNotNull(interval4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean7 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime4.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        boolean boolean13 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime12);
        long long14 = property8.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime10.withPeriodAdded(readablePeriod15, 1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime17);
        java.lang.String str19 = dateTimeZone2.getID();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        boolean boolean25 = dateTime22.isBefore((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property26 = dateTime22.monthOfYear();
        org.joda.time.DateTime dateTime27 = property26.roundHalfEvenCopy();
        boolean boolean28 = iSOChronology20.equals((java.lang.Object) dateTime27);
        org.joda.time.DurationField durationField29 = iSOChronology20.years();
        org.joda.time.DurationField durationField30 = iSOChronology20.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+100:35" + "'", str19.equals("+100:35"));
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        long long8 = dateTimeZone3.convertLocalToUTC((-10L), true);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField10 = buddhistChronology9.weekyears();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-362100010L) + "'", long8 == (-362100010L));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.centuryOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, (int) (short) 1, 1, 6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 1);
        int int12 = offsetDateTimeField9.getDifference((long) (byte) 1, (long) 0);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
        org.joda.time.YearMonthDay yearMonthDay16 = dateTime14.toYearMonthDay();
        int[] intArray22 = new int[] { (short) 1, 2019, 2019, (short) 1 };
        int[] intArray24 = offsetDateTimeField9.add((org.joda.time.ReadablePartial) yearMonthDay16, (int) 'a', intArray22, (int) (short) 0);
        int[] intArray26 = julianChronology0.get((org.joda.time.ReadablePartial) yearMonthDay16, (-3599968L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(yearMonthDay16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType10);
//        int int13 = delegatedDateTimeField11.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, (org.joda.time.DateTimeField) delegatedDateTimeField11);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField11);
//        java.util.Locale locale16 = null;
//        int int17 = delegatedDateTimeField11.getMaximumShortTextLength(locale16);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField22, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType27);
//        int int30 = delegatedDateTimeField28.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, (org.joda.time.DateTimeField) delegatedDateTimeField28);
//        long long34 = skipUndoDateTimeField31.set((long) 0, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology36);
//        java.lang.String str38 = dateTimeFormatter35.print((org.joda.time.ReadablePartial) monthDay37);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = monthDay37.getFieldType(0);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField41 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField31, dateTimeFieldType40);
//        int int43 = zeroIsMaxDateTimeField41.getLeapAmount((long) 86399);
//        boolean boolean45 = zeroIsMaxDateTimeField41.isLeap((long) (byte) -1);
//        int int47 = zeroIsMaxDateTimeField41.get((long) 171);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology49);
//        java.lang.String str51 = dateTimeFormatter48.print((org.joda.time.ReadablePartial) monthDay50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = monthDay50.getFieldType(0);
//        org.joda.time.MonthDay monthDay55 = monthDay50.withMonthOfYear((int) (short) 1);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray56 = monthDay55.getFieldTypes();
//        int int57 = zeroIsMaxDateTimeField41.getMaximumValue((org.joda.time.ReadablePartial) monthDay55);
//        java.util.Locale locale58 = null;
//        try {
//            java.lang.String str59 = delegatedDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay55, locale58);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 86399 + "'", int13 == 86399);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 86399 + "'", int30 == 86399);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97000L + "'", long34 == 97000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "����0615T������.000" + "'", str38.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 86400 + "'", int47 == 86400);
//        org.junit.Assert.assertNotNull(dateTimeFormatter48);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "����0615T������.000" + "'", str51.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(monthDay55);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 86400 + "'", int57 == 86400);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getMaximumValue((long) (short) 100);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 4559, (java.lang.Number) 10L, (java.lang.Number) 1001L);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        boolean boolean23 = dateTime20.isBefore((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime.Property property24 = dateTime20.monthOfYear();
//        org.joda.time.DurationField durationField25 = property24.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
//        boolean boolean30 = dateTime27.isBefore((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.DateTime.Property property31 = dateTime27.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology32);
//        int int34 = monthDay33.getMonthOfYear();
//        int int35 = property31.compareTo((org.joda.time.ReadablePartial) monthDay33);
//        org.joda.time.DateTime dateTime36 = property31.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime37 = property31.getDateTime();
//        org.joda.time.DurationField durationField38 = property31.getRangeDurationField();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField39 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType14, durationField25, durationField38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 86399 + "'", int12 == 86399);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(durationField38);
//    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean5 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime2.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology7);
//        int int9 = monthDay8.getMonthOfYear();
//        int int10 = property6.compareTo((org.joda.time.ReadablePartial) monthDay8);
//        org.joda.time.DateTime dateTime11 = property6.roundHalfFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property6.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendYearOfCentury(74466, 4539);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(86399);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.addRecurringSavings("org.joda.time.IllegalFieldValueException: Value \"(\"org.joda.time.JodaTimePermission\" \"--12-01\")\" for 10 is not supported", (-292275054), 20, 2019, '#', 4546, 20, 0, false, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(3249, (-98), 4, 585, 4559, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 585 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10", "(\"org.joda.time.JodaTimePermission\" \"--12-01\")");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"--12-01\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"--12-01\")"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property5 = dateTime1.monthOfYear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology6);
//        int int8 = monthDay7.getMonthOfYear();
//        int int9 = property5.compareTo((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.DateTime dateTime10 = property5.roundHalfFloorCopy();
//        java.lang.String str11 = property5.getAsString();
//        java.lang.String str12 = property5.getAsShortText();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6" + "'", str11.equals("6"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Jun" + "'", str12.equals("Jun"));
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 1, 1, 6);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 1);
//        int int8 = offsetDateTimeField7.getOffset();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField7.getAsText((int) (short) 10, locale10);
//        boolean boolean12 = offsetDateTimeField7.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.secondOfDay();
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField14, (int) (short) 1, 1, 6);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType19);
//        org.joda.time.DateTimeField dateTimeField21 = delegatedDateTimeField20.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology23);
//        java.lang.String str25 = dateTimeFormatter22.print((org.joda.time.ReadablePartial) monthDay24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = monthDay24.getFieldType(0);
//        int int28 = delegatedDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) monthDay24);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.MonthDay monthDay31 = monthDay24.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology30);
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.MonthDay monthDay34 = monthDay31.withPeriodAdded(readablePeriod32, 5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter35.withPivotYear((java.lang.Integer) 20);
//        java.lang.String str38 = monthDay31.toString(dateTimeFormatter37);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology39);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray41 = monthDay40.getFieldTypes();
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.yearOfCentury();
//        org.joda.time.Chronology chronology45 = gregorianChronology42.withUTC();
//        org.joda.time.MonthDay monthDay46 = monthDay40.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology42);
//        boolean boolean47 = monthDay31.isBefore((org.joda.time.ReadablePartial) monthDay40);
//        int[] intArray55 = new int[] { 4566035, 4563941, 4559, 30, (byte) 0, (byte) 10 };
//        try {
//            int[] intArray57 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) monthDay31, 4, intArray55, (-442223));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -442223 for secondOfDay must be in the range [1,86400]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "����0615T������.000" + "'", str25.equals("����0615T������.000"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86399 + "'", int28 == 86399);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Jun 15, ���� �:��:�� �" + "'", str38.equals("Jun 15, ���� �:��:�� �"));
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray41);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(monthDay46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(intArray55);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) 'a');
        org.joda.time.DateTime dateTime8 = dateTime6.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = dateTime6.plusMonths(0);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfMinute();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("10", "(\"org.joda.time.JodaTimePermission\" \"--12-01\")");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean4 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime3.toMutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean10 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime12 = dateTime9.toDateTime();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray16 = monthDay15.getFieldTypes();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.yearOfCentury();
        org.joda.time.Chronology chronology20 = gregorianChronology17.withUTC();
        org.joda.time.MonthDay monthDay21 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 100, (int) '#');
        org.joda.time.Chronology chronology26 = copticChronology22.withZone(dateTimeZone25);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone25);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone25);
        org.joda.time.DateTime dateTime30 = dateTime9.withZoneRetainFields(dateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime30.minusMonths(74458);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
    }
}

