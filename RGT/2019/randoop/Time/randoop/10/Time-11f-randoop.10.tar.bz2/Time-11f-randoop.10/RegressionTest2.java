import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        int int1 = periodType0.size();
        org.joda.time.PeriodType periodType2 = periodType0.withMillisRemoved();
        org.joda.time.DurationField durationField3 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.secondOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology6.monthOfYear();
        org.joda.time.DurationField durationField10 = iSOChronology6.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        long long18 = fixedDateTimeZone15.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale25 = null;
        java.lang.String str26 = fixedDateTimeZone23.getShortName(0L, locale25);
        boolean boolean28 = fixedDateTimeZone23.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime29 = null;
        boolean boolean30 = fixedDateTimeZone23.isLocalDateTimeGap(localDateTime29);
        long long32 = fixedDateTimeZone23.convertUTCToLocal((long) 350);
        long long34 = fixedDateTimeZone15.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone23, (long) 104);
        boolean boolean35 = periodType4.equals((java.lang.Object) long34);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType37 = periodType36.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType39 = periodType36.getFieldType(0);
        int int40 = periodType4.indexOf(durationFieldType39);
        org.joda.time.field.ScaledDurationField scaledDurationField42 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType39, 123);
        java.lang.Object obj43 = null;
        org.joda.time.PeriodType periodType44 = null;
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.Period period46 = new org.joda.time.Period(obj43, periodType44, chronology45);
        org.joda.time.Period period48 = period46.minusYears((int) (byte) 0);
        org.joda.time.PeriodType periodType49 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone50);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.secondOfDay();
        org.joda.time.DateTimeField dateTimeField54 = iSOChronology51.monthOfYear();
        org.joda.time.DurationField durationField55 = iSOChronology51.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone60 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology61 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology51, (org.joda.time.DateTimeZone) fixedDateTimeZone60);
        long long63 = fixedDateTimeZone60.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone68 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale70 = null;
        java.lang.String str71 = fixedDateTimeZone68.getShortName(0L, locale70);
        boolean boolean73 = fixedDateTimeZone68.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime74 = null;
        boolean boolean75 = fixedDateTimeZone68.isLocalDateTimeGap(localDateTime74);
        long long77 = fixedDateTimeZone68.convertUTCToLocal((long) 350);
        long long79 = fixedDateTimeZone60.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone68, (long) 104);
        boolean boolean80 = periodType49.equals((java.lang.Object) long79);
        org.joda.time.PeriodType periodType81 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType82 = periodType81.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType84 = periodType81.getFieldType(0);
        int int85 = periodType49.indexOf(durationFieldType84);
        org.joda.time.Period period87 = period46.withFieldAdded(durationFieldType84, (-32));
        org.joda.time.field.ScaledDurationField scaledDurationField89 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType84, (-1));
        long long92 = scaledDurationField89.getValueAsLong((-86399965L), (long) ' ');
        int int95 = scaledDurationField89.getDifference((long) 106, 259200000L);
        org.joda.time.DurationFieldType durationFieldType96 = scaledDurationField89.getType();
        boolean boolean97 = periodType2.isSupported(durationFieldType96);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+00:00" + "'", str26.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 350L + "'", long32 == 350L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 114L + "'", long34 == 114L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(zonedChronology61);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 52L + "'", long63 == 52L);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "+00:00" + "'", str71.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 350L + "'", long77 == 350L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 114L + "'", long79 == 114L);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(periodType81);
        org.junit.Assert.assertNotNull(periodType82);
        org.junit.Assert.assertNotNull(durationFieldType84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertNotNull(period87);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 86399965L + "'", long92 == 86399965L);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 259199894 + "'", int95 == 259199894);
        org.junit.Assert.assertNotNull(durationFieldType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 100);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField31.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType32, 104, (int) ' ', (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType32, (int) ' ');
        java.util.Locale locale39 = null;
        int int40 = remainderDateTimeField38.getMaximumShortTextLength(locale39);
        int int41 = remainderDateTimeField38.getMinimumValue();
        long long43 = remainderDateTimeField38.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        int int39 = unsupportedDateTimeField35.getDifference((-3024000000L), 0L);
        java.lang.String str40 = unsupportedDateTimeField35.toString();
        int int43 = unsupportedDateTimeField35.getDifference((long) 1, (-123L));
        java.util.Locale locale46 = null;
        try {
            long long47 = unsupportedDateTimeField35.set((-123L), "DurationField[years]", locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UnsupportedDateTimeField" + "'", str40.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean10 = unsupportedDurationField9.isSupported();
        org.joda.time.DurationField durationField11 = null;
        int int12 = unsupportedDurationField9.compareTo(durationField11);
        try {
            long long15 = unsupportedDurationField9.add((long) 132, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0f + "'", number8.equals(0.0f));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 1);
        org.joda.time.Period period6 = period3.negated();
        int int7 = period6.getYears();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology5 = iSOChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.year();
        org.joda.time.DurationField durationField8 = iSOChronology3.eras();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumShortTextLength(locale6);
        long long9 = offsetDateTimeField5.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 100);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(0L, 0L);
        long long23 = offsetDateTimeField18.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology29);
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        java.lang.Object obj32 = null;
        org.joda.time.PeriodType periodType33 = null;
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(obj32, periodType33, chronology34);
        org.joda.time.Period period37 = period35.withDays(0);
        int int38 = period37.getHours();
        int int39 = period37.size();
        int[] intArray41 = iSOChronology29.get((org.joda.time.ReadablePeriod) period37, (long) (-10));
        int[] intArray43 = offsetDateTimeField18.add(readablePartial24, 4, intArray41, 0);
        int int44 = offsetDateTimeField5.getMaximumValue(readablePartial10, intArray43);
        int int45 = offsetDateTimeField5.getMaximumValue();
        long long47 = offsetDateTimeField5.roundCeiling(1560627574045L);
        org.joda.time.ReadablePartial readablePartial48 = null;
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.chrono.LenientChronology lenientChronology51 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology50);
        java.lang.Object obj52 = null;
        org.joda.time.PeriodType periodType53 = null;
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period(obj52, periodType53, chronology54);
        org.joda.time.Period period57 = period55.withDays(0);
        org.joda.time.Period period59 = period55.withHours(10);
        boolean boolean60 = lenientChronology51.equals((java.lang.Object) period59);
        java.lang.String str61 = lenientChronology51.toString();
        org.joda.time.Chronology chronology62 = lenientChronology51.withUTC();
        java.lang.Object obj63 = null;
        org.joda.time.PeriodType periodType64 = null;
        org.joda.time.Chronology chronology65 = null;
        org.joda.time.Period period66 = new org.joda.time.Period(obj63, periodType64, chronology65);
        int int67 = period66.getMinutes();
        java.lang.Class<?> wildcardClass68 = period66.getClass();
        org.joda.time.Period period69 = period66.negated();
        java.lang.Object obj70 = null;
        org.joda.time.PeriodType periodType71 = null;
        org.joda.time.Chronology chronology72 = null;
        org.joda.time.Period period73 = new org.joda.time.Period(obj70, periodType71, chronology72);
        int int74 = period73.getMinutes();
        java.lang.Class<?> wildcardClass75 = period73.getClass();
        org.joda.time.Duration duration76 = period73.toStandardDuration();
        boolean boolean78 = period73.equals((java.lang.Object) '4');
        org.joda.time.Period period79 = period66.plus((org.joda.time.ReadablePeriod) period73);
        org.joda.time.Period period80 = period73.normalizedStandard();
        org.joda.time.Period period82 = period73.withMillis(100);
        int[] intArray84 = lenientChronology51.get((org.joda.time.ReadablePeriod) period73, (long) '4');
        int int85 = offsetDateTimeField5.getMaximumValue(readablePartial48, intArray84);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86400000L + "'", long23 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 123 + "'", int44 == 123);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 123 + "'", int45 == 123);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560628800000L + "'", long47 == 1560628800000L);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(lenientChronology51);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "LenientChronology[ISOChronology[hi!]]" + "'", str61.equals("LenientChronology[ISOChronology[hi!]]"));
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(duration76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertNotNull(period82);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 123 + "'", int85 == 123);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone5.getShortName(0L, locale7);
        long long11 = fixedDateTimeZone5.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone12 = fixedDateTimeZone5.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale19 = null;
        java.lang.String str20 = fixedDateTimeZone17.getShortName(0L, locale19);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        long long24 = fixedDateTimeZone17.convertLocalToUTC((long) 10, false);
        long long26 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone17, (long) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.lang.String str32 = fixedDateTimeZone31.getID();
        long long34 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone31, (long) 350);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology35 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 350L + "'", long34 == 350L);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = remainderDateTimeField27.getMinimumValue();
        int int43 = remainderDateTimeField27.getDivisor();
        java.lang.String str44 = remainderDateTimeField27.getName();
        java.util.Locale locale45 = null;
        int int46 = remainderDateTimeField27.getMaximumShortTextLength(locale45);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.Period period51 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology50);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 100);
        long long57 = offsetDateTimeField54.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale58 = null;
        int int59 = offsetDateTimeField54.getMaximumShortTextLength(locale58);
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone62);
        org.joda.time.Period period64 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology63);
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology63.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = offsetDateTimeField67.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType68, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField54, dateTimeFieldType68, 243);
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone77);
        org.joda.time.Period period79 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology78);
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology78.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField82 = new org.joda.time.field.OffsetDateTimeField(dateTimeField80, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType83 = offsetDateTimeField82.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType83, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField88 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField74, dateTimeFieldType83);
        long long91 = dividedDateTimeField88.add(3675L, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType92 = dividedDateTimeField88.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField93 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType92);
        long long95 = zeroIsMaxDateTimeField93.remainder((long) 101);
        long long97 = zeroIsMaxDateTimeField93.roundHalfEven(82252800000L);
        org.joda.time.ReadablePartial readablePartial98 = null;
        int int99 = zeroIsMaxDateTimeField93.getMinimumValue(readablePartial98);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 243 + "'", int43 == 243);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "dayOfWeek" + "'", str44.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertNotNull(iSOChronology78);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeFieldType83);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 3675L + "'", long91 == 3675L);
        org.junit.Assert.assertNotNull(dateTimeFieldType92);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 101L + "'", long95 == 101L);
        org.junit.Assert.assertTrue("'" + long97 + "' != '" + 82252800000L + "'", long97 == 82252800000L);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 1 + "'", int99 == 1);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '4');
        int int9 = fixedDateTimeZone4.getOffsetFromLocal((long) 8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone10.getUncachedZone();
        int int14 = cachedDateTimeZone10.getOffset((-131L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 1);
        org.joda.time.Period period7 = period3.withMillis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period7.toDurationFrom(readableInstant8);
        org.joda.time.Period period11 = period7.withMonths((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.Object obj13 = null;
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(obj13, periodType14, chronology15);
        org.joda.time.Period period18 = period16.withDays(0);
        org.joda.time.Period period20 = period16.withHours(10);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period22 = period16.normalizedStandard(periodType21);
        org.joda.time.Period period24 = period16.withYears((-10));
        boolean boolean25 = gregorianChronology12.equals((java.lang.Object) period24);
        java.lang.String str26 = gregorianChronology12.toString();
        java.lang.String str27 = gregorianChronology12.toString();
        org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) period11, (org.joda.time.Chronology) gregorianChronology12);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "GregorianChronology[hi!]" + "'", str26.equals("GregorianChronology[hi!]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "GregorianChronology[hi!]" + "'", str27.equals("GregorianChronology[hi!]"));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = remainderDateTimeField27.getMinimumValue();
        int int43 = remainderDateTimeField27.getDivisor();
        java.lang.String str44 = remainderDateTimeField27.getName();
        java.util.Locale locale45 = null;
        int int46 = remainderDateTimeField27.getMaximumShortTextLength(locale45);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.Period period51 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology50);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 100);
        long long57 = offsetDateTimeField54.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale58 = null;
        int int59 = offsetDateTimeField54.getMaximumShortTextLength(locale58);
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone62);
        org.joda.time.Period period64 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology63);
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology63.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = offsetDateTimeField67.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType68, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField54, dateTimeFieldType68, 243);
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.chrono.ISOChronology iSOChronology78 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone77);
        org.joda.time.Period period79 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology78);
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology78.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField82 = new org.joda.time.field.OffsetDateTimeField(dateTimeField80, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType83 = offsetDateTimeField82.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType83, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField88 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField74, dateTimeFieldType83);
        long long91 = dividedDateTimeField88.add(3675L, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType92 = dividedDateTimeField88.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField93 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField27, dateTimeFieldType92);
        long long95 = zeroIsMaxDateTimeField93.remainder(132L);
        int int96 = zeroIsMaxDateTimeField93.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 243 + "'", int43 == 243);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "dayOfWeek" + "'", str44.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
        org.junit.Assert.assertNotNull(iSOChronology63);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertNotNull(iSOChronology78);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(dateTimeFieldType83);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 3675L + "'", long91 == 3675L);
        org.junit.Assert.assertNotNull(dateTimeFieldType92);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 132L + "'", long95 == 132L);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 243 + "'", int96 == 243);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        org.joda.time.ReadablePartial readablePartial38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial45 = null;
        int[] intArray50 = new int[] { (short) 1, (byte) 0, (-10), (-10) };
        int int51 = offsetDateTimeField44.getMaximumValue(readablePartial45, intArray50);
        try {
            int int52 = unsupportedDateTimeField35.getMaximumValue(readablePartial38, intArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 123 + "'", int51 == 123);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 104, (-106L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 210L + "'", long2 == 210L);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.Period period2 = new org.joda.time.Period(1560628800000L, (-210857702400000L));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.ReadableInstant readableInstant0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(obj1, periodType2, chronology3);
        org.joda.time.Period period6 = period4.withDays(0);
        org.joda.time.Period period8 = period4.withHours(10);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationFrom(readableInstant9);
        long long11 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration10);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 36000000L + "'", long11 == 36000000L);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = zonedChronology11.weeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.monthOfYear();
        org.joda.time.DurationField durationField21 = iSOChronology17.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology17, (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long29 = fixedDateTimeZone26.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale36 = null;
        java.lang.String str37 = fixedDateTimeZone34.getShortName(0L, locale36);
        boolean boolean39 = fixedDateTimeZone34.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime40 = null;
        boolean boolean41 = fixedDateTimeZone34.isLocalDateTimeGap(localDateTime40);
        long long43 = fixedDateTimeZone34.convertUTCToLocal((long) 350);
        long long45 = fixedDateTimeZone26.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone34, (long) 104);
        boolean boolean46 = periodType15.equals((java.lang.Object) long45);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType48 = periodType47.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType50 = periodType47.getFieldType(0);
        int int51 = periodType15.indexOf(durationFieldType50);
        org.joda.time.field.DecoratedDurationField decoratedDurationField52 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType50);
        long long53 = decoratedDurationField52.getUnitMillis();
        long long56 = decoratedDurationField52.getMillis((long) 132, (long) (byte) -1);
        long long59 = decoratedDurationField52.getMillis(8, (-2764799990L));
        boolean boolean60 = decoratedDurationField52.isSupported();
        int int62 = decoratedDurationField52.getValue((long) 10);
        int int65 = decoratedDurationField52.getDifference((long) (short) 10, 0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+00:00" + "'", str37.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 350L + "'", long43 == 350L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 114L + "'", long45 == 114L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(durationFieldType50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604800000L + "'", long53 == 604800000L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 79833600000L + "'", long56 == 79833600000L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 4838400000L + "'", long59 == 4838400000L);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.halfdayOfDay();
        org.joda.time.DurationField durationField7 = iSOChronology1.millis();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.years();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableInstant9, periodType10);
        long long14 = iSOChronology1.add((org.joda.time.ReadablePeriod) period11, (-52L), (int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-52L) + "'", long14 == (-52L));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DurationField durationField5 = iSOChronology1.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        boolean boolean11 = fixedDateTimeZone10.isFixed();
        java.lang.String str13 = fixedDateTimeZone10.getName((long) '4');
        int int15 = fixedDateTimeZone10.getOffsetFromLocal((long) 8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        java.lang.String str18 = cachedDateTimeZone16.getNameKey((long) 107);
        int int20 = cachedDateTimeZone16.getOffset(79833600000L);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(zonedChronology21);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        int int39 = unsupportedDateTimeField35.getDifference((-3024000000L), 0L);
        java.lang.String str40 = unsupportedDateTimeField35.toString();
        int int43 = unsupportedDateTimeField35.getDifference((long) 1, (-123L));
        try {
            long long45 = unsupportedDateTimeField35.roundCeiling((long) 107);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "UnsupportedDateTimeField" + "'", str40.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Weeks weeks2 = period1.toStandardWeeks();
        org.joda.time.Period period4 = period1.plusMonths((int) (byte) -1);
        org.joda.time.Period period6 = period4.plusSeconds(100);
        org.joda.time.Period period7 = period4.toPeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(weeks2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-62161257599997L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -62161257599997");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '4');
        int int9 = fixedDateTimeZone4.getOffsetFromLocal((long) 8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        java.lang.String str13 = dateTimeZone11.getName(243L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00" + "'", str13.equals("+00:00"));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        long long44 = dividedDateTimeField41.add(3675L, 0L);
        java.util.Locale locale46 = null;
        java.lang.String str47 = dividedDateTimeField41.getAsShortText(0, locale46);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 3675L + "'", long44 == 3675L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "0" + "'", str47.equals("0"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period8 = period3.toPeriod();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType10 = periodType9.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.monthOfYear();
        org.joda.time.DurationField durationField16 = iSOChronology12.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = zonedChronology22.withZone(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period8, periodType9, (org.joda.time.Chronology) zonedChronology22);
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology22.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology22.secondOfMinute();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationFieldType8);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(obj3, periodType4, chronology5);
        org.joda.time.Period period8 = period6.withDays(0);
        org.joda.time.Period period10 = period6.withHours(10);
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) period10);
        java.lang.String str12 = lenientChronology2.toString();
        org.joda.time.DateTimeField dateTimeField13 = lenientChronology2.hourOfHalfday();
        long long19 = lenientChronology2.getDateTimeMillis(100L, 0, 243, 0, 107);
        org.joda.time.DurationField durationField20 = lenientChronology2.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = fixedDateTimeZone25.getShortName(0L, locale27);
        long long31 = fixedDateTimeZone25.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant32 = null;
        int int33 = fixedDateTimeZone25.getOffset(readableInstant32);
        int int35 = fixedDateTimeZone25.getOffset((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale42 = null;
        java.lang.String str43 = fixedDateTimeZone40.getShortName(0L, locale42);
        long long46 = fixedDateTimeZone40.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant47 = null;
        int int48 = fixedDateTimeZone40.getOffset(readableInstant47);
        int int50 = fixedDateTimeZone40.getOffset((long) (short) -1);
        long long52 = fixedDateTimeZone25.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone40, (long) 35);
        boolean boolean54 = fixedDateTimeZone40.isStandardOffset((long) (-10));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone55 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone56 = cachedDateTimeZone55.getUncachedZone();
        boolean boolean57 = lenientChronology2.equals((java.lang.Object) cachedDateTimeZone55);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LenientChronology[ISOChronology[hi!]]" + "'", str12.equals("LenientChronology[ISOChronology[hi!]]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 14580107L + "'", long19 == 14580107L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+00:00" + "'", str43.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 35L + "'", long46 == 35L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 35L + "'", long52 == 35L);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }
}

