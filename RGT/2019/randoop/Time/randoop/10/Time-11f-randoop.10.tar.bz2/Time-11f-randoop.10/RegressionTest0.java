import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePartial readablePartial2 = null;
        int[] intArray8 = new int[] { (short) -1, ' ', 0, ' ', (short) 1 };
        try {
            iSOChronology1.validate(readablePartial2, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = iSOChronology1.get(readablePartial2, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) 100, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("PT0S");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT0S/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) 35, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1.0f), (java.lang.Number) 0L, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Period period6 = period3.withFieldAdded(durationFieldType4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology1.get(readablePeriod3, (long) 'a', (long) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationField durationField2 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType5 = periodType4.withMillisRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant2, readableDuration3, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMonthsRemoved();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = fixedDateTimeZone4.getOffset(readableInstant11);
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffset((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PT0S", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT0S/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            int[] intArray7 = iSOChronology3.get(readablePartial5, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long9 = iSOChronology1.getDateTimeMillis(100, (int) (byte) 1, (int) (byte) -1, (int) '#', (int) (byte) 0, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType9 = periodType8.withMillisRemoved();
        try {
            org.joda.time.Period period10 = new org.joda.time.Period((int) (byte) 0, 35, (int) '#', (int) (short) 10, 35, (int) ' ', 0, 0, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = offsetDateTimeField7.getAsShortText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(100L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = new org.joda.time.DurationFieldType[] { durationFieldType0 };
        try {
            org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.forFields(durationFieldTypeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withMonthsRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 35, periodType6);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 1);
        org.joda.time.Period period6 = period3.negated();
        org.joda.time.Period period8 = period3.minusMonths((int) (short) 100);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.hours();
        try {
            org.joda.time.Period period10 = period8.normalizedStandard(periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 10, "PeriodType[YearMonthDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        long long12 = offsetDateTimeField7.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale13 = null;
        try {
            long long14 = offsetDateTimeField7.set((long) 'a', "+00:00", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        try {
            long long17 = zonedChronology11.getDateTimeMillis((long) (-1), (int) (short) 0, (-1), (int) (short) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            int[] intArray3 = gregorianChronology0.get(readablePartial1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (short) 10, 0, (int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField7.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.get(durationFieldType2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.weeks();
        org.joda.time.DurationField durationField6 = iSOChronology2.eras();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField7 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.weeks();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology7.hourOfDay();
        org.joda.time.DurationField durationField10 = iSOChronology7.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField11 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField5, durationField10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        try {
            long long19 = iSOChronology1.getDateTimeMillis(35, (-1), 0, (int) (short) 1, 100, (int) (short) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) -1, 2764800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -2764800000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        try {
            long long19 = offsetDateTimeField7.set((long) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.centuryOfEra();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, 0, (int) (short) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [-1,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.centuryOfEra();
        java.lang.String str4 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[hi!]" + "'", str4.equals("ISOChronology[hi!]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (short) 1, (short) 100 };
        try {
            int[] intArray17 = offsetDateTimeField7.add(readablePartial11, 8, intArray15, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.dayOfWeek();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) (-1L), (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.minuteOfDay();
        try {
            long long22 = iSOChronology1.getDateTimeMillis((int) (short) 1, (int) ' ', (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 10, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 350 + "'", int2 == 350);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560627574045L + "'", long1 == 1560627574045L);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField10 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 3, (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = period3.normalizedStandard(periodType8);
        try {
            org.joda.time.Period period11 = period9.withWeeks(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        try {
            org.joda.time.Period period5 = period3.withMonths(8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.centuries();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = iSOChronology1.set(readablePartial5, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        long long17 = offsetDateTimeField7.roundHalfEven((long) '4');
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        org.joda.time.Period period8 = period3.plusMonths((int) '4');
        org.joda.time.Period period10 = period3.plusDays(100);
        org.joda.time.Hours hours11 = period10.toStandardHours();
        try {
            int int13 = period10.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(hours11);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.Period period1 = new org.joda.time.Period((long) (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1560627574045L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        org.joda.time.IllegalInstantException illegalInstantException3 = new org.joda.time.IllegalInstantException("");
        org.joda.time.IllegalInstantException illegalInstantException6 = new org.joda.time.IllegalInstantException((long) 0, "PeriodType[YearMonthDayTime]");
        illegalInstantException3.addSuppressed((java.lang.Throwable) illegalInstantException6);
        illegalInstantException1.addSuppressed((java.lang.Throwable) illegalInstantException3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusYears((int) (byte) 0);
        java.lang.Object obj6 = null;
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(obj6, periodType7, chronology8);
        org.joda.time.Period period11 = period9.withDays(0);
        org.joda.time.Period period13 = period9.withHours(10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period15 = period9.normalizedStandard(periodType14);
        org.joda.time.Period period16 = period3.withPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = null;
        try {
            org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) periodType14, periodType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        try {
            long long18 = zonedChronology11.getDateTimeMillis((int) (byte) 1, (int) (byte) 0, (int) '#', 101);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 0, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology1.days();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 100);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, dateTimeFieldType27, 104, (int) ' ', (int) '4');
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2764800000L + "'", long10 == 2764800000L);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1.0f), (java.lang.Number) 3L, (java.lang.Number) 104);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        long long13 = fixedDateTimeZone10.nextTransition((long) '4');
        org.joda.time.LocalDateTime localDateTime14 = null;
        boolean boolean15 = fixedDateTimeZone10.isLocalDateTimeGap(localDateTime14);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DurationField durationField14 = iSOChronology12.eras();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.hourOfDay();
        org.joda.time.DurationField durationField19 = iSOChronology16.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField20 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType8, durationField14, durationField19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The unit milliseconds must be at least 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfWeek();
        try {
            long long11 = iSOChronology1.getDateTimeMillis((int) '#', (int) (short) 1, (int) (byte) 1, (int) (byte) 10, (-1), (int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusYears((int) (byte) 0);
        java.lang.Object obj6 = null;
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(obj6, periodType7, chronology8);
        org.joda.time.Period period11 = period9.withDays(0);
        org.joda.time.Period period13 = period9.withHours(10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period15 = period9.normalizedStandard(periodType14);
        org.joda.time.Period period16 = period3.withPeriodType(periodType14);
        org.joda.time.Weeks weeks17 = period16.toStandardWeeks();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(weeks17);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = period3.normalizedStandard(periodType8);
        int int10 = period9.getMillis();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.lang.String str5 = fixedDateTimeZone4.getID();
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) 1, false);
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology5 = iSOChronology3.withUTC();
        long long9 = iSOChronology3.add((long) 0, 0L, 35);
        java.lang.Object obj10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(obj10, periodType11, chronology12);
        org.joda.time.Period period15 = period13.withDays(0);
        int int16 = period15.getYears();
        org.joda.time.Days days17 = period15.toStandardDays();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period19 = period15.normalizedStandard(periodType18);
        java.lang.Object obj20 = null;
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(obj20, periodType21, chronology22);
        int int24 = period23.getMinutes();
        org.joda.time.Period period26 = period23.plusHours((int) (short) -1);
        org.joda.time.Period period28 = period23.plusMonths((int) '4');
        org.joda.time.Period period29 = period15.minus((org.joda.time.ReadablePeriod) period23);
        boolean boolean30 = iSOChronology3.equals((java.lang.Object) period15);
        org.joda.time.Period period32 = period15.withYears(0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(days17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(period32);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period6 = period5.toPeriod();
        org.joda.time.PeriodType periodType7 = period5.getPeriodType();
        java.lang.Class<?> wildcardClass8 = period5.getClass();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.String str3 = lenientChronology2.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LenientChronology[ISOChronology[hi!]]" + "'", str3.equals("LenientChronology[ISOChronology[hi!]]"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) -1, 107, 350);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 243 + "'", int4 == 243);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((int) (short) 0, 4, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        org.joda.time.Period period8 = period3.withWeeks((int) '4');
        org.joda.time.Period period10 = period8.plusMonths(0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PeriodType[YearMonthDayTime]", (int) (short) 100, (-10), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for PeriodType[YearMonthDayTime] must be in the range [-10,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        int int6 = period5.getYears();
        org.joda.time.Days days7 = period5.toStandardDays();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period9 = period5.normalizedStandard(periodType8);
        java.lang.Object obj10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(obj10, periodType11, chronology12);
        int int14 = period13.getMinutes();
        org.joda.time.Period period16 = period13.plusHours((int) (short) -1);
        org.joda.time.Period period18 = period13.plusMonths((int) '4');
        org.joda.time.Period period19 = period5.minus((org.joda.time.ReadablePeriod) period13);
        try {
            org.joda.time.DurationFieldType durationFieldType21 = period5.getFieldType((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        java.lang.Class<?> wildcardClass5 = period3.getClass();
        org.joda.time.Period period6 = period3.negated();
        java.lang.Object obj7 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(obj7, periodType8, chronology9);
        int int11 = period10.getMinutes();
        java.lang.Class<?> wildcardClass12 = period10.getClass();
        org.joda.time.Duration duration13 = period10.toStandardDuration();
        boolean boolean15 = period10.equals((java.lang.Object) '4');
        org.joda.time.Period period16 = period3.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period17 = period10.normalizedStandard();
        org.joda.time.Seconds seconds18 = period10.toStandardSeconds();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(seconds18);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField10 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        try {
            int int5 = period3.getValue(107);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = period3.normalizedStandard(periodType8);
        try {
            org.joda.time.Period period11 = period9.withHours(104);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        long long12 = offsetDateTimeField7.roundCeiling((long) ' ');
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType29, 104, (int) ' ', (int) '4');
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, (int) (short) 0, 3, 107);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400000L + "'", long12 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("ISOChronology[hi!]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[hi!]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        try {
            long long30 = remainderDateTimeField27.set((-32L), 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone10 = dateTimeZone9.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.secondOfDay();
        org.joda.time.DurationField durationField18 = iSOChronology1.millis();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField20 = new org.joda.time.field.DecoratedDurationField(durationField18, durationFieldType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-10), (java.lang.Number) 123, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        int int12 = offsetDateTimeField7.getMaximumValue((long) 8);
        long long14 = offsetDateTimeField7.remainder(1L);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 100);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology26);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology26.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, dateTimeFieldType31, 104, (int) ' ', (int) '4');
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField36 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 107 + "'", int12 == 107);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = zonedChronology11.weeks();
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology11.getZone();
        org.joda.time.ReadablePartial readablePartial16 = null;
        try {
            long long18 = zonedChronology11.set(readablePartial16, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Days days6 = period5.toStandardDays();
        org.joda.time.Period period8 = period5.minusDays((-10));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(days6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 105, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3675L + "'", long2 == 3675L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(0L, locale11);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology14 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DurationField durationField16 = gregorianChronology15.eras();
        try {
            long long19 = durationField16.subtract((-1L), 3675L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) ' ');
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField13 = new org.joda.time.field.DecoratedDurationField(durationField11, durationFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2764800000L + "'", long10 == 2764800000L);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        org.joda.time.Period period8 = period3.plusMonths((int) '4');
        org.joda.time.Period period10 = period3.plusDays(100);
        org.joda.time.Hours hours11 = period10.toStandardHours();
        java.lang.Object obj12 = null;
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(obj12, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withDays(0);
        int int18 = period17.getHours();
        int int19 = period17.size();
        org.joda.time.Period period20 = period10.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.years();
        org.joda.time.Period period22 = period10.normalizedStandard(periodType21);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(hours11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) (byte) 100, 1);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 99L + "'", long3 == 99L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = period3.normalizedStandard(periodType8);
        try {
            org.joda.time.Period period11 = period9.plusDays((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        try {
            long long21 = zonedChronology11.getDateTimeMillis((-1), 104, (int) (byte) 100, 100, (int) (byte) 1, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        int int6 = period5.getHours();
        int int7 = period5.size();
        int int8 = period5.getHours();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.millisOfSecond();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType9 = periodType8.withMillisRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant6, readableDuration7, periodType8);
        int[] intArray12 = iSOChronology1.get((org.joda.time.ReadablePeriod) period10, (long) 105);
        int int13 = period10.getHours();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) '#');
        org.joda.time.Period period3 = period1.minusMillis(350);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DurationField durationField3 = iSOChronology1.days();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 101);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858033600000L) + "'", long1 == (-210858033600000L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        try {
            long long6 = iSOChronology1.getDateTimeMillis(243, (int) '4', (int) (byte) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology5 = iSOChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.Object obj1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(obj1, periodType2, chronology3);
        org.joda.time.Period period6 = period4.withDays(0);
        org.joda.time.Period period8 = period4.withHours(10);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period10 = period4.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period4.withYears((-10));
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) period12);
        int int14 = period12.getWeeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) 'a');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 105, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 106L + "'", long2 == 106L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        boolean boolean4 = iSOChronology1.equals((java.lang.Object) 10.0d);
        org.joda.time.DurationField durationField5 = iSOChronology1.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology30.millisOfSecond();
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType38 = periodType37.withMillisRemoved();
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant35, readableDuration36, periodType37);
        int[] intArray41 = iSOChronology30.get((org.joda.time.ReadablePeriod) period39, (long) 105);
        int int42 = remainderDateTimeField27.getMaximumValue(readablePartial28, intArray41);
        boolean boolean43 = remainderDateTimeField27.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 242 + "'", int42 == 242);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.dayOfWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, 0L, periodType2, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.PeriodType periodType10 = null;
        try {
            org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) (short) 1, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1.0f), (java.lang.Number) (-1L), (java.lang.Number) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 0, "PeriodType[YearMonthDayTime]");
        java.lang.String str3 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (PeriodType[YearMonthDayTime])" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (PeriodType[YearMonthDayTime])"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        java.lang.String str12 = zonedChronology11.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str12.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = remainderDateTimeField27.getMinimumValue();
        try {
            long long45 = remainderDateTimeField27.addWrapField((long) 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 204 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.Chronology chronology35 = iSOChronology33.withUTC();
        java.lang.Object obj36 = null;
        org.joda.time.PeriodType periodType37 = null;
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period(obj36, periodType37, chronology38);
        org.joda.time.Period period41 = period39.withDays(0);
        int int42 = period41.getHours();
        int int43 = period41.size();
        int[] intArray45 = iSOChronology33.get((org.joda.time.ReadablePeriod) period41, (long) (-10));
        try {
            int[] intArray47 = remainderDateTimeField27.add(readablePartial28, (int) (byte) 0, intArray45, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) '#', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period8 = period3.toPeriod();
        org.joda.time.Period period9 = period3.negated();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(104);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology1.year();
        org.joda.time.DurationField durationField19 = iSOChronology1.years();
        java.lang.Object obj20 = null;
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period(obj20, periodType21, chronology22);
        int int24 = period23.getMinutes();
        java.lang.Class<?> wildcardClass25 = period23.getClass();
        org.joda.time.Period period26 = period23.negated();
        org.joda.time.Period period27 = period26.normalizedStandard();
        boolean boolean28 = iSOChronology1.equals((java.lang.Object) period27);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusYears((int) (byte) 0);
        java.lang.String str6 = period5.toString();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField7.getWrappedField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.lang.Object obj10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(obj10, periodType11, chronology12);
        org.joda.time.Period period15 = period13.minusMillis((int) (byte) 1);
        org.joda.time.Period period16 = period13.negated();
        org.joda.time.Period period18 = period13.minusMonths((int) (short) 100);
        int[] intArray19 = period13.getValues();
        int int20 = offsetDateTimeField7.getMinimumValue(readablePartial9, intArray19);
        int int22 = offsetDateTimeField7.getLeapAmount((long) 4);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 101 + "'", int20 == 101);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str19 = illegalFieldValueException18.getIllegalStringValue();
        java.lang.Number number20 = illegalFieldValueException18.getLowerBound();
        boolean boolean21 = zonedChronology11.equals((java.lang.Object) illegalFieldValueException18);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = illegalFieldValueException18.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(dateTimeFieldType22);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period6 = period5.toPeriod();
        org.joda.time.Seconds seconds7 = period6.toStandardSeconds();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(seconds7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 35, chronology1);
        org.joda.time.Period period4 = period2.withYears(350);
        org.joda.time.Period period6 = period2.minusMillis(0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.Period period13 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 100);
        long long19 = offsetDateTimeField16.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField16.getMaximumShortTextLength(locale20);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField29.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField36 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType30, 243);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.Period period41 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology40);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField44.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType45, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField36, dateTimeFieldType45);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType45, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str19 = illegalFieldValueException18.getIllegalStringValue();
        java.lang.Number number20 = illegalFieldValueException18.getLowerBound();
        boolean boolean21 = zonedChronology11.equals((java.lang.Object) illegalFieldValueException18);
        java.lang.String str22 = illegalFieldValueException18.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.0" + "'", str22.equals("1.0"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560627574045L + "'", long0 == 1560627574045L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(243, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 243 + "'", int2 == 243);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType9, 8, 4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.secondOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology30.monthOfYear();
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology30.millisOfSecond();
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType38 = periodType37.withMillisRemoved();
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant35, readableDuration36, periodType37);
        int[] intArray41 = iSOChronology30.get((org.joda.time.ReadablePeriod) period39, (long) 105);
        int int42 = remainderDateTimeField27.getMaximumValue(readablePartial28, intArray41);
        int int43 = remainderDateTimeField27.getDivisor();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 242 + "'", int42 == 242);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 243 + "'", int43 == 243);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = zonedChronology11.weeks();
        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField21.getMaximumShortTextLength(locale22);
        long long25 = offsetDateTimeField21.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial26 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.Period period31 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology30.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, 100);
        long long37 = offsetDateTimeField34.getDifferenceAsLong(0L, 0L);
        long long39 = offsetDateTimeField34.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial40 = null;
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology45);
        org.joda.time.Chronology chronology47 = iSOChronology45.withUTC();
        java.lang.Object obj48 = null;
        org.joda.time.PeriodType periodType49 = null;
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period(obj48, periodType49, chronology50);
        org.joda.time.Period period53 = period51.withDays(0);
        int int54 = period53.getHours();
        int int55 = period53.size();
        int[] intArray57 = iSOChronology45.get((org.joda.time.ReadablePeriod) period53, (long) (-10));
        int[] intArray59 = offsetDateTimeField34.add(readablePartial40, 4, intArray57, 0);
        int int60 = offsetDateTimeField21.getMaximumValue(readablePartial26, intArray59);
        boolean boolean61 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone15, (java.lang.Object) readablePartial26);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 86400000L + "'", long39 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 8 + "'", int55 == 8);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 123 + "'", int60 == 123);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "LenientChronology[ISOChronology[hi!]]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 100);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = fixedDateTimeZone4.getOffset(readableInstant6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getShortName(259200010L, locale9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) ' ', "");
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(107);
        org.joda.time.Period period3 = period1.minusSeconds(1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.era();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        int int28 = remainderDateTimeField27.getDivisor();
        long long30 = remainderDateTimeField27.roundFloor((long) '#');
        long long32 = remainderDateTimeField27.roundHalfCeiling(259200010L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 243 + "'", int28 == 243);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 259200000L + "'", long32 == 259200000L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 259200010L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        int int6 = period5.getYears();
        org.joda.time.Days days7 = period5.toStandardDays();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period9 = period5.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period5.minusMonths(100);
        java.lang.String str12 = period5.toString();
        org.joda.time.Period period14 = period5.plusMonths(243);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PT0S" + "'", str12.equals("PT0S"));
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "PT0S");
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        int int45 = dividedDateTimeField41.getDifference((long) 35, (long) 243);
        long long47 = dividedDateTimeField41.remainder((long) 242);
        try {
            long long49 = dividedDateTimeField41.roundFloor(0L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 242L + "'", long47 == 242L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        int int6 = period5.getYears();
        org.joda.time.Days days7 = period5.toStandardDays();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period9 = period5.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period5.minusDays((int) '4');
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(days7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) 'a', ' ', 104, (int) (byte) 10, (-1), false, 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover(10, '#', 8, (int) (short) 10, 0, false, 123);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(105);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-105) + "'", int1 == (-105));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        java.lang.String str14 = zonedChronology11.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[ISOChronology[UTC], ]" + "'", str14.equals("ZonedChronology[ISOChronology[UTC], ]"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray11 = new int[] { (short) 1, (byte) 0, (-10), (-10) };
        int int12 = offsetDateTimeField5.getMaximumValue(readablePartial6, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.monthOfYear();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology16.millisOfSecond();
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType24 = periodType23.withMillisRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant21, readableDuration22, periodType23);
        int[] intArray27 = iSOChronology16.get((org.joda.time.ReadablePeriod) period25, (long) 105);
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = offsetDateTimeField5.set(readablePartial13, 104, intArray27, "PeriodType[YearMonthDayTime]", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[YearMonthDayTime]\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 123 + "'", int12 == 123);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        try {
            long long44 = dividedDateTimeField41.roundFloor(2764800000L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        org.joda.time.DurationField durationField42 = dividedDateTimeField41.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.Period period47 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology46);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 100);
        long long53 = offsetDateTimeField50.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale54 = null;
        int int55 = offsetDateTimeField50.getMaximumShortTextLength(locale54);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField63.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType64, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType64, 243);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField41, dateTimeFieldType64, 107);
        try {
            long long75 = dividedDateTimeField41.addWrapField((-32L), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("119", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"119/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        try {
            long long43 = dividedDateTimeField41.roundFloor((-115200001L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.Period period8 = new org.joda.time.Period(3, 10, (int) (short) -1, 8, 4, 0, 1, 100);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        org.joda.time.Period period8 = period3.plusMonths((int) '4');
        org.joda.time.Period period9 = period8.negated();
        try {
            org.joda.time.Minutes minutes10 = period9.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) (byte) 100);
        java.util.Locale locale51 = null;
        int int52 = offsetDateTimeField50.getMaximumShortTextLength(locale51);
        long long54 = offsetDateTimeField50.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial55 = null;
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        long long66 = offsetDateTimeField63.getDifferenceAsLong(0L, 0L);
        long long68 = offsetDateTimeField63.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial69 = null;
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone73);
        org.joda.time.Period period75 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology74);
        org.joda.time.Chronology chronology76 = iSOChronology74.withUTC();
        java.lang.Object obj77 = null;
        org.joda.time.PeriodType periodType78 = null;
        org.joda.time.Chronology chronology79 = null;
        org.joda.time.Period period80 = new org.joda.time.Period(obj77, periodType78, chronology79);
        org.joda.time.Period period82 = period80.withDays(0);
        int int83 = period82.getHours();
        int int84 = period82.size();
        int[] intArray86 = iSOChronology74.get((org.joda.time.ReadablePeriod) period82, (long) (-10));
        int[] intArray88 = offsetDateTimeField63.add(readablePartial69, 4, intArray86, 0);
        int int89 = offsetDateTimeField50.getMaximumValue(readablePartial55, intArray88);
        java.util.Locale locale91 = null;
        try {
            int[] intArray92 = dividedDateTimeField41.set(readablePartial43, 8, intArray88, "PT0S", locale91);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT0S\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 86400000L + "'", long68 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology74);
        org.junit.Assert.assertNotNull(chronology76);
        org.junit.Assert.assertNotNull(period82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 8 + "'", int84 == 8);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 123 + "'", int89 == 123);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.lang.String str5 = fixedDateTimeZone4.getID();
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) 1, false);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) 100);
        long long14 = fixedDateTimeZone4.convertLocalToUTC((long) 243, true, 10L);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 243L + "'", long14 == 243L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.centuries();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        int int28 = remainderDateTimeField27.getDivisor();
        long long30 = remainderDateTimeField27.roundFloor((long) '#');
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.Period period37 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology36);
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology36.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, 100);
        org.joda.time.DateTimeField dateTimeField41 = offsetDateTimeField40.getWrappedField();
        int int43 = offsetDateTimeField40.getLeapAmount(1L);
        org.joda.time.ReadablePartial readablePartial44 = null;
        java.lang.Object obj46 = null;
        org.joda.time.PeriodType periodType47 = null;
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.Period period49 = new org.joda.time.Period(obj46, periodType47, chronology48);
        org.joda.time.Period period51 = period49.minusMillis((int) (byte) 1);
        org.joda.time.Period period52 = period49.negated();
        org.joda.time.Period period54 = period49.minusMonths((int) (short) 100);
        int[] intArray55 = period49.getValues();
        int[] intArray57 = offsetDateTimeField40.add(readablePartial44, (int) (byte) 100, intArray55, 0);
        try {
            int[] intArray59 = remainderDateTimeField27.set(readablePartial31, (int) (byte) -1, intArray57, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 243 + "'", int28 == 243);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.lang.String str5 = fixedDateTimeZone4.getID();
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) 1, false);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal((long) 100);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = fixedDateTimeZone4.getShortName(2764800000L, locale14);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00" + "'", str15.equals("+00:00"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 1);
        org.joda.time.Seconds seconds6 = period3.toStandardSeconds();
        try {
            int int8 = period3.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(seconds6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType3 = periodType0.getFieldType(0);
        java.lang.Object obj4 = null;
        org.joda.time.PeriodType periodType5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(obj4, periodType5, chronology6);
        org.joda.time.Period period9 = period7.withDays(0);
        org.joda.time.Period period11 = period7.withHours(10);
        org.joda.time.Period period12 = period7.toPeriod();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType14 = periodType13.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.secondOfDay();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology16.monthOfYear();
        org.joda.time.DurationField durationField20 = iSOChronology16.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology16, (org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.Chronology chronology28 = zonedChronology26.withZone(dateTimeZone27);
        org.joda.time.Period period29 = new org.joda.time.Period((java.lang.Object) period12, periodType13, (org.joda.time.Chronology) zonedChronology26);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology33);
        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology33.minuteOfHour();
        try {
            org.joda.time.Period period37 = new org.joda.time.Period((java.lang.Object) 0, periodType13, (org.joda.time.Chronology) iSOChronology33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(durationFieldType3);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Object obj13 = null;
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(obj13, periodType14, chronology15);
        org.joda.time.Period period18 = period16.withDays(0);
        org.joda.time.Period period20 = period16.withHours(10);
        org.joda.time.Period period21 = period16.toPeriod();
        boolean boolean22 = fixedDateTimeZone4.equals((java.lang.Object) period21);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-115200001L), "GregorianChronology[hi!]");
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone5.getShortName(0L, locale7);
        long long11 = fixedDateTimeZone5.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant12 = null;
        int int13 = fixedDateTimeZone5.getOffset(readableInstant12);
        int int15 = fixedDateTimeZone5.getOffset((long) (short) -1);
        long long19 = fixedDateTimeZone5.convertLocalToUTC((long) (byte) 100, false, (long) ' ');
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) 100);
        java.util.Locale locale24 = null;
        int int25 = offsetDateTimeField23.getMaximumShortTextLength(locale24);
        long long27 = offsetDateTimeField23.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology32);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 100);
        long long39 = offsetDateTimeField36.getDifferenceAsLong(0L, 0L);
        long long41 = offsetDateTimeField36.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial42 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone46);
        org.joda.time.Period period48 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology47);
        org.joda.time.Chronology chronology49 = iSOChronology47.withUTC();
        java.lang.Object obj50 = null;
        org.joda.time.PeriodType periodType51 = null;
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period(obj50, periodType51, chronology52);
        org.joda.time.Period period55 = period53.withDays(0);
        int int56 = period55.getHours();
        int int57 = period55.size();
        int[] intArray59 = iSOChronology47.get((org.joda.time.ReadablePeriod) period55, (long) (-10));
        int[] intArray61 = offsetDateTimeField36.add(readablePartial42, 4, intArray59, 0);
        int int62 = offsetDateTimeField23.getMaximumValue(readablePartial28, intArray61);
        try {
            iSOChronology1.validate(readablePartial17, intArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 86400000L + "'", long41 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 123 + "'", int62 == 123);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        long long44 = remainderDateTimeField27.set((long) 10, 107);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 100);
        org.joda.time.DateTimeField dateTimeField53 = offsetDateTimeField52.getWrappedField();
        org.joda.time.DurationField durationField54 = offsetDateTimeField52.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField52.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField56 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType55);
        try {
            long long59 = dividedDateTimeField56.addWrapField((long) 3, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 259200010L + "'", long44 == 259200010L);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray18 = null;
        int int19 = offsetDateTimeField7.getMinimumValue(readablePartial17, intArray18);
        long long21 = offsetDateTimeField7.roundHalfEven((long) (short) 1);
        int int23 = offsetDateTimeField7.get(1L);
        long long25 = offsetDateTimeField7.roundCeiling((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType26, 350);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 104 + "'", int23 == 104);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86400000L + "'", long25 == 86400000L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        int int45 = dividedDateTimeField41.getDifference((long) 35, (long) 243);
        long long48 = dividedDateTimeField41.getDifferenceAsLong((long) 1, 100L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumShortTextLength(locale6);
        long long9 = offsetDateTimeField5.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 100);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(0L, 0L);
        long long23 = offsetDateTimeField18.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology29);
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        java.lang.Object obj32 = null;
        org.joda.time.PeriodType periodType33 = null;
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(obj32, periodType33, chronology34);
        org.joda.time.Period period37 = period35.withDays(0);
        int int38 = period37.getHours();
        int int39 = period37.size();
        int[] intArray41 = iSOChronology29.get((org.joda.time.ReadablePeriod) period37, (long) (-10));
        int[] intArray43 = offsetDateTimeField18.add(readablePartial24, 4, intArray41, 0);
        int int44 = offsetDateTimeField5.getMaximumValue(readablePartial10, intArray43);
        long long47 = offsetDateTimeField5.add((long) (-10), 10);
        boolean boolean49 = offsetDateTimeField5.isLeap((long) (short) -1);
        org.joda.time.ReadablePartial readablePartial50 = null;
        int[] intArray54 = new int[] { 242, 350 };
        java.util.Locale locale56 = null;
        try {
            int[] intArray57 = offsetDateTimeField5.set(readablePartial50, 1, intArray54, "", locale56);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86400000L + "'", long23 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 123 + "'", int44 == 123);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 35999990L + "'", long47 == 35999990L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str12 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", (java.lang.Number) 9244800052L, (java.lang.Number) 106L, (java.lang.Number) 10.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, 107, 242, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 107 for hourOfDay must be in the range [242,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withSecondsRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType1.isSupported(durationFieldType4);
        org.joda.time.PeriodType periodType6 = periodType1.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8L) + "'", long2 == (-8L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        java.lang.Throwable[] throwableArray2 = illegalInstantException1.getSuppressed();
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException1);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 100);
        long long11 = offsetDateTimeField8.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField8.getMaximumShortTextLength(locale12);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField21.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType22, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType22, 243);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology32);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField36.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType37, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField28, dateTimeFieldType37);
        long long45 = remainderDateTimeField28.set((long) 10, 107);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.Period period50 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology49);
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 100);
        org.joda.time.DateTimeField dateTimeField54 = offsetDateTimeField53.getWrappedField();
        org.joda.time.DurationField durationField55 = offsetDateTimeField53.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField53.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField28, dateTimeFieldType56);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField58 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 259200010L + "'", long45 == 259200010L);
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology1.year();
        org.joda.time.DurationField durationField19 = iSOChronology1.years();
        org.joda.time.ReadablePartial readablePartial20 = null;
        try {
            long long22 = iSOChronology1.set(readablePartial20, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.monthOfYear();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) readableInterval2, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray14 = iSOChronology5.get(readablePeriod11, 0L, (long) 104);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone22.getShortName(0L, locale24);
        long long28 = fixedDateTimeZone22.convertLocalToUTC((long) '#', true);
        org.joda.time.Chronology chronology29 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        int int32 = fixedDateTimeZone22.getOffsetFromLocal(35999990L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.monthOfYear();
        org.joda.time.DurationField durationField17 = iSOChronology13.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
        long long25 = fixedDateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone22, (long) (short) 0);
        java.util.TimeZone timeZone26 = fixedDateTimeZone22.toTimeZone();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-10));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (long) 242);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "-1", "GregorianChronology[hi!]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        java.lang.Class<?> wildcardClass5 = period3.getClass();
        org.joda.time.Period period6 = period3.negated();
        java.lang.Object obj7 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(obj7, periodType8, chronology9);
        int int11 = period10.getMinutes();
        java.lang.Class<?> wildcardClass12 = period10.getClass();
        org.joda.time.Duration duration13 = period10.toStandardDuration();
        boolean boolean15 = period10.equals((java.lang.Object) '4');
        org.joda.time.Period period16 = period3.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period17 = period10.normalizedStandard();
        org.joda.time.Period period19 = period10.minusDays((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str4 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[hi!]" + "'", str4.equals("GregorianChronology[hi!]"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0" + "'", str5.equals("1.0"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) 'a', ' ', 104, (int) (byte) 10, (-1), false, 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder11.addRecurringSavings("119", 242, (int) (byte) 0, (int) (short) 0, '#', (int) (short) 0, 104, 101, false, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusYears((int) (byte) 0);
        org.joda.time.Hours hours6 = period3.toStandardHours();
        org.joda.time.Period period8 = period3.withHours((int) 'a');
        int int9 = period8.size();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(hours6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.Object obj1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(obj1, periodType2, chronology3);
        org.joda.time.Period period6 = period4.withDays(0);
        org.joda.time.Period period8 = period4.withHours(10);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period10 = period4.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period4.withYears((-10));
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) period12);
        java.lang.String str14 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[hi!]" + "'", str14.equals("GregorianChronology[hi!]"));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("ISOChronology[hi!]");
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) ' ');
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        long long14 = durationField11.subtract(0L, (long) '#');
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2764800000L + "'", long10 == 2764800000L);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-3024000000L) + "'", long14 == (-3024000000L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(242L, "");
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.centuryOfEra();
        org.joda.time.Period period5 = new org.joda.time.Period(106L, (org.joda.time.Chronology) iSOChronology2);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.monthOfYear();
        org.joda.time.DurationField durationField17 = iSOChronology13.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
        long long25 = fixedDateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone22, (long) (short) 0);
        int int27 = fixedDateTimeZone10.getOffset(35L);
        long long29 = fixedDateTimeZone10.nextTransition((long) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period8 = period3.toPeriod();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType10 = periodType9.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.monthOfYear();
        org.joda.time.DurationField durationField16 = iSOChronology12.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = zonedChronology22.withZone(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period8, periodType9, (org.joda.time.Chronology) zonedChronology22);
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology22.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology22.hourOfHalfday();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 100);
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField16.getMaximumShortTextLength(locale17);
        long long20 = offsetDateTimeField16.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 100);
        long long32 = offsetDateTimeField29.getDifferenceAsLong(0L, 0L);
        long long34 = offsetDateTimeField29.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.Period period41 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology40);
        org.joda.time.Chronology chronology42 = iSOChronology40.withUTC();
        java.lang.Object obj43 = null;
        org.joda.time.PeriodType periodType44 = null;
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.Period period46 = new org.joda.time.Period(obj43, periodType44, chronology45);
        org.joda.time.Period period48 = period46.withDays(0);
        int int49 = period48.getHours();
        int int50 = period48.size();
        int[] intArray52 = iSOChronology40.get((org.joda.time.ReadablePeriod) period48, (long) (-10));
        int[] intArray54 = offsetDateTimeField29.add(readablePartial35, 4, intArray52, 0);
        int int55 = offsetDateTimeField16.getMaximumValue(readablePartial21, intArray54);
        try {
            int[] intArray57 = offsetDateTimeField7.add(readablePartial9, 100, intArray54, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 86400000L + "'", long34 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 8 + "'", int50 == 8);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 123 + "'", int55 == 123);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        org.joda.time.DurationField durationField42 = dividedDateTimeField41.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.Period period47 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology46);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 100);
        long long53 = offsetDateTimeField50.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale54 = null;
        int int55 = offsetDateTimeField50.getMaximumShortTextLength(locale54);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField63.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType64, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType64, 243);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField41, dateTimeFieldType64, 107);
        long long75 = dividedDateTimeField41.add((long) '4', 0);
        try {
            long long77 = dividedDateTimeField41.roundHalfCeiling((long) 242);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 52L + "'", long75 == 52L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumShortTextLength(locale6);
        long long9 = offsetDateTimeField5.roundFloor((long) 0);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 100);
        long long21 = offsetDateTimeField18.getDifferenceAsLong(0L, 0L);
        long long23 = offsetDateTimeField18.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone28);
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology29);
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        java.lang.Object obj32 = null;
        org.joda.time.PeriodType periodType33 = null;
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(obj32, periodType33, chronology34);
        org.joda.time.Period period37 = period35.withDays(0);
        int int38 = period37.getHours();
        int int39 = period37.size();
        int[] intArray41 = iSOChronology29.get((org.joda.time.ReadablePeriod) period37, (long) (-10));
        int[] intArray43 = offsetDateTimeField18.add(readablePartial24, 4, intArray41, 0);
        int int44 = offsetDateTimeField5.getMaximumValue(readablePartial10, intArray43);
        long long47 = offsetDateTimeField5.add((long) (-10), 10);
        boolean boolean49 = offsetDateTimeField5.isLeap((long) (short) -1);
        int int51 = offsetDateTimeField5.getLeapAmount((-61833283199757L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 86400000L + "'", long23 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 123 + "'", int44 == 123);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 35999990L + "'", long47 == 35999990L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.monthOfYear();
        org.joda.time.DurationField durationField17 = iSOChronology13.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
        long long25 = fixedDateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone22, (long) (short) 0);
        int int27 = fixedDateTimeZone22.getOffset((long) 107);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfWeek();
        org.joda.time.Period period7 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) ' ');
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        long long23 = offsetDateTimeField20.getDifferenceAsLong(0L, 0L);
        long long25 = offsetDateTimeField20.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial26 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.Chronology chronology33 = iSOChronology31.withUTC();
        java.lang.Object obj34 = null;
        org.joda.time.PeriodType periodType35 = null;
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period(obj34, periodType35, chronology36);
        org.joda.time.Period period39 = period37.withDays(0);
        int int40 = period39.getHours();
        int int41 = period39.size();
        int[] intArray43 = iSOChronology31.get((org.joda.time.ReadablePeriod) period39, (long) (-10));
        int[] intArray45 = offsetDateTimeField20.add(readablePartial26, 4, intArray43, 0);
        int int46 = offsetDateTimeField7.getMinimumValue(readablePartial12, intArray43);
        long long48 = offsetDateTimeField7.remainder(99L);
        try {
            long long51 = offsetDateTimeField7.set(3675L, 123);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 123 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2764800000L + "'", long10 == 2764800000L);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86400000L + "'", long25 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 8 + "'", int41 == 8);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 101 + "'", int46 == 101);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 99L + "'", long48 == 99L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        java.lang.Class<?> wildcardClass5 = period3.getClass();
        org.joda.time.Period period6 = period3.negated();
        org.joda.time.Period period8 = period6.plusHours((int) (byte) 1);
        org.joda.time.Period period10 = period6.withDays(3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) (short) 10, "");
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isLenient();
        long long18 = offsetDateTimeField7.roundHalfEven((-210858033600000L));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-210858076800000L) + "'", long18 == (-210858076800000L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        java.lang.Class<?> wildcardClass5 = period3.getClass();
        org.joda.time.Period period6 = period3.negated();
        org.joda.time.Period period7 = period6.normalizedStandard();
        org.joda.time.Period period9 = period7.plusMonths(3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period8 = period3.toPeriod();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType10 = periodType9.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.monthOfYear();
        org.joda.time.DurationField durationField16 = iSOChronology12.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = zonedChronology22.withZone(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period8, periodType9, (org.joda.time.Chronology) zonedChronology22);
        org.joda.time.DateTimeField dateTimeField26 = zonedChronology22.weekyearOfCentury();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField26, (int) (short) -1, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekyearOfCentury must be in the range [52,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) '#');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period8 = period3.toPeriod();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType10 = periodType9.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.monthOfYear();
        org.joda.time.DurationField durationField16 = iSOChronology12.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = zonedChronology22.withZone(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period8, periodType9, (org.joda.time.Chronology) zonedChronology22);
        org.joda.time.Period period26 = period25.negated();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField7.getWrappedField();
        int int10 = offsetDateTimeField7.getLeapAmount(1L);
        int int12 = offsetDateTimeField7.getLeapAmount(35L);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period15 = new org.joda.time.Period(1L, periodType14);
        java.lang.String str16 = periodType14.toString();
        try {
            org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) 35L, periodType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str16.equals("PeriodType[YearMonthDayTime]"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Seconds seconds6 = period5.toStandardSeconds();
        java.lang.Object obj7 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(obj7, periodType8, chronology9);
        org.joda.time.Period period12 = period10.withDays(0);
        org.joda.time.Period period14 = period10.withHours(10);
        org.joda.time.Period period16 = period10.minusMonths((int) (byte) 10);
        org.joda.time.Period period18 = period16.withMinutes(107);
        org.joda.time.Period period19 = period5.plus((org.joda.time.ReadablePeriod) period18);
        int int21 = period18.getValue(0);
        int int22 = period18.getMinutes();
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(seconds6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 107 + "'", int22 == 107);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField8.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType9, 8, 3, (int) ' ');
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType9, (-1), 4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology45);
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology45.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, 100);
        long long52 = offsetDateTimeField49.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale53 = null;
        int int54 = offsetDateTimeField49.getMaximumShortTextLength(locale53);
        org.joda.time.DurationField durationField55 = offsetDateTimeField49.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.Period period68 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology67);
        org.joda.time.DateTimeField dateTimeField69 = iSOChronology67.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField69, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = offsetDateTimeField71.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, dateTimeFieldType72, 104, (int) ' ', (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField49, dateTimeFieldType72, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField79 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField41, dateTimeFieldType72);
        long long81 = remainderDateTimeField79.roundHalfFloor(2764800000L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 3 + "'", int54 == 3);
        org.junit.Assert.assertNull(durationField55);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 2764800000L + "'", long81 == 2764800000L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        java.lang.Object obj7 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(obj7, periodType8, chronology9);
        org.joda.time.Period period12 = period10.withDays(0);
        org.joda.time.Seconds seconds13 = period12.toStandardSeconds();
        java.lang.Object obj14 = null;
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(obj14, periodType15, chronology16);
        org.joda.time.Period period19 = period17.withDays(0);
        org.joda.time.Period period21 = period17.withHours(10);
        org.joda.time.Period period23 = period17.minusMonths((int) (byte) 10);
        org.joda.time.Period period25 = period23.withMinutes(107);
        org.joda.time.Period period26 = period12.plus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.Period period27 = period3.withFields((org.joda.time.ReadablePeriod) period25);
        org.joda.time.Period period29 = period27.minusDays(35);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray18 = null;
        int int19 = offsetDateTimeField7.getMinimumValue(readablePartial17, intArray18);
        long long21 = offsetDateTimeField7.roundHalfEven((long) (short) 1);
        int int23 = offsetDateTimeField7.get(1L);
        long long25 = offsetDateTimeField7.roundCeiling((long) 10);
        int int27 = offsetDateTimeField7.getLeapAmount(259200010L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 104 + "'", int23 == 104);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86400000L + "'", long25 == 86400000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        long long44 = remainderDateTimeField27.set((long) 10, 107);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 100);
        long long55 = offsetDateTimeField52.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale56 = null;
        int int57 = offsetDateTimeField52.getMaximumShortTextLength(locale56);
        long long60 = offsetDateTimeField52.add((long) 3, 0);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone63);
        org.joda.time.Period period65 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology64);
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology64.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, 100);
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.chrono.ISOChronology iSOChronology72 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
        org.joda.time.Period period73 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology72);
        org.joda.time.DateTimeField dateTimeField74 = iSOChronology72.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField74, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = offsetDateTimeField76.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField81 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, dateTimeFieldType77, 104, (int) ' ', (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField83 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField52, dateTimeFieldType77, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField84 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType77);
        long long86 = remainderDateTimeField27.remainder((long) ' ');
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 259200010L + "'", long44 == 259200010L);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 3 + "'", int57 == 3);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 3L + "'", long60 == 3L);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(iSOChronology72);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 32L + "'", long86 == 32L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) '4');
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("1.0", false);
        java.lang.String str8 = dateTimeZone6.getShortName((-1L));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.052" + "'", str8.equals("+00:00:00.052"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException4.getDurationFieldType();
        illegalFieldValueException4.prependMessage("LenientChronology[ISOChronology[hi!]]");
        java.lang.String str12 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("+00:00");
        java.lang.Throwable[] throwableArray2 = illegalInstantException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology1.hourOfDay();
        long long17 = iSOChronology1.getDateTimeMillis((int) (short) 1, 1, (int) (short) 1, 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62135596800000L) + "'", long17 == (-62135596800000L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = fixedDateTimeZone4.getOffset(readableInstant11);
        int int14 = fixedDateTimeZone4.getOffset((long) (short) -1);
        java.lang.String str15 = fixedDateTimeZone4.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        long long44 = dividedDateTimeField41.add(3675L, 0L);
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.Period period51 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology50);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology50.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 100);
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField54.getWrappedField();
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.lang.Object obj57 = null;
        org.joda.time.PeriodType periodType58 = null;
        org.joda.time.Chronology chronology59 = null;
        org.joda.time.Period period60 = new org.joda.time.Period(obj57, periodType58, chronology59);
        org.joda.time.Period period62 = period60.minusMillis((int) (byte) 1);
        org.joda.time.Period period63 = period60.negated();
        org.joda.time.Period period65 = period60.minusMonths((int) (short) 100);
        int[] intArray66 = period60.getValues();
        int int67 = offsetDateTimeField54.getMinimumValue(readablePartial56, intArray66);
        try {
            int[] intArray69 = dividedDateTimeField41.addWrapPartial(readablePartial45, 105, intArray66, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 105");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 3675L + "'", long44 == 3675L);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(period65);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 101 + "'", int67 == 101);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        int int28 = remainderDateTimeField27.getDivisor();
        long long30 = remainderDateTimeField27.roundFloor((long) '#');
        try {
            long long33 = remainderDateTimeField27.addWrapField(1560627574045L, (-105));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 243 + "'", int28 == 243);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField5.getMaximumShortTextLength(locale6);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.hourOfDay();
        org.joda.time.DurationField durationField5 = iSOChronology2.weeks();
        java.lang.Object obj6 = null;
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(obj6, periodType7, chronology8);
        int int10 = period9.getMinutes();
        org.joda.time.Period period12 = period9.plusHours((int) (short) -1);
        org.joda.time.Period period14 = period9.plusMonths((int) '4');
        org.joda.time.Period period16 = period9.plusDays(100);
        boolean boolean17 = iSOChronology2.equals((java.lang.Object) period16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.year();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 35, (java.lang.Object) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology2.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        java.lang.Object obj12 = null;
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(obj12, periodType13, chronology14);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.dayOfWeek();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) 1, 0L, periodType18, (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.Period period26 = period15.normalizedStandard(periodType18);
        try {
            org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) timeZone11, periodType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.util.SimpleTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(period26);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField7.getAsShortText(0L, locale12);
        int int14 = offsetDateTimeField7.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "104" + "'", str13.equals("104"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        long long13 = fixedDateTimeZone10.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale20 = null;
        java.lang.String str21 = fixedDateTimeZone18.getShortName(0L, locale20);
        boolean boolean23 = fixedDateTimeZone18.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = fixedDateTimeZone18.isLocalDateTimeGap(localDateTime24);
        long long27 = fixedDateTimeZone18.convertUTCToLocal((long) 350);
        long long29 = fixedDateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone18, (long) 104);
        java.util.Locale locale31 = null;
        java.lang.String str32 = fixedDateTimeZone10.getName((long) (-10), locale31);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00" + "'", str21.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 350L + "'", long27 == 350L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 114L + "'", long29 == 114L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+00:00:00.010" + "'", str32.equals("+00:00:00.010"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[hi!]" + "'", str1.equals("GregorianChronology[hi!]"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) -1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        long long44 = remainderDateTimeField27.set((long) 10, 107);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 100);
        org.joda.time.DateTimeField dateTimeField53 = offsetDateTimeField52.getWrappedField();
        org.joda.time.DurationField durationField54 = offsetDateTimeField52.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField52.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField56 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType55);
        long long58 = remainderDateTimeField27.roundFloor((long) (-105));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 259200010L + "'", long44 == 259200010L);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-86400000L) + "'", long58 == (-86400000L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("119");
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        org.joda.time.Period period8 = period3.plusMonths((int) '4');
        org.joda.time.Period period10 = period3.plusDays(100);
        org.joda.time.Hours hours11 = period10.toStandardHours();
        java.lang.Object obj12 = null;
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(obj12, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withDays(0);
        int int18 = period17.getHours();
        int int19 = period17.size();
        org.joda.time.Period period20 = period10.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period22 = period20.withMinutes(350);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(hours11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone16.getShortName(0L, locale18);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        long long23 = fixedDateTimeZone16.convertLocalToUTC((long) 10, false);
        long long25 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone16, (long) 100);
        java.util.TimeZone timeZone26 = fixedDateTimeZone16.toTimeZone();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        java.lang.Class<?> wildcardClass5 = period3.getClass();
        org.joda.time.Period period6 = period3.negated();
        java.lang.Object obj7 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(obj7, periodType8, chronology9);
        int int11 = period10.getMinutes();
        java.lang.Class<?> wildcardClass12 = period10.getClass();
        org.joda.time.Duration duration13 = period10.toStandardDuration();
        boolean boolean15 = period10.equals((java.lang.Object) '4');
        org.joda.time.Period period16 = period3.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period17 = period10.normalizedStandard();
        org.joda.time.Period period19 = period10.withMillis(100);
        org.joda.time.Seconds seconds20 = period19.toStandardSeconds();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(seconds20);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add(10L, (-32));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2764799990L) + "'", long15 == (-2764799990L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(114L, 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11400L + "'", long2 == 11400L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.dayOfWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, 0L, periodType2, (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str10 = period9.toString();
        try {
            int int12 = period9.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.001S" + "'", str10.equals("PT-0.001S"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.add(52L, 107);
        int int12 = offsetDateTimeField7.getLeapAmount((long) '4');
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
        long long16 = offsetDateTimeField7.add(35L, (int) (short) -1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9244800052L + "'", long10 == 9244800052L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-86399965L) + "'", long16 == (-86399965L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        long long29 = remainderDateTimeField27.roundHalfFloor(100L);
        org.joda.time.DurationField durationField30 = remainderDateTimeField27.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(obj3, periodType4, chronology5);
        org.joda.time.Period period8 = period6.withDays(0);
        org.joda.time.Period period10 = period6.withHours(10);
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) period10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone16.getShortName(0L, locale18);
        long long22 = fixedDateTimeZone16.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone23 = fixedDateTimeZone16.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone28.getShortName(0L, locale30);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        long long35 = fixedDateTimeZone28.convertLocalToUTC((long) 10, false);
        long long37 = fixedDateTimeZone16.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone28, (long) 100);
        org.joda.time.ReadableInstant readableInstant38 = null;
        int int39 = fixedDateTimeZone16.getOffset(readableInstant38);
        org.joda.time.Chronology chronology40 = lenientChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        java.lang.String str41 = fixedDateTimeZone16.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology38.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology38.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray48 = new int[] { (short) 1, (byte) 0, (-10), (-10) };
        int int49 = offsetDateTimeField42.getMaximumValue(readablePartial43, intArray48);
        org.joda.time.ReadablePartial readablePartial50 = null;
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.Period period55 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology54);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology54.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, 100);
        long long61 = offsetDateTimeField58.getDifferenceAsLong(0L, 0L);
        long long63 = offsetDateTimeField58.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial64 = null;
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.ISOChronology iSOChronology69 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone68);
        org.joda.time.Period period70 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology69);
        org.joda.time.Chronology chronology71 = iSOChronology69.withUTC();
        java.lang.Object obj72 = null;
        org.joda.time.PeriodType periodType73 = null;
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.Period period75 = new org.joda.time.Period(obj72, periodType73, chronology74);
        org.joda.time.Period period77 = period75.withDays(0);
        int int78 = period77.getHours();
        int int79 = period77.size();
        int[] intArray81 = iSOChronology69.get((org.joda.time.ReadablePeriod) period77, (long) (-10));
        int[] intArray83 = offsetDateTimeField58.add(readablePartial64, 4, intArray81, 0);
        int int84 = offsetDateTimeField42.getMaximumValue(readablePartial50, intArray81);
        try {
            int int85 = unsupportedDateTimeField35.getMaximumValue(readablePartial36, intArray81);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 123 + "'", int49 == 123);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 86400000L + "'", long63 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology69);
        org.junit.Assert.assertNotNull(chronology71);
        org.junit.Assert.assertNotNull(period77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 8 + "'", int79 == 8);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 123 + "'", int84 == 123);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        try {
            long long38 = unsupportedDateTimeField35.set((-32L), "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (PeriodType[YearMonthDayTime])");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = zonedChronology11.weeks();
        org.joda.time.Period period15 = org.joda.time.Period.ZERO;
        long long18 = zonedChronology11.add((org.joda.time.ReadablePeriod) period15, (long) (-105), (int) ' ');
        org.joda.time.Period period20 = period15.withYears((int) '4');
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-105L) + "'", long18 == (-105L));
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, (int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Period period1 = org.joda.time.Period.parse("PT0S");
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField7.getWrappedField();
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.lang.Object obj10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(obj10, periodType11, chronology12);
        org.joda.time.Period period15 = period13.minusMillis((int) (byte) 1);
        org.joda.time.Period period16 = period13.negated();
        org.joda.time.Period period18 = period13.minusMonths((int) (short) 100);
        int[] intArray19 = period13.getValues();
        int int20 = offsetDateTimeField7.getMinimumValue(readablePartial9, intArray19);
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = offsetDateTimeField7.getAsText(readablePartial21, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 101 + "'", int20 == 101);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.secondOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology13.monthOfYear();
        org.joda.time.DurationField durationField17 = iSOChronology13.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
        long long25 = fixedDateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone22, (long) (short) 0);
        java.util.TimeZone timeZone26 = fixedDateTimeZone10.toTimeZone();
        java.lang.String str28 = fixedDateTimeZone10.getNameKey((-86399965L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00" + "'", str28.equals("+00:00"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        org.joda.time.ReadablePartial readablePartial37 = null;
        try {
            int int38 = unsupportedDateTimeField35.getMaximumValue(readablePartial37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        int int45 = dividedDateTimeField41.getDifference((long) 35, (long) 243);
        long long47 = dividedDateTimeField41.remainder((long) 242);
        long long50 = dividedDateTimeField41.add(0L, 99L);
        try {
            long long52 = dividedDateTimeField41.roundFloor((-32L));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 242L + "'", long47 == 242L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2078524800000L + "'", long50 == 2078524800000L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("119", (java.lang.Number) (-210858033600000L), (java.lang.Number) 35999990L, (java.lang.Number) 1.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.Period period5 = period1.withFieldAdded(durationFieldType3, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(minutes2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType16, 104, (int) ' ', (int) '4');
        boolean boolean21 = offsetDateTimeField20.isSupported();
        long long23 = offsetDateTimeField20.roundFloor(10L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField7.getWrappedField();
        int int10 = offsetDateTimeField7.getLeapAmount(1L);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 100);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField18.getWrappedField();
        org.joda.time.DurationField durationField20 = offsetDateTimeField18.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField18.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField22 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        boolean boolean37 = unsupportedDateTimeField35.isSupported();
        try {
            long long40 = unsupportedDateTimeField35.set(114L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isLenient();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField7.getMaximumTextLength(locale17);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.util.Locale locale37 = null;
        try {
            java.lang.String str38 = unsupportedDateTimeField35.getAsShortText((-2764799990L), locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.Period period20 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, 100);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone26);
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology27);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField31.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType32, 104, (int) ' ', (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType32, (int) ' ');
        org.joda.time.DurationField durationField39 = remainderDateTimeField38.getRangeDurationField();
        long long41 = remainderDateTimeField38.roundCeiling(243L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 86400000L + "'", long41 == 86400000L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.monthOfYear();
        org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) readableInterval2, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.hourOfHalfday();
        org.joda.time.ReadablePartial readablePartial11 = null;
        try {
            int[] intArray13 = iSOChronology5.get(readablePartial11, 259200010L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology1.year();
        org.joda.time.DurationField durationField19 = iSOChronology1.years();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) '4');
        java.lang.String str8 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.convertUTCToLocal((-86399965L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-86399965L) + "'", long10 == (-86399965L));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(obj3, periodType4, chronology5);
        org.joda.time.Period period8 = period6.withDays(0);
        int int9 = period8.getYears();
        org.joda.time.Days days10 = period8.toStandardDays();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period12 = period8.normalizedStandard(periodType11);
        java.lang.Object obj13 = null;
        org.joda.time.PeriodType periodType14 = null;
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(obj13, periodType14, chronology15);
        int int17 = period16.getMinutes();
        org.joda.time.Period period19 = period16.plusHours((int) (short) -1);
        org.joda.time.Period period21 = period16.plusMonths((int) '4');
        org.joda.time.Period period22 = period8.minus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period24 = period8.plusDays((int) 'a');
        long long27 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (short) 10, (int) (short) 0);
        org.joda.time.Period period29 = period8.plusMonths(104);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(days10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(period29);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        try {
            java.lang.String str37 = unsupportedDateTimeField35.getAsText(100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 100, periodType1);
        org.joda.time.PeriodType periodType4 = periodType1.withMinutesRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType6 = periodType1.getFieldType((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField6 = iSOChronology1.centuries();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        boolean boolean37 = unsupportedDateTimeField35.isSupported();
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = unsupportedDateTimeField35.getAsShortText(readablePartial38, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str19 = illegalFieldValueException18.getIllegalStringValue();
        java.lang.Number number20 = illegalFieldValueException18.getLowerBound();
        boolean boolean21 = zonedChronology11.equals((java.lang.Object) illegalFieldValueException18);
        boolean boolean22 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException18);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusMillis((int) (byte) 1);
        org.joda.time.Period period6 = period3.negated();
        org.joda.time.Period period8 = period3.minusMonths((int) (short) 100);
        int[] intArray9 = period3.getValues();
        org.joda.time.Period period11 = period3.plusMonths(243);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        java.lang.Class<?> wildcardClass5 = period3.getClass();
        org.joda.time.Duration duration6 = period3.toStandardDuration();
        java.lang.Object obj7 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(obj7, periodType8, chronology9);
        org.joda.time.Period period12 = period10.minusYears((int) (byte) 0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.secondOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology15.monthOfYear();
        org.joda.time.DurationField durationField19 = iSOChronology15.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, (org.joda.time.DateTimeZone) fixedDateTimeZone24);
        long long27 = fixedDateTimeZone24.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale34 = null;
        java.lang.String str35 = fixedDateTimeZone32.getShortName(0L, locale34);
        boolean boolean37 = fixedDateTimeZone32.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime38 = null;
        boolean boolean39 = fixedDateTimeZone32.isLocalDateTimeGap(localDateTime38);
        long long41 = fixedDateTimeZone32.convertUTCToLocal((long) 350);
        long long43 = fixedDateTimeZone24.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone32, (long) 104);
        boolean boolean44 = periodType13.equals((java.lang.Object) long43);
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType46 = periodType45.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType48 = periodType45.getFieldType(0);
        int int49 = periodType13.indexOf(durationFieldType48);
        org.joda.time.Period period51 = period10.withFieldAdded(durationFieldType48, (-32));
        int int52 = period3.indexOf(durationFieldType48);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00" + "'", str35.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 350L + "'", long41 == 350L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 114L + "'", long43 == 114L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(durationFieldType48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(0L, locale11);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology14 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str16 = fixedDateTimeZone9.getShortName(3L);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DurationField durationField18 = iSOChronology17.years();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        long long18 = offsetDateTimeField7.roundHalfEven(0L);
        long long20 = offsetDateTimeField7.roundCeiling((-210858076800000L));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210858076800000L) + "'", long20 == (-210858076800000L));
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        java.lang.String str3 = dateTimeZone1.getName(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        long long44 = dividedDateTimeField41.remainder((long) 0);
        try {
            long long46 = dividedDateTimeField41.roundCeiling(350L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [101,107]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        try {
            java.lang.String str37 = unsupportedDateTimeField35.getAsText((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray18 = null;
        int int19 = offsetDateTimeField7.getMinimumValue(readablePartial17, intArray18);
        long long21 = offsetDateTimeField7.roundHalfEven((long) (short) 1);
        int int23 = offsetDateTimeField7.get(1L);
        long long25 = offsetDateTimeField7.roundCeiling((long) (short) 10);
        boolean boolean27 = offsetDateTimeField7.isLeap((long) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 104 + "'", int23 == 104);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86400000L + "'", long25 == 86400000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        long long18 = offsetDateTimeField7.roundHalfCeiling((long) 100);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField7.getAsShortText(35999990L, locale20);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "104" + "'", str21.equals("104"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, (int) (short) 100, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        long long14 = fixedDateTimeZone4.convertLocalToUTC(32L, true, 2764800000L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        long long29 = remainderDateTimeField27.roundHalfFloor(100L);
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone34);
        org.joda.time.Period period36 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology35);
        org.joda.time.Chronology chronology37 = iSOChronology35.withUTC();
        java.lang.Object obj38 = null;
        org.joda.time.PeriodType periodType39 = null;
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.Period period41 = new org.joda.time.Period(obj38, periodType39, chronology40);
        org.joda.time.Period period43 = period41.withDays(0);
        int int44 = period43.getHours();
        int int45 = period43.size();
        int[] intArray47 = iSOChronology35.get((org.joda.time.ReadablePeriod) period43, (long) (-10));
        java.util.Locale locale49 = null;
        try {
            int[] intArray50 = remainderDateTimeField27.set(readablePartial30, 101, intArray47, "", locale49);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 8 + "'", int45 == 8);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Period period1 = new org.joda.time.Period(2764800000L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone22.getShortName(0L, locale24);
        long long28 = fixedDateTimeZone22.convertLocalToUTC((long) '#', true);
        org.joda.time.Chronology chronology29 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        java.lang.String str31 = fixedDateTimeZone22.getID();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        boolean boolean7 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DurationField durationField5 = iSOChronology3.eras();
        try {
            long long8 = durationField5.subtract(35L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        long long44 = dividedDateTimeField41.remainder((long) 0);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 100);
        long long55 = offsetDateTimeField52.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale56 = null;
        int int57 = offsetDateTimeField52.getMaximumShortTextLength(locale56);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone60);
        org.joda.time.Period period62 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology61);
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology61.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = offsetDateTimeField65.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType66, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField52, dateTimeFieldType66, 243);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField41, dateTimeFieldType66);
        try {
            long long76 = dividedDateTimeField41.set((-32L), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfWeek must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 3 + "'", int57 == 3);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 32, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 132L + "'", long2 == 132L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology1.yearOfCentury();
        org.joda.time.DurationField durationField20 = iSOChronology1.months();
        org.joda.time.DurationField durationField21 = iSOChronology1.hours();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210863736000000L) + "'", long1 == (-210863736000000L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) 'a', ' ', 104, (int) (byte) 10, (-1), false, 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder0.writeTo("LenientChronology[ISOChronology[hi!]]", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.add(52L, 107);
        int int12 = offsetDateTimeField7.getLeapAmount((long) '4');
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField7, 105, 104, 243);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9244800052L + "'", long10 == 9244800052L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-32L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        try {
            java.lang.String str37 = unsupportedDateTimeField35.getAsShortText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        org.joda.time.DurationField durationField42 = dividedDateTimeField41.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.Period period47 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology46);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 100);
        long long53 = offsetDateTimeField50.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale54 = null;
        int int55 = offsetDateTimeField50.getMaximumShortTextLength(locale54);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField63.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType64, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType64, 243);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField41, dateTimeFieldType64, 107);
        long long74 = remainderDateTimeField72.remainder(106L);
        org.joda.time.ReadablePartial readablePartial75 = null;
        java.util.Locale locale77 = null;
        java.lang.String str78 = remainderDateTimeField72.getAsShortText(readablePartial75, (int) (byte) -1, locale77);
        int int79 = remainderDateTimeField72.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 106L + "'", long74 == 106L);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "-1" + "'", str78.equals("-1"));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        try {
            java.lang.String str37 = unsupportedDateTimeField35.getAsText((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField35.getType();
        try {
            long long40 = unsupportedDateTimeField35.roundHalfFloor((long) 107);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType30, 104, (int) ' ', (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType30, (int) '#');
        long long38 = offsetDateTimeField7.roundHalfEven(0L);
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.lang.Object obj41 = null;
        org.joda.time.PeriodType periodType42 = null;
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.Period period44 = new org.joda.time.Period(obj41, periodType42, chronology43);
        org.joda.time.Period period46 = period44.withDays(0);
        org.joda.time.Seconds seconds47 = period46.toStandardSeconds();
        java.lang.String str48 = period46.toString();
        int[] intArray49 = period46.getValues();
        try {
            int[] intArray51 = offsetDateTimeField7.add(readablePartial39, 4, intArray49, (-105));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(seconds47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "PT0S" + "'", str48.equals("PT0S"));
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.Object obj1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(obj1, periodType2, chronology3);
        org.joda.time.Period period6 = period4.withDays(0);
        org.joda.time.Period period8 = period4.withHours(10);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period10 = period4.normalizedStandard(periodType9);
        org.joda.time.Period period12 = period4.withYears((-10));
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) period12);
        try {
            long long21 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, 105, 3, (int) (byte) 0, 105, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 105 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) 'a');
        int int2 = period1.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.add((long) (short) 0, (int) ' ');
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getDurationField();
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        long long23 = offsetDateTimeField20.getDifferenceAsLong(0L, 0L);
        long long25 = offsetDateTimeField20.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial26 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.Chronology chronology33 = iSOChronology31.withUTC();
        java.lang.Object obj34 = null;
        org.joda.time.PeriodType periodType35 = null;
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period(obj34, periodType35, chronology36);
        org.joda.time.Period period39 = period37.withDays(0);
        int int40 = period39.getHours();
        int int41 = period39.size();
        int[] intArray43 = iSOChronology31.get((org.joda.time.ReadablePeriod) period39, (long) (-10));
        int[] intArray45 = offsetDateTimeField20.add(readablePartial26, 4, intArray43, 0);
        int int46 = offsetDateTimeField7.getMinimumValue(readablePartial12, intArray43);
        long long48 = offsetDateTimeField7.remainder(99L);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField7, (int) ' ', (int) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfWeek must be in the range [100,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2764800000L + "'", long10 == 2764800000L);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86400000L + "'", long25 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 8 + "'", int41 == 8);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 101 + "'", int46 == 101);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 99L + "'", long48 == 99L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField35.getType();
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.util.Locale locale40 = null;
        try {
            java.lang.String str41 = unsupportedDateTimeField35.getAsText(readablePartial39, locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        long long44 = dividedDateTimeField41.remainder((long) 0);
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 100);
        long long55 = offsetDateTimeField52.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale56 = null;
        int int57 = offsetDateTimeField52.getMaximumShortTextLength(locale56);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone60);
        org.joda.time.Period period62 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology61);
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology61.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = offsetDateTimeField65.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType66, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField52, dateTimeFieldType66, 243);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField41, dateTimeFieldType66);
        long long76 = dividedDateTimeField41.getDifferenceAsLong((-8L), (-3024000000L));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 3 + "'", int57 == 3);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        int int28 = remainderDateTimeField27.getDivisor();
        java.util.Locale locale30 = null;
        java.lang.String str31 = remainderDateTimeField27.getAsShortText((long) ' ', locale30);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 243 + "'", int28 == 243);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "104" + "'", str31.equals("104"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.Period period1 = org.joda.time.Period.hours(8);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.add(52L, 107);
        java.lang.String str11 = offsetDateTimeField7.toString();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9244800052L + "'", long10 == 9244800052L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str11.equals("DateTimeField[dayOfWeek]"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        try {
            int int38 = unsupportedDateTimeField35.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Object obj1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(obj1, periodType2, chronology3);
        int int5 = period4.getMinutes();
        org.joda.time.Period period7 = period4.plusHours((int) (short) -1);
        org.joda.time.Period period9 = period4.plusMonths((int) '4');
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType11 = periodType10.withHoursRemoved();
        org.joda.time.Period period12 = period4.withPeriodType(periodType11);
        org.joda.time.PeriodType periodType13 = periodType11.withWeeksRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', periodType11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-2764799990L), 242L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2764799748L) + "'", long2 == (-2764799748L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "DurationField[years]");
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 132);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 132");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = zonedChronology11.weeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.monthOfYear();
        org.joda.time.DurationField durationField21 = iSOChronology17.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology17, (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long29 = fixedDateTimeZone26.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale36 = null;
        java.lang.String str37 = fixedDateTimeZone34.getShortName(0L, locale36);
        boolean boolean39 = fixedDateTimeZone34.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime40 = null;
        boolean boolean41 = fixedDateTimeZone34.isLocalDateTimeGap(localDateTime40);
        long long43 = fixedDateTimeZone34.convertUTCToLocal((long) 350);
        long long45 = fixedDateTimeZone26.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone34, (long) 104);
        boolean boolean46 = periodType15.equals((java.lang.Object) long45);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType48 = periodType47.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType50 = periodType47.getFieldType(0);
        int int51 = periodType15.indexOf(durationFieldType50);
        org.joda.time.field.DecoratedDurationField decoratedDurationField52 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType50);
        long long53 = decoratedDurationField52.getUnitMillis();
        int int55 = decoratedDurationField52.getValue((-86400000L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+00:00" + "'", str37.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 350L + "'", long43 == 350L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 114L + "'", long45 == 114L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(durationFieldType50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604800000L + "'", long53 == 604800000L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.monthOfYear();
        org.joda.time.DurationField durationField18 = iSOChronology14.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        long long26 = fixedDateTimeZone23.nextTransition((long) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.Chronology chronology28 = gregorianChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology12.dayOfMonth();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        boolean boolean37 = unsupportedDateTimeField35.isSupported();
        try {
            long long39 = unsupportedDateTimeField35.roundHalfCeiling((long) 101);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        int int8 = offsetDateTimeField5.getDifference((long) '#', 0L);
        long long11 = offsetDateTimeField5.add((long) (-1), (-32L));
        int int12 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        long long23 = offsetDateTimeField20.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale24 = null;
        int int25 = offsetDateTimeField20.getMaximumShortTextLength(locale24);
        long long28 = offsetDateTimeField20.add((long) 3, 0);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology32);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, 100);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.Period period41 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology40);
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology40.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField44.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType45, 104, (int) ' ', (int) '4');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType45, (int) ' ');
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, (java.lang.Number) 4, "Coordinated Universal Time");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType45, 132);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-115200001L) + "'", long11 == (-115200001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 123 + "'", int12 == 123);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 3L + "'", long28 == 3L);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray18 = null;
        int int19 = offsetDateTimeField7.getMinimumValue(readablePartial17, intArray18);
        long long21 = offsetDateTimeField7.remainder(0L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.joda.time.Period period5 = period3.plusHours((int) (short) 0);
        java.lang.Object obj6 = null;
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(obj6, periodType7, chronology8);
        int int10 = period9.getMinutes();
        java.lang.Class<?> wildcardClass11 = period9.getClass();
        org.joda.time.Period period12 = period9.negated();
        org.joda.time.Period period13 = period12.normalizedStandard();
        org.joda.time.Period period14 = period5.minus((org.joda.time.ReadablePeriod) period12);
        int int15 = period5.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.Period period46 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology45);
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology45.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, 100);
        long long52 = offsetDateTimeField49.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale53 = null;
        int int54 = offsetDateTimeField49.getMaximumShortTextLength(locale53);
        org.joda.time.DurationField durationField55 = offsetDateTimeField49.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone66);
        org.joda.time.Period period68 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology67);
        org.joda.time.DateTimeField dateTimeField69 = iSOChronology67.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField69, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = offsetDateTimeField71.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, dateTimeFieldType72, 104, (int) ' ', (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField49, dateTimeFieldType72, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField79 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField41, dateTimeFieldType72);
        org.joda.time.ReadablePartial readablePartial80 = null;
        java.util.Locale locale81 = null;
        try {
            java.lang.String str82 = remainderDateTimeField79.getAsText(readablePartial80, locale81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 3 + "'", int54 == 3);
        org.junit.Assert.assertNull(durationField55);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        try {
            int int11 = unsupportedDurationField9.getValue(209951999968L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = zonedChronology11.weeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.monthOfYear();
        org.joda.time.DurationField durationField21 = iSOChronology17.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology17, (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long29 = fixedDateTimeZone26.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale36 = null;
        java.lang.String str37 = fixedDateTimeZone34.getShortName(0L, locale36);
        boolean boolean39 = fixedDateTimeZone34.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime40 = null;
        boolean boolean41 = fixedDateTimeZone34.isLocalDateTimeGap(localDateTime40);
        long long43 = fixedDateTimeZone34.convertUTCToLocal((long) 350);
        long long45 = fixedDateTimeZone26.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone34, (long) 104);
        boolean boolean46 = periodType15.equals((java.lang.Object) long45);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType48 = periodType47.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType50 = periodType47.getFieldType(0);
        int int51 = periodType15.indexOf(durationFieldType50);
        org.joda.time.field.DecoratedDurationField decoratedDurationField52 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType50);
        java.lang.String str53 = decoratedDurationField52.toString();
        java.lang.String str54 = decoratedDurationField52.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+00:00" + "'", str37.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 350L + "'", long43 == 350L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 114L + "'", long45 == 114L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(durationFieldType50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DurationField[years]" + "'", str53.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DurationField[years]" + "'", str54.equals("DurationField[years]"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        try {
            long long38 = unsupportedDateTimeField35.roundHalfFloor((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        org.joda.time.Period period8 = period3.minusSeconds(3);
        org.joda.time.Period period9 = period3.toPeriod();
        org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) period9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        try {
            long long12 = unsupportedDurationField9.getMillis((int) (byte) 0, (long) (-32));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        long long12 = fixedDateTimeZone4.nextTransition((long) '4');
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        illegalFieldValueException4.prependMessage("hi!");
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.Period period10 = period8.withDays((int) (short) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period9 = period3.normalizedStandard(periodType8);
        org.joda.time.Period period11 = period3.withYears((-10));
        org.joda.time.Period period13 = period3.withMinutes((int) (byte) -1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isLenient();
        long long18 = offsetDateTimeField7.roundHalfCeiling(114L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology4.minuteOfHour();
        org.joda.time.Period period8 = new org.joda.time.Period(14580107L, (org.joda.time.Chronology) iSOChronology4);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        org.joda.time.Period period8 = period3.plusMonths((int) '4');
        org.joda.time.Period period10 = period3.plusDays(100);
        org.joda.time.Hours hours11 = period10.toStandardHours();
        org.joda.time.Period period12 = period10.toPeriod();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(hours11);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        try {
            long long11 = unsupportedDurationField9.getValueAsLong((long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.standard();
        org.joda.time.Period period9 = new org.joda.time.Period((int) (byte) -1, (int) (byte) 0, (-105), 1, 104, 10, (int) '4', (int) ' ', periodType8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType13 = periodType12.withMillisRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant10, readableDuration11, periodType12);
        try {
            org.joda.time.Period period15 = period9.withPeriodType(periodType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.centuries();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 100);
        long long16 = offsetDateTimeField13.add((long) (short) 0, (int) ' ');
        org.joda.time.DurationField durationField17 = offsetDateTimeField13.getDurationField();
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, 100);
        long long29 = offsetDateTimeField26.getDifferenceAsLong(0L, 0L);
        long long31 = offsetDateTimeField26.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        org.joda.time.Period period38 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology37);
        org.joda.time.Chronology chronology39 = iSOChronology37.withUTC();
        java.lang.Object obj40 = null;
        org.joda.time.PeriodType periodType41 = null;
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(obj40, periodType41, chronology42);
        org.joda.time.Period period45 = period43.withDays(0);
        int int46 = period45.getHours();
        int int47 = period45.size();
        int[] intArray49 = iSOChronology37.get((org.joda.time.ReadablePeriod) period45, (long) (-10));
        int[] intArray51 = offsetDateTimeField26.add(readablePartial32, 4, intArray49, 0);
        int int52 = offsetDateTimeField13.getMinimumValue(readablePartial18, intArray49);
        try {
            iSOChronology1.validate(readablePartial5, intArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2764800000L + "'", long16 == 2764800000L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 86400000L + "'", long31 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 8 + "'", int47 == 8);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 101 + "'", int52 == 101);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(86400000L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = fixedDateTimeZone4.getOffset(readableInstant11);
        int int14 = fixedDateTimeZone4.getOffset((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale21 = null;
        java.lang.String str22 = fixedDateTimeZone19.getShortName(0L, locale21);
        long long25 = fixedDateTimeZone19.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant26 = null;
        int int27 = fixedDateTimeZone19.getOffset(readableInstant26);
        int int29 = fixedDateTimeZone19.getOffset((long) (short) -1);
        long long31 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone19, (long) 35);
        long long35 = fixedDateTimeZone4.convertLocalToUTC((long) 10, false, 10L);
        boolean boolean36 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 35L + "'", long25 == 35L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) '4');
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("1.0", false);
        java.util.TimeZone timeZone7 = dateTimeZone6.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.centuries();
        java.lang.String str5 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[hi!]" + "'", str5.equals("ISOChronology[hi!]"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone22.getShortName(0L, locale24);
        long long28 = fixedDateTimeZone22.convertLocalToUTC((long) '#', true);
        org.joda.time.Chronology chronology29 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        long long32 = fixedDateTimeZone22.previousTransition(86400000L);
        org.joda.time.LocalDateTime localDateTime33 = null;
        boolean boolean34 = fixedDateTimeZone22.isLocalDateTimeGap(localDateTime33);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 86400000L + "'", long32 == 86400000L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period8 = period3.toPeriod();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType10 = periodType9.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.monthOfYear();
        org.joda.time.DurationField durationField16 = iSOChronology12.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = zonedChronology22.withZone(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period8, periodType9, (org.joda.time.Chronology) zonedChronology22);
        org.joda.time.Period period27 = period8.plusDays(100);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], ]");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("ZonedChronology[ISOChronology[UTC], ]");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"ZonedChronology[ISOChronology[UTC], ]\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"ZonedChronology[ISOChronology[UTC], ]\")"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-8L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210867451200000L) + "'", long1 == (-210867451200000L));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        try {
            long long11 = unsupportedDurationField9.getMillis(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        try {
            int int36 = unsupportedDateTimeField35.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        illegalFieldValueException4.prependMessage("1.0");
        java.lang.String str11 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0" + "'", str8.equals("1.0"));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.dayOfWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, 0L, periodType2, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone11 = iSOChronology6.getZone();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.util.Locale locale37 = null;
        try {
            java.lang.String str38 = unsupportedDateTimeField35.getAsText((int) (byte) 0, locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray11 = new int[] { (short) 1, (byte) 0, (-10), (-10) };
        int int12 = offsetDateTimeField5.getMaximumValue(readablePartial6, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 100);
        long long24 = offsetDateTimeField21.getDifferenceAsLong(0L, 0L);
        long long26 = offsetDateTimeField21.roundCeiling((long) ' ');
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology32);
        org.joda.time.Chronology chronology34 = iSOChronology32.withUTC();
        java.lang.Object obj35 = null;
        org.joda.time.PeriodType periodType36 = null;
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period(obj35, periodType36, chronology37);
        org.joda.time.Period period40 = period38.withDays(0);
        int int41 = period40.getHours();
        int int42 = period40.size();
        int[] intArray44 = iSOChronology32.get((org.joda.time.ReadablePeriod) period40, (long) (-10));
        int[] intArray46 = offsetDateTimeField21.add(readablePartial27, 4, intArray44, 0);
        int int47 = offsetDateTimeField5.getMaximumValue(readablePartial13, intArray44);
        long long49 = offsetDateTimeField5.roundHalfEven((long) 123);
        long long51 = offsetDateTimeField5.roundHalfCeiling(242L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 123 + "'", int12 == 123);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86400000L + "'", long26 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 8 + "'", int42 == 8);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 123 + "'", int47 == 123);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        boolean boolean9 = fixedDateTimeZone4.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime10);
        long long13 = fixedDateTimeZone4.convertUTCToLocal((long) 350);
        org.joda.time.LocalDateTime localDateTime14 = null;
        boolean boolean15 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime14);
        java.util.Locale locale17 = null;
        java.lang.String str18 = fixedDateTimeZone4.getShortName(35L, locale17);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 350L + "'", long13 == 350L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00" + "'", str18.equals("+00:00"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        org.joda.time.DurationField durationField36 = unsupportedDateTimeField35.getRangeDurationField();
        java.util.Locale locale37 = null;
        try {
            int int38 = unsupportedDateTimeField35.getMaximumTextLength(locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNull(durationField36);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField7.getWrappedField();
        long long10 = offsetDateTimeField7.roundHalfEven(1560627574045L);
        long long12 = offsetDateTimeField7.roundHalfEven(259200000L);
        long long14 = offsetDateTimeField7.roundCeiling((long) 4);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560643200000L + "'", long10 == 1560643200000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 259200000L + "'", long12 == 259200000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        org.joda.time.DurationField durationField42 = dividedDateTimeField41.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.Period period47 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology46);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 100);
        long long53 = offsetDateTimeField50.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale54 = null;
        int int55 = offsetDateTimeField50.getMaximumShortTextLength(locale54);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField63.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType64, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType64, 243);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField41, dateTimeFieldType64, 107);
        long long75 = dividedDateTimeField41.add((long) '4', 0);
        long long78 = dividedDateTimeField41.getDifferenceAsLong(3L, 0L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 52L + "'", long75 == 52L);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = remainderDateTimeField27.getMinimumValue();
        int int43 = remainderDateTimeField27.getDivisor();
        java.lang.String str44 = remainderDateTimeField27.getName();
        int int45 = remainderDateTimeField27.getMaximumValue();
        long long47 = remainderDateTimeField27.roundHalfCeiling(2764800000L);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 243 + "'", int43 == 243);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "dayOfWeek" + "'", str44.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 242 + "'", int45 == 242);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2764800000L + "'", long47 == 2764800000L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(99L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period9 = period3.minusMonths((int) (byte) 10);
        org.joda.time.Period period11 = period3.withHours(350);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        org.joda.time.DurationField durationField42 = dividedDateTimeField41.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.Period period47 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology46);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 100);
        long long53 = offsetDateTimeField50.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale54 = null;
        int int55 = offsetDateTimeField50.getMaximumShortTextLength(locale54);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField63.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType64, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType64, 243);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField41, dateTimeFieldType64, 107);
        int int75 = remainderDateTimeField72.getDifference(0L, 106L);
        long long77 = remainderDateTimeField72.remainder((long) 132);
        long long80 = remainderDateTimeField72.addWrapField((-62135596800000L), (int) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 132L + "'", long77 == 132L);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-62135596800000L) + "'", long80 == (-62135596800000L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        org.joda.time.DurationField durationField36 = unsupportedDateTimeField35.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial37 = null;
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = unsupportedDateTimeField35.getAsShortText(readablePartial37, (int) '4', locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNull(durationField36);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType30, 104, (int) ' ', (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType30, (int) '#');
        long long39 = offsetDateTimeField36.add(2764800000L, 0);
        int int41 = offsetDateTimeField36.get((-210863736000000L));
        try {
            long long44 = offsetDateTimeField36.set(242L, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [136,142]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2764800000L + "'", long39 == 2764800000L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 136 + "'", int41 == 136);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        long long38 = unsupportedDateTimeField35.getDifferenceAsLong((long) (byte) 100, (long) 10);
        try {
            long long40 = unsupportedDateTimeField35.roundHalfCeiling((-32L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.dayOfWeek();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 1, 0L, periodType2, (org.joda.time.Chronology) iSOChronology6);
        java.lang.String str10 = period9.toString();
        java.lang.Object obj11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(obj11, periodType12, chronology13);
        org.joda.time.Period period16 = period14.withDays(0);
        org.joda.time.Period period18 = period14.withHours(10);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period20 = period14.normalizedStandard(periodType19);
        org.joda.time.Period period22 = new org.joda.time.Period(0L);
        org.joda.time.Minutes minutes23 = period22.toStandardMinutes();
        org.joda.time.Period period24 = period14.withFields((org.joda.time.ReadablePeriod) minutes23);
        org.joda.time.Period period25 = period9.minus((org.joda.time.ReadablePeriod) minutes23);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.001S" + "'", str10.equals("PT-0.001S"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(minutes23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = dividedDateTimeField41.getMinimumValue();
        int int45 = dividedDateTimeField41.getDifference((long) 35, (long) 243);
        long long47 = dividedDateTimeField41.remainder((long) 242);
        long long50 = dividedDateTimeField41.add(0L, 99L);
        try {
            long long53 = dividedDateTimeField41.set(0L, 136);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 136 for dayOfWeek must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 242L + "'", long47 == 242L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2078524800000L + "'", long50 == 2078524800000L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType30, 104, (int) ' ', (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType30, (int) '#');
        java.util.Locale locale37 = null;
        int int38 = offsetDateTimeField36.getMaximumTextLength(locale37);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 3 + "'", int38 == 3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        org.joda.time.DurationField durationField36 = unsupportedDateTimeField35.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.Period period43 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology42);
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, 100);
        org.joda.time.DateTimeField dateTimeField47 = offsetDateTimeField46.getWrappedField();
        int int49 = offsetDateTimeField46.getLeapAmount(1L);
        org.joda.time.ReadablePartial readablePartial50 = null;
        java.lang.Object obj52 = null;
        org.joda.time.PeriodType periodType53 = null;
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period(obj52, periodType53, chronology54);
        org.joda.time.Period period57 = period55.minusMillis((int) (byte) 1);
        org.joda.time.Period period58 = period55.negated();
        org.joda.time.Period period60 = period55.minusMonths((int) (short) 100);
        int[] intArray61 = period55.getValues();
        int[] intArray63 = offsetDateTimeField46.add(readablePartial50, (int) (byte) 100, intArray61, 0);
        try {
            int[] intArray65 = unsupportedDateTimeField35.addWrapField(readablePartial37, 123, intArray63, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNull(durationField36);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(obj3, periodType4, chronology5);
        org.joda.time.Period period8 = period6.withDays(0);
        org.joda.time.Period period10 = period6.withHours(10);
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) period10);
        java.lang.String str12 = lenientChronology2.toString();
        org.joda.time.Chronology chronology13 = lenientChronology2.withUTC();
        java.lang.Object obj14 = null;
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(obj14, periodType15, chronology16);
        int int18 = period17.getMinutes();
        java.lang.Class<?> wildcardClass19 = period17.getClass();
        org.joda.time.Period period20 = period17.negated();
        java.lang.Object obj21 = null;
        org.joda.time.PeriodType periodType22 = null;
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(obj21, periodType22, chronology23);
        int int25 = period24.getMinutes();
        java.lang.Class<?> wildcardClass26 = period24.getClass();
        org.joda.time.Duration duration27 = period24.toStandardDuration();
        boolean boolean29 = period24.equals((java.lang.Object) '4');
        org.joda.time.Period period30 = period17.plus((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period31 = period24.normalizedStandard();
        org.joda.time.Period period33 = period24.withMillis(100);
        int[] intArray35 = lenientChronology2.get((org.joda.time.ReadablePeriod) period24, (long) '4');
        org.joda.time.ReadablePartial readablePartial36 = null;
        try {
            int[] intArray38 = lenientChronology2.get(readablePartial36, (-101L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LenientChronology[ISOChronology[hi!]]" + "'", str12.equals("LenientChronology[ISOChronology[hi!]]"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType3);
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        org.joda.time.Period period10 = period8.minusYears((int) (byte) 0);
        java.lang.Object obj11 = null;
        org.joda.time.PeriodType periodType12 = null;
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(obj11, periodType12, chronology13);
        org.joda.time.Period period16 = period14.withDays(0);
        org.joda.time.Period period18 = period14.withHours(10);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period20 = period14.normalizedStandard(periodType19);
        org.joda.time.Period period21 = period8.withPeriodType(periodType19);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType3, (java.lang.Object) period21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.hourOfDay();
        org.joda.time.DurationField durationField27 = iSOChronology24.weeks();
        java.lang.Object obj28 = null;
        org.joda.time.PeriodType periodType29 = null;
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(obj28, periodType29, chronology30);
        int int32 = period31.getMinutes();
        org.joda.time.Period period34 = period31.plusHours((int) (short) -1);
        org.joda.time.Period period36 = period31.plusMonths((int) '4');
        org.joda.time.Period period38 = period31.plusDays(100);
        boolean boolean39 = iSOChronology24.equals((java.lang.Object) period38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology24.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology24.weekyearOfCentury();
        org.joda.time.Period period42 = new org.joda.time.Period(obj0, periodType3, (org.joda.time.Chronology) iSOChronology24);
        org.joda.time.DurationField durationField43 = iSOChronology24.hours();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Chronology chronology45 = null;
        try {
            org.joda.time.Period period46 = new org.joda.time.Period((java.lang.Object) durationField43, periodType44, chronology45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDurationField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(periodType44);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray18 = null;
        int int19 = offsetDateTimeField7.getMinimumValue(readablePartial17, intArray18);
        long long21 = offsetDateTimeField7.roundHalfEven((long) (short) 1);
        int int23 = offsetDateTimeField7.get(1L);
        int int25 = offsetDateTimeField7.getLeapAmount((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial26 = null;
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField35.getWrappedField();
        org.joda.time.ReadablePartial readablePartial37 = null;
        java.lang.Object obj38 = null;
        org.joda.time.PeriodType periodType39 = null;
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.Period period41 = new org.joda.time.Period(obj38, periodType39, chronology40);
        org.joda.time.Period period43 = period41.minusMillis((int) (byte) 1);
        org.joda.time.Period period44 = period41.negated();
        org.joda.time.Period period46 = period41.minusMonths((int) (short) 100);
        int[] intArray47 = period41.getValues();
        int int48 = offsetDateTimeField35.getMinimumValue(readablePartial37, intArray47);
        try {
            int[] intArray50 = offsetDateTimeField7.addWrapField(readablePartial26, (int) (short) 1, intArray47, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 104 + "'", int23 == 104);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 101 + "'", int48 == 101);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) 100);
        java.lang.Object obj2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(obj2, periodType3, chronology4);
        org.joda.time.Period period7 = period5.minusMillis((int) (byte) 1);
        org.joda.time.Period period9 = period5.plusMonths((int) '4');
        org.joda.time.Period period10 = period1.plus((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period11 = period1.negated();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.Period period10 = period8.withMillis((-1));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long8 = offsetDateTimeField5.add((long) (byte) 0, 2078524800000L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 7482689280000000000L + "'", long8 == 7482689280000000000L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.secondOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology11.dayOfYear();
        org.joda.time.DurationField durationField16 = iSOChronology11.seconds();
        int int17 = unsupportedDurationField9.compareTo(durationField16);
        try {
            long long20 = unsupportedDurationField9.getMillis((long) (byte) 100, 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.monthOfYear();
        org.joda.time.DurationField durationField7 = iSOChronology3.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long15 = fixedDateTimeZone12.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale22 = null;
        java.lang.String str23 = fixedDateTimeZone20.getShortName(0L, locale22);
        boolean boolean25 = fixedDateTimeZone20.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = fixedDateTimeZone20.isLocalDateTimeGap(localDateTime26);
        long long29 = fixedDateTimeZone20.convertUTCToLocal((long) 350);
        long long31 = fixedDateTimeZone12.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone20, (long) 104);
        boolean boolean32 = periodType1.equals((java.lang.Object) long31);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType34 = periodType33.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType36 = periodType33.getFieldType(0);
        int int37 = periodType1.indexOf(durationFieldType36);
        org.joda.time.field.ScaledDurationField scaledDurationField39 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType36, 123);
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType41 = periodType40.withMillisRemoved();
        boolean boolean42 = scaledDurationField39.equals((java.lang.Object) periodType41);
        int int44 = scaledDurationField39.getValue(32L);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 350L + "'", long29 == 350L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 114L + "'", long31 == 114L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        int int39 = unsupportedDateTimeField35.getDifference((-3024000000L), 0L);
        org.joda.time.ReadablePartial readablePartial40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.chrono.LenientChronology lenientChronology43 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology42);
        java.lang.Object obj44 = null;
        org.joda.time.PeriodType periodType45 = null;
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.Period period47 = new org.joda.time.Period(obj44, periodType45, chronology46);
        org.joda.time.Period period49 = period47.withDays(0);
        org.joda.time.Period period51 = period47.withHours(10);
        boolean boolean52 = lenientChronology43.equals((java.lang.Object) period51);
        java.lang.String str53 = lenientChronology43.toString();
        org.joda.time.Chronology chronology54 = lenientChronology43.withUTC();
        java.lang.Object obj55 = null;
        org.joda.time.PeriodType periodType56 = null;
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period(obj55, periodType56, chronology57);
        int int59 = period58.getMinutes();
        java.lang.Class<?> wildcardClass60 = period58.getClass();
        org.joda.time.Period period61 = period58.negated();
        java.lang.Object obj62 = null;
        org.joda.time.PeriodType periodType63 = null;
        org.joda.time.Chronology chronology64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(obj62, periodType63, chronology64);
        int int66 = period65.getMinutes();
        java.lang.Class<?> wildcardClass67 = period65.getClass();
        org.joda.time.Duration duration68 = period65.toStandardDuration();
        boolean boolean70 = period65.equals((java.lang.Object) '4');
        org.joda.time.Period period71 = period58.plus((org.joda.time.ReadablePeriod) period65);
        org.joda.time.Period period72 = period65.normalizedStandard();
        org.joda.time.Period period74 = period65.withMillis(100);
        int[] intArray76 = lenientChronology43.get((org.joda.time.ReadablePeriod) period65, (long) '4');
        try {
            int int77 = unsupportedDateTimeField35.getMinimumValue(readablePartial40, intArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(lenientChronology43);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "LenientChronology[ISOChronology[hi!]]" + "'", str53.equals("LenientChronology[ISOChronology[hi!]]"));
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(duration68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(period72);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(intArray76);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology1.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology1.yearOfCentury();
        org.joda.time.DurationField durationField20 = iSOChronology1.months();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period8 = period3.toPeriod();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType10 = periodType9.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.secondOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.monthOfYear();
        org.joda.time.DurationField durationField16 = iSOChronology12.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology12, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.Chronology chronology24 = zonedChronology22.withZone(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period8, periodType9, (org.joda.time.Chronology) zonedChronology22);
        org.joda.time.Period period27 = period8.plusMinutes((-105));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period6 = period5.toPeriod();
        org.joda.time.PeriodType periodType7 = period5.getPeriodType();
        org.joda.time.Period period9 = period5.withMillis(101);
        org.joda.time.Period period11 = period5.withDays(35);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(obj3, periodType4, chronology5);
        org.joda.time.Period period8 = period6.withDays(0);
        org.joda.time.Period period10 = period6.withHours(10);
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) period10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale18 = null;
        java.lang.String str19 = fixedDateTimeZone16.getShortName(0L, locale18);
        long long22 = fixedDateTimeZone16.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone23 = fixedDateTimeZone16.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale30 = null;
        java.lang.String str31 = fixedDateTimeZone28.getShortName(0L, locale30);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        long long35 = fixedDateTimeZone28.convertLocalToUTC((long) 10, false);
        long long37 = fixedDateTimeZone16.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone28, (long) 100);
        org.joda.time.ReadableInstant readableInstant38 = null;
        int int39 = fixedDateTimeZone16.getOffset(readableInstant38);
        org.joda.time.Chronology chronology40 = lenientChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        java.lang.String str41 = lenientChronology2.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00" + "'", str19.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+00:00" + "'", str31.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "LenientChronology[ISOChronology[hi!]]" + "'", str41.equals("LenientChronology[ISOChronology[hi!]]"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = fixedDateTimeZone4.getOffset(readableInstant11);
        int int14 = fixedDateTimeZone4.getOffset((long) (short) -1);
        long long16 = fixedDateTimeZone4.previousTransition(2078524800000L);
        long long18 = fixedDateTimeZone4.previousTransition((long) 123);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2078524800000L + "'", long16 == 2078524800000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 123L + "'", long18 == 123L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        long long29 = remainderDateTimeField27.roundHalfFloor(100L);
        int int30 = remainderDateTimeField27.getDivisor();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 243 + "'", int30 == 243);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.ReadableInstant readableInstant0 = null;
        java.lang.Object obj1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(obj1, periodType2, chronology3);
        org.joda.time.Period period6 = period4.minusMillis((int) (byte) 1);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationFrom(readableInstant7);
        java.lang.Object obj9 = null;
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(obj9, periodType10, chronology11);
        int int13 = period12.getMinutes();
        org.joda.time.Period period15 = period12.plusHours((int) (short) -1);
        org.joda.time.Period period17 = period12.plusMonths((int) '4');
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType19 = periodType18.withHoursRemoved();
        org.joda.time.Period period20 = period12.withPeriodType(periodType19);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType19);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        org.joda.time.DurationField durationField42 = dividedDateTimeField41.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone45);
        org.joda.time.Period period47 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology46);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, 100);
        long long53 = offsetDateTimeField50.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale54 = null;
        int int55 = offsetDateTimeField50.getMaximumShortTextLength(locale54);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology59);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField63.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType64, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType64, 243);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField41, dateTimeFieldType64, 107);
        int int73 = dividedDateTimeField41.getDivisor();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 243 + "'", int73 == 243);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(obj3, periodType4, chronology5);
        org.joda.time.Period period8 = period6.withDays(0);
        org.joda.time.Period period10 = period6.withHours(10);
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) period10);
        java.lang.String str12 = lenientChronology2.toString();
        org.joda.time.DateTimeField dateTimeField13 = lenientChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology2.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LenientChronology[ISOChronology[hi!]]" + "'", str12.equals("LenientChronology[ISOChronology[hi!]]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.secondOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.monthOfYear();
        org.joda.time.DurationField durationField18 = iSOChronology14.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, (org.joda.time.DateTimeZone) fixedDateTimeZone23);
        long long26 = fixedDateTimeZone23.nextTransition((long) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.Chronology chronology28 = gregorianChronology12.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        int int29 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        int int12 = offsetDateTimeField7.getMaximumValue((long) 8);
        long long14 = offsetDateTimeField7.remainder(1L);
        java.lang.String str15 = offsetDateTimeField7.getName();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 107 + "'", int12 == 107);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfWeek" + "'", str15.equals("dayOfWeek"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number10 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0" + "'", str7.equals("1.0"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.0d + "'", number10.equals(1.0d));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.years();
        org.joda.time.Period period2 = new org.joda.time.Period(52L, periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) 'a', ' ', 104, (int) (byte) 10, (-1), false, 4);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.setStandardOffset((-10));
        java.io.OutputStream outputStream15 = null;
        try {
            dateTimeZoneBuilder0.writeTo("dayOfWeek", outputStream15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        try {
            long long16 = zonedChronology11.getDateTimeMillis(123, 101, 136, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 101 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = fixedDateTimeZone4.getOffset(readableInstant11);
        int int14 = fixedDateTimeZone4.getOffset((long) (short) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale21 = null;
        java.lang.String str22 = fixedDateTimeZone19.getShortName(0L, locale21);
        long long25 = fixedDateTimeZone19.convertLocalToUTC((long) '#', true);
        org.joda.time.ReadableInstant readableInstant26 = null;
        int int27 = fixedDateTimeZone19.getOffset(readableInstant26);
        int int29 = fixedDateTimeZone19.getOffset((long) (short) -1);
        long long31 = fixedDateTimeZone4.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone19, (long) 35);
        boolean boolean33 = fixedDateTimeZone19.isStandardOffset((long) (-10));
        java.lang.String str34 = fixedDateTimeZone19.getID();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00" + "'", str22.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 35L + "'", long25 == 35L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Object obj1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(obj1, periodType2, chronology3);
        org.joda.time.Period period6 = period4.withDays(0);
        int int7 = period6.getYears();
        org.joda.time.Days days8 = period6.toStandardDays();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period10 = period6.normalizedStandard(periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withWeeksRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology13 = gregorianChronology12.withUTC();
        org.joda.time.Period period14 = new org.joda.time.Period(11400L, periodType9, (org.joda.time.Chronology) gregorianChronology12);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(days8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField35.getType();
        java.lang.String str39 = unsupportedDateTimeField35.toString();
        org.joda.time.ReadablePartial readablePartial40 = null;
        java.util.Locale locale42 = null;
        try {
            java.lang.String str43 = unsupportedDateTimeField35.getAsText(readablePartial40, 242, locale42);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UnsupportedDateTimeField" + "'", str39.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField7.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, "97");
        java.lang.Number number11 = illegalFieldValueException10.getUpperBound();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField35.getType();
        java.lang.String str39 = unsupportedDateTimeField35.toString();
        java.util.Locale locale40 = null;
        try {
            int int41 = unsupportedDateTimeField35.getMaximumShortTextLength(locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UnsupportedDateTimeField" + "'", str39.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale11 = null;
        java.lang.String str12 = fixedDateTimeZone9.getShortName(0L, locale11);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.Chronology chronology14 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationTo(readableInstant2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology1.eras();
        try {
            long long11 = iSOChronology1.getDateTimeMillis(242L, (int) (byte) 100, 0, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.minusYears((int) (byte) 0);
        java.lang.Object obj6 = null;
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(obj6, periodType7, chronology8);
        org.joda.time.Period period11 = period9.withDays(0);
        org.joda.time.Period period13 = period9.withHours(10);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.seconds();
        org.joda.time.Period period15 = period9.normalizedStandard(periodType14);
        org.joda.time.Period period16 = period3.withPeriodType(periodType14);
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Duration duration19 = mutablePeriod17.toDurationTo(readableInstant18);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(duration19);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) '4');
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("1.0", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder3.setStandardOffset(243);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-210858076800000L), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210858076800000L) + "'", long2 == (-210858076800000L));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.DurationField durationField14 = zonedChronology11.weeks();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology17.monthOfYear();
        org.joda.time.DurationField durationField21 = iSOChronology17.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology17, (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        long long29 = fixedDateTimeZone26.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale36 = null;
        java.lang.String str37 = fixedDateTimeZone34.getShortName(0L, locale36);
        boolean boolean39 = fixedDateTimeZone34.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime40 = null;
        boolean boolean41 = fixedDateTimeZone34.isLocalDateTimeGap(localDateTime40);
        long long43 = fixedDateTimeZone34.convertUTCToLocal((long) 350);
        long long45 = fixedDateTimeZone26.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone34, (long) 104);
        boolean boolean46 = periodType15.equals((java.lang.Object) long45);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType48 = periodType47.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType50 = periodType47.getFieldType(0);
        int int51 = periodType15.indexOf(durationFieldType50);
        org.joda.time.field.DecoratedDurationField decoratedDurationField52 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType50);
        java.lang.String str53 = decoratedDurationField52.toString();
        boolean boolean54 = decoratedDurationField52.isSupported();
        long long57 = decoratedDurationField52.getMillis((-32L), 1560627574045L);
        int int59 = decoratedDurationField52.getValue((long) (short) 1);
        long long61 = decoratedDurationField52.getMillis(136);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+00:00" + "'", str37.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 350L + "'", long43 == 350L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 114L + "'", long45 == 114L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(durationFieldType50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DurationField[years]" + "'", str53.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-19353600000L) + "'", long57 == (-19353600000L));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 82252800000L + "'", long61 == 82252800000L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        long long38 = unsupportedDateTimeField35.getDifferenceAsLong((long) (byte) 100, (long) 10);
        org.joda.time.DurationField durationField39 = unsupportedDateTimeField35.getDurationField();
        java.util.Locale locale41 = null;
        try {
            java.lang.String str42 = unsupportedDateTimeField35.getAsShortText((int) (byte) -1, locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) 'a');
        org.joda.time.Hours hours2 = period1.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(hours2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        org.joda.time.Period period8 = period3.plusMonths((int) '4');
        org.joda.time.Period period10 = period3.plusDays(100);
        org.joda.time.Hours hours11 = period10.toStandardHours();
        java.lang.Object obj12 = null;
        org.joda.time.PeriodType periodType13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(obj12, periodType13, chronology14);
        org.joda.time.Period period17 = period15.withDays(0);
        int int18 = period17.getHours();
        int int19 = period17.size();
        org.joda.time.Period period20 = period10.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period22 = period17.withMinutes(0);
        boolean boolean24 = period22.equals((java.lang.Object) 9244800052L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(hours11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray18 = null;
        int int19 = offsetDateTimeField7.getMinimumValue(readablePartial17, intArray18);
        long long21 = offsetDateTimeField7.roundHalfEven((long) (short) 1);
        int int23 = offsetDateTimeField7.get(1L);
        long long25 = offsetDateTimeField7.roundCeiling((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField7.getAsShortText(readablePartial26, 242, locale28);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 104 + "'", int23 == 104);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86400000L + "'", long25 == 86400000L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "242" + "'", str29.equals("242"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        int int39 = unsupportedDateTimeField35.getDifference((-3024000000L), 0L);
        org.joda.time.ReadablePartial readablePartial40 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone42);
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology43.secondOfDay();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology43.monthOfYear();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology43.millisOfSecond();
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.PeriodType periodType50 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType51 = periodType50.withMillisRemoved();
        org.joda.time.Period period52 = new org.joda.time.Period(readableInstant48, readableDuration49, periodType50);
        int[] intArray54 = iSOChronology43.get((org.joda.time.ReadablePeriod) period52, (long) 105);
        try {
            int[] intArray56 = unsupportedDateTimeField35.addWrapPartial(readablePartial40, 0, intArray54, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(periodType51);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period9 = period3.minusMonths((int) (byte) 10);
        org.joda.time.Period period11 = period3.plusSeconds(10);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval5 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(readableInterval5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DurationField durationField13 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType30, 104, (int) ' ', (int) '4');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType30, (int) '#');
        long long38 = offsetDateTimeField7.roundHalfEven(0L);
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField7.getAsText(0, locale40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        java.util.Locale locale44 = null;
        java.lang.String str45 = offsetDateTimeField7.getAsText(readablePartial42, 243, locale44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField7.getAsText(0, locale47);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0" + "'", str41.equals("0"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "243" + "'", str45.equals("243"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "0" + "'", str48.equals("0"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.secondOfDay();
        org.joda.time.DurationField durationField18 = iSOChronology1.millis();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology20.hourOfDay();
        org.joda.time.DurationField durationField23 = iSOChronology20.weeks();
        java.lang.Object obj24 = null;
        org.joda.time.PeriodType periodType25 = null;
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.Period period27 = new org.joda.time.Period(obj24, periodType25, chronology26);
        int int28 = period27.getMinutes();
        org.joda.time.Period period30 = period27.plusHours((int) (short) -1);
        org.joda.time.Period period32 = period27.plusMonths((int) '4');
        org.joda.time.Period period34 = period27.plusDays(100);
        boolean boolean35 = iSOChronology20.equals((java.lang.Object) period34);
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology20.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone37 = iSOChronology20.getZone();
        org.joda.time.Chronology chronology38 = iSOChronology1.withZone(dateTimeZone37);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(chronology38);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("GregorianChronology[hi!]", (java.lang.Number) 132, (java.lang.Number) (-62135596800000L), (java.lang.Number) (-2764800000L));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField35.getType();
        java.lang.String str39 = unsupportedDateTimeField35.toString();
        try {
            int int41 = unsupportedDateTimeField35.get(7482689280000000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UnsupportedDateTimeField" + "'", str39.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, 350);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 350");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray18 = null;
        int int19 = offsetDateTimeField7.getMinimumValue(readablePartial17, intArray18);
        long long21 = offsetDateTimeField7.roundHalfEven((long) (short) 1);
        int int23 = offsetDateTimeField7.get(1L);
        long long25 = offsetDateTimeField7.roundCeiling((long) 10);
        java.lang.String str27 = offsetDateTimeField7.getAsText(0L);
        int int29 = offsetDateTimeField7.getMaximumValue((-123L));
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 104 + "'", int23 == 104);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 86400000L + "'", long25 == 86400000L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "104" + "'", str27.equals("104"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 107 + "'", int29 == 107);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean10 = unsupportedDurationField9.isSupported();
        try {
            long long12 = unsupportedDurationField9.getMillis((long) (-32));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        long long15 = offsetDateTimeField7.add((long) 3, 0);
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.secondOfDay();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.monthOfYear();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology19.millisOfSecond();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType27 = periodType26.withMillisRemoved();
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant24, readableDuration25, periodType26);
        int[] intArray30 = iSOChronology19.get((org.joda.time.ReadablePeriod) period28, (long) 105);
        int int31 = offsetDateTimeField7.getMaximumValue(readablePartial17, intArray30);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 107 + "'", int31 == 107);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField5 = iSOChronology1.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.Chronology chronology13 = zonedChronology11.withZone(dateTimeZone12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str19 = illegalFieldValueException18.getIllegalStringValue();
        java.lang.Number number20 = illegalFieldValueException18.getLowerBound();
        boolean boolean21 = zonedChronology11.equals((java.lang.Object) illegalFieldValueException18);
        java.lang.String str22 = illegalFieldValueException18.getFieldName();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology24.secondOfDay();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology24.monthOfYear();
        org.joda.time.DurationField durationField28 = iSOChronology24.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology24, (org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.Chronology chronology36 = zonedChronology34.withZone(dateTimeZone35);
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1.0d, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str42 = illegalFieldValueException41.getIllegalStringValue();
        java.lang.Number number43 = illegalFieldValueException41.getLowerBound();
        boolean boolean44 = zonedChronology34.equals((java.lang.Object) illegalFieldValueException41);
        java.lang.String str45 = illegalFieldValueException41.getFieldName();
        illegalFieldValueException18.addSuppressed((java.lang.Throwable) illegalFieldValueException41);
        java.lang.Throwable[] throwableArray47 = illegalFieldValueException41.getSuppressed();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0f + "'", number43.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertNotNull(throwableArray47);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Period period5 = period3.withDays(0);
        org.joda.time.Period period7 = period3.withHours(10);
        org.joda.time.Period period9 = period7.minusDays((int) (byte) 100);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology1);
        java.lang.Object obj3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(obj3, periodType4, chronology5);
        org.joda.time.Period period8 = period6.withDays(0);
        org.joda.time.Period period10 = period6.withHours(10);
        boolean boolean11 = lenientChronology2.equals((java.lang.Object) period10);
        java.lang.String str12 = lenientChronology2.toString();
        org.joda.time.ReadablePartial readablePartial13 = null;
        try {
            long long15 = lenientChronology2.set(readablePartial13, 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LenientChronology[ISOChronology[hi!]]" + "'", str12.equals("LenientChronology[ISOChronology[hi!]]"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.Period period1 = org.joda.time.Period.months((-105));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.monthOfYear();
        org.joda.time.DurationField durationField7 = iSOChronology3.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long15 = fixedDateTimeZone12.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale22 = null;
        java.lang.String str23 = fixedDateTimeZone20.getShortName(0L, locale22);
        boolean boolean25 = fixedDateTimeZone20.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = fixedDateTimeZone20.isLocalDateTimeGap(localDateTime26);
        long long29 = fixedDateTimeZone20.convertUTCToLocal((long) 350);
        long long31 = fixedDateTimeZone12.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone20, (long) 104);
        boolean boolean32 = periodType1.equals((java.lang.Object) long31);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType34 = periodType33.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType36 = periodType33.getFieldType(0);
        int int37 = periodType1.indexOf(durationFieldType36);
        org.joda.time.field.ScaledDurationField scaledDurationField39 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType36, 123);
        java.lang.Object obj40 = null;
        org.joda.time.PeriodType periodType41 = null;
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period(obj40, periodType41, chronology42);
        org.joda.time.Period period45 = period43.minusYears((int) (byte) 0);
        org.joda.time.PeriodType periodType46 = org.joda.time.PeriodType.seconds();
        org.joda.time.DateTimeZone dateTimeZone47 = null;
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone47);
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology48.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology48.secondOfDay();
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology48.monthOfYear();
        org.joda.time.DurationField durationField52 = iSOChronology48.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone57 = new org.joda.time.tz.FixedDateTimeZone("", "+00:00", (int) (short) 10, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology58 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology48, (org.joda.time.DateTimeZone) fixedDateTimeZone57);
        long long60 = fixedDateTimeZone57.nextTransition((long) '4');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone65 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale67 = null;
        java.lang.String str68 = fixedDateTimeZone65.getShortName(0L, locale67);
        boolean boolean70 = fixedDateTimeZone65.equals((java.lang.Object) ' ');
        org.joda.time.LocalDateTime localDateTime71 = null;
        boolean boolean72 = fixedDateTimeZone65.isLocalDateTimeGap(localDateTime71);
        long long74 = fixedDateTimeZone65.convertUTCToLocal((long) 350);
        long long76 = fixedDateTimeZone57.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone65, (long) 104);
        boolean boolean77 = periodType46.equals((java.lang.Object) long76);
        org.joda.time.PeriodType periodType78 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType79 = periodType78.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType81 = periodType78.getFieldType(0);
        int int82 = periodType46.indexOf(durationFieldType81);
        org.joda.time.Period period84 = period43.withFieldAdded(durationFieldType81, (-32));
        org.joda.time.field.ScaledDurationField scaledDurationField86 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType81, (-1));
        long long88 = scaledDurationField86.getValueAsLong((long) 101);
        int int91 = scaledDurationField86.getDifference((long) 8, (-86400000L));
        long long94 = scaledDurationField86.add(1560643200000L, 3);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 350L + "'", long29 == 350L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 114L + "'", long31 == 114L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(zonedChronology58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 52L + "'", long60 == 52L);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "+00:00" + "'", str68.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 350L + "'", long74 == 350L);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 114L + "'", long76 == 114L);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(periodType78);
        org.junit.Assert.assertNotNull(periodType79);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(period84);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-101L) + "'", long88 == (-101L));
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-86400008) + "'", int91 == (-86400008));
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 1560643199997L + "'", long94 == 1560643199997L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "PT-0.001S", "ZonedChronology[ISOChronology[UTC], ]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "dayOfWeek", "-1");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getName(locale13, "97", "");
        java.util.Locale locale17 = null;
        java.lang.String str20 = defaultNameProvider0.getName(locale17, "", "PT-0.001S");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.Period period1 = org.joda.time.Period.years(35);
        int int2 = period1.getYears();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType6 = periodType3.getFieldType(0);
        org.joda.time.Period period8 = period1.withFieldAdded(durationFieldType6, 100);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField9 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        java.lang.String str10 = unsupportedDurationField9.toString();
        try {
            long long12 = unsupportedDurationField9.getMillis((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(unsupportedDurationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnsupportedDurationField[years]" + "'", str10.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        int int4 = period3.getMinutes();
        org.joda.time.Period period6 = period3.plusHours((int) (short) -1);
        java.lang.Object obj7 = null;
        org.joda.time.PeriodType periodType8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(obj7, periodType8, chronology9);
        org.joda.time.Period period12 = period10.withDays(0);
        org.joda.time.Seconds seconds13 = period12.toStandardSeconds();
        java.lang.Object obj14 = null;
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(obj14, periodType15, chronology16);
        org.joda.time.Period period19 = period17.withDays(0);
        org.joda.time.Period period21 = period17.withHours(10);
        org.joda.time.Period period23 = period17.minusMonths((int) (byte) 10);
        org.joda.time.Period period25 = period23.withMinutes(107);
        org.joda.time.Period period26 = period12.plus((org.joda.time.ReadablePeriod) period25);
        org.joda.time.Period period27 = period3.withFields((org.joda.time.ReadablePeriod) period25);
        int int28 = period3.getMinutes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(seconds13);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField35.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType36, 8, 3, (int) ' ');
        org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField27, dateTimeFieldType36);
        int int42 = remainderDateTimeField27.getMinimumValue();
        org.joda.time.DurationField durationField43 = remainderDateTimeField27.getRangeDurationField();
        boolean boolean45 = remainderDateTimeField27.isLeap(32L);
        org.joda.time.ReadablePartial readablePartial46 = null;
        java.util.Locale locale48 = null;
        java.lang.String str49 = remainderDateTimeField27.getAsShortText(readablePartial46, (int) (byte) 0, locale48);
        org.joda.time.ReadablePartial readablePartial50 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone52);
        org.joda.time.chrono.LenientChronology lenientChronology54 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology53);
        java.lang.Object obj55 = null;
        org.joda.time.PeriodType periodType56 = null;
        org.joda.time.Chronology chronology57 = null;
        org.joda.time.Period period58 = new org.joda.time.Period(obj55, periodType56, chronology57);
        org.joda.time.Period period60 = period58.withDays(0);
        int int61 = period60.getYears();
        org.joda.time.Days days62 = period60.toStandardDays();
        org.joda.time.PeriodType periodType63 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period64 = period60.normalizedStandard(periodType63);
        org.joda.time.Period period66 = period60.minusMonths(100);
        int[] intArray68 = lenientChronology54.get((org.joda.time.ReadablePeriod) period60, 1560643200000L);
        try {
            int[] intArray70 = remainderDateTimeField27.addWrapField(readablePartial50, 123, intArray68, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 123");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertNotNull(lenientChronology54);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(days62);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertNotNull(intArray68);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.hourOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        java.lang.Object obj5 = null;
        org.joda.time.PeriodType periodType6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(obj5, periodType6, chronology7);
        int int9 = period8.getMinutes();
        org.joda.time.Period period11 = period8.plusHours((int) (short) -1);
        org.joda.time.Period period13 = period8.plusMonths((int) '4');
        org.joda.time.Period period15 = period8.plusDays(100);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) period15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology1.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone22.getShortName(0L, locale24);
        long long28 = fixedDateTimeZone22.convertLocalToUTC((long) '#', true);
        org.joda.time.Chronology chronology29 = iSOChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology1.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00" + "'", str25.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 100);
        long long10 = offsetDateTimeField7.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField7.getMaximumShortTextLength(locale11);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.Period period17 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField20.getType();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType21, 8, 3, (int) ' ');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField27 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType21, 243);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, "ISOChronology[hi!]");
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology31.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.hourOfDay();
        org.joda.time.DurationField durationField34 = iSOChronology31.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField34);
        java.lang.String str36 = unsupportedDateTimeField35.toString();
        java.lang.String str37 = unsupportedDateTimeField35.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField35.getType();
        org.joda.time.ReadablePartial readablePartial39 = null;
        try {
            int int40 = unsupportedDateTimeField35.getMaximumValue(readablePartial39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UnsupportedDateTimeField" + "'", str36.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "UnsupportedDateTimeField" + "'", str37.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) 'a', ' ', 104, (int) (byte) 10, (-1), false, 4);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(4, '4', (-10), (int) (byte) 1, (int) 'a', false, 123);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 0, (-1L), (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology5 = iSOChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology3.clockhourOfDay();
        java.lang.Object obj8 = null;
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(obj8, periodType9, chronology10);
        int int12 = period11.getMinutes();
        org.joda.time.Period period14 = period11.plusHours((int) (short) -1);
        org.joda.time.Period period16 = period11.withWeeks((int) '4');
        long long19 = iSOChronology3.add((org.joda.time.ReadablePeriod) period16, (-19353600000L), 0);
        long long24 = iSOChronology3.getDateTimeMillis(0, 3, (int) (short) 10, 3);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-19353600000L) + "'", long19 == (-19353600000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62161257599997L) + "'", long24 == (-62161257599997L));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getShortName(0L, locale6);
        long long10 = fixedDateTimeZone4.convertLocalToUTC((long) '#', true);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        int int13 = fixedDateTimeZone4.getOffset((-86399965L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }
}

