import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.get(durationFieldType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.Period period0 = new org.joda.time.Period();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Period period6 = period3.withFieldAdded(durationFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.Period period13 = period10.withFieldAdded(durationFieldType11, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("hi!", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePartial2, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withSecondsRemoved();
        boolean boolean3 = org.joda.time.field.FieldUtils.equals((java.lang.Object) '4', (java.lang.Object) periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis((int) '#', (int) (byte) 100, (int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) 100.0f, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMinutesRemoved();
        java.lang.Object obj3 = null;
        boolean boolean4 = periodType2.equals(obj3);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Object obj8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(obj8, periodType9, chronology10);
        org.joda.time.PeriodType periodType12 = periodType9.withSecondsRemoved();
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((int) (byte) -1, 101, (int) (short) -1, (int) (short) 10, (int) ' ', 101, (int) ' ', (int) (byte) 10, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        long long12 = dateTimeZone3.getMillisKeepLocal(dateTimeZone8, (long) (short) 100);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) (short) 100, periodType13, (org.joda.time.Chronology) gregorianChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        int int2 = periodType1.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("+00:00", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.ReadablePartial readablePartial2 = null;
        int[] intArray8 = new int[] { (byte) 100, 101, (byte) 1, (short) 0, 10 };
        try {
            gregorianChronology0.validate(readablePartial2, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) 0, 28800100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.monthOfYear();
        org.joda.time.DurationField durationField10 = gregorianChronology8.weeks();
        try {
            org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) (short) 0, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        int int7 = period6.getDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.adjustOffset((long) (short) 10, false);
//        java.lang.String str4 = dateTimeZone0.getID();
//        org.joda.time.LocalDateTime localDateTime5 = null;
//        try {
//            boolean boolean6 = dateTimeZone0.isLocalDateTimeGap(localDateTime5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis((int) (byte) 1, (int) (byte) -1, (int) (short) 100, (int) (short) 1, (int) ' ', (int) (byte) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        java.lang.String str6 = dateTimeZone3.getID();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 100, 0, 1, (int) (short) 10);
        org.joda.time.Period period6 = period4.minusHours((int) (byte) -1);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(1);
        java.io.OutputStream outputStream7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("UTC", outputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) -1, 2440588L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2440588) + "'", int2 == (-2440588));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        java.lang.String str2 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
//        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
//        int int13 = offsetDateTimeField5.getLeapAmount(100L);
//        long long15 = offsetDateTimeField5.remainder((long) 10);
//        try {
//            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 230400010L + "'", long15 == 230400010L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(1L, "hi!");
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        try {
            long long7 = iSOChronology0.getDateTimeMillis(101, 6, (int) (short) 100, 101);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 'a');
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10, number2, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = offsetDateTimeField5.getAsText(readablePartial14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField18 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType16, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5);
        org.junit.Assert.assertNotNull(duration5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) ' ');
        long long13 = cachedDateTimeZone8.adjustOffset((long) 101, true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 101L + "'", long13 == 101L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        org.joda.time.Period period8 = period6.withYears((int) ' ');
        int int9 = period8.getMinutes();
        org.joda.time.PeriodType periodType10 = period8.getPeriodType();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(6, 200);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 206 + "'", int2 == 206);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMonthsRemoved();
        java.lang.Class<?> wildcardClass3 = periodType1.getClass();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        int int13 = offsetDateTimeField5.getLeapAmount(100L);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.monthOfYear();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray26 = new int[] { (byte) 1, 100, (short) 100 };
        int int27 = offsetDateTimeField21.getMinimumValue(readablePartial22, intArray26);
        org.joda.time.DateTimeField dateTimeField28 = offsetDateTimeField21.getWrappedField();
        boolean boolean29 = offsetDateTimeField21.isLenient();
        long long31 = offsetDateTimeField21.roundHalfFloor((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.monthOfYear();
        org.joda.time.DurationField durationField35 = gregorianChronology33.weeks();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial39 = null;
        int[] intArray43 = new int[] { (byte) 1, 100, (short) 100 };
        int int44 = offsetDateTimeField38.getMinimumValue(readablePartial39, intArray43);
        int int45 = offsetDateTimeField21.getMinimumValue(readablePartial32, intArray43);
        java.util.Locale locale47 = null;
        try {
            int[] intArray48 = offsetDateTimeField5.set(readablePartial14, (-52), intArray43, "America/Los_Angeles", locale47);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 101 + "'", int27 == 101);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-259200001L) + "'", long31 == (-259200001L));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 101 + "'", int44 == 101);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "P32Y");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        long long22 = offsetDateTimeField5.roundCeiling((-230400000L));
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType23, (int) (byte) 100, (int) '#', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 31795199999L + "'", long22 == 31795199999L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        long long15 = offsetDateTimeField5.roundCeiling((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { '#', (-2440588), (short) 1, (byte) 100, ' ' };
        try {
            int[] intArray25 = offsetDateTimeField5.add(readablePartial16, 0, intArray23, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31795199999L + "'", long15 == 31795199999L);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        int int7 = offsetDateTimeField5.getMaximumValue((long) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 200 + "'", int7 == 200);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusSeconds((int) (byte) 10);
        org.joda.time.Days days7 = period6.toStandardDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(days7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) (-2440588));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getName(0L);
        java.lang.String str6 = dateTimeZone3.getID();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) -1, chronology3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType8 = periodType7.withDaysRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withMonthsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6, periodType9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        org.joda.time.Chronology chronology17 = iSOChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        try {
            org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) (byte) -1, periodType9, chronology17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("DateTimeField[weekyearOfCentury]", 206, 6, (int) (short) 10, ' ', (-52), 0, 1, false, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        try {
            long long13 = gregorianChronology5.getDateTimeMillis((int) (short) -1, (int) '#', 1, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        java.util.Locale locale14 = null;
        try {
            long long15 = offsetDateTimeField5.set((long) 10, "PT0S", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT0S\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.DurationField durationField5 = gregorianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.clockhourOfHalfday();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) periodType0, (org.joda.time.Chronology) gregorianChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            int[] intArray14 = lenientChronology11.get(readablePartial12, 28800100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        java.lang.String str21 = offsetDateTimeField5.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "weekyearOfCentury" + "'", str21.equals("weekyearOfCentury"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Period period21 = period19.withHours((int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.monthOfYear();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int[] intArray32 = new int[] { (byte) 1, 100, (short) 100 };
        int int33 = offsetDateTimeField27.getMinimumValue(readablePartial28, intArray32);
        org.joda.time.DateTimeField dateTimeField34 = offsetDateTimeField27.getWrappedField();
        long long36 = offsetDateTimeField27.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField37 = offsetDateTimeField27.getWrappedField();
        int int39 = offsetDateTimeField27.get(2440588L);
        boolean boolean40 = period19.equals((java.lang.Object) 2440588L);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 101 + "'", int33 == 101);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-259200001L) + "'", long36 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 171 + "'", int39 == 171);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        int int13 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DurationField durationField14 = offsetDateTimeField5.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = offsetDateTimeField5.getAsText(readablePartial15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(101L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(0);
        org.joda.time.Period period3 = period1.multipliedBy((int) (short) 1);
        org.joda.time.Period period5 = period1.minusYears((int) (byte) 10);
        org.joda.time.Period period7 = period5.plusSeconds((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.years();
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) periodType0, periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("171");
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7);
        org.joda.time.Period period9 = period8.toPeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number7 = illegalFieldValueException5.getLowerBound();
        java.lang.String str8 = illegalFieldValueException5.getIllegalStringValue();
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((-1), 'a', 0, (int) '4', (int) (byte) 100, true, (int) ' ');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder11.addRecurringSavings("", (int) '#', (int) '4', 200, 'a', (int) (short) 1, (int) (byte) 1, 206, false, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, 206);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-259200001L), 2440588L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-256759413L) + "'", long2 == (-256759413L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 100, 200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20000L + "'", long2 == 20000L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology6);
        org.joda.time.Period period8 = period3.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType10 = periodType9.withDaysRemoved();
        try {
            org.joda.time.Period period11 = period8.normalizedStandard(periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField5.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.monthOfYear();
        org.joda.time.DurationField durationField26 = gregorianChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial30 = null;
        int[] intArray34 = new int[] { (byte) 1, 100, (short) 100 };
        int int35 = offsetDateTimeField29.getMinimumValue(readablePartial30, intArray34);
        try {
            int[] intArray37 = offsetDateTimeField5.addWrapPartial(readablePartial22, (int) (byte) 0, intArray34, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 101 + "'", int35 == 101);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        int int13 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = null;
        try {
            int[] intArray18 = offsetDateTimeField5.set(readablePartial14, (int) (byte) 0, intArray16, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for weekyearOfCentury must be in the range [101,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.junit.Assert.assertNotNull(period0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.monthOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray11 = new int[] { (byte) 1, 100, (short) 100 };
        int int12 = offsetDateTimeField6.getMinimumValue(readablePartial7, intArray11);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField6.getWrappedField();
        long long15 = offsetDateTimeField6.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField6.getWrappedField();
        int int18 = offsetDateTimeField6.get(2440588L);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField6.getAsShortText((int) (short) 10, locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField6.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField23 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 101 + "'", int12 == 101);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 171 + "'", int18 == 171);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.monthOfYear();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.Period period5 = period3.minusYears(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.Period period11 = period3.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period3, periodType12, chronology13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone18 = iSOChronology15.getZone();
        org.joda.time.Period period19 = new org.joda.time.Period((-34990L), periodType12, (org.joda.time.Chronology) iSOChronology15);
        try {
            long long24 = iSOChronology15.getDateTimeMillis(6, 0, (int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-1640591999990L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2421599.1666667825d + "'", double1 == 2421599.1666667825d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.Object obj8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(obj8, periodType9, chronology10);
        org.joda.time.PeriodType periodType12 = periodType9.withSecondsRemoved();
        try {
            org.joda.time.Period period13 = new org.joda.time.Period((int) (short) -1, 206, 6, (int) (byte) 0, 0, 0, (int) (byte) 100, 200, periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            long long6 = gregorianChronology0.set(readablePartial4, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfMonth();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField5 = iSOChronology0.hours();
        long long8 = durationField5.subtract(31795199999L, (long) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31669199999L + "'", long8 == 31669199999L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) (short) 0);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType5 = periodType3.getFieldType((int) (short) 0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray6 = new org.joda.time.DurationFieldType[] { durationFieldType2, durationFieldType5 };
        try {
            org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.forFields(durationFieldTypeArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: PeriodType does not support fields: [years]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(durationFieldType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(durationFieldType5);
        org.junit.Assert.assertNotNull(durationFieldTypeArray6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        org.joda.time.Period period8 = period6.withYears((int) ' ');
        int int9 = period8.getMinutes();
        org.joda.time.Period period10 = period8.normalizedStandard();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType12 = periodType11.withDaysRemoved();
        org.joda.time.PeriodType periodType13 = periodType11.withMonthsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.hourOfDay();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology14.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.millisOfSecond();
        try {
            org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period10, periodType13, (org.joda.time.Chronology) iSOChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(171, 206, (int) 'a', (int) (short) 100, (int) (byte) -1, (int) 'a', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) (byte) 1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        int int12 = cachedDateTimeZone8.getOffset(readableInstant11);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone4.getOffset(readableInstant5);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology6);
        org.joda.time.Period period8 = period3.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period8.plusMinutes((int) '#');
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.monthOfYear();
        org.joda.time.DurationField durationField10 = gregorianChronology8.weeks();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) '4', periodType7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DurationField durationField12 = gregorianChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.monthOfYear();
        org.joda.time.Chronology chronology14 = gregorianChronology8.withUTC();
        org.joda.time.Period period15 = new org.joda.time.Period(0L, (long) 100, periodType2, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType18 = periodType16.getFieldType((int) (short) 0);
        int int19 = periodType2.indexOf(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType18, "+00:00");
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        int int7 = offsetDateTimeField5.getMaximumValue((long) 0);
        long long10 = offsetDateTimeField5.addWrapField(230400010L, (-52));
        long long12 = offsetDateTimeField5.roundCeiling((-1640591999990L));
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.monthOfYear();
        org.joda.time.DurationField durationField17 = gregorianChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray25 = new int[] { (byte) 1, 100, (short) 100 };
        int int26 = offsetDateTimeField20.getMinimumValue(readablePartial21, intArray25);
        try {
            int[] intArray28 = offsetDateTimeField5.add(readablePartial13, (int) (byte) 0, intArray25, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 11 for weekyearOfCentury must be in the range [101,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 200 + "'", int7 == 200);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1640591999990L) + "'", long10 == (-1640591999990L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1609632000001L) + "'", long12 == (-1609632000001L));
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 101 + "'", int26 == 101);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        long long18 = offsetDateTimeField5.add((long) (short) 10, (int) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32054400010L + "'", long18 == 32054400010L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        long long63 = dividedDateTimeField59.add(28800100L, (int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 28800100L + "'", long63 == 28800100L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        int int20 = period19.getMonths();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("1", (int) (short) -1, (int) (byte) -1, 0, 'a', (int) (byte) 10, (int) (short) 100, (int) (short) -1, false, (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        int int8 = fixedDateTimeZone4.getOffset(31824000000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("10");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, (int) (byte) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PT0S", 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("", (int) (byte) -1, (-2440588), 171, '#', 97, (int) '4', 6, false, (-2440588));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        long long4 = dateTimeZone1.convertLocalToUTC(230400010L, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 230400010L + "'", long4 == 230400010L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Period period16 = period14.minusYears(0);
        org.joda.time.Period period17 = period11.withFields((org.joda.time.ReadablePeriod) period14);
        org.joda.time.PeriodType periodType18 = period17.getPeriodType();
        java.lang.Object obj19 = null;
        boolean boolean20 = periodType18.equals(obj19);
        org.joda.time.Period period21 = new org.joda.time.Period((int) (byte) -1, 10, (int) (short) 1, 0, 206, (int) '4', (int) '#', (int) ' ', periodType18);
        try {
            org.joda.time.DurationFieldType durationFieldType23 = periodType18.getFieldType(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 171, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        long long15 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.monthOfYear();
        org.joda.time.DurationField durationField19 = gregorianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray27 = new int[] { (byte) 1, 100, (short) 100 };
        int int28 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray27);
        int int29 = offsetDateTimeField5.getMinimumValue(readablePartial16, intArray27);
        boolean boolean30 = offsetDateTimeField5.isSupported();
        java.lang.String str31 = offsetDateTimeField5.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 101 + "'", int28 == 101);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 101 + "'", int29 == 101);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str31.equals("DateTimeField[weekyearOfCentury]"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType3 = periodType0.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        try {
            long long25 = zonedChronology17.getDateTimeMillis((int) (short) 0, (int) '4', (int) (byte) 0, (int) (short) 0, 0, 10, 101);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(1);
        java.io.DataOutput dataOutput7 = null;
        try {
            dateTimeZoneBuilder5.writeTo("America/Los_Angeles", dataOutput7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset((long) (short) 10, false);
        int int5 = dateTimeZone0.getOffsetFromLocal(100L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.Period period1 = org.joda.time.Period.months(100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Period period1 = org.joda.time.Period.millis(97);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology6);
        org.joda.time.Period period8 = period3.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period10 = period7.withYears((int) (byte) -1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        try {
            long long22 = zonedChronology17.getDateTimeMillis((-52), (-2440588), (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2440588 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        java.lang.String str15 = offsetDateTimeField5.toString();
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.monthOfYear();
        org.joda.time.DurationField durationField23 = gregorianChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray31 = new int[] { (byte) 1, 100, (short) 100 };
        int int32 = offsetDateTimeField26.getMinimumValue(readablePartial27, intArray31);
        try {
            int[] intArray34 = offsetDateTimeField5.add(readablePartial19, (-1), intArray31, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str15.equals("DateTimeField[weekyearOfCentury]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 101 + "'", int32 == 101);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(52L, "10");
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset((long) (short) 10, false);
        java.lang.String str4 = dateTimeZone0.getID();
        java.lang.String str6 = dateTimeZone0.getShortName((long) 206);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0S" + "'", str4.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.001" + "'", str6.equals("+00:00:00.001"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "");
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        long long6 = dateTimeZone3.getMillisKeepLocal(dateTimeZone4, (long) (short) 100);
        org.joda.time.LocalDateTime localDateTime7 = null;
        boolean boolean8 = dateTimeZone3.isLocalDateTimeGap(localDateTime7);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        long long15 = dateTimeZone12.getMillisKeepLocal(dateTimeZone13, (long) (short) 100);
        long long17 = dateTimeZone3.getMillisKeepLocal(dateTimeZone12, (long) 0);
        long long20 = dateTimeZone3.adjustOffset((long) (byte) 10, true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 99L + "'", long6 == 99L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 99L + "'", long15 == 99L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField5.getAsText((long) (byte) 1, locale15);
        boolean boolean18 = offsetDateTimeField5.isLeap((long) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "171" + "'", str16.equals("171"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 230400097L, (java.lang.Number) 171, (java.lang.Number) (byte) -1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.Period period1 = org.joda.time.Period.millis(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.001", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.001/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusMillis((int) (short) 1);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusSeconds((int) (byte) 10);
        org.joda.time.Period period8 = period6.multipliedBy((int) (short) 1);
        org.joda.time.Period period10 = period6.minusMonths((int) (short) 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        long long22 = offsetDateTimeField5.roundHalfFloor((long) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200001L) + "'", long22 == (-259200001L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology0.getZone();
        long long5 = dateTimeZone3.convertUTCToLocal((long) (short) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("DateTimeField[weekyearOfCentury]", (java.lang.Number) (-230400000L), (java.lang.Number) 31824000000L, (java.lang.Number) 101L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology17.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.Period period1 = new org.joda.time.Period((-259200001L));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology2);
        org.joda.time.Period period5 = period3.plusYears((int) (byte) -1);
        try {
            org.joda.time.Days days6 = period5.toStandardDays();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        int int7 = offsetDateTimeField5.getMaximumValue((long) 0);
        long long10 = offsetDateTimeField5.addWrapField(230400010L, (-52));
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText(28800100L, locale12);
        long long16 = offsetDateTimeField5.addWrapField((long) '4', (int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 200 + "'", int7 == 200);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1640591999990L) + "'", long10 == (-1640591999990L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "171" + "'", str13.equals("171"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-94348799948L) + "'", long16 == (-94348799948L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        boolean boolean7 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str8 = illegalFieldValueException5.getFieldName();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Weeks weeks4 = period3.toStandardWeeks();
        org.joda.time.MutablePeriod mutablePeriod5 = period3.toMutablePeriod();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(weeks4);
        org.junit.Assert.assertNotNull(mutablePeriod5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology7);
        org.joda.time.Period period9 = period4.minus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType12 = periodType10.getFieldType((int) (short) 0);
        org.joda.time.Period period14 = period9.withField(durationFieldType12, (int) ' ');
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField15 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        org.joda.time.Seconds seconds10 = period9.toStandardSeconds();
        int int11 = period9.getMonths();
        org.joda.time.Period period13 = period9.plusMonths(0);
        int int14 = period13.getYears();
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(seconds10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Period period8 = period6.minusYears(0);
        org.joda.time.Period period9 = period3.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period11 = period6.minusDays((int) (byte) -1);
        org.joda.time.Period period13 = period11.plusMinutes((int) (short) 10);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((-1), 'a', 0, (int) '4', (int) (byte) 100, true, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("America/Los_Angeles", 97, 3, 0, '4', (int) (short) -1, (int) (byte) 10, (int) (short) 10, true, 0);
        java.io.DataOutput dataOutput24 = null;
        try {
            dateTimeZoneBuilder22.writeTo("10", dataOutput24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) '#');
        org.joda.time.Seconds seconds2 = period1.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(seconds2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology6);
        org.joda.time.Period period8 = period3.minus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType11 = periodType9.getFieldType((int) (short) 0);
        org.joda.time.Period period13 = period8.withField(durationFieldType11, (int) ' ');
        org.joda.time.Period period15 = period8.withHours(100);
        org.joda.time.PeriodType periodType16 = period15.getPeriodType();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long3 = dateTimeZone0.adjustOffset((long) (short) 10, false);
        java.lang.String str4 = dateTimeZone0.getID();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField6 = iSOChronology5.months();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0S" + "'", str4.equals("PT0S"));
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 59, "P32Y");
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder6.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("", true);
        java.lang.String str16 = dateTimeZone14.getShortName((long) ' ');
        long long18 = dateTimeZone9.getMillisKeepLocal(dateTimeZone14, (long) (short) 100);
        boolean boolean19 = fixedDateTimeZone4.equals((java.lang.Object) (short) 100);
        long long21 = fixedDateTimeZone4.nextTransition((long) '4');
        int int23 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        long long15 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.monthOfYear();
        org.joda.time.DurationField durationField19 = gregorianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray27 = new int[] { (byte) 1, 100, (short) 100 };
        int int28 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray27);
        int int29 = offsetDateTimeField5.getMinimumValue(readablePartial16, intArray27);
        long long31 = offsetDateTimeField5.roundCeiling((long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 101 + "'", int28 == 101);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 101 + "'", int29 == 101);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31795199999L + "'", long31 == 31795199999L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        long long7 = offsetDateTimeField5.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-259200001L) + "'", long7 == (-259200001L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        java.lang.String str15 = offsetDateTimeField5.toString();
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.monthOfYear();
        org.joda.time.DurationField durationField23 = gregorianChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray31 = new int[] { (byte) 1, 100, (short) 100 };
        int int32 = offsetDateTimeField26.getMinimumValue(readablePartial27, intArray31);
        try {
            int[] intArray34 = offsetDateTimeField5.addWrapField(readablePartial19, 1, intArray31, 101);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str15.equals("DateTimeField[weekyearOfCentury]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 101 + "'", int32 == 101);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology5.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology3 = gregorianChronology2.withUTC();
        org.joda.time.Period period4 = new org.joda.time.Period((-60001L), (long) (short) -1, chronology3);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("weekyearOfCentury", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        java.lang.String str1 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[Years]" + "'", str1.equals("PeriodType[Years]"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeZoneBuilder6.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("", true);
        java.lang.String str16 = dateTimeZone14.getShortName((long) ' ');
        long long18 = dateTimeZone9.getMillisKeepLocal(dateTimeZone14, (long) (short) 100);
        boolean boolean19 = fixedDateTimeZone4.equals((java.lang.Object) (short) 100);
        long long21 = fixedDateTimeZone4.nextTransition((long) '4');
        java.lang.String str22 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PT0S" + "'", str22.equals("PT0S"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = offsetDateTimeField5.getMinimumValue(readablePartial18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = offsetDateTimeField5.getAsShortText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 101 + "'", int19 == 101);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            long long12 = gregorianChronology5.set(readablePartial10, 206L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology2.millis();
        org.joda.time.Chronology chronology5 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeZoneBuilder7.toDateTimeZone("", true);
        java.lang.String str12 = dateTimeZone10.getShortName((long) ' ');
        boolean boolean14 = dateTimeZone10.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        java.lang.String str17 = cachedDateTimeZone15.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = cachedDateTimeZone15.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone18);
        org.joda.time.Chronology chronology20 = zonedChronology19.withUTC();
        org.joda.time.Period period21 = new org.joda.time.Period((long) '4', 230399999L, (org.joda.time.Chronology) zonedChronology19);
        org.joda.time.Chronology chronology22 = zonedChronology19.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00" + "'", str12.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 3);
        org.joda.time.Period period3 = period1.withWeeks((int) (byte) 0);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        long long22 = offsetDateTimeField5.roundCeiling((-230400000L));
        int int23 = offsetDateTimeField5.getMaximumValue();
        long long25 = offsetDateTimeField5.roundFloor(77017518492040587L);
        long long27 = offsetDateTimeField5.remainder(10L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 31795199999L + "'", long22 == 31795199999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 200 + "'", int23 == 200);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 77017518489599999L + "'", long25 == 77017518489599999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 259200011L + "'", long27 == 259200011L);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560628202472L + "'", long0 == 1560628202472L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("UTC", (java.lang.Number) (-1.0f), number2, (java.lang.Number) (-1.0d));
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((-1), 'a', 0, (int) '4', (int) (byte) 100, true, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("America/Los_Angeles", 97, 3, 0, '4', (int) (short) -1, (int) (byte) 10, (int) (short) 10, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder24);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) (-2440588));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField19 = gregorianChronology0.halfdays();
        org.joda.time.DurationField durationField20 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((-1), 'a', 0, (int) '4', (int) (byte) 100, true, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("America/Los_Angeles", 97, 3, 0, '4', (int) (short) -1, (int) (byte) 10, (int) (short) 10, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = dateTimeZoneBuilder0.setFixedSavings("PT0S", (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder25);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(0);
        int int2 = period1.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 206);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        try {
            long long25 = zonedChronology17.getDateTimeMillis((int) (byte) 0, 35, 171, (int) (byte) -1, (int) '4', 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        long long12 = dateTimeZone3.getMillisKeepLocal(dateTimeZone8, (long) (short) 100);
        int int14 = dateTimeZone3.getOffsetFromLocal(0L);
        long long16 = dateTimeZone3.convertUTCToLocal((long) (byte) 0);
        long long20 = dateTimeZone3.convertLocalToUTC((-1L), false, 28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        long long15 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.monthOfYear();
        org.joda.time.DurationField durationField19 = gregorianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray27 = new int[] { (byte) 1, 100, (short) 100 };
        int int28 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray27);
        int int29 = offsetDateTimeField5.getMinimumValue(readablePartial16, intArray27);
        long long32 = offsetDateTimeField5.getDifferenceAsLong((long) 0, (-230400000L));
        org.joda.time.ReadablePartial readablePartial33 = null;
        int[] intArray34 = null;
        int int35 = offsetDateTimeField5.getMaximumValue(readablePartial33, intArray34);
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.monthOfYear();
        org.joda.time.DurationField durationField40 = gregorianChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology38.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (byte) 100);
        int int45 = offsetDateTimeField43.getMaximumValue((long) 0);
        java.lang.String str47 = offsetDateTimeField43.getAsText(0L);
        org.joda.time.ReadablePartial readablePartial48 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.monthOfYear();
        org.joda.time.DurationField durationField51 = gregorianChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology49.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial55 = null;
        int[] intArray59 = new int[] { (byte) 1, 100, (short) 100 };
        int int60 = offsetDateTimeField54.getMinimumValue(readablePartial55, intArray59);
        int int61 = offsetDateTimeField43.getMaximumValue(readablePartial48, intArray59);
        try {
            int[] intArray63 = offsetDateTimeField5.addWrapField(readablePartial36, 1, intArray59, (-2440588));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 101 + "'", int28 == 101);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 101 + "'", int29 == 101);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 200 + "'", int35 == 200);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 200 + "'", int45 == 200);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "171" + "'", str47.equals("171"));
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 101 + "'", int60 == 101);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 200 + "'", int61 == 200);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField5.getType();
        java.lang.Number number24 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 1.0d, (java.lang.Number) 200, number24);
        java.lang.Number number26 = illegalFieldValueException25.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.0d + "'", number26.equals(1.0d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        long long22 = offsetDateTimeField5.roundCeiling((-230400000L));
        int int23 = offsetDateTimeField5.getMaximumValue();
        long long25 = offsetDateTimeField5.roundFloor(77017518492040587L);
        java.util.Locale locale28 = null;
        try {
            long long29 = offsetDateTimeField5.set((-1640591999990L), "weekyearOfCentury", locale28);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"weekyearOfCentury\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 31795199999L + "'", long22 == 31795199999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 200 + "'", int23 == 200);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 77017518489599999L + "'", long25 == 77017518489599999L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        try {
            long long37 = remainderDateTimeField28.set((long) 200, "hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.monthOfYear();
        org.joda.time.DurationField durationField35 = gregorianChronology33.weeks();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial39 = null;
        int[] intArray43 = new int[] { (byte) 1, 100, (short) 100 };
        int int44 = offsetDateTimeField38.getMinimumValue(readablePartial39, intArray43);
        org.joda.time.DateTimeField dateTimeField45 = offsetDateTimeField38.getWrappedField();
        long long47 = offsetDateTimeField38.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField38.getWrappedField();
        int int50 = offsetDateTimeField38.get(2440588L);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField38.getAsShortText((int) (short) 10, locale52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = offsetDateTimeField38.getType();
        org.joda.time.ReadablePartial readablePartial55 = null;
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField38.getAsText(readablePartial55, (-2440588), locale57);
        long long60 = offsetDateTimeField38.roundHalfFloor(32054399999L);
        org.joda.time.ReadablePartial readablePartial61 = null;
        org.joda.time.Period period63 = org.joda.time.Period.millis((-1));
        int[] intArray64 = period63.getValues();
        int int65 = offsetDateTimeField38.getMaximumValue(readablePartial61, intArray64);
        try {
            int[] intArray67 = remainderDateTimeField28.set(readablePartial31, (int) (short) 100, intArray64, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 101 + "'", int44 == 101);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-259200001L) + "'", long47 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 171 + "'", int50 == 171);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10" + "'", str53.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "-2440588" + "'", str58.equals("-2440588"));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 31795199999L + "'", long60 == 31795199999L);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 200 + "'", int65 == 200);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        java.util.Locale locale61 = null;
        int int62 = dividedDateTimeField59.getMaximumShortTextLength(locale61);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField59);
        java.lang.String str64 = dividedDateTimeField59.toString();
        int int65 = dividedDateTimeField59.getMinimumValue();
        try {
            long long68 = dividedDateTimeField59.set((-1609632000001L), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for weekyearOfCentury must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str64.equals("DateTimeField[weekyearOfCentury]"));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1024 + "'", int2 == 1024);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
        int int57 = offsetDateTimeField45.get(2440588L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
        long long66 = zeroIsMaxDateTimeField64.roundHalfFloor((long) 171);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200001L) + "'", long54 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-1L) + "'", long66 == (-1L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = offsetDateTimeField5.getMinimumValue(readablePartial21);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 101 + "'", int22 == 101);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.field.FieldUtils.verifyValueBounds("UTC", (int) 'a', (int) (short) 10, 101);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        try {
            int int11 = period9.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "+00:00");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        int int11 = period7.getMillis();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        java.lang.String str7 = period2.toString();
        org.joda.time.MutablePeriod mutablePeriod8 = period2.toMutablePeriod();
        java.lang.String str9 = mutablePeriod8.toString();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PT0S" + "'", str9.equals("PT0S"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale13);
        long long16 = offsetDateTimeField5.roundCeiling((-256759413L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31795199999L + "'", long16 == 31795199999L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getShortName((long) (short) 1, locale10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone(dateTimeZone8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        int int14 = dateTimeZone8.getOffset(readableInstant13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("hi!", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        org.joda.time.Seconds seconds10 = period9.toStandardSeconds();
        int int11 = period9.getMonths();
        try {
            org.joda.time.Period period13 = period9.plusMonths(6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(seconds10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P32Y");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "P32Y" + "'", str2.equals("P32Y"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "P32Y" + "'", str3.equals("P32Y"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("10");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        boolean boolean5 = jodaTimePermission1.equals((java.lang.Object) readableInterval4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.Period period4 = new org.joda.time.Period(171, (int) (byte) 100, 10, (int) 'a');
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560628207626L + "'", long1 == 1560628207626L);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.months();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((int) '#', (int) '4', 59, 0, (int) (short) -1, 0, 1, (int) '4', periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("P32Y", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        org.joda.time.Chronology chronology19 = iSOChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology13.weekyear();
        boolean boolean21 = cachedDateTimeZone12.equals((java.lang.Object) iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        int int13 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DurationField durationField14 = offsetDateTimeField5.getLeapDurationField();
        java.util.Locale locale17 = null;
        try {
            long long18 = offsetDateTimeField5.set((long) (short) 100, "weekyearOfCentury", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"weekyearOfCentury\" for weekyearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Period period8 = period6.minusYears(0);
        org.joda.time.Period period9 = period3.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period11 = period9.minusWeeks(200);
        int int12 = period11.getMonths();
        org.joda.time.Period period14 = org.joda.time.Period.millis((-1));
        int[] intArray15 = period14.getValues();
        org.joda.time.Minutes minutes16 = period14.toStandardMinutes();
        org.joda.time.Period period17 = period11.plus((org.joda.time.ReadablePeriod) period14);
        org.joda.time.Duration duration18 = period11.toStandardDuration();
        try {
            org.joda.time.DurationFieldType durationFieldType20 = period11.getFieldType(101);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 101");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(minutes16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(duration18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusSeconds((int) (byte) 10);
        org.joda.time.Period period8 = period6.multipliedBy((int) (short) 1);
        org.joda.time.Period period10 = period8.withWeeks((-52));
        org.joda.time.Period period12 = period10.withYears((int) (short) 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.years();
        org.joda.time.DurationField durationField3 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(0);
        org.joda.time.Period period3 = period1.multipliedBy((int) (short) 1);
        org.joda.time.Period period5 = period1.minusYears((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Period period9 = period8.negated();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology12);
        org.joda.time.Period period14 = period9.minus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType17 = periodType15.getFieldType((int) (short) 0);
        org.joda.time.Period period19 = period14.withField(durationFieldType17, (int) ' ');
        int int20 = period5.indexOf(durationFieldType17);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1, 6682);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 6682");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(24405L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("10");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"10\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"10\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"10\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"10\")"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(0);
        org.joda.time.Period period3 = period1.multipliedBy((int) (short) 1);
        org.joda.time.Period period5 = period1.minusYears((int) (byte) 10);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period5.isSupported(durationFieldType6);
        int int8 = period5.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) (-1L));
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(12622780800097L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.yearOfEra();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.minuteOfHour();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        java.lang.Class<?> wildcardClass11 = gregorianChronology5.getClass();
        org.joda.time.DurationField durationField12 = gregorianChronology5.millis();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((-1), 'a', 0, (int) '4', (int) (byte) 100, true, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("America/Los_Angeles", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder11.setStandardOffset((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType8 = periodType7.withDaysRemoved();
        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
        org.joda.time.Period period10 = period2.withPeriodType(periodType7);
        org.joda.time.format.PeriodFormatter periodFormatter11 = null;
        java.lang.String str12 = period2.toString(periodFormatter11);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PT0S" + "'", str12.equals("PT0S"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("-2440588", (-52), (int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -52 for -2440588 must be in the range [0,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.Period period1 = org.joda.time.Period.days(1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
        int int57 = offsetDateTimeField45.get(2440588L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
        long long66 = zeroIsMaxDateTimeField64.roundHalfFloor((-210866760000001L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60000L) + "'", long30 == (-60000L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230400000L + "'", long32 == 230400000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200000L) + "'", long54 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-210866760000000L) + "'", long66 == (-210866760000000L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) ' ');
        int int12 = cachedDateTimeZone8.getStandardOffset(28800100L);
        org.joda.time.LocalDateTime localDateTime13 = null;
        boolean boolean14 = cachedDateTimeZone8.isLocalDateTimeGap(localDateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int62 = dividedDateTimeField59.getDifference((long) 0, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200000L) + "'", long48 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Chronology chronology12 = gregorianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology5.yearOfEra();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
        int int57 = offsetDateTimeField45.get(2440588L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
        int int65 = remainderDateTimeField28.getDivisor();
        org.joda.time.ReadablePartial readablePartial66 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology67.monthOfYear();
        org.joda.time.DurationField durationField69 = gregorianChronology67.weeks();
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology67.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField(dateTimeField70, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial73 = null;
        int[] intArray77 = new int[] { (byte) 1, 100, (short) 100 };
        int int78 = offsetDateTimeField72.getMinimumValue(readablePartial73, intArray77);
        org.joda.time.DateTimeField dateTimeField79 = offsetDateTimeField72.getWrappedField();
        boolean boolean80 = offsetDateTimeField72.isLenient();
        long long82 = offsetDateTimeField72.roundHalfFloor((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial83 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology84 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField85 = gregorianChronology84.monthOfYear();
        org.joda.time.DurationField durationField86 = gregorianChronology84.weeks();
        org.joda.time.DateTimeField dateTimeField87 = gregorianChronology84.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField89 = new org.joda.time.field.OffsetDateTimeField(dateTimeField87, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial90 = null;
        int[] intArray94 = new int[] { (byte) 1, 100, (short) 100 };
        int int95 = offsetDateTimeField89.getMinimumValue(readablePartial90, intArray94);
        int int96 = offsetDateTimeField72.getMinimumValue(readablePartial83, intArray94);
        int int97 = remainderDateTimeField28.getMinimumValue(readablePartial66, intArray94);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60000L) + "'", long30 == (-60000L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230400000L + "'", long32 == 230400000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200000L) + "'", long54 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 101 + "'", int78 == 101);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-259200000L) + "'", long82 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology84);
        org.junit.Assert.assertNotNull(dateTimeField85);
        org.junit.Assert.assertNotNull(durationField86);
        org.junit.Assert.assertNotNull(dateTimeField87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 101 + "'", int95 == 101);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 101 + "'", int96 == 101);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        long long62 = dividedDateTimeField59.remainder((long) 1);
        long long64 = dividedDateTimeField59.roundHalfCeiling((-230400000L));
        try {
            long long67 = dividedDateTimeField59.addWrapField(36L, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200000L) + "'", long48 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1L + "'", long62 == 1L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-230400000L) + "'", long64 == (-230400000L));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(7701751836777600100L, (-210866760000001L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7701962703537600101L + "'", long2 == 7701962703537600101L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) (-230400001L), periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long33 = remainderDateTimeField28.addWrapField((-1L), (int) (byte) 0);
        org.joda.time.DurationField durationField34 = remainderDateTimeField28.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60000L) + "'", long30 == (-60000L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
        int int57 = offsetDateTimeField45.get(2440588L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
        int int65 = remainderDateTimeField28.getDivisor();
        int int66 = remainderDateTimeField28.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60000L) + "'", long30 == (-60000L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230400000L + "'", long32 == 230400000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200000L) + "'", long54 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale62 = null;
        try {
            java.lang.String str63 = dividedDateTimeField59.getAsText(readablePartial61, locale62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200000L) + "'", long48 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        long long22 = offsetDateTimeField5.roundCeiling((-230400000L));
        int int23 = offsetDateTimeField5.getMaximumValue();
        long long26 = offsetDateTimeField5.addWrapField((long) (short) -1, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 31795200000L + "'", long22 == 31795200000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 200 + "'", int23 == 200);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withYearsRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType5);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT0S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundCeiling(0L);
        long long32 = remainderDateTimeField28.roundHalfEven(35L);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int[] intArray35 = null;
        try {
            int[] intArray37 = remainderDateTimeField28.addWrapField(readablePartial33, 100, intArray35, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("171");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.monthOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.monthOfYear();
        org.joda.time.DurationField durationField9 = gregorianChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray17 = new int[] { (byte) 1, 100, (short) 100 };
        int int18 = offsetDateTimeField12.getMinimumValue(readablePartial13, intArray17);
        org.joda.time.DateTimeField dateTimeField19 = offsetDateTimeField12.getWrappedField();
        long long21 = offsetDateTimeField12.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField22 = offsetDateTimeField12.getWrappedField();
        int int24 = offsetDateTimeField12.get(2440588L);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField12.getAsShortText((int) (short) 10, locale26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField12.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType28, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.monthOfYear();
        org.joda.time.DurationField durationField33 = gregorianChronology31.weeks();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology31.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology31.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.monthOfYear();
        org.joda.time.DurationField durationField38 = gregorianChronology36.weeks();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray46 = new int[] { (byte) 1, 100, (short) 100 };
        int int47 = offsetDateTimeField41.getMinimumValue(readablePartial42, intArray46);
        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField41.getWrappedField();
        long long50 = offsetDateTimeField41.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField51 = offsetDateTimeField41.getWrappedField();
        int int53 = offsetDateTimeField41.get(2440588L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField41.getAsShortText((int) (short) 10, locale55);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = offsetDateTimeField41.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dateTimeField35, dateTimeFieldType57, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField30, dateTimeFieldType57, (int) (short) 100);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeFieldType57);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 101 + "'", int18 == 101);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-259200000L) + "'", long21 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 171 + "'", int24 == 171);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10" + "'", str27.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 101 + "'", int47 == 101);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-259200000L) + "'", long50 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 171 + "'", int53 == 171);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology5.weekOfWeekyear();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Period period8 = period6.minusYears(0);
        org.joda.time.Period period9 = period3.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.PeriodType periodType10 = period9.getPeriodType();
        try {
            org.joda.time.DurationFieldType durationFieldType12 = periodType10.getFieldType((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period2, periodType11, chronology12);
        org.joda.time.PeriodType periodType14 = periodType11.withWeeksRemoved();
        java.lang.String str15 = periodType14.toString();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PeriodType[Hours]" + "'", str15.equals("PeriodType[Hours]"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        int int63 = dividedDateTimeField59.getDifference(52L, (long) 206);
        try {
            long long66 = dividedDateTimeField59.add(600000000L, 7701962703537600101L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -4566980742041157772 * 60000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200000L) + "'", long48 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Period period5 = period3.minusHours(4);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType6 = periodType5.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.monthOfYear();
        org.joda.time.DurationField durationField10 = gregorianChronology8.weeks();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, (long) '4', periodType7, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DurationField durationField12 = gregorianChronology8.centuries();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.monthOfYear();
        org.joda.time.Chronology chronology14 = gregorianChronology8.withUTC();
        org.joda.time.Period period15 = new org.joda.time.Period(0L, (long) 100, periodType2, (org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology8.weekyearOfCentury();
        org.joda.time.DurationField durationField17 = gregorianChronology8.halfdays();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Period period8 = period6.minusYears(0);
        org.joda.time.Period period9 = period3.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period11 = period6.withYears(4);
        int int12 = period11.getWeeks();
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        long long63 = dividedDateTimeField59.add((long) 101, (long) 0);
        long long66 = dividedDateTimeField59.add(0L, 36L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200000L) + "'", long48 == (-259200000L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 101L + "'", long63 == 101L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 216000000L + "'", long66 == 216000000L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            long long4 = gregorianChronology0.set(readablePartial2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        int int10 = cachedDateTimeZone8.getOffsetFromLocal((long) (byte) 100);
        int int12 = cachedDateTimeZone8.getOffset(52L);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        org.joda.time.Period period10 = period9.toPeriod();
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearWeekDayTime();
        boolean boolean7 = lenientChronology5.equals((java.lang.Object) periodType6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 100, 101);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10100L + "'", long2 == 10100L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.Period period6 = period5.negated();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology9);
        org.joda.time.Period period11 = period6.minus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        org.joda.time.Period period16 = period11.withField(durationFieldType14, (int) ' ');
        org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType14);
        long long19 = decoratedDurationField17.getMillis((long) 3);
        org.joda.time.DurationFieldType durationFieldType20 = decoratedDurationField17.getType();
        long long22 = decoratedDurationField17.getValueAsLong(77017518489599999L);
        int int24 = decoratedDurationField17.getValue((long) (short) 0);
        long long27 = decoratedDurationField17.add(32054399999L, (long) 6);
        long long30 = decoratedDurationField17.getMillis((int) (short) 1, 0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9467085600000L + "'", long19 == 9467085600000L);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24405L + "'", long22 == 24405L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 18966268799999L + "'", long27 == 18966268799999L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 3155760000000L + "'", long30 == 3155760000000L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone8.getUncachedZone();
        long long13 = cachedDateTimeZone8.previousTransition((long) (byte) 10);
        int int15 = cachedDateTimeZone8.getOffset(31795199999L);
        long long17 = cachedDateTimeZone8.nextTransition((-34990L));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-34990L) + "'", long17 == (-34990L));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.Period period5 = period3.minusYears(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.Period period11 = period3.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period3, periodType12, chronology13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone18 = iSOChronology15.getZone();
        org.joda.time.Period period19 = new org.joda.time.Period((-34990L), periodType12, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.DurationField durationField20 = iSOChronology15.seconds();
        long long23 = durationField20.subtract(32054400010L, 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 32054400010L + "'", long23 == 32054400010L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(obj0, periodType1, chronology2);
        org.joda.time.Weeks weeks4 = period3.toStandardWeeks();
        try {
            org.joda.time.Period period6 = period3.plusMillis(206);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(weeks4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7);
        int int9 = period8.getMillis();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        org.joda.time.Period period8 = period6.withYears((int) ' ');
        org.joda.time.Period period10 = period8.minusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.Period period15 = period13.minusYears(0);
        org.joda.time.Period period17 = period13.minusMonths(0);
        org.joda.time.Period period19 = period17.withYears((int) ' ');
        org.joda.time.Period period20 = period8.withFields((org.joda.time.ReadablePeriod) period17);
        org.joda.time.Period period22 = period8.withYears(206);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfMonth();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField5 = iSOChronology0.hours();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology6.millis();
        org.joda.time.Chronology chronology9 = gregorianChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder11.toDateTimeZone("", true);
        java.lang.String str16 = dateTimeZone14.getShortName((long) ' ');
        boolean boolean18 = dateTimeZone14.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        java.lang.String str21 = cachedDateTimeZone19.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone19.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone22);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone27 = dateTimeZoneBuilder24.toDateTimeZone("", true);
        java.lang.String str29 = dateTimeZone27.getShortName((long) ' ');
        boolean boolean31 = dateTimeZone27.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone27);
        java.lang.String str34 = cachedDateTimeZone32.getNameKey((long) (byte) 1);
        org.joda.time.Chronology chronology35 = zonedChronology23.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone32);
        boolean boolean37 = cachedDateTimeZone32.isStandardOffset((long) 6682);
        org.joda.time.Chronology chronology38 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone32);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00" + "'", str16.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "UTC" + "'", str21.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00" + "'", str29.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "UTC" + "'", str34.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(chronology38);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Period period7 = period6.negated();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology10);
        org.joda.time.Period period12 = period7.minus((org.joda.time.ReadablePeriod) period11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType15 = periodType13.getFieldType((int) (short) 0);
        org.joda.time.Period period17 = period12.withField(durationFieldType15, (int) ' ');
        int int18 = period3.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, "");
        java.lang.String str21 = illegalFieldValueException20.toString();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6682 + "'", int18 == 6682);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for years is not supported" + "'", str21.equals("org.joda.time.IllegalFieldValueException: Value \"\" for years is not supported"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType5 = periodType4.withSecondsRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.monthOfYear();
        org.joda.time.DurationField durationField9 = gregorianChronology7.weeks();
        org.joda.time.Period period10 = new org.joda.time.Period(0L, (long) '4', periodType6, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DurationField durationField11 = gregorianChronology7.centuries();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.monthOfYear();
        org.joda.time.Chronology chronology13 = gregorianChronology7.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology7.secondOfDay();
        org.joda.time.Period period15 = new org.joda.time.Period((long) 3, (long) (short) -1, (org.joda.time.Chronology) gregorianChronology7);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period2, periodType11, chronology12);
        int int14 = periodType11.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        org.joda.time.Seconds seconds10 = period9.toStandardSeconds();
        int int11 = period9.getMonths();
        org.joda.time.Period period13 = period9.plusMonths(0);
        org.joda.time.Duration duration14 = period9.toStandardDuration();
        org.joda.time.Period period16 = period9.plusMinutes((int) (byte) 0);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(seconds10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.withWeeks(206);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 3);
        org.joda.time.Period period7 = period4.withFields((org.joda.time.ReadablePeriod) period6);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, 206, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.centuries();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) gregorianChronology18);
        org.joda.time.DurationField durationField22 = zonedChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.yearOfCentury();
        boolean boolean25 = zonedChronology17.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str7 = illegalFieldValueException5.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException5.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value \"\" for +00:00 is not supported"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number7 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.centuries();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) gregorianChronology18);
        try {
            long long27 = zonedChronology17.getDateTimeMillis((long) (byte) 10, 10, (-2440588), 6, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2440588 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
//        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        boolean boolean13 = offsetDateTimeField5.isLenient();
//        long long15 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.monthOfYear();
//        org.joda.time.DurationField durationField19 = gregorianChronology17.weeks();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        int[] intArray27 = new int[] { (byte) 1, 100, (short) 100 };
//        int int28 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray27);
//        int int29 = offsetDateTimeField5.getMinimumValue(readablePartial16, intArray27);
//        boolean boolean30 = offsetDateTimeField5.isSupported();
//        org.joda.time.DurationField durationField31 = offsetDateTimeField5.getRangeDurationField();
//        java.util.Locale locale32 = null;
//        int int33 = offsetDateTimeField5.getMaximumTextLength(locale32);
//        long long36 = offsetDateTimeField5.add((-256759413L), 2440588L);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = offsetDateTimeField5.getAsShortText(readablePartial37, (int) (byte) 10, locale39);
//        long long42 = offsetDateTimeField5.roundCeiling((long) (short) -1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 101 + "'", int28 == 101);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 101 + "'", int29 == 101);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 77017518492040587L + "'", long36 == 77017518492040587L);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 31795199999L + "'", long42 == 31795199999L);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
//        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        boolean boolean13 = offsetDateTimeField5.isLenient();
//        long long15 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
//        java.lang.String str16 = offsetDateTimeField5.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "weekyearOfCentury" + "'", str16.equals("weekyearOfCentury"));
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTimeZone3.getShortName(31824000000L, locale7);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusSeconds((int) (byte) 10);
        org.joda.time.Period period8 = period6.multipliedBy((int) (short) 1);
        org.joda.time.Period period10 = period8.withWeeks((-52));
        org.joda.time.Period period12 = period8.minusMinutes(3);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType16 = periodType15.withDaysRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekyearOfCentury();
        org.joda.time.DurationField durationField19 = gregorianChronology17.millis();
        org.joda.time.Chronology chronology20 = gregorianChronology17.withUTC();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology17.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeZoneBuilder22.toDateTimeZone("", true);
        java.lang.String str27 = dateTimeZone25.getShortName((long) ' ');
        boolean boolean29 = dateTimeZone25.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone30 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone25);
        java.lang.String str32 = cachedDateTimeZone30.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone33 = cachedDateTimeZone30.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone33);
        java.lang.Class<?> wildcardClass35 = gregorianChronology17.getClass();
        org.joda.time.Period period36 = new org.joda.time.Period(32054399999L, (long) (byte) 100, periodType16, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.Period period37 = period8.normalizedStandard(periodType16);
        try {
            org.joda.time.DurationFieldType durationFieldType39 = periodType16.getFieldType((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UTC" + "'", str32.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(period37);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.weeks((-1));
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period8 = period4.minusYears((int) '4');
        long long11 = iSOChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (-1), 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeZoneBuilder12.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.Chronology chronology17 = iSOChronology0.withZone(dateTimeZone16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone16.getName(6000097L, locale19);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00" + "'", str20.equals("+00:00"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.Period period5 = period3.minusYears(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.Period period11 = period3.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period3, periodType12, chronology13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone18 = iSOChronology15.getZone();
        org.joda.time.Period period19 = new org.joda.time.Period((-34990L), periodType12, (org.joda.time.Chronology) iSOChronology15);
        try {
            org.joda.time.Period period21 = period19.withYears(100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PT0S", (int) 'a', (int) '4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for PT0S must be in the range [52,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        java.lang.Class<?> wildcardClass2 = periodType1.getClass();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("+00:00:00.001", (java.lang.Number) 171, (java.lang.Number) (-94348799948L), (java.lang.Number) 10.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period2, periodType11, chronology12);
        int int14 = period2.getSeconds();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
//        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        boolean boolean13 = offsetDateTimeField5.isLenient();
//        long long15 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.monthOfYear();
//        org.joda.time.DurationField durationField19 = gregorianChronology17.weeks();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        int[] intArray27 = new int[] { (byte) 1, 100, (short) 100 };
//        int int28 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray27);
//        int int29 = offsetDateTimeField5.getMinimumValue(readablePartial16, intArray27);
//        boolean boolean30 = offsetDateTimeField5.isSupported();
//        org.joda.time.DurationField durationField31 = offsetDateTimeField5.getRangeDurationField();
//        java.util.Locale locale32 = null;
//        int int33 = offsetDateTimeField5.getMaximumTextLength(locale32);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField5.getAsText((-230400000L), locale35);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        org.joda.time.ReadableDuration readableDuration39 = null;
//        org.joda.time.ReadableInstant readableInstant40 = null;
//        org.joda.time.Period period41 = new org.joda.time.Period(readableDuration39, readableInstant40);
//        org.joda.time.Period period43 = period41.minusYears(0);
//        org.joda.time.Period period45 = period41.minusMonths(0);
//        java.lang.String str46 = period41.toString();
//        org.joda.time.MutablePeriod mutablePeriod47 = period41.toMutablePeriod();
//        org.joda.time.ReadableDuration readableDuration48 = null;
//        org.joda.time.ReadableInstant readableInstant49 = null;
//        org.joda.time.Period period50 = new org.joda.time.Period(readableDuration48, readableInstant49);
//        org.joda.time.Period period52 = period50.minusYears(0);
//        org.joda.time.Period period54 = period50.minusMonths(0);
//        java.lang.String str55 = period50.toString();
//        org.joda.time.Period period56 = period41.withFields((org.joda.time.ReadablePeriod) period50);
//        int[] intArray57 = period41.getValues();
//        try {
//            int[] intArray59 = offsetDateTimeField5.set(readablePartial37, 6682, intArray57, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekyearOfCentury must be in the range [101,200]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 101 + "'", int28 == 101);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 101 + "'", int29 == 101);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "171" + "'", str36.equals("171"));
//        org.junit.Assert.assertNotNull(period43);
//        org.junit.Assert.assertNotNull(period45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "PT0S" + "'", str46.equals("PT0S"));
//        org.junit.Assert.assertNotNull(mutablePeriod47);
//        org.junit.Assert.assertNotNull(period52);
//        org.junit.Assert.assertNotNull(period54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "PT0S" + "'", str55.equals("PT0S"));
//        org.junit.Assert.assertNotNull(period56);
//        org.junit.Assert.assertNotNull(intArray57);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
//        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
//        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
//        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
//        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
//        int int22 = offsetDateTimeField10.get(2440588L);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
//        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
//        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
//        long long34 = remainderDateTimeField28.remainder(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
//        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
//        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial46 = null;
//        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
//        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
//        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
//        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
//        int int57 = offsetDateTimeField45.get(2440588L);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
//        long long67 = zeroIsMaxDateTimeField64.add((long) 'a', (int) (short) 100);
//        long long70 = zeroIsMaxDateTimeField64.add(230400000L, 59999L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200001L) + "'", long54 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 6000097L + "'", long67 == 6000097L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 3830340000L + "'", long70 == 3830340000L);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "America/Los_Angeles");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.Period period4 = new org.joda.time.Period(97, 97, 0, 3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        long long12 = dateTimeZone3.getMillisKeepLocal(dateTimeZone8, (long) (short) 100);
        java.lang.String str13 = dateTimeZone8.getID();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-256759413L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440585L + "'", long1 == 2440585L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        try {
            long long8 = iSOChronology0.getDateTimeMillis(259200102L, (int) (byte) 10, 3, (-1), 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekOfWeekyear();
        long long7 = iSOChronology0.add((long) '4', 12622780800097L, (int) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) 0, 20000L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.centuries();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) gregorianChronology18);
        org.joda.time.DurationField durationField22 = zonedChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.yearOfCentury();
        try {
            long long28 = zonedChronology17.getDateTimeMillis(301, 6, 200, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00" + "'", str8.equals("+00:00"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = gregorianChronology0.get(readablePartial2, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyearOfCentury();
        org.joda.time.DurationField durationField6 = gregorianChronology4.millis();
        org.joda.time.Chronology chronology7 = gregorianChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology4.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", true);
        java.lang.String str14 = dateTimeZone12.getShortName((long) ' ');
        boolean boolean16 = dateTimeZone12.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        java.lang.String str19 = cachedDateTimeZone17.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone17.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, dateTimeZone20);
        java.lang.Class<?> wildcardClass22 = gregorianChronology4.getClass();
        org.joda.time.Period period23 = new org.joda.time.Period(32054399999L, (long) (byte) 100, periodType3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology4.weekyearOfCentury();
        int int25 = gregorianChronology4.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(2440585L, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 126910420L + "'", long2 == 126910420L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (int) (short) -1, 35, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) -1, chronology1);
        int int3 = period2.getMinutes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
//        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
//        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
//        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
//        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
//        int int22 = offsetDateTimeField10.get(2440588L);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
//        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
//        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
//        long long34 = remainderDateTimeField28.remainder(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
//        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
//        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial46 = null;
//        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
//        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
//        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
//        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
//        int int57 = offsetDateTimeField45.get(2440588L);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
//        long long66 = zeroIsMaxDateTimeField64.roundCeiling((long) (byte) -1);
//        long long68 = zeroIsMaxDateTimeField64.remainder(10L);
//        long long71 = zeroIsMaxDateTimeField64.add((-259200001L), 32054399999L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200001L) + "'", long54 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-1L) + "'", long66 == (-1L));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 11L + "'", long68 == 11L);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1923263740739999L + "'", long71 == 1923263740739999L);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) ' ', 1024, (int) (short) -1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder5.setStandardOffset((-52));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder7.addCutover((int) ' ', 'a', 3, 3, (int) '#', true, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        java.lang.String str8 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
//        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
//        int int13 = offsetDateTimeField5.getLeapAmount(100L);
//        int int15 = offsetDateTimeField5.get((long) 171);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.monthOfYear();
//        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        int[] intArray26 = new int[] { (byte) 1, 100, (short) 100 };
//        int int27 = offsetDateTimeField21.getMinimumValue(readablePartial22, intArray26);
//        org.joda.time.DateTimeField dateTimeField28 = offsetDateTimeField21.getWrappedField();
//        long long30 = offsetDateTimeField21.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField21.getWrappedField();
//        int int33 = offsetDateTimeField21.get(2440588L);
//        java.util.Locale locale35 = null;
//        java.lang.String str36 = offsetDateTimeField21.getAsShortText((int) (short) 10, locale35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField21.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType37, 200);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = offsetDateTimeField39.getMinimumValue(readablePartial40);
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        java.util.Locale locale43 = null;
//        try {
//            java.lang.String str44 = offsetDateTimeField39.getAsText(readablePartial42, locale43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 171 + "'", int15 == 171);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 101 + "'", int27 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-259200001L) + "'", long30 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 171 + "'", int33 == 171);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 301 + "'", int41 == 301);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfMonth();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology3);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period4.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = period7.getPeriodType();
        org.joda.time.PeriodType periodType12 = periodType11.withMonthsRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(31795200000L, periodType11);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
//        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
//        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
//        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
//        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
//        int int22 = offsetDateTimeField10.get(2440588L);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
//        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
//        long long33 = remainderDateTimeField28.addWrapField((-1L), (int) (byte) 0);
//        int int34 = remainderDateTimeField28.getMinimumValue();
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
//        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
//        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
//        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial46 = null;
//        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
//        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
//        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
//        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
//        int int57 = offsetDateTimeField45.get(2440588L);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology64.monthOfYear();
//        org.joda.time.DurationField durationField66 = gregorianChronology64.weeks();
//        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology64.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology64.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology69.monthOfYear();
//        org.joda.time.DurationField durationField71 = gregorianChronology69.weeks();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology69.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial75 = null;
//        int[] intArray79 = new int[] { (byte) 1, 100, (short) 100 };
//        int int80 = offsetDateTimeField74.getMinimumValue(readablePartial75, intArray79);
//        org.joda.time.DateTimeField dateTimeField81 = offsetDateTimeField74.getWrappedField();
//        long long83 = offsetDateTimeField74.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField84 = offsetDateTimeField74.getWrappedField();
//        int int86 = offsetDateTimeField74.get(2440588L);
//        java.util.Locale locale88 = null;
//        java.lang.String str89 = offsetDateTimeField74.getAsShortText((int) (short) 10, locale88);
//        org.joda.time.DateTimeFieldType dateTimeFieldType90 = offsetDateTimeField74.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField92 = new org.joda.time.field.RemainderDateTimeField(dateTimeField68, dateTimeFieldType90, (int) (byte) 100);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField94 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField63, dateTimeFieldType90, (int) (short) 100);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException96 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType90, "100");
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField98 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType90, 3);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(gregorianChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200001L) + "'", long54 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertNotNull(gregorianChronology64);
//        org.junit.Assert.assertNotNull(dateTimeField65);
//        org.junit.Assert.assertNotNull(durationField66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(dateTimeField68);
//        org.junit.Assert.assertNotNull(gregorianChronology69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(durationField71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 101 + "'", int80 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-259200001L) + "'", long83 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField84);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 171 + "'", int86 == 171);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "10" + "'", str89.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType90);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
//        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
//        org.joda.time.DurationField durationField15 = offsetDateTimeField5.getLeapDurationField();
//        long long17 = offsetDateTimeField5.remainder(101L);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.monthOfYear();
//        org.joda.time.DurationField durationField21 = gregorianChronology19.weeks();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        int[] intArray29 = new int[] { (byte) 1, 100, (short) 100 };
//        int int30 = offsetDateTimeField24.getMinimumValue(readablePartial25, intArray29);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField24.getWrappedField();
//        long long33 = offsetDateTimeField24.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField34 = offsetDateTimeField24.getWrappedField();
//        int int36 = offsetDateTimeField24.get(2440588L);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField24.getAsShortText((int) (short) 10, locale38);
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField24.getType();
//        org.joda.time.ReadablePartial readablePartial41 = null;
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField24.getAsText(readablePartial41, (-2440588), locale43);
//        long long46 = offsetDateTimeField24.roundHalfFloor(32054399999L);
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        org.joda.time.Period period49 = org.joda.time.Period.millis((-1));
//        int[] intArray50 = period49.getValues();
//        int int51 = offsetDateTimeField24.getMaximumValue(readablePartial47, intArray50);
//        int int52 = offsetDateTimeField5.getMinimumValue(readablePartial18, intArray50);
//        boolean boolean54 = offsetDateTimeField5.isLeap((long) 59);
//        int int55 = offsetDateTimeField5.getOffset();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
//        org.junit.Assert.assertNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 259200102L + "'", long17 == 259200102L);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(intArray29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 101 + "'", int30 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-259200001L) + "'", long33 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 171 + "'", int36 == 171);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-2440588" + "'", str44.equals("-2440588"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 31795199999L + "'", long46 == 31795199999L);
//        org.junit.Assert.assertNotNull(period49);
//        org.junit.Assert.assertNotNull(intArray50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 200 + "'", int51 == 200);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 101 + "'", int52 == 101);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 100 + "'", int55 == 100);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        org.joda.time.Seconds seconds10 = period9.toStandardSeconds();
        int int11 = period9.getMonths();
        org.joda.time.Period period13 = period9.plusMonths(0);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(seconds10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        long long14 = cachedDateTimeZone12.nextTransition(0L);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(0);
        org.joda.time.Period period3 = period1.multipliedBy((int) (short) 1);
        org.joda.time.Period period5 = period1.plusWeeks((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) period1, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.year();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
//        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
//        java.lang.String str16 = offsetDateTimeField5.getAsText(6000097L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "171" + "'", str16.equals("171"));
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        org.joda.time.Seconds seconds10 = period9.toStandardSeconds();
        int int11 = period9.getMonths();
        try {
            org.joda.time.Period period13 = period9.minusMinutes(1560628202);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(seconds10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
//        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        boolean boolean13 = offsetDateTimeField5.isLenient();
//        long long15 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.monthOfYear();
//        org.joda.time.DurationField durationField19 = gregorianChronology17.weeks();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        int[] intArray27 = new int[] { (byte) 1, 100, (short) 100 };
//        int int28 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray27);
//        int int29 = offsetDateTimeField5.getMinimumValue(readablePartial16, intArray27);
//        boolean boolean30 = offsetDateTimeField5.isSupported();
//        org.joda.time.DurationField durationField31 = offsetDateTimeField5.getRangeDurationField();
//        org.joda.time.DurationField durationField32 = offsetDateTimeField5.getLeapDurationField();
//        org.joda.time.DurationField durationField33 = offsetDateTimeField5.getRangeDurationField();
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.monthOfYear();
//        org.joda.time.DurationField durationField38 = gregorianChronology36.weeks();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        int[] intArray46 = new int[] { (byte) 1, 100, (short) 100 };
//        int int47 = offsetDateTimeField41.getMinimumValue(readablePartial42, intArray46);
//        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField41.getWrappedField();
//        long long50 = offsetDateTimeField41.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField51 = offsetDateTimeField41.getWrappedField();
//        int int53 = offsetDateTimeField41.get(2440588L);
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = offsetDateTimeField41.getAsShortText((int) (short) 10, locale55);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = offsetDateTimeField41.getType();
//        org.joda.time.ReadablePartial readablePartial58 = null;
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = offsetDateTimeField41.getAsText(readablePartial58, (-2440588), locale60);
//        long long63 = offsetDateTimeField41.roundHalfFloor(32054399999L);
//        org.joda.time.ReadablePartial readablePartial64 = null;
//        org.joda.time.Period period66 = org.joda.time.Period.millis((-1));
//        int[] intArray67 = period66.getValues();
//        int int68 = offsetDateTimeField41.getMaximumValue(readablePartial64, intArray67);
//        try {
//            int[] intArray70 = offsetDateTimeField5.addWrapPartial(readablePartial34, 206, intArray67, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 206");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(intArray27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 101 + "'", int28 == 101);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 101 + "'", int29 == 101);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNull(durationField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 101 + "'", int47 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-259200001L) + "'", long50 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 171 + "'", int53 == 171);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "-2440588" + "'", str61.equals("-2440588"));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 31795199999L + "'", long63 == 31795199999L);
//        org.junit.Assert.assertNotNull(period66);
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 200 + "'", int68 == 200);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        java.lang.Object obj2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.days();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(obj2, periodType3, chronology4);
        org.joda.time.PeriodType periodType6 = periodType3.withSecondsRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType3);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        org.joda.time.Chronology chronology11 = gregorianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology5.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 4);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.Period period5 = period3.minusYears(0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period3.toDurationTo(readableInstant6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant8);
        org.joda.time.Period period11 = period9.minusHours((int) (short) 10);
        org.joda.time.PeriodType periodType12 = period9.getPeriodType();
        org.joda.time.Period period13 = new org.joda.time.Period(1923263740739999L, periodType12);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) '#');
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
//        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
//        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
//        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
//        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
//        int int22 = offsetDateTimeField10.get(2440588L);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
//        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
//        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
//        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
//        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
//        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
//        int int51 = offsetDateTimeField39.get(2440588L);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
//        long long61 = remainderDateTimeField28.roundHalfEven((-210866760000000L));
//        int int63 = remainderDateTimeField28.get((long) (short) 0);
//        org.joda.time.DurationField durationField64 = remainderDateTimeField28.getRangeDurationField();
//        int int66 = remainderDateTimeField28.get(20000L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(gregorianChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-210866760000001L) + "'", long61 == (-210866760000001L));
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
//        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
//        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
//        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
//        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
//        int int22 = offsetDateTimeField10.get(2440588L);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
//        java.util.Locale locale29 = null;
//        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.monthOfYear();
//        org.joda.time.DurationField durationField33 = gregorianChronology31.weeks();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology31.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology31.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.monthOfYear();
//        org.joda.time.DurationField durationField38 = gregorianChronology36.weeks();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial42 = null;
//        int[] intArray46 = new int[] { (byte) 1, 100, (short) 100 };
//        int int47 = offsetDateTimeField41.getMinimumValue(readablePartial42, intArray46);
//        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField41.getWrappedField();
//        long long50 = offsetDateTimeField41.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField51 = offsetDateTimeField41.getWrappedField();
//        int int53 = offsetDateTimeField41.get(2440588L);
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = offsetDateTimeField41.getAsShortText((int) (short) 10, locale55);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = offsetDateTimeField41.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dateTimeField35, dateTimeFieldType57, (int) (byte) 100);
//        long long61 = remainderDateTimeField59.roundFloor((long) (-52));
//        long long63 = remainderDateTimeField59.roundHalfEven(230400010L);
//        long long65 = remainderDateTimeField59.remainder(0L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology66.monthOfYear();
//        org.joda.time.DurationField durationField68 = gregorianChronology66.weeks();
//        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology66.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology66.minuteOfHour();
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.monthOfYear();
//        org.joda.time.DurationField durationField73 = gregorianChronology71.weeks();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology71.weekyearOfCentury();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField74, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial77 = null;
//        int[] intArray81 = new int[] { (byte) 1, 100, (short) 100 };
//        int int82 = offsetDateTimeField76.getMinimumValue(readablePartial77, intArray81);
//        org.joda.time.DateTimeField dateTimeField83 = offsetDateTimeField76.getWrappedField();
//        long long85 = offsetDateTimeField76.roundHalfCeiling((long) 'a');
//        org.joda.time.DateTimeField dateTimeField86 = offsetDateTimeField76.getWrappedField();
//        int int88 = offsetDateTimeField76.get(2440588L);
//        java.util.Locale locale90 = null;
//        java.lang.String str91 = offsetDateTimeField76.getAsShortText((int) (short) 10, locale90);
//        org.joda.time.DateTimeFieldType dateTimeFieldType92 = offsetDateTimeField76.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField94 = new org.joda.time.field.RemainderDateTimeField(dateTimeField70, dateTimeFieldType92, (int) (byte) 100);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField95 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField59, dateTimeFieldType92);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField96 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType92);
//        org.joda.time.ReadablePartial readablePartial97 = null;
//        java.util.Locale locale98 = null;
//        try {
//            java.lang.String str99 = zeroIsMaxDateTimeField96.getAsText(readablePartial97, locale98);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(intArray46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 101 + "'", int47 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-259200001L) + "'", long50 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 171 + "'", int53 == 171);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-60001L) + "'", long61 == (-60001L));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 230399999L + "'", long63 == 230399999L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeField67);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertNotNull(dateTimeField69);
//        org.junit.Assert.assertNotNull(dateTimeField70);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(durationField73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 101 + "'", int82 == 101);
//        org.junit.Assert.assertNotNull(dateTimeField83);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-259200001L) + "'", long85 == (-259200001L));
//        org.junit.Assert.assertNotNull(dateTimeField86);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 171 + "'", int88 == 171);
//        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "10" + "'", str91.equals("10"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType92);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) '4');
        int int9 = fixedDateTimeZone4.getStandardOffset((-34990L));
        org.joda.time.ReadableInstant readableInstant10 = null;
        int int11 = fixedDateTimeZone4.getOffset(readableInstant10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.yearOfEra();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology18.halfdayOfDay();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 1);
        long long9 = fixedDateTimeZone4.previousTransition(306102499200000L);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 306102499200000L + "'", long9 == 306102499200000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0S" + "'", str11.equals("PT0S"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField5.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField5.getAsText(readablePartial22, (-2440588), locale24);
        long long27 = offsetDateTimeField5.roundHalfFloor(32054399999L);
        try {
            long long30 = offsetDateTimeField5.set((long) 35, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for weekyearOfCentury must be in the range [101,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-2440588" + "'", str25.equals("-2440588"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 31795199999L + "'", long27 == 31795199999L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(59, 40, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder1 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeZoneBuilder1.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        int int13 = offsetDateTimeField5.getLeapAmount(100L);
        int int15 = offsetDateTimeField5.get((long) 171);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.monthOfYear();
        org.joda.time.DurationField durationField18 = gregorianChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int[] intArray26 = new int[] { (byte) 1, 100, (short) 100 };
        int int27 = offsetDateTimeField21.getMinimumValue(readablePartial22, intArray26);
        org.joda.time.DateTimeField dateTimeField28 = offsetDateTimeField21.getWrappedField();
        long long30 = offsetDateTimeField21.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField21.getWrappedField();
        int int33 = offsetDateTimeField21.get(2440588L);
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField21.getAsShortText((int) (short) 10, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = offsetDateTimeField21.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType37, 200);
        long long42 = offsetDateTimeField5.set((long) 6682, 200);
        org.joda.time.ReadablePartial readablePartial43 = null;
        org.joda.time.Period period46 = org.joda.time.Period.millis((-1));
        int[] intArray47 = period46.getValues();
        try {
            int[] intArray49 = offsetDateTimeField5.addWrapField(readablePartial43, (int) '4', intArray47, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 171 + "'", int15 == 171);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 101 + "'", int27 == 101);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-259200001L) + "'", long30 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 171 + "'", int33 == 171);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 915667206682L + "'", long42 == 915667206682L);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        int int31 = remainderDateTimeField28.getMinimumValue();
        org.joda.time.DurationField durationField32 = remainderDateTimeField28.getRangeDurationField();
        int int33 = remainderDateTimeField28.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        int int7 = offsetDateTimeField5.getMaximumValue((long) 0);
        java.lang.String str9 = offsetDateTimeField5.getAsText(0L);
        java.lang.String str10 = offsetDateTimeField5.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 200 + "'", int7 == 200);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "171" + "'", str9.equals("171"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "weekyearOfCentury" + "'", str10.equals("weekyearOfCentury"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) period2, periodType11, chronology12);
        org.joda.time.PeriodType periodType14 = periodType11.withWeeksRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType16 = periodType11.getFieldType((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType14);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Period period6 = period4.minusYears(0);
        org.joda.time.Period period8 = period4.minusMonths(0);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period(readableDuration13, readableInstant14);
        org.joda.time.Period period17 = period15.minusYears(0);
        org.joda.time.Period period18 = period12.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.PeriodType periodType19 = period18.getPeriodType();
        boolean boolean20 = period4.equals((java.lang.Object) periodType19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Duration duration22 = period4.toDurationTo(readableInstant21);
        org.joda.time.PeriodType periodType23 = period4.getPeriodType();
        org.joda.time.Period period24 = new org.joda.time.Period(0L, 0L, periodType23);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(duration22);
        org.junit.Assert.assertNotNull(periodType23);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(126910420L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440588.968870602d + "'", double1 == 2440588.968870602d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        org.joda.time.ReadablePartial readablePartial16 = null;
        int int17 = offsetDateTimeField5.getMinimumValue(readablePartial16);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = offsetDateTimeField5.getMaximumValue(readablePartial18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 101 + "'", int17 == 101);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 200 + "'", int19 == 200);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(3830340000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3830340000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.chrono.LenientChronology lenientChronology12 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology5);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(lenientChronology12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone8.getUncachedZone();
        java.lang.String str12 = dateTimeZone11.getID();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, chronology2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period3.toDurationFrom(readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType7 = periodType6.withDaysRemoved();
        org.joda.time.PeriodType periodType8 = periodType7.withMonthsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType8);
        org.joda.time.Seconds seconds10 = period9.toStandardSeconds();
        try {
            org.joda.time.Period period12 = period9.withMillis(100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(seconds10);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.Period period1 = org.joda.time.Period.hours(2);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.monthOfYear();
        org.joda.time.DurationField durationField3 = iSOChronology1.hours();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.joda.time.Seconds seconds7 = period2.toStandardSeconds();
        org.joda.time.Period period9 = period2.minusMonths(200);
        org.joda.time.Period period11 = period2.minusSeconds((int) (short) 1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(seconds7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Chronology chronology12 = gregorianChronology5.withUTC();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology5.monthOfYear();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology2);
        org.joda.time.Period period4 = period3.negated();
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.Number number7 = illegalFieldValueException5.getUpperBound();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException5);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Object obj2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.days();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(obj2, periodType3, chronology4);
        org.joda.time.PeriodType periodType6 = periodType3.withSecondsRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(2440587L, (long) (-52), periodType3);
        org.joda.time.PeriodType periodType8 = periodType3.withYearsRemoved();
        java.lang.String str9 = periodType8.toString();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PeriodType[Days]" + "'", str9.equals("PeriodType[Days]"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMonthsRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType4 = periodType1.getFieldType(59);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 59");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray3 = period2.getFieldTypes();
        org.joda.time.Period period5 = period2.multipliedBy(1);
        org.junit.Assert.assertNotNull(durationFieldTypeArray3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(0);
        org.joda.time.Period period3 = period1.multipliedBy((int) (short) 1);
        org.joda.time.Period period5 = period1.minusYears((int) (byte) 10);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.Period period15 = period13.minusYears(0);
        org.joda.time.Period period16 = period8.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration17, readableInstant18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Duration duration21 = period19.toDurationFrom(readableInstant20);
        org.joda.time.Period period22 = period13.withFields((org.joda.time.ReadablePeriod) period19);
        int int23 = period19.getMillis();
        org.joda.time.Duration duration24 = period19.toStandardDuration();
        org.joda.time.Period period25 = period1.withFields((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period27 = period1.withMonths(3);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        org.joda.time.Period period8 = period6.withYears((int) ' ');
        org.joda.time.Period period10 = period8.minusWeeks(101);
        int int11 = period8.getHours();
        boolean boolean13 = period8.equals((java.lang.Object) (-256759413L));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[UTC]", (java.lang.Number) 24405L, (java.lang.Number) 20000L, (java.lang.Number) 31824000000L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.Period period6 = period5.negated();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology9);
        org.joda.time.Period period11 = period6.minus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        org.joda.time.Period period16 = period11.withField(durationFieldType14, (int) ' ');
        org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType14);
        long long19 = decoratedDurationField17.getMillis((long) 3);
        long long22 = decoratedDurationField17.add((long) 'a', 4);
        long long25 = decoratedDurationField17.getDifferenceAsLong(36L, 101L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9467085600000L + "'", long19 == 9467085600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 12622780800097L + "'", long22 == 12622780800097L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 3);
        int int2 = period1.getDays();
        org.joda.time.Period period4 = period1.minusHours((int) 'a');
        org.joda.time.Period period6 = period4.plusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMonths((int) (short) 10);
        try {
            org.joda.time.Weeks weeks9 = period8.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        int int31 = remainderDateTimeField28.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 99 + "'", int31 == 99);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsText(readablePartial14, (int) (byte) 100, locale16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) -1, locale19);
        long long22 = offsetDateTimeField5.roundHalfEven((long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1" + "'", str20.equals("-1"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200001L) + "'", long22 == (-259200001L));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.centuries();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) gregorianChronology18);
        org.joda.time.DurationField durationField22 = zonedChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField23 = zonedChronology17.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology17.year();
        try {
            long long29 = zonedChronology17.getDateTimeMillis(0, (int) (byte) 10, 171, (-2440588));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2440588 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        java.util.Locale locale29 = null;
        int int30 = remainderDateTimeField28.getMaximumShortTextLength(locale29);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.monthOfYear();
        org.joda.time.DurationField durationField33 = gregorianChronology31.weeks();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology31.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology31.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.monthOfYear();
        org.joda.time.DurationField durationField38 = gregorianChronology36.weeks();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology36.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray46 = new int[] { (byte) 1, 100, (short) 100 };
        int int47 = offsetDateTimeField41.getMinimumValue(readablePartial42, intArray46);
        org.joda.time.DateTimeField dateTimeField48 = offsetDateTimeField41.getWrappedField();
        long long50 = offsetDateTimeField41.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField51 = offsetDateTimeField41.getWrappedField();
        int int53 = offsetDateTimeField41.get(2440588L);
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField41.getAsShortText((int) (short) 10, locale55);
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = offsetDateTimeField41.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField(dateTimeField35, dateTimeFieldType57, (int) (byte) 100);
        long long61 = remainderDateTimeField59.roundFloor((long) (-52));
        long long63 = remainderDateTimeField59.roundHalfEven(230400010L);
        long long65 = remainderDateTimeField59.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology66.monthOfYear();
        org.joda.time.DurationField durationField68 = gregorianChronology66.weeks();
        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology66.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology66.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.monthOfYear();
        org.joda.time.DurationField durationField73 = gregorianChronology71.weeks();
        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology71.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField74, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial77 = null;
        int[] intArray81 = new int[] { (byte) 1, 100, (short) 100 };
        int int82 = offsetDateTimeField76.getMinimumValue(readablePartial77, intArray81);
        org.joda.time.DateTimeField dateTimeField83 = offsetDateTimeField76.getWrappedField();
        long long85 = offsetDateTimeField76.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField86 = offsetDateTimeField76.getWrappedField();
        int int88 = offsetDateTimeField76.get(2440588L);
        java.util.Locale locale90 = null;
        java.lang.String str91 = offsetDateTimeField76.getAsShortText((int) (short) 10, locale90);
        org.joda.time.DateTimeFieldType dateTimeFieldType92 = offsetDateTimeField76.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField94 = new org.joda.time.field.RemainderDateTimeField(dateTimeField70, dateTimeFieldType92, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField95 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField59, dateTimeFieldType92);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField96 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType92);
        long long98 = remainderDateTimeField28.roundHalfCeiling(1806020000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 101 + "'", int47 == 101);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-259200001L) + "'", long50 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 171 + "'", int53 == 171);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-60001L) + "'", long61 == (-60001L));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 230399999L + "'", long63 == 230399999L);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(gregorianChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 101 + "'", int82 == 101);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-259200001L) + "'", long85 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 171 + "'", int88 == 171);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "10" + "'", str91.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType92);
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 1805999999L + "'", long98 == 1805999999L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        java.lang.String str15 = offsetDateTimeField5.toString();
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsShortText((int) (short) 1, locale17);
        long long20 = offsetDateTimeField5.roundCeiling((-210866760000001L));
        long long22 = offsetDateTimeField5.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[weekyearOfCentury]" + "'", str15.equals("DateTimeField[weekyearOfCentury]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210863779200001L) + "'", long20 == (-210863779200001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-259200001L) + "'", long22 == (-259200001L));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        org.joda.time.PeriodType periodType61 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType62 = periodType61.withMillisRemoved();
        org.joda.time.PeriodType periodType63 = periodType62.withSecondsRemoved();
        org.joda.time.PeriodType periodType64 = periodType63.withMillisRemoved();
        try {
            org.joda.time.Period period65 = new org.joda.time.Period((java.lang.Object) int60, periodType64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertNotNull(periodType62);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(periodType64);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone8.getUncachedZone();
        long long13 = cachedDateTimeZone8.previousTransition((long) (byte) 10);
        long long16 = cachedDateTimeZone8.convertLocalToUTC((long) 0, false);
        java.lang.String str18 = cachedDateTimeZone8.getNameKey((-210863779200001L));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Period period21 = period19.plusHours(171);
        org.joda.time.Period period23 = period21.minusHours(100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(306102499200000L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(32054400010L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440958.500000116d + "'", double1 == 2440958.500000116d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.Period period15 = period13.minusYears(0);
        org.joda.time.Period period16 = period10.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = period16.getPeriodType();
        boolean boolean18 = period2.equals((java.lang.Object) periodType17);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period2.toDurationTo(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType28 = periodType27.withSecondsRemoved();
        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.monthOfYear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.weeks();
        org.joda.time.Period period33 = new org.joda.time.Period(0L, (long) '4', periodType29, (org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.DurationField durationField34 = gregorianChronology30.centuries();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology30.monthOfYear();
        org.joda.time.Chronology chronology36 = gregorianChronology30.withUTC();
        org.joda.time.Period period37 = new org.joda.time.Period(0L, (long) 100, periodType24, (org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.Period period38 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21, periodType24);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyearOfCentury();
        org.joda.time.DurationField durationField6 = gregorianChronology4.millis();
        org.joda.time.Chronology chronology7 = gregorianChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology4.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeZoneBuilder9.toDateTimeZone("", true);
        java.lang.String str14 = dateTimeZone12.getShortName((long) ' ');
        boolean boolean16 = dateTimeZone12.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone12);
        java.lang.String str19 = cachedDateTimeZone17.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone17.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, dateTimeZone20);
        java.lang.Class<?> wildcardClass22 = gregorianChronology4.getClass();
        org.joda.time.Period period23 = new org.joda.time.Period(32054399999L, (long) (byte) 100, periodType3, (org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.PeriodType periodType24 = periodType3.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00" + "'", str14.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DurationField durationField15 = offsetDateTimeField5.getLeapDurationField();
        long long17 = offsetDateTimeField5.remainder(101L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.monthOfYear();
        org.joda.time.DurationField durationField21 = gregorianChronology19.weeks();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray29 = new int[] { (byte) 1, 100, (short) 100 };
        int int30 = offsetDateTimeField24.getMinimumValue(readablePartial25, intArray29);
        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField24.getWrappedField();
        long long33 = offsetDateTimeField24.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField34 = offsetDateTimeField24.getWrappedField();
        int int36 = offsetDateTimeField24.get(2440588L);
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField24.getAsShortText((int) (short) 10, locale38);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField24.getType();
        org.joda.time.ReadablePartial readablePartial41 = null;
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField24.getAsText(readablePartial41, (-2440588), locale43);
        long long46 = offsetDateTimeField24.roundHalfFloor(32054399999L);
        org.joda.time.ReadablePartial readablePartial47 = null;
        org.joda.time.Period period49 = org.joda.time.Period.millis((-1));
        int[] intArray50 = period49.getValues();
        int int51 = offsetDateTimeField24.getMaximumValue(readablePartial47, intArray50);
        int int52 = offsetDateTimeField5.getMinimumValue(readablePartial18, intArray50);
        boolean boolean54 = offsetDateTimeField5.isLeap((long) 59);
        long long56 = offsetDateTimeField5.remainder((-210866760000001L));
        long long59 = offsetDateTimeField5.add((-60000L), 1L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 259200102L + "'", long17 == 259200102L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 101 + "'", int30 == 101);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-259200001L) + "'", long33 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 171 + "'", int36 == 171);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-2440588" + "'", str44.equals("-2440588"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 31795199999L + "'", long46 == 31795199999L);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 200 + "'", int51 == 200);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 101 + "'", int52 == 101);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 28468800000L + "'", long56 == 28468800000L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 32054340000L + "'", long59 == 32054340000L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.Period period6 = period5.negated();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology9);
        org.joda.time.Period period11 = period6.minus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        org.joda.time.Period period16 = period11.withField(durationFieldType14, (int) ' ');
        org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType14);
        long long19 = decoratedDurationField17.getMillis((long) 3);
        long long22 = decoratedDurationField17.add((long) 'a', 4);
        long long25 = decoratedDurationField17.add(77017518492040587L, 24405);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9467085600000L + "'", long19 == 9467085600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 12622780800097L + "'", long22 == 12622780800097L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 154032259826440587L + "'", long25 == 154032259826440587L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        long long18 = offsetDateTimeField5.add(1805999999L, (-52));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1639016400001L) + "'", long18 == (-1639016400001L));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        long long4 = durationField1.subtract((long) (short) 10, (long) '#');
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period8 = period7.negated();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology11);
        org.joda.time.Period period13 = period8.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType16 = periodType14.getFieldType((int) (short) 0);
        org.joda.time.Period period18 = period13.withField(durationFieldType16, (int) ' ');
        org.joda.time.field.DecoratedDurationField decoratedDurationField19 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType16);
        int int22 = decoratedDurationField19.getValue(1560628202472L, 2440588L);
        long long25 = decoratedDurationField19.getDifferenceAsLong(259200011L, 7701751836777600100L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-34990L) + "'", long4 == (-34990L));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1560628202 + "'", int22 == 1560628202);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-7701751836518400L) + "'", long25 == (-7701751836518400L));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((-1), 'a', 0, (int) '4', (int) (byte) 100, true, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder0.setStandardOffset(3);
        java.io.DataOutput dataOutput15 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1", dataOutput15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        long long62 = dividedDateTimeField59.remainder((long) 1);
        try {
            long long65 = dividedDateTimeField59.addWrapField(0L, (-52));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1L + "'", long62 == 1L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField5.getType();
        java.lang.Number number24 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 1.0d, (java.lang.Number) 200, number24);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.monthOfYear();
        org.joda.time.DurationField durationField28 = gregorianChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology26.weekyearOfCentury();
        org.joda.time.DurationField durationField30 = gregorianChronology26.millis();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology26.hourOfHalfday();
        org.joda.time.DurationField durationField32 = gregorianChronology26.weekyears();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        long long36 = dateTimeZone33.adjustOffset((long) (short) 10, false);
        java.lang.String str37 = dateTimeZone33.getID();
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone33);
        org.joda.time.DurationField durationField39 = iSOChronology38.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField40 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType21, durationField32, durationField39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PT0S" + "'", str37.equals("PT0S"));
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        long long14 = offsetDateTimeField5.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
        int int17 = offsetDateTimeField5.get(2440588L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField5.getAsShortText((int) (short) 10, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField5.getType();
        org.joda.time.ReadablePartial readablePartial22 = null;
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField5.getAsText(readablePartial22, (-2440588), locale24);
        long long27 = offsetDateTimeField5.roundHalfFloor(32054399999L);
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.Period period30 = org.joda.time.Period.millis((-1));
        int[] intArray31 = period30.getValues();
        int int32 = offsetDateTimeField5.getMaximumValue(readablePartial28, intArray31);
        org.joda.time.DurationField durationField33 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200001L) + "'", long14 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 171 + "'", int17 == 171);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-2440588" + "'", str25.equals("-2440588"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 31795199999L + "'", long27 == 31795199999L);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 200 + "'", int32 == 200);
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.centuries();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) gregorianChronology18);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.weekyearOfCentury();
        org.joda.time.DurationField durationField25 = gregorianChronology23.millis();
        org.joda.time.Chronology chronology26 = gregorianChronology23.withUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology23.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder28 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone31 = dateTimeZoneBuilder28.toDateTimeZone("", true);
        java.lang.String str33 = dateTimeZone31.getShortName((long) ' ');
        boolean boolean35 = dateTimeZone31.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone31);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone39 = cachedDateTimeZone36.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology40 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology23, dateTimeZone39);
        org.joda.time.Chronology chronology41 = zonedChronology40.withUTC();
        org.joda.time.DateTimeZone dateTimeZone42 = zonedChronology40.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.weekyearOfCentury();
        org.joda.time.DurationField durationField45 = gregorianChronology43.millis();
        org.joda.time.Chronology chronology46 = gregorianChronology43.withUTC();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology43.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder48 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone51 = dateTimeZoneBuilder48.toDateTimeZone("", true);
        java.lang.String str53 = dateTimeZone51.getShortName((long) ' ');
        boolean boolean55 = dateTimeZone51.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone56 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone51);
        java.lang.String str58 = cachedDateTimeZone56.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone59 = cachedDateTimeZone56.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology60 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology43, dateTimeZone59);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder61 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone64 = dateTimeZoneBuilder61.toDateTimeZone("", true);
        java.lang.String str66 = dateTimeZone64.getShortName((long) ' ');
        boolean boolean68 = dateTimeZone64.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone69 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone64);
        java.lang.String str71 = cachedDateTimeZone69.getNameKey((long) (byte) 1);
        org.joda.time.Chronology chronology72 = zonedChronology60.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone69);
        org.joda.time.Chronology chronology73 = zonedChronology40.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone69);
        org.joda.time.Chronology chronology74 = zonedChronology17.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone69);
        try {
            long long82 = zonedChronology17.getDateTimeMillis((int) '#', 0, 0, 1024, 206, 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1024 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00" + "'", str33.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(zonedChronology40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "+00:00" + "'", str53.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "UTC" + "'", str58.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(zonedChronology60);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "+00:00" + "'", str66.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone69);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "UTC" + "'", str71.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertNotNull(chronology73);
        org.junit.Assert.assertNotNull(chronology74);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((-1), 'a', 0, (int) '4', (int) (byte) 100, true, (int) ' ');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("America/Los_Angeles", (int) (byte) 1);
        java.io.DataOutput dataOutput16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("GregorianChronology[UTC]", dataOutput16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        org.joda.time.Period period8 = period6.withYears((int) ' ');
        org.joda.time.Period period10 = period8.minusHours((int) (byte) -1);
        int int11 = period8.getWeeks();
        java.lang.String str12 = period8.toString();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "P32Y" + "'", str12.equals("P32Y"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        int int1 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        org.joda.time.Chronology chronology6 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int15 = fixedDateTimeZone12.getOffsetFromLocal((long) (byte) 1);
        org.joda.time.Chronology chronology16 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = iSOChronology6.getZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        long long4 = durationField1.subtract((long) (short) 10, (long) '#');
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period8 = period7.negated();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology11);
        org.joda.time.Period period13 = period8.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType16 = periodType14.getFieldType((int) (short) 0);
        org.joda.time.Period period18 = period13.withField(durationFieldType16, (int) ' ');
        org.joda.time.field.DecoratedDurationField decoratedDurationField19 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType16);
        org.joda.time.DurationField durationField20 = decoratedDurationField19.getWrappedField();
        long long23 = decoratedDurationField19.add(0L, 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-34990L) + "'", long4 == (-34990L));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1000L + "'", long23 == 1000L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        java.lang.Number number61 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException63 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 1.0f, number61, (java.lang.Number) (short) -1);
        boolean boolean64 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException63);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(32054399999L, (-259200000L), chronology2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        boolean boolean13 = offsetDateTimeField5.isLenient();
        long long15 = offsetDateTimeField5.roundHalfFloor((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.monthOfYear();
        org.joda.time.DurationField durationField19 = gregorianChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray27 = new int[] { (byte) 1, 100, (short) 100 };
        int int28 = offsetDateTimeField22.getMinimumValue(readablePartial23, intArray27);
        int int29 = offsetDateTimeField5.getMinimumValue(readablePartial16, intArray27);
        boolean boolean30 = offsetDateTimeField5.isSupported();
        org.joda.time.DurationField durationField31 = offsetDateTimeField5.getRangeDurationField();
        int int33 = offsetDateTimeField5.getLeapAmount(31795199999L);
        int int35 = offsetDateTimeField5.get(2440585L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200001L) + "'", long15 == (-259200001L));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 101 + "'", int28 == 101);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 101 + "'", int29 == 101);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 171 + "'", int35 == 171);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
        int int57 = offsetDateTimeField45.get(2440588L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
        long long66 = zeroIsMaxDateTimeField64.roundCeiling((long) (byte) -1);
        org.joda.time.ReadablePartial readablePartial67 = null;
        int int68 = zeroIsMaxDateTimeField64.getMaximumValue(readablePartial67);
        int int69 = zeroIsMaxDateTimeField64.getMinimumValue();
        org.joda.time.DurationField durationField70 = zeroIsMaxDateTimeField64.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200001L) + "'", long54 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-1L) + "'", long66 == (-1L));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 100 + "'", int68 == 100);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNull(durationField70);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Period period21 = period19.withHours((int) (short) 10);
        org.joda.time.Period period23 = period19.plusMinutes((-2440588));
        java.lang.Class<?> wildcardClass24 = period23.getClass();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Period period6 = period4.minusYears(0);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration7, readableInstant8);
        org.joda.time.Period period11 = period9.minusYears(0);
        org.joda.time.Period period12 = period4.plus((org.joda.time.ReadablePeriod) period9);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period4, periodType13, chronology14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.hourOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology16.getZone();
        org.joda.time.Period period20 = new org.joda.time.Period((-34990L), periodType13, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (byte) -1, chronology23);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Duration duration26 = period24.toDurationFrom(readableInstant25);
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType28 = periodType27.withDaysRemoved();
        org.joda.time.PeriodType periodType29 = periodType28.withMonthsRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant21, (org.joda.time.ReadableDuration) duration26, periodType29);
        boolean boolean31 = periodType13.equals((java.lang.Object) duration26);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Period period34 = org.joda.time.Period.weeks((-1));
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Duration duration36 = period34.toDurationFrom(readableInstant35);
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType38 = periodType37.withSecondsRemoved();
        org.joda.time.Period period39 = new org.joda.time.Period(readableInstant32, (org.joda.time.ReadableDuration) duration36, periodType38);
        org.joda.time.Period period40 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration26, periodType38);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(duration26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(duration36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
        int int57 = offsetDateTimeField45.get(2440588L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
        long long66 = zeroIsMaxDateTimeField64.roundCeiling((long) (byte) -1);
        try {
            long long69 = zeroIsMaxDateTimeField64.set(99L, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekyearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200001L) + "'", long54 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-1L) + "'", long66 == (-1L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period18 = period13.withMonths(0);
        org.joda.time.Period period20 = period18.withYears((int) (byte) 1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        org.joda.time.Period period8 = period6.withYears((int) ' ');
        org.joda.time.Period period10 = period8.minusHours((int) (byte) -1);
        int int11 = period10.getSeconds();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((-1));
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        org.joda.time.Period period5 = period1.minusYears((int) '4');
        int int6 = period1.getMinutes();
        org.joda.time.Period period7 = period1.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period12 = period2.minusMillis((int) (short) 0);
        org.joda.time.Period period14 = period2.plusWeeks(4320);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply(4320, (-2440588));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: 4320 * -2440588");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) '4');
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        long long61 = remainderDateTimeField28.roundHalfEven((-210866760000000L));
        int int63 = remainderDateTimeField28.get((long) (short) 0);
        org.joda.time.DurationField durationField64 = remainderDateTimeField28.getRangeDurationField();
        org.joda.time.Chronology chronology67 = null;
        org.joda.time.Period period68 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology67);
        org.joda.time.ReadableDuration readableDuration69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.Period period71 = new org.joda.time.Period(readableDuration69, readableInstant70);
        org.joda.time.Period period73 = period71.minusYears(0);
        org.joda.time.Period period74 = period68.withFields((org.joda.time.ReadablePeriod) period71);
        org.joda.time.Chronology chronology77 = null;
        org.joda.time.Period period78 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology77);
        org.joda.time.ReadableDuration readableDuration79 = null;
        org.joda.time.ReadableInstant readableInstant80 = null;
        org.joda.time.Period period81 = new org.joda.time.Period(readableDuration79, readableInstant80);
        org.joda.time.Period period82 = period81.negated();
        org.joda.time.Chronology chronology85 = null;
        org.joda.time.Period period86 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology85);
        org.joda.time.Period period87 = period82.minus((org.joda.time.ReadablePeriod) period86);
        org.joda.time.PeriodType periodType88 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType90 = periodType88.getFieldType((int) (short) 0);
        org.joda.time.Period period92 = period87.withField(durationFieldType90, (int) ' ');
        int int93 = period78.get(durationFieldType90);
        boolean boolean94 = period74.isSupported(durationFieldType90);
        org.joda.time.field.ScaledDurationField scaledDurationField96 = new org.joda.time.field.ScaledDurationField(durationField64, durationFieldType90, (int) (byte) 100);
        long long99 = scaledDurationField96.add((-259200000L), (long) 200);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-210866760000001L) + "'", long61 == (-210866760000001L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(period82);
        org.junit.Assert.assertNotNull(period87);
        org.junit.Assert.assertNotNull(periodType88);
        org.junit.Assert.assertNotNull(durationFieldType90);
        org.junit.Assert.assertNotNull(period92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 6682 + "'", int93 == 6682);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + long99 + "' != '" + 119740800000L + "'", long99 == 119740800000L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.weeks((-1));
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period4.toDurationFrom(readableInstant5);
        org.joda.time.Period period8 = period4.minusYears((int) '4');
        long long11 = iSOChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (-1), 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeZoneBuilder12.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.Chronology chronology17 = iSOChronology0.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology0.millisOfDay();
        try {
            long long26 = iSOChronology0.getDateTimeMillis(2, 100, 171, (int) (byte) 0, (int) 'a', 1024, 1560628202);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period12 = period2.withYears((int) (short) -1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
        int int57 = offsetDateTimeField45.get(2440588L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
        long long66 = zeroIsMaxDateTimeField64.remainder((long) '#');
        long long69 = zeroIsMaxDateTimeField64.getDifferenceAsLong(1L, (long) 206);
        int int72 = zeroIsMaxDateTimeField64.getDifference(259200102L, (long) 10);
        long long75 = zeroIsMaxDateTimeField64.getDifferenceAsLong((long) (byte) -1, 7701751836777600100L);
        long long77 = zeroIsMaxDateTimeField64.roundHalfCeiling(25010L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200001L) + "'", long54 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 36L + "'", long66 == 36L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 4320 + "'", int72 == 4320);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-128362530612960L) + "'", long75 == (-128362530612960L));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-1L) + "'", long77 == (-1L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.PeriodType periodType36 = periodType35.withMillisRemoved();
        org.joda.time.PeriodType periodType37 = periodType35.withSecondsRemoved();
        org.joda.time.Period period39 = org.joda.time.Period.weeks(0);
        org.joda.time.Period period41 = period39.multipliedBy((int) (short) 1);
        org.joda.time.Period period43 = period39.plusWeeks((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period45 = new org.joda.time.Period((java.lang.Object) period39, (org.joda.time.Chronology) gregorianChronology44);
        try {
            org.joda.time.Period period46 = new org.joda.time.Period((java.lang.Object) 0L, periodType35, (org.joda.time.Chronology) gregorianChronology44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 6, (long) ' ', periodType6);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 100, 31795199999L, periodType6);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType12 = periodType11.withSecondsRemoved();
        org.joda.time.PeriodType periodType13 = periodType12.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.monthOfYear();
        org.joda.time.DurationField durationField16 = gregorianChronology14.weeks();
        org.joda.time.Period period17 = new org.joda.time.Period(0L, (long) '4', periodType13, (org.joda.time.Chronology) gregorianChronology14);
        org.joda.time.DurationField durationField18 = gregorianChronology14.centuries();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology14.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology20 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology14);
        java.lang.Object obj21 = null;
        boolean boolean22 = lenientChronology20.equals(obj21);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 99, 99L, periodType6, (org.joda.time.Chronology) lenientChronology20);
        org.joda.time.Days days24 = period23.toStandardDays();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(lenientChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(days24);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.monthOfYear();
        org.joda.time.DurationField durationField42 = gregorianChronology40.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology40.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray50 = new int[] { (byte) 1, 100, (short) 100 };
        int int51 = offsetDateTimeField45.getMinimumValue(readablePartial46, intArray50);
        org.joda.time.DateTimeField dateTimeField52 = offsetDateTimeField45.getWrappedField();
        long long54 = offsetDateTimeField45.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField55 = offsetDateTimeField45.getWrappedField();
        int int57 = offsetDateTimeField45.get(2440588L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField45.getAsShortText((int) (short) 10, locale59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField45.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField63 = new org.joda.time.field.RemainderDateTimeField(dateTimeField39, dateTimeFieldType61, (int) (byte) 100);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField64 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType61);
        int int65 = zeroIsMaxDateTimeField64.getMinimumValue();
        long long67 = zeroIsMaxDateTimeField64.roundHalfFloor(31795200000L);
        long long70 = zeroIsMaxDateTimeField64.getDifferenceAsLong(0L, (long) (short) 0);
        org.joda.time.ReadablePartial readablePartial71 = null;
        int int72 = zeroIsMaxDateTimeField64.getMaximumValue(readablePartial71);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 101 + "'", int51 == 101);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-259200001L) + "'", long54 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 171 + "'", int57 == 171);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 31795199999L + "'", long67 == 31795199999L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.era();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField3 = iSOChronology0.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) strMap2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.Period period5 = period3.minusYears(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.Period period11 = period3.plus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period3, periodType12, chronology13);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone18 = iSOChronology15.getZone();
        org.joda.time.Period period19 = new org.joda.time.Period((-34990L), periodType12, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType23 = periodType22.withDaysRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.weekyearOfCentury();
        org.joda.time.DurationField durationField26 = gregorianChronology24.millis();
        org.joda.time.Chronology chronology27 = gregorianChronology24.withUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology24.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder29 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone32 = dateTimeZoneBuilder29.toDateTimeZone("", true);
        java.lang.String str34 = dateTimeZone32.getShortName((long) ' ');
        boolean boolean36 = dateTimeZone32.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone32);
        java.lang.String str39 = cachedDateTimeZone37.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone40 = cachedDateTimeZone37.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology24, dateTimeZone40);
        java.lang.Class<?> wildcardClass42 = gregorianChronology24.getClass();
        org.joda.time.Period period43 = new org.joda.time.Period(32054399999L, (long) (byte) 100, periodType23, (org.joda.time.Chronology) gregorianChronology24);
        boolean boolean44 = periodType12.equals((java.lang.Object) gregorianChronology24);
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology24);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00" + "'", str34.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UTC" + "'", str39.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(zonedChronology41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(chronology45);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        long long62 = dividedDateTimeField59.remainder((long) 1);
        long long64 = dividedDateTimeField59.roundHalfCeiling((-230400000L));
        int int67 = dividedDateTimeField59.getDifference((long) 2, 0L);
        try {
            long long70 = dividedDateTimeField59.addWrapField(77017518489599999L, (-2440588));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1L + "'", long62 == 1L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-230400001L) + "'", long64 == (-230400001L));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        int int60 = dividedDateTimeField59.getMaximumValue();
        long long63 = dividedDateTimeField59.add((long) 101, (long) 0);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField59);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) dividedDateTimeField59, 1, 1024, (-52));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for weekyearOfCentury must be in the range [1024,-52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 101L + "'", long63 == 101L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        java.lang.String str5 = dateTimeZone3.getShortName((long) ' ');
        boolean boolean7 = dateTimeZone3.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey((long) (byte) 1);
        java.util.TimeZone timeZone11 = cachedDateTimeZone8.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT0S", "PT0S", 1, (-1));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 1);
        java.lang.Object obj8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.days();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(obj8, periodType9, chronology10);
        org.joda.time.Weeks weeks12 = period11.toStandardWeeks();
        boolean boolean13 = fixedDateTimeZone4.equals((java.lang.Object) weeks12);
        long long16 = fixedDateTimeZone4.convertLocalToUTC((-210863779200001L), false);
        long long18 = fixedDateTimeZone4.nextTransition((long) 6682);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-210863779200002L) + "'", long16 == (-210863779200002L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 6682L + "'", long18 == 6682L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.monthOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) 100);
        int int8 = offsetDateTimeField6.getMaximumValue((long) 0);
        java.lang.String str10 = offsetDateTimeField6.getAsText(0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.monthOfYear();
        org.joda.time.DurationField durationField14 = gregorianChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray22 = new int[] { (byte) 1, 100, (short) 100 };
        int int23 = offsetDateTimeField17.getMinimumValue(readablePartial18, intArray22);
        int int24 = offsetDateTimeField6.getMaximumValue(readablePartial11, intArray22);
        boolean boolean25 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) intArray22);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 200 + "'", int8 == 200);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "171" + "'", str10.equals("171"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 101 + "'", int23 == 101);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 200 + "'", int24 == 200);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("+00:00", "");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Number number8 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap2 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) strMap2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.millisOfSecond();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusSeconds((int) (byte) 10);
        org.joda.time.Period period8 = period6.multipliedBy((int) (short) 1);
        org.joda.time.Period period10 = period8.withMillis(0);
        org.joda.time.Period period12 = period8.plusDays((-1));
        org.joda.time.Period period14 = period12.minusYears(4320);
        try {
            org.joda.time.Weeks weeks15 = period14.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PT0S", 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addRecurringSavings("35", (int) ' ', 6682, 0, ' ', 0, 1, 1, true, 59);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("(\"org.joda.time.JodaTimePermission\" \"10\")");
        boolean boolean2 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("UTC", "DateTimeField[weekyearOfCentury]");
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.Chronology chronology18 = zonedChronology17.withUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology17.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.weekyearOfCentury();
        org.joda.time.DurationField durationField22 = gregorianChronology20.millis();
        org.joda.time.Chronology chronology23 = gregorianChronology20.withUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology20.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder25 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone28 = dateTimeZoneBuilder25.toDateTimeZone("", true);
        java.lang.String str30 = dateTimeZone28.getShortName((long) ' ');
        boolean boolean32 = dateTimeZone28.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone33 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone28);
        java.lang.String str35 = cachedDateTimeZone33.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone36 = cachedDateTimeZone33.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone36);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder38 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone41 = dateTimeZoneBuilder38.toDateTimeZone("", true);
        java.lang.String str43 = dateTimeZone41.getShortName((long) ' ');
        boolean boolean45 = dateTimeZone41.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone46 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone41);
        java.lang.String str48 = cachedDateTimeZone46.getNameKey((long) (byte) 1);
        org.joda.time.Chronology chronology49 = zonedChronology37.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone46);
        org.joda.time.Chronology chronology50 = zonedChronology17.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone46);
        org.joda.time.DateTimeField dateTimeField51 = zonedChronology17.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+00:00" + "'", str30.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "UTC" + "'", str35.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(zonedChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+00:00" + "'", str43.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "UTC" + "'", str48.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (byte) 0, 40, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = iSOChronology1.centuries();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.Period period6 = period5.negated();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology9);
        org.joda.time.Period period11 = period6.minus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType14 = periodType12.getFieldType((int) (short) 0);
        org.joda.time.Period period16 = period11.withField(durationFieldType14, (int) ' ');
        org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType14);
        long long19 = decoratedDurationField17.getMillis((long) 3);
        org.joda.time.DurationFieldType durationFieldType20 = decoratedDurationField17.getType();
        try {
            long long23 = decoratedDurationField17.getMillis(1560628202, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 156062820200");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9467085600000L + "'", long19 == 9467085600000L);
        org.junit.Assert.assertNotNull(durationFieldType20);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        int int13 = offsetDateTimeField5.getLeapAmount(100L);
        int int15 = offsetDateTimeField5.get((long) 171);
        long long17 = offsetDateTimeField5.roundHalfCeiling(59999L);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.monthOfYear();
        org.joda.time.DurationField durationField21 = gregorianChronology19.weeks();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 100);
        int int26 = offsetDateTimeField24.getMaximumValue((long) 0);
        org.joda.time.ReadablePartial readablePartial27 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.monthOfYear();
        org.joda.time.DurationField durationField30 = gregorianChronology28.weeks();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray38 = new int[] { (byte) 1, 100, (short) 100 };
        int int39 = offsetDateTimeField33.getMinimumValue(readablePartial34, intArray38);
        org.joda.time.DateTimeField dateTimeField40 = offsetDateTimeField33.getWrappedField();
        boolean boolean41 = offsetDateTimeField33.isLenient();
        long long43 = offsetDateTimeField33.roundHalfFloor((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.monthOfYear();
        org.joda.time.DurationField durationField47 = gregorianChronology45.weeks();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial51 = null;
        int[] intArray55 = new int[] { (byte) 1, 100, (short) 100 };
        int int56 = offsetDateTimeField50.getMinimumValue(readablePartial51, intArray55);
        int int57 = offsetDateTimeField33.getMinimumValue(readablePartial44, intArray55);
        int int58 = offsetDateTimeField24.getMaximumValue(readablePartial27, intArray55);
        int int59 = offsetDateTimeField5.getMinimumValue(readablePartial18, intArray55);
        org.joda.time.DateTimeField dateTimeField60 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 171 + "'", int15 == 171);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259200001L) + "'", long17 == (-259200001L));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 200 + "'", int26 == 200);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 101 + "'", int39 == 101);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-259200001L) + "'", long43 == (-259200001L));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 101 + "'", int56 == 101);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 101 + "'", int57 == 101);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 200 + "'", int58 == 200);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 101 + "'", int59 == 101);
        org.junit.Assert.assertNotNull(dateTimeField60);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(206);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-206) + "'", int1 == (-206));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.Period period8 = new org.joda.time.Period(0L, (long) '4', periodType4, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationField durationField9 = gregorianChronology5.centuries();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology5.monthOfYear();
        org.joda.time.chrono.LenientChronology lenientChronology11 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTimeZoneBuilder12.toDateTimeZone("", true);
        java.lang.String str17 = dateTimeZone15.getName(0L);
        org.joda.time.Chronology chronology18 = lenientChronology11.withZone(dateTimeZone15);
        org.joda.time.DurationField durationField19 = lenientChronology11.minutes();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(lenientChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00" + "'", str17.equals("+00:00"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("171");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("P32Y");
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekyearOfCentury();
        org.joda.time.DurationField durationField6 = gregorianChronology4.millis();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        boolean boolean8 = jodaTimePermission3.equals((java.lang.Object) dateTimeZone7);
        boolean boolean9 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        long long61 = remainderDateTimeField28.roundHalfEven((-210866760000000L));
        int int63 = remainderDateTimeField28.get((long) (short) 0);
        org.joda.time.DurationField durationField64 = remainderDateTimeField28.getRangeDurationField();
        org.joda.time.Chronology chronology67 = null;
        org.joda.time.Period period68 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology67);
        org.joda.time.ReadableDuration readableDuration69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.Period period71 = new org.joda.time.Period(readableDuration69, readableInstant70);
        org.joda.time.Period period73 = period71.minusYears(0);
        org.joda.time.Period period74 = period68.withFields((org.joda.time.ReadablePeriod) period71);
        org.joda.time.Chronology chronology77 = null;
        org.joda.time.Period period78 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology77);
        org.joda.time.ReadableDuration readableDuration79 = null;
        org.joda.time.ReadableInstant readableInstant80 = null;
        org.joda.time.Period period81 = new org.joda.time.Period(readableDuration79, readableInstant80);
        org.joda.time.Period period82 = period81.negated();
        org.joda.time.Chronology chronology85 = null;
        org.joda.time.Period period86 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology85);
        org.joda.time.Period period87 = period82.minus((org.joda.time.ReadablePeriod) period86);
        org.joda.time.PeriodType periodType88 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType90 = periodType88.getFieldType((int) (short) 0);
        org.joda.time.Period period92 = period87.withField(durationFieldType90, (int) ' ');
        int int93 = period78.get(durationFieldType90);
        boolean boolean94 = period74.isSupported(durationFieldType90);
        org.joda.time.field.ScaledDurationField scaledDurationField96 = new org.joda.time.field.ScaledDurationField(durationField64, durationFieldType90, (int) (byte) 100);
        long long98 = scaledDurationField96.getMillis((-52));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-210866760000001L) + "'", long61 == (-210866760000001L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(period82);
        org.junit.Assert.assertNotNull(period87);
        org.junit.Assert.assertNotNull(periodType88);
        org.junit.Assert.assertNotNull(durationFieldType90);
        org.junit.Assert.assertNotNull(period92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 6682 + "'", int93 == 6682);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + (-31200000000L) + "'", long98 == (-31200000000L));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration5, readableInstant6);
        org.joda.time.Period period9 = period7.minusYears(0);
        org.joda.time.Period period10 = period2.plus((org.joda.time.ReadablePeriod) period7);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.Period period16 = period7.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period16, periodType17, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.Weeks weeks20 = period19.toStandardWeeks();
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period19.getFieldTypes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(weeks20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", true);
        java.lang.String str10 = dateTimeZone8.getShortName((long) ' ');
        boolean boolean12 = dateTimeZone8.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str15 = cachedDateTimeZone13.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone16 = cachedDateTimeZone13.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfWeek();
        org.joda.time.DurationField durationField20 = gregorianChronology18.centuries();
        boolean boolean21 = zonedChronology17.equals((java.lang.Object) gregorianChronology18);
        org.joda.time.DateTimeZone dateTimeZone22 = zonedChronology17.getZone();
        org.joda.time.Chronology chronology23 = zonedChronology17.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.monthOfYear();
        org.joda.time.DurationField durationField31 = gregorianChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology29.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.monthOfYear();
        org.joda.time.DurationField durationField36 = gregorianChronology34.weeks();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology34.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int[] intArray44 = new int[] { (byte) 1, 100, (short) 100 };
        int int45 = offsetDateTimeField39.getMinimumValue(readablePartial40, intArray44);
        org.joda.time.DateTimeField dateTimeField46 = offsetDateTimeField39.getWrappedField();
        long long48 = offsetDateTimeField39.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField39.getWrappedField();
        int int51 = offsetDateTimeField39.get(2440588L);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField39.getAsShortText((int) (short) 10, locale53);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField39.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField33, dateTimeFieldType55, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField59 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType55, (int) (short) 100);
        long long61 = remainderDateTimeField28.roundHalfEven((-210866760000000L));
        int int63 = remainderDateTimeField28.get((long) (short) 0);
        org.joda.time.DurationField durationField64 = remainderDateTimeField28.getRangeDurationField();
        org.joda.time.Chronology chronology67 = null;
        org.joda.time.Period period68 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology67);
        org.joda.time.ReadableDuration readableDuration69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.Period period71 = new org.joda.time.Period(readableDuration69, readableInstant70);
        org.joda.time.Period period73 = period71.minusYears(0);
        org.joda.time.Period period74 = period68.withFields((org.joda.time.ReadablePeriod) period71);
        org.joda.time.Chronology chronology77 = null;
        org.joda.time.Period period78 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology77);
        org.joda.time.ReadableDuration readableDuration79 = null;
        org.joda.time.ReadableInstant readableInstant80 = null;
        org.joda.time.Period period81 = new org.joda.time.Period(readableDuration79, readableInstant80);
        org.joda.time.Period period82 = period81.negated();
        org.joda.time.Chronology chronology85 = null;
        org.joda.time.Period period86 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology85);
        org.joda.time.Period period87 = period82.minus((org.joda.time.ReadablePeriod) period86);
        org.joda.time.PeriodType periodType88 = org.joda.time.PeriodType.years();
        org.joda.time.DurationFieldType durationFieldType90 = periodType88.getFieldType((int) (short) 0);
        org.joda.time.Period period92 = period87.withField(durationFieldType90, (int) ' ');
        int int93 = period78.get(durationFieldType90);
        boolean boolean94 = period74.isSupported(durationFieldType90);
        org.joda.time.field.ScaledDurationField scaledDurationField96 = new org.joda.time.field.ScaledDurationField(durationField64, durationFieldType90, (int) (byte) 100);
        try {
            int int99 = scaledDurationField96.getDifference(259200011L, (-210865896000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3514435920");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 101 + "'", int45 == 101);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-259200001L) + "'", long48 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 171 + "'", int51 == 171);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10" + "'", str54.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-210866760000001L) + "'", long61 == (-210866760000001L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(period73);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(period82);
        org.junit.Assert.assertNotNull(period87);
        org.junit.Assert.assertNotNull(periodType88);
        org.junit.Assert.assertNotNull(durationFieldType90);
        org.junit.Assert.assertNotNull(period92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 6682 + "'", int93 == 6682);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 0, periodType1, chronology2);
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period3.toString(periodFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        int int13 = offsetDateTimeField5.getLeapAmount(100L);
        int int15 = offsetDateTimeField5.get((long) 171);
        boolean boolean17 = offsetDateTimeField5.isLeap(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 171 + "'", int15 == 171);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.monthOfYear();
        org.joda.time.DurationField durationField7 = gregorianChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial11 = null;
        int[] intArray15 = new int[] { (byte) 1, 100, (short) 100 };
        int int16 = offsetDateTimeField10.getMinimumValue(readablePartial11, intArray15);
        org.joda.time.DateTimeField dateTimeField17 = offsetDateTimeField10.getWrappedField();
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField10.getWrappedField();
        int int22 = offsetDateTimeField10.get(2440588L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField10.getAsShortText((int) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField10.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType26, (int) (byte) 100);
        long long30 = remainderDateTimeField28.roundFloor((long) (-52));
        long long32 = remainderDateTimeField28.roundHalfEven(230400010L);
        long long34 = remainderDateTimeField28.remainder(0L);
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.monthOfYear();
        org.joda.time.DurationField durationField39 = gregorianChronology37.weeks();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial43 = null;
        int[] intArray47 = new int[] { (byte) 1, 100, (short) 100 };
        int int48 = offsetDateTimeField42.getMinimumValue(readablePartial43, intArray47);
        org.joda.time.DateTimeField dateTimeField49 = offsetDateTimeField42.getWrappedField();
        long long51 = offsetDateTimeField42.roundHalfCeiling((long) 'a');
        org.joda.time.DurationField durationField52 = offsetDateTimeField42.getLeapDurationField();
        long long54 = offsetDateTimeField42.remainder(101L);
        org.joda.time.ReadablePartial readablePartial55 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.monthOfYear();
        org.joda.time.DurationField durationField58 = gregorianChronology56.weeks();
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology56.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField(dateTimeField59, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial62 = null;
        int[] intArray66 = new int[] { (byte) 1, 100, (short) 100 };
        int int67 = offsetDateTimeField61.getMinimumValue(readablePartial62, intArray66);
        org.joda.time.DateTimeField dateTimeField68 = offsetDateTimeField61.getWrappedField();
        long long70 = offsetDateTimeField61.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField71 = offsetDateTimeField61.getWrappedField();
        int int73 = offsetDateTimeField61.get(2440588L);
        java.util.Locale locale75 = null;
        java.lang.String str76 = offsetDateTimeField61.getAsShortText((int) (short) 10, locale75);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = offsetDateTimeField61.getType();
        org.joda.time.ReadablePartial readablePartial78 = null;
        java.util.Locale locale80 = null;
        java.lang.String str81 = offsetDateTimeField61.getAsText(readablePartial78, (-2440588), locale80);
        long long83 = offsetDateTimeField61.roundHalfFloor(32054399999L);
        org.joda.time.ReadablePartial readablePartial84 = null;
        org.joda.time.Period period86 = org.joda.time.Period.millis((-1));
        int[] intArray87 = period86.getValues();
        int int88 = offsetDateTimeField61.getMaximumValue(readablePartial84, intArray87);
        int int89 = offsetDateTimeField42.getMinimumValue(readablePartial55, intArray87);
        try {
            int[] intArray91 = remainderDateTimeField28.add(readablePartial35, 0, intArray87, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 101 + "'", int16 == 101);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200001L) + "'", long19 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 171 + "'", int22 == 171);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-60001L) + "'", long30 == (-60001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 230399999L + "'", long32 == 230399999L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 101 + "'", int48 == 101);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-259200001L) + "'", long51 == (-259200001L));
        org.junit.Assert.assertNull(durationField52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 259200102L + "'", long54 == 259200102L);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 101 + "'", int67 == 101);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-259200001L) + "'", long70 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 171 + "'", int73 == 171);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "10" + "'", str76.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "-2440588" + "'", str81.equals("-2440588"));
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 31795199999L + "'", long83 == 31795199999L);
        org.junit.Assert.assertNotNull(period86);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 200 + "'", int88 == 200);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 101 + "'", int89 == 101);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 3);
        int int2 = period1.getDays();
        org.joda.time.Period period4 = period1.minusHours((int) 'a');
        org.joda.time.Period period6 = period4.plusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMonths((int) (short) 10);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType12 = periodType11.withDaysRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.weekyearOfCentury();
        org.joda.time.DurationField durationField15 = gregorianChronology13.millis();
        org.joda.time.Chronology chronology16 = gregorianChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology13.weekyearOfCentury();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder18.toDateTimeZone("", true);
        java.lang.String str23 = dateTimeZone21.getShortName((long) ' ');
        boolean boolean25 = dateTimeZone21.isStandardOffset((long) (short) 0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone26 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
        java.lang.String str28 = cachedDateTimeZone26.getNameKey((long) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone29 = cachedDateTimeZone26.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, dateTimeZone29);
        java.lang.Class<?> wildcardClass31 = gregorianChronology13.getClass();
        org.joda.time.Period period32 = new org.joda.time.Period(32054399999L, (long) (byte) 100, periodType12, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.Period period33 = period8.minus((org.joda.time.ReadablePeriod) period32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00" + "'", str23.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "UTC" + "'", str28.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(zonedChronology30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(period33);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { (byte) 1, 100, (short) 100 };
        int int11 = offsetDateTimeField5.getMinimumValue(readablePartial6, intArray10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
        int int13 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DurationField durationField14 = offsetDateTimeField5.getLeapDurationField();
        long long16 = offsetDateTimeField5.roundHalfEven((long) (-1));
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.monthOfYear();
        org.joda.time.DurationField durationField21 = gregorianChronology19.weeks();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology19.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray29 = new int[] { (byte) 1, 100, (short) 100 };
        int int30 = offsetDateTimeField24.getMinimumValue(readablePartial25, intArray29);
        int int32 = offsetDateTimeField24.getLeapAmount(100L);
        int int34 = offsetDateTimeField24.get((long) 171);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology35.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int[] intArray45 = new int[] { (byte) 1, 100, (short) 100 };
        int int46 = offsetDateTimeField40.getMinimumValue(readablePartial41, intArray45);
        org.joda.time.DateTimeField dateTimeField47 = offsetDateTimeField40.getWrappedField();
        long long49 = offsetDateTimeField40.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeField dateTimeField50 = offsetDateTimeField40.getWrappedField();
        int int52 = offsetDateTimeField40.get(2440588L);
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField40.getAsShortText((int) (short) 10, locale54);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField40.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType56, 200);
        long long61 = offsetDateTimeField24.set((long) 6682, 200);
        org.joda.time.ReadablePartial readablePartial62 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology64 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology64.monthOfYear();
        org.joda.time.DurationField durationField66 = gregorianChronology64.weeks();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology64.weekyearOfCentury();
        boolean boolean69 = gregorianChronology64.equals((java.lang.Object) (-1L));
        org.joda.time.ReadableDuration readableDuration70 = null;
        org.joda.time.ReadableInstant readableInstant71 = null;
        org.joda.time.Period period72 = new org.joda.time.Period(readableDuration70, readableInstant71);
        org.joda.time.Period period74 = period72.minusYears(0);
        org.joda.time.Period period76 = period72.minusMonths(0);
        org.joda.time.Chronology chronology79 = null;
        org.joda.time.Period period80 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology79);
        org.joda.time.ReadableDuration readableDuration81 = null;
        org.joda.time.ReadableInstant readableInstant82 = null;
        org.joda.time.Period period83 = new org.joda.time.Period(readableDuration81, readableInstant82);
        org.joda.time.Period period85 = period83.minusYears(0);
        org.joda.time.Period period86 = period80.withFields((org.joda.time.ReadablePeriod) period83);
        org.joda.time.PeriodType periodType87 = period86.getPeriodType();
        boolean boolean88 = period72.equals((java.lang.Object) periodType87);
        org.joda.time.ReadableInstant readableInstant89 = null;
        org.joda.time.Duration duration90 = period72.toDurationTo(readableInstant89);
        org.joda.time.PeriodType periodType91 = period72.getPeriodType();
        int[] intArray94 = gregorianChronology64.get((org.joda.time.ReadablePeriod) period72, (long) 101, (long) ' ');
        int[] intArray96 = offsetDateTimeField24.add(readablePartial62, (int) (short) 1, intArray94, 0);
        try {
            int[] intArray98 = offsetDateTimeField5.set(readablePartial17, 0, intArray96, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekyearOfCentury must be in the range [101,200]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 101 + "'", int11 == 101);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200001L) + "'", long16 == (-259200001L));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 101 + "'", int30 == 101);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 171 + "'", int34 == 171);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 101 + "'", int46 == 101);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-259200001L) + "'", long49 == (-259200001L));
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 171 + "'", int52 == 171);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10" + "'", str55.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 915667206682L + "'", long61 == 915667206682L);
        org.junit.Assert.assertNotNull(gregorianChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertNotNull(period85);
        org.junit.Assert.assertNotNull(period86);
        org.junit.Assert.assertNotNull(periodType87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(duration90);
        org.junit.Assert.assertNotNull(periodType91);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField3 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField4 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("10");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        boolean boolean5 = jodaTimePermission1.equals((java.lang.Object) readableInterval4);
        java.lang.String str6 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"10\")" + "'", str6.equals("(\"org.joda.time.JodaTimePermission\" \"10\")"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((-210866760000000L), (long) (byte) 0, chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Period period8 = period6.minusYears(0);
        org.joda.time.Period period9 = period3.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period11 = period6.minusDays((int) (byte) -1);
        org.joda.time.Period period13 = period6.minusHours(0);
        org.joda.time.Period period15 = period6.plusDays(0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Period period4 = period2.minusYears(0);
        org.joda.time.Period period6 = period2.minusMonths(0);
        java.lang.String str7 = period2.toString();
        org.joda.time.Period period9 = period2.withMillis((-40));
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant2, readableInstant3, periodType4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Period period10 = period8.minusYears(0);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration11, readableInstant12);
        org.joda.time.Period period15 = period13.minusYears(0);
        org.joda.time.Period period16 = period8.plus((org.joda.time.ReadablePeriod) period13);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.hours();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period8, periodType17, chronology18);
        org.joda.time.PeriodType periodType20 = periodType17.withWeeksRemoved();
        org.joda.time.Period period21 = period5.normalizedStandard(periodType17);
        org.joda.time.Period period22 = new org.joda.time.Period((long) 2, 6L, periodType17);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("America/Los_Angeles");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-230400000L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-230400000) + "'", int1 == (-230400000));
    }
}

