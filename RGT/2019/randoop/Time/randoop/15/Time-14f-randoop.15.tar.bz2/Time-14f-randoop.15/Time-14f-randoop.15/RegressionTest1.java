import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.centuryOfEra();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
//        int int10 = delegatedDateTimeField8.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField11 = delegatedDateTimeField8.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 97);
//        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 10, (long) 59);
//        int int18 = offsetDateTimeField13.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime22 = dateTime20.plusHours((int) (short) -1);
//        int int23 = dateTime22.getSecondOfMinute();
//        org.joda.time.DateTime dateTime25 = dateTime22.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime27 = dateTime25.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        int int34 = dateTimeZone32.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now(dateTimeZone32);
//        org.joda.time.MonthDay.Property property36 = monthDay35.dayOfMonth();
//        java.lang.String str37 = property36.getName();
//        java.lang.String str38 = property36.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder29.appendFixedSignedDecimal(dateTimeFieldType39, 9700);
//        int int42 = dateTime25.get(dateTimeFieldType39);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType39, 23);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType39);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType39, (int) (byte) 0, 31, 4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [31,4]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86496 + "'", int18 == 86496);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "dayOfMonth" + "'", str37.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1" + "'", str38.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 31 + "'", int42 == 31);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        int int14 = offsetDateTimeField9.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        int int21 = localTime19.indexOf(dateTimeFieldType20);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime25 = dateTime23.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        int int28 = localTime26.indexOf(dateTimeFieldType27);
//        boolean boolean29 = localTime19.isBefore((org.joda.time.ReadablePartial) localTime26);
//        int int30 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localTime26);
//        long long33 = offsetDateTimeField9.set((long) 23, (int) (byte) 100);
//        long long35 = offsetDateTimeField9.roundHalfEven(86399990L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86496 + "'", int14 == 86496);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localTime26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 97 + "'", int30 == 97);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3023L + "'", long33 == 3023L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 86399990L + "'", long35 == 86399990L);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("1");
        int int4 = dateTimeFormatter0.getDefaultYear();
        int int5 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2000 + "'", int4 == 2000);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime24 = dateTime21.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime26 = dateTime21.withYearOfEra((int) ' ');
        boolean boolean27 = dateTime18.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28, readableInstant29);
        org.joda.time.DurationField durationField31 = gJChronology30.days();
        org.joda.time.DurationField durationField32 = gJChronology30.centuries();
        org.joda.time.DateTime dateTime33 = dateTime21.toDateTime((org.joda.time.Chronology) gJChronology30);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTime33);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        long long18 = dateTime16.getMillis();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime26 = dateTime24.plusHours((int) (short) -1);
//        int int27 = dateTime26.getSecondOfMinute();
//        org.joda.time.DateTime dateTime29 = dateTime26.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime31 = dateTime29.withHourOfDay(0);
//        boolean boolean32 = limitChronology22.equals((java.lang.Object) dateTime31);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        long long9 = delegatedDateTimeField4.roundFloor((long) 15);
//        long long11 = delegatedDateTimeField4.roundCeiling((-28740062L));
//        long long14 = delegatedDateTimeField4.add((-53174879820000L), 2);
//        int int15 = delegatedDateTimeField4.getMinimumValue();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField18, dateTimeFieldType19);
//        int int22 = delegatedDateTimeField20.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField23 = delegatedDateTimeField20.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 97);
//        long long28 = offsetDateTimeField25.set((long) 19, 9700);
//        java.lang.String str30 = offsetDateTimeField25.getAsText((long) 57600);
//        int int32 = offsetDateTimeField25.getMaximumValue((long) (byte) 100);
//        java.lang.String str34 = offsetDateTimeField25.getAsText((long) 69);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        int int37 = dateTimeZone35.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay38 = org.joda.time.MonthDay.now(dateTimeZone35);
//        org.joda.time.MonthDay.Property property39 = monthDay38.monthOfYear();
//        org.joda.time.MonthDay monthDay41 = monthDay38.plusMonths(97);
//        org.joda.time.ReadableInterval readableInterval42 = null;
//        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval42);
//        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(chronology43);
//        org.joda.time.MonthDay monthDay46 = monthDay44.minusDays((int) (short) 10);
//        int[] intArray47 = monthDay46.getValues();
//        int int48 = offsetDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay41, intArray47);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52, dateTimeFieldType53);
//        int int56 = delegatedDateTimeField54.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField57 = delegatedDateTimeField54.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, 97);
//        long long62 = offsetDateTimeField59.set((long) 19, 9700);
//        java.lang.String str64 = offsetDateTimeField59.getAsText((long) 57600);
//        int int66 = offsetDateTimeField59.getMaximumValue((long) (byte) 100);
//        java.lang.String str68 = offsetDateTimeField59.getAsText((long) 69);
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.getDefault();
//        int int71 = dateTimeZone69.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay72 = org.joda.time.MonthDay.now(dateTimeZone69);
//        org.joda.time.MonthDay.Property property73 = monthDay72.monthOfYear();
//        org.joda.time.MonthDay monthDay75 = monthDay72.plusMonths(97);
//        org.joda.time.ReadableInterval readableInterval76 = null;
//        org.joda.time.Chronology chronology77 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval76);
//        org.joda.time.MonthDay monthDay78 = new org.joda.time.MonthDay(chronology77);
//        org.joda.time.MonthDay monthDay80 = monthDay78.minusDays((int) (short) 10);
//        int[] intArray81 = monthDay80.getValues();
//        int int82 = offsetDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay75, intArray81);
//        try {
//            int[] intArray84 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) monthDay41, 2000, intArray81, 59958);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2000");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28740010L) + "'", long11 == (-28740010L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-53174879818000L) + "'", long14 == (-53174879818000L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9603019L + "'", long28 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "154" + "'", str30.equals("154"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86496 + "'", int32 == 86496);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "97" + "'", str34.equals("97"));
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(monthDay41);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(monthDay46);
//        org.junit.Assert.assertNotNull(intArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9603019L + "'", long62 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "154" + "'", str64.equals("154"));
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 86496 + "'", int66 == 86496);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "97" + "'", str68.equals("97"));
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 10 + "'", int71 == 10);
//        org.junit.Assert.assertNotNull(monthDay72);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(chronology77);
//        org.junit.Assert.assertNotNull(monthDay80);
//        org.junit.Assert.assertNotNull(intArray81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 97 + "'", int82 == 97);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-28800000), '#', 86399999, 97, (int) (short) 1, false, 86496);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder8.addCutover(28740, '4', 0, 23, (int) (short) 100, false, 59948);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.LocalDateTime localDateTime17 = null;
        boolean boolean18 = fixedDateTimeZone12.isLocalDateTimeGap(localDateTime17);
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime7.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.util.Date date20 = mutableDateTime19.toDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj2 = null;
        jodaTimePermission1.checkGuard(obj2);
        java.lang.String str4 = jodaTimePermission1.toString();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime15);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime8);
        boolean boolean19 = dateTime8.isBefore((-3599948L));
        org.joda.time.DateTimeZone dateTimeZone20 = dateTime8.getZone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("57659", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.days();
//        org.joda.time.DurationField durationField4 = gJChronology2.centuries();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        int int11 = delegatedDateTimeField9.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField12 = delegatedDateTimeField9.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 97);
//        long long17 = offsetDateTimeField14.set((long) 19, 9700);
//        java.lang.String str19 = offsetDateTimeField14.getAsText((long) 57600);
//        int int21 = offsetDateTimeField14.getMaximumValue((long) (byte) 100);
//        java.lang.String str23 = offsetDateTimeField14.getAsText((long) 69);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField14, (-1));
//        java.util.Locale locale26 = null;
//        int int27 = offsetDateTimeField14.getMaximumShortTextLength(locale26);
//        int int29 = offsetDateTimeField14.getMaximumValue((long) '4');
//        int int31 = offsetDateTimeField14.getLeapAmount((-32L));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (-28740052));
//        long long36 = offsetDateTimeField14.addWrapField((-1L), 0);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9603019L + "'", long17 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "154" + "'", str19.equals("154"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86496 + "'", int21 == 86496);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "97" + "'", str23.equals("97"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86496 + "'", int29 == 86496);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.days();
//        org.joda.time.DurationField durationField4 = gJChronology2.centuries();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        int int11 = delegatedDateTimeField9.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField12 = delegatedDateTimeField9.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 97);
//        long long17 = offsetDateTimeField14.set((long) 19, 9700);
//        java.lang.String str19 = offsetDateTimeField14.getAsText((long) 57600);
//        int int21 = offsetDateTimeField14.getMaximumValue((long) (byte) 100);
//        java.lang.String str23 = offsetDateTimeField14.getAsText((long) 69);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField14, (-1));
//        java.util.Locale locale26 = null;
//        int int27 = offsetDateTimeField14.getMaximumShortTextLength(locale26);
//        int int29 = offsetDateTimeField14.getMaximumValue((long) '4');
//        int int31 = offsetDateTimeField14.getLeapAmount((-32L));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (-28740052));
//        org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.now();
//        java.lang.String str36 = monthDay34.toString("+00:00:00.010");
//        org.joda.time.ReadableInterval readableInterval38 = null;
//        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval38);
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(chronology39);
//        org.joda.time.MonthDay monthDay42 = monthDay40.minusDays((int) (short) 10);
//        int[] intArray43 = monthDay42.getValues();
//        java.util.Locale locale45 = null;
//        try {
//            int[] intArray46 = offsetDateTimeField14.set((org.joda.time.ReadablePartial) monthDay34, (int) (short) 10, intArray43, "14", locale45);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 14 for secondOfDay must be in the range [97,86496]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9603019L + "'", long17 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "154" + "'", str19.equals("154"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86496 + "'", int21 == 86496);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "97" + "'", str23.equals("97"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86496 + "'", int29 == 86496);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(monthDay34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00:00.010" + "'", str36.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(intArray43);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        long long4 = dateTime1.getMillis();
//        org.joda.time.DateTime dateTime5 = dateTime1.withLaterOffsetAtOverlap();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
//        int int12 = delegatedDateTimeField10.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField13 = delegatedDateTimeField10.getWrappedField();
//        long long15 = delegatedDateTimeField10.roundFloor((long) 15);
//        long long17 = delegatedDateTimeField10.roundCeiling((-28740062L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField10.getType();
//        org.joda.time.DateTime dateTime20 = dateTime1.withField(dateTimeFieldType18, 0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-10L) + "'", long15 == (-10L));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28740010L) + "'", long17 == (-28740010L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.Instant instant4 = gJChronology2.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        boolean boolean11 = property6.equals((java.lang.Object) monthDay10);
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = monthDay10.toString("", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone2);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        java.lang.String str7 = property6.getName();
//        java.lang.String str8 = property6.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property6.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType9, 2000, 86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder1.appendTwoDigitYear(86496, true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean11 = dateTime9.isAfter(0L);
        org.joda.time.DateTime.Property property12 = dateTime9.centuryOfEra();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DurationField durationField20 = property6.getRangeDurationField();
        org.joda.time.DateTime dateTime21 = property6.withMaximumValue();
        org.joda.time.DateTime dateTime22 = property6.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = property6.addWrapFieldToCopy(9700);
        org.joda.time.DateTime dateTime22 = property6.roundFloorCopy();
        int int23 = property6.getMaximumValueOverall();
        try {
            org.joda.time.DateTime dateTime25 = property6.setCopy("2000");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 59 + "'", int23 == 59);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getLeapDurationField();
//        long long15 = offsetDateTimeField9.roundHalfCeiling((long) (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28800010L) + "'", long15 == (-28800010L));
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        int int15 = offsetDateTimeField9.getDifference((-10L), (long) (short) -1);
//        int int17 = offsetDateTimeField9.get((long) 69);
//        long long20 = offsetDateTimeField9.add((long) (short) -1, (int) (short) 10);
//        org.joda.time.DurationField durationField21 = offsetDateTimeField9.getDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9999L + "'", long20 == 9999L);
//        org.junit.Assert.assertNotNull(durationField21);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.days();
//        org.joda.time.DurationField durationField4 = gJChronology2.centuries();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        int int11 = delegatedDateTimeField9.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField12 = delegatedDateTimeField9.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 97);
//        long long17 = offsetDateTimeField14.set((long) 19, 9700);
//        java.lang.String str19 = offsetDateTimeField14.getAsText((long) 57600);
//        int int21 = offsetDateTimeField14.getMaximumValue((long) (byte) 100);
//        java.lang.String str23 = offsetDateTimeField14.getAsText((long) 69);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField14, (-1));
//        int int27 = skipDateTimeField25.get(9L);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9603019L + "'", long17 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "154" + "'", str19.equals("154"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86496 + "'", int21 == 86496);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "97" + "'", str23.equals("97"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime3.minus(readableDuration15);
        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfMonth(6);
        org.joda.time.DateTime dateTime19 = dateTime18.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 4, dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.minuteOfHour();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.DateTime dateTime6 = property3.setCopy("CopticChronology[]", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean19 = dateTime17.equals((java.lang.Object) dateTimeFormatter18);
        org.joda.time.DateTime.Property property20 = dateTime17.minuteOfHour();
        org.joda.time.DateTime dateTime21 = property20.roundCeilingCopy();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = localTime13.toDateTime((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology25 = dateTime24.getChronology();
        boolean boolean26 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime28 = dateTime7.minusWeeks(2000);
        org.joda.time.DateMidnight dateMidnight29 = dateTime7.toDateMidnight();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) '4');
        boolean boolean32 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime31);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localTime13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateMidnight29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        java.lang.String str5 = property4.getAsShortText();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        int int19 = property4.getDifference((org.joda.time.ReadableInstant) dateTime18);
        try {
            org.joda.time.DateTime dateTime21 = property4.setCopy("12/31/69");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"12/31/69\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        int int11 = delegatedDateTimeField9.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField12 = delegatedDateTimeField9.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 97);
//        long long17 = offsetDateTimeField14.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime21 = dateTime19.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
//        int int24 = localTime22.indexOf(dateTimeFieldType23);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime28 = dateTime26.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime29 = dateTime28.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
//        int int31 = localTime29.indexOf(dateTimeFieldType30);
//        boolean boolean32 = localTime22.isBefore((org.joda.time.ReadablePartial) localTime29);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = offsetDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localTime29, 19, locale34);
//        long long37 = gJChronology2.set((org.joda.time.ReadablePartial) localTime29, 9L);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localTime22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localTime29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "19" + "'", str35.equals("19"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 82800052L + "'", long37 == 82800052L);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime.Property property13 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime14 = property13.roundCeilingCopy();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone20 = fixedDateTimeZone19.toTimeZone();
        java.lang.String str22 = fixedDateTimeZone19.getName((long) 10);
        java.util.TimeZone timeZone23 = fixedDateTimeZone19.toTimeZone();
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = fixedDateTimeZone19.isLocalDateTimeGap(localDateTime24);
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime14.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTime dateTime29 = dateTime3.plusYears((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.010" + "'", str22.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.minuteOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        java.lang.Class<?> wildcardClass14 = gregorianChronology12.getClass();
        org.joda.time.DurationField durationField15 = gregorianChronology12.days();
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime6.toMutableDateTime((org.joda.time.Chronology) gregorianChronology12);
        try {
            long long24 = gregorianChronology12.getDateTimeMillis((int) (short) 1, 69, (int) (short) 10, (-1), 10, 19, 83940062);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        int int17 = dateTimeZone15.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone15);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        java.lang.String str20 = property19.getName();
//        java.lang.String str21 = property19.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType22, 9700);
//        int int25 = dateTime8.get(dateTimeFieldType22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType22, 2000, 69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(59948);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "dayOfMonth" + "'", str20.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfSecond(48, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str15 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        try {
            long long22 = zonedChronology16.getDateTimeMillis((-28740010L), (-28740052), 0, (-28800000), 86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28740052 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfDay();
//        java.lang.String str4 = gJChronology2.toString();
//        org.joda.time.DurationField durationField5 = gJChronology2.hours();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[]" + "'", str4.equals("GJChronology[]"));
//        org.junit.Assert.assertNotNull(durationField5);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime15);
        org.joda.time.DateTime dateTime17 = dateTime1.withFields((org.joda.time.ReadablePartial) localTime15);
        org.joda.time.DateTime dateTime19 = dateTime1.withYearOfCentury(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
//        org.joda.time.DurationField durationField5 = gJChronology2.hours();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
//        long long12 = gJChronology2.set((org.joda.time.ReadablePartial) localTime10, 52L);
//        boolean boolean13 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime10);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localTime10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 82800052L + "'", long12 == 82800052L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime3.hourOfDay();
        org.joda.time.DurationField durationField12 = property11.getDurationField();
        org.joda.time.DurationField durationField13 = property11.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        boolean boolean4 = jodaTimePermission1.equals((java.lang.Object) (byte) 100);
        java.security.Permission permission5 = null;
        boolean boolean6 = jodaTimePermission1.implies(permission5);
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime12 = dateTime9.withTimeAtStartOfDay();
        long long13 = dateTime9.getMillis();
        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) dateTime9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(permissionCollection7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours((int) (short) -1);
        int int5 = dateTime4.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime4.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = dateTime4.isSupported(dateTimeFieldType12);
        org.joda.time.DateTime dateTime15 = dateTime4.plusMillis(0);
        org.joda.time.ReadableDateTime readableDateTime16 = null;
        try {
            org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime4, readableDateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        java.lang.Class<?> wildcardClass2 = gregorianChronology0.getClass();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType6);
//        int int9 = delegatedDateTimeField7.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField10 = delegatedDateTimeField7.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 97);
//        long long15 = offsetDateTimeField12.set((long) 19, 9700);
//        java.lang.String str17 = offsetDateTimeField12.getAsText((long) 57600);
//        int int19 = offsetDateTimeField12.getMaximumValue((long) (byte) 100);
//        java.lang.String str21 = offsetDateTimeField12.getAsText((long) 69);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        int int24 = dateTimeZone22.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now(dateTimeZone22);
//        org.joda.time.MonthDay.Property property26 = monthDay25.monthOfYear();
//        org.joda.time.MonthDay monthDay28 = monthDay25.plusMonths(97);
//        org.joda.time.ReadableInterval readableInterval29 = null;
//        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval29);
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay(chronology30);
//        org.joda.time.MonthDay monthDay33 = monthDay31.minusDays((int) (short) 10);
//        int[] intArray34 = monthDay33.getValues();
//        int int35 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay28, intArray34);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField12, (int) (byte) -1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9603019L + "'", long15 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "154" + "'", str17.equals("154"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 86496 + "'", int19 == 86496);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "97" + "'", str21.equals("97"));
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(chronology30);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertNotNull(intArray34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 97 + "'", int35 == 97);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "JulianChronology[]", "weekOfWeekyear");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "19", "org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMinutes(19);
        org.joda.time.DateTime.Property property9 = dateTime3.centuryOfEra();
        java.lang.Class<?> wildcardClass10 = property9.getClass();
        int int11 = property9.get();
        org.joda.time.DateTime dateTime12 = property9.withMinimumValue();
        int int13 = property9.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder4.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMillisOfDay(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField4.getType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10, (java.lang.Number) (short) 0, (java.lang.Number) 1990L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
//        java.util.Locale locale10 = null;
//        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
//        int int13 = delegatedDateTimeField4.getLeapAmount((long) (short) 10);
//        java.lang.String str15 = delegatedDateTimeField4.getAsText(0L);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        int int22 = localTime20.indexOf(dateTimeFieldType21);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime26 = dateTime24.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
//        int int29 = localTime27.indexOf(dateTimeFieldType28);
//        boolean boolean30 = localTime20.isBefore((org.joda.time.ReadablePartial) localTime27);
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology32.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34, dateTimeFieldType35);
//        int int38 = delegatedDateTimeField36.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField39 = delegatedDateTimeField36.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 97);
//        long long44 = offsetDateTimeField41.getDifferenceAsLong((long) 10, (long) 59);
//        int int46 = offsetDateTimeField41.getMaximumValue(9602990L);
//        org.joda.time.MonthDay monthDay47 = org.joda.time.MonthDay.now();
//        java.lang.String str49 = monthDay47.toString("+00:00:00.010");
//        org.joda.time.MonthDay monthDay51 = monthDay47.plusDays((int) (byte) 0);
//        org.joda.time.ReadableInterval readableInterval53 = null;
//        org.joda.time.Chronology chronology54 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval53);
//        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay(chronology54);
//        org.joda.time.MonthDay monthDay57 = monthDay55.minusDays((int) (short) 10);
//        int[] intArray58 = monthDay57.getValues();
//        int[] intArray60 = offsetDateTimeField41.add((org.joda.time.ReadablePartial) monthDay47, 57600, intArray58, 0);
//        try {
//            int[] intArray62 = delegatedDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localTime20, 19, intArray60, 31);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localTime20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 86496 + "'", int46 == 86496);
//        org.junit.Assert.assertNotNull(monthDay47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+00:00:00.010" + "'", str49.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertNotNull(chronology54);
//        org.junit.Assert.assertNotNull(monthDay57);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertNotNull(intArray60);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
//        org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) dateTime1);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekyear();
//        int int7 = dateTime1.getYearOfCentury();
//        org.joda.time.DateTime dateTime9 = dateTime1.plusMillis(15);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 70 + "'", int7 == 70);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.plus(readableDuration6);
        org.joda.time.Instant instant9 = instant5.plus((long) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        java.lang.String str17 = fixedDateTimeZone14.getName((long) 10);
        java.util.TimeZone timeZone18 = fixedDateTimeZone14.toTimeZone();
        long long21 = fixedDateTimeZone14.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime22 = instant9.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        int int23 = dateTime22.getMillisOfDay();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.010" + "'", str17.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 11 + "'", int23 == 11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.append(dateTimePrinter5, dateTimeParser6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter2.parseLocalDateTime("+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra((int) ' ');
        java.util.GregorianCalendar gregorianCalendar7 = dateTime1.toGregorianCalendar();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar7);
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar7);
        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        int int11 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone17 = fixedDateTimeZone16.toTimeZone();
        org.joda.time.Chronology chronology18 = gregorianChronology9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int20 = fixedDateTimeZone16.getOffsetFromLocal((long) 69);
        org.joda.time.DateTime dateTime21 = dateTime7.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = dateTime16.getMinuteOfHour();
        int int19 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime16);
        boolean boolean20 = dateTime16.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        long long9 = delegatedDateTimeField4.roundFloor((long) 15);
//        boolean boolean10 = delegatedDateTimeField4.isLenient();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        int int12 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime.Property property13 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime15 = property13.addToCopy(67);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str11 = fixedDateTimeZone10.toString();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0, 51, 23, 83940062, 69, 69, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83940062 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getMaximumValue(9999L);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime14 = dateTime13.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        int int16 = localTime14.indexOf(dateTimeFieldType15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime14, 69, locale18);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localTime14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "69" + "'", str19.equals("69"));
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        boolean boolean13 = offsetDateTimeField9.isLenient();
//        long long15 = offsetDateTimeField9.roundCeiling((-28740010L));
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now(dateTimeZone16);
//        org.joda.time.MonthDay.Property property20 = monthDay19.monthOfYear();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) monthDay19, 59948, locale22);
//        int int24 = offsetDateTimeField9.getOffset();
//        long long26 = offsetDateTimeField9.roundCeiling((long) '4');
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology32.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34, dateTimeFieldType35);
//        int int38 = delegatedDateTimeField36.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField39 = delegatedDateTimeField36.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 97);
//        long long44 = offsetDateTimeField41.getDifferenceAsLong((long) 10, (long) 59);
//        int int46 = offsetDateTimeField41.getMaximumValue(9602990L);
//        org.joda.time.MonthDay monthDay47 = org.joda.time.MonthDay.now();
//        java.lang.String str49 = monthDay47.toString("+00:00:00.010");
//        org.joda.time.MonthDay monthDay51 = monthDay47.plusDays((int) (byte) 0);
//        org.joda.time.ReadableInterval readableInterval53 = null;
//        org.joda.time.Chronology chronology54 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval53);
//        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay(chronology54);
//        org.joda.time.MonthDay monthDay57 = monthDay55.minusDays((int) (short) 10);
//        int[] intArray58 = monthDay57.getValues();
//        int[] intArray60 = offsetDateTimeField41.add((org.joda.time.ReadablePartial) monthDay47, 57600, intArray58, 0);
//        try {
//            int[] intArray62 = offsetDateTimeField9.set((org.joda.time.ReadablePartial) monthDay30, (-1), intArray60, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for secondOfDay must be in the range [97,86496]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28740010L) + "'", long15 == (-28740010L));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59948" + "'", str23.equals("59948"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 97 + "'", int24 == 97);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 990L + "'", long26 == 990L);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 86496 + "'", int46 == 86496);
//        org.junit.Assert.assertNotNull(monthDay47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "+00:00:00.010" + "'", str49.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertNotNull(chronology54);
//        org.junit.Assert.assertNotNull(monthDay57);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertNotNull(intArray60);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.era();
        org.joda.time.DurationField durationField7 = gJChronology4.hours();
        org.joda.time.DurationField durationField8 = gJChronology4.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        java.lang.String str16 = fixedDateTimeZone13.getName((long) 10);
        java.util.TimeZone timeZone17 = fixedDateTimeZone13.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.monthOfYear();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.era();
        org.joda.time.DurationField durationField26 = gJChronology23.hours();
        org.joda.time.DurationField durationField27 = gJChronology23.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone33 = fixedDateTimeZone32.toTimeZone();
        java.lang.String str35 = fixedDateTimeZone32.getName((long) 10);
        java.util.TimeZone timeZone36 = fixedDateTimeZone32.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology23, (org.joda.time.DateTimeZone) fixedDateTimeZone32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        long long41 = fixedDateTimeZone32.convertLocalToUTC((long) (-28740052), false);
        long long44 = fixedDateTimeZone32.adjustOffset(0L, true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        int int48 = fixedDateTimeZone32.getOffset(59L);
        java.util.TimeZone timeZone49 = fixedDateTimeZone32.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.010" + "'", str16.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.010" + "'", str35.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(zonedChronology37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-28740062L) + "'", long41 == (-28740062L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
        org.junit.Assert.assertNotNull(timeZone49);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str2 = monthDay0.toString("+00:00:00.010");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
        org.joda.time.MonthDay monthDay6 = monthDay0.withChronologyRetainFields((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay monthDay8 = monthDay6.withDayOfMonth((int) (short) 1);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.010" + "'", str2.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("weekOfWeekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"weekOfWeekyear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        long long42 = remainderDateTimeField39.roundHalfEven(86399990L);
//        long long44 = remainderDateTimeField39.roundCeiling((long) 1380);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField39);
//        org.joda.time.DurationField durationField46 = delegatedDateTimeField45.getDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1990L + "'", long44 == 1990L);
//        org.junit.Assert.assertNotNull(durationField46);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 3200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 3200");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        org.joda.time.Chronology chronology7 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int8 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField9 = julianChronology0.days();
        try {
            long long17 = julianChronology0.getDateTimeMillis(100, 8, 1380, 96736, 97, 86496, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 96736 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        try {
            long long11 = julianChronology0.getDateTimeMillis(1, (-2), (-2), 3200, 5, (-2), 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(82800052L, (long) 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 745200468 + "'", int2 == 745200468);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
//        int int7 = delegatedDateTimeField5.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField5.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 97);
//        long long13 = offsetDateTimeField10.getDifferenceAsLong((long) 10, (long) 59);
//        boolean boolean14 = offsetDateTimeField10.isLenient();
//        long long16 = offsetDateTimeField10.roundCeiling((-28740010L));
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        int int19 = dateTimeZone17.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone17);
//        org.joda.time.MonthDay.Property property21 = monthDay20.monthOfYear();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField10.getAsText((org.joda.time.ReadablePartial) monthDay20, 59948, locale23);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime28 = dateTime26.plusHours((int) (short) -1);
//        int int29 = dateTime28.getSecondOfMinute();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime28.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime28.hourOfDay();
//        org.joda.time.DateTime dateTime37 = dateTime28.withLaterOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap39 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendTimeZoneShortName(strMap39);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder38.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap44 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendTimeZoneShortName(strMap44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder43.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
//        int int50 = dateTimeZone48.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay51 = org.joda.time.MonthDay.now(dateTimeZone48);
//        org.joda.time.MonthDay.Property property52 = monthDay51.dayOfMonth();
//        java.lang.String str53 = property52.getName();
//        java.lang.String str54 = property52.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property52.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder43.appendSignedDecimal(dateTimeFieldType55, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder42.appendFixedDecimal(dateTimeFieldType55, 23);
//        boolean boolean61 = dateTime37.isSupported(dateTimeFieldType55);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType55, (int) (short) 1, 86496, 3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField66 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField10);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-28740010L) + "'", long16 == (-28740010L));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "59948" + "'", str24.equals("59948"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 10 + "'", int50 == 10);
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "dayOfMonth" + "'", str53.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1" + "'", str54.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getLeapDurationField();
        long long16 = offsetDateTimeField9.add(0L, 3200);
        org.joda.time.DurationField durationField17 = offsetDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3200000L + "'", long16 == 3200000L);
        org.junit.Assert.assertNull(durationField17);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        int int8 = delegatedDateTimeField6.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField6.getWrappedField();
        boolean boolean10 = delegatedDateTimeField6.isSupported();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6, (int) 'a');
        long long15 = delegatedDateTimeField6.add((-10L), (-28740052));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28740052010L) + "'", long15 == (-28740052010L));
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.centuryOfEra();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
//        int int10 = delegatedDateTimeField8.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField11 = delegatedDateTimeField8.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 97);
//        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 10, (long) 59);
//        int int18 = offsetDateTimeField13.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime22 = dateTime20.plusHours((int) (short) -1);
//        int int23 = dateTime22.getSecondOfMinute();
//        org.joda.time.DateTime dateTime25 = dateTime22.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime27 = dateTime25.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        int int34 = dateTimeZone32.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now(dateTimeZone32);
//        org.joda.time.MonthDay.Property property36 = monthDay35.dayOfMonth();
//        java.lang.String str37 = property36.getName();
//        java.lang.String str38 = property36.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder29.appendFixedSignedDecimal(dateTimeFieldType39, 9700);
//        int int42 = dateTime25.get(dateTimeFieldType39);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType39, 23);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType39);
//        try {
//            org.joda.time.Instant instant46 = new org.joda.time.Instant((java.lang.Object) dateTimeField3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86496 + "'", int18 == 86496);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "dayOfMonth" + "'", str37.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1" + "'", str38.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 31 + "'", int42 == 31);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        long long42 = remainderDateTimeField39.roundHalfEven(86399990L);
//        long long44 = remainderDateTimeField39.roundCeiling((long) 1380);
//        org.joda.time.DurationField durationField45 = remainderDateTimeField39.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1990L + "'", long44 == 1990L);
//        org.junit.Assert.assertNotNull(durationField45);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType2, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((-2));
        org.joda.time.DateTime.Property property15 = dateTime12.weekOfWeekyear();
        org.joda.time.DurationField durationField16 = property15.getDurationField();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(durationField16);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        java.lang.String str2 = copticChronology0.toString();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        java.util.TimeZone timeZone8 = fixedDateTimeZone7.toTimeZone();
//        java.lang.String str10 = fixedDateTimeZone7.getName((long) 10);
//        boolean boolean11 = fixedDateTimeZone7.isFixed();
//        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.Chronology chronology13 = copticChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[]" + "'", str2.equals("CopticChronology[]"));
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.010" + "'", str10.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(chronology13);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.secondOfDay();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(10, 86399999, 100, 8, (-28740052), 0, 97, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28740052 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        java.lang.String str7 = property6.getAsText();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.minusYears(48);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        java.lang.String str6 = property4.getAsString();
//        int int7 = property4.getMaximumValueOverall();
//        org.joda.time.MonthDay monthDay9 = property4.addToCopy((-32));
//        try {
//            java.lang.String str11 = monthDay9.toString("(\"org.joda.time.JodaTimePermission\" \"hi!\")");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
//        org.junit.Assert.assertNotNull(monthDay9);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("Property[dayOfMonth]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported", 4, (int) (byte) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported must be in the range [100,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
//        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
//        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
//        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime22 = property8.roundHalfFloorCopy();
//        long long23 = property8.remainder();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone14);
//        org.joda.time.MonthDay.Property property18 = monthDay17.dayOfMonth();
//        java.lang.String str19 = property18.getName();
//        java.lang.String str20 = property18.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType21, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder8.appendFixedDecimal(dateTimeFieldType21, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType21, 59938);
//        long long31 = dividedDateTimeField28.set((-3599010L), 0);
//        int int34 = dividedDateTimeField28.getDifference((long) (-1), (-28740062L));
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-3599010L) + "'", long31 == (-3599010L));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.Chronology chronology3 = iSOChronology1.withUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(52L, chronology3);
        org.joda.time.DateTime.Property property5 = dateTime4.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-53174879818000L), (java.lang.Number) (-3104L), (java.lang.Number) (-3599958L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        int int7 = property6.getMaximumValue();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property6.getAsShortText(locale8);
        try {
            org.joda.time.DateTime dateTime11 = property6.setCopy("millisOfSecond");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"millisOfSecond\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
//        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
//        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
//        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime23 = property8.setCopy(1);
//        org.joda.time.DateTime dateTime25 = property8.setCopy("19");
//        boolean boolean26 = property8.isLeap();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
        int int5 = gJChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.era();
//        org.joda.time.Instant instant11 = gJChronology8.getGregorianCutover();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.Instant instant13 = instant11.minus(readableDuration12);
//        org.joda.time.Instant instant15 = instant13.plus((long) 59948);
//        int int16 = property4.compareTo((org.joda.time.ReadableInstant) instant15);
//        int int17 = property4.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant13);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str15 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        try {
            long long21 = zonedChronology16.getDateTimeMillis(48, 6, 59958, 746);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59958 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str5 = fixedDateTimeZone4.toString();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property4 = dateTime3.year();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime9 = dateTime6.withTimeAtStartOfDay();
//        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.Interval interval11 = property4.toInterval();
//        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval11);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(interval11);
//        org.junit.Assert.assertNotNull(readableInterval12);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getRangeDurationField();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = delegatedDateTimeField4.getAsShortText((long) 8, locale9);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(82800052L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 82800062L + "'", long2 == 82800062L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((-2));
        int int15 = dateTime14.getDayOfWeek();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        long long18 = dateTime16.getMillis();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology24 = limitChronology22.withZone(dateTimeZone23);
//        try {
//            long long32 = limitChronology22.getDateTimeMillis(51, 0, (int) '#', 746, 86496, (int) (byte) 1, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 746 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneName();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        int int7 = dateTimeZone5.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone5);
//        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
//        java.lang.String str10 = property9.getName();
//        java.lang.String str11 = property9.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendSignedDecimal(dateTimeFieldType12, 2000, 86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType12, 57600);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendWeekOfWeekyear((int) '#');
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "dayOfMonth" + "'", str10.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone8 = fixedDateTimeZone7.toTimeZone();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.String str10 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay(2);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendTimeZoneOffset("����-��-��", false, 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        java.lang.String str6 = property4.getAsString();
//        org.joda.time.DurationField durationField7 = property4.getDurationField();
//        java.lang.String str8 = property4.getName();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfMonth" + "'", str8.equals("dayOfMonth"));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        long long11 = copticChronology3.getDateTimeMillis((int) (byte) 1, 4, 19, 0, 3, 0, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology3.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-53174879820000L) + "'", long11 == (-53174879820000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((-1L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay((int) (byte) 0);
        org.joda.time.DateTime dateTime15 = dateTime11.withMillis((-28740062L));
        org.joda.time.DateTime dateTime17 = dateTime15.withEra(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendPattern("12/31/69");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-28800000), '#', 86399999, 97, (int) (short) 1, false, 86496);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("59948", (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTimeZoneBuilder0.toDateTimeZone("Property[dayOfMonth]", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj7 = null;
        jodaTimePermission6.checkGuard(obj7);
        java.lang.String str9 = jodaTimePermission6.toString();
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj12 = null;
        jodaTimePermission11.checkGuard(obj12);
        java.lang.String str14 = jodaTimePermission11.toString();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean20 = dateTime18.equals((java.lang.Object) dateTimeFormatter19);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime24 = dateTime22.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime25 = dateTime24.toLocalTime();
        org.joda.time.DateTime dateTime26 = dateTime18.withFields((org.joda.time.ReadablePartial) localTime25);
        jodaTimePermission11.checkGuard((java.lang.Object) dateTime18);
        boolean boolean28 = jodaTimePermission6.equals((java.lang.Object) jodaTimePermission11);
        boolean boolean29 = julianChronology4.equals((java.lang.Object) jodaTimePermission11);
        boolean boolean30 = jodaTimePermission1.equals((java.lang.Object) julianChronology4);
        try {
            long long35 = julianChronology4.getDateTimeMillis((int) '#', 59948, 1380, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59948 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str9.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str14.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 96736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9383392 + "'", int2 == 9383392);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        int int15 = offsetDateTimeField9.getDifference((-10L), (long) (short) -1);
//        int int17 = offsetDateTimeField9.get((long) 69);
//        int int19 = offsetDateTimeField9.getLeapAmount(9L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getLeapDurationField();
        long long16 = offsetDateTimeField9.add((long) 6, 31148031L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31148031006L + "'", long16 == 31148031006L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        int int15 = offsetDateTimeField9.getDifference((-10L), (long) (short) -1);
//        int int17 = offsetDateTimeField9.get((long) 69);
//        long long20 = offsetDateTimeField9.add((long) (short) -1, (int) (short) 10);
//        org.joda.time.DurationField durationField21 = offsetDateTimeField9.getLeapDurationField();
//        java.util.Locale locale24 = null;
//        try {
//            long long25 = offsetDateTimeField9.set((long) 24, "12/31/69", locale24);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"12/31/69\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9999L + "'", long20 == 9999L);
//        org.junit.Assert.assertNull(durationField21);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "dayOfMonth" + "'", str4.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported"));
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        long long42 = remainderDateTimeField39.roundHalfFloor((long) 86399999);
//        long long44 = remainderDateTimeField39.roundHalfFloor((-10L));
//        long long46 = remainderDateTimeField39.roundCeiling((-3104L));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-10L) + "'", long44 == (-10L));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-3010L) + "'", long46 == (-3010L));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.Instant instant7 = instant5.minus((long) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime8 = instant7.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        long long7 = delegatedDateTimeField4.getDifferenceAsLong((long) (short) 1, (-10L));
//        int int10 = delegatedDateTimeField4.getDifference(0L, (long) (short) 10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean21 = dateTime19.equals((java.lang.Object) dateTimeFormatter20);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime25 = dateTime23.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
//        org.joda.time.DateTime dateTime27 = dateTime19.withFields((org.joda.time.ReadablePartial) localTime26);
//        org.joda.time.DateTimeField dateTimeField29 = localTime26.getField(0);
//        boolean boolean30 = localTime15.isAfter((org.joda.time.ReadablePartial) localTime26);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) localTime15, 2000, locale32);
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
//        int int40 = delegatedDateTimeField38.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField41 = delegatedDateTimeField38.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 97);
//        long long46 = offsetDateTimeField43.getDifferenceAsLong((long) 10, (long) 59);
//        boolean boolean47 = offsetDateTimeField43.isLenient();
//        long long49 = offsetDateTimeField43.roundCeiling((-28740010L));
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
//        int int52 = dateTimeZone50.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay53 = org.joda.time.MonthDay.now(dateTimeZone50);
//        org.joda.time.MonthDay.Property property54 = monthDay53.monthOfYear();
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = offsetDateTimeField43.getAsText((org.joda.time.ReadablePartial) monthDay53, 59948, locale56);
//        org.joda.time.DateTimeZone dateTimeZone58 = null;
//        org.joda.time.ReadableInstant readableInstant59 = null;
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58, readableInstant59);
//        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap63 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendTimeZoneShortName(strMap63);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder62.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap68 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder69 = dateTimeFormatterBuilder67.appendTimeZoneShortName(strMap68);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder67.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.getDefault();
//        int int74 = dateTimeZone72.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay75 = org.joda.time.MonthDay.now(dateTimeZone72);
//        org.joda.time.MonthDay.Property property76 = monthDay75.dayOfMonth();
//        java.lang.String str77 = property76.getName();
//        java.lang.String str78 = property76.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType79 = property76.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder67.appendSignedDecimal(dateTimeFieldType79, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder84 = dateTimeFormatterBuilder66.appendFixedDecimal(dateTimeFieldType79, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField86 = new org.joda.time.field.DividedDateTimeField(dateTimeField61, dateTimeFieldType79, 59938);
//        org.joda.time.MonthDay.Property property87 = monthDay53.property(dateTimeFieldType79);
//        org.joda.time.ReadableInterval readableInterval89 = null;
//        org.joda.time.Chronology chronology90 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval89);
//        org.joda.time.MonthDay monthDay91 = new org.joda.time.MonthDay(chronology90);
//        org.joda.time.MonthDay monthDay93 = monthDay91.minusDays((int) (short) 10);
//        int[] intArray94 = monthDay93.getValues();
//        java.util.Locale locale96 = null;
//        try {
//            int[] intArray97 = delegatedDateTimeField4.set((org.joda.time.ReadablePartial) monthDay53, 0, intArray94, "154", locale96);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 153");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localTime15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2000" + "'", str33.equals("2000"));
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-28740010L) + "'", long49 == (-28740010L));
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "59948" + "'", str57.equals("59948"));
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertNotNull(dateTimeField61);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder69);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 10 + "'", int74 == 10);
//        org.junit.Assert.assertNotNull(monthDay75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "dayOfMonth" + "'", str77.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "1" + "'", str78.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType79);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder84);
//        org.junit.Assert.assertNotNull(property87);
//        org.junit.Assert.assertNotNull(chronology90);
//        org.junit.Assert.assertNotNull(monthDay93);
//        org.junit.Assert.assertNotNull(intArray94);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime4 = dateTime2.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        java.lang.String str6 = property5.getAsShortText();
//        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean13 = dateTime11.equals((java.lang.Object) dateTimeFormatter12);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        org.joda.time.DateTime dateTime19 = dateTime11.withFields((org.joda.time.ReadablePartial) localTime18);
//        int int20 = property5.getDifference((org.joda.time.ReadableInstant) dateTime19);
//        boolean boolean21 = julianChronology0.equals((java.lang.Object) dateTime19);
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType25);
//        int int28 = delegatedDateTimeField26.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField29 = delegatedDateTimeField26.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 97);
//        long long34 = offsetDateTimeField31.getDifferenceAsLong((long) 10, (long) 59);
//        int int36 = offsetDateTimeField31.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime40 = dateTime38.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime41 = dateTime40.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
//        int int43 = localTime41.indexOf(dateTimeFieldType42);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime47 = dateTime45.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime48 = dateTime47.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        int int50 = localTime48.indexOf(dateTimeFieldType49);
//        boolean boolean51 = localTime41.isBefore((org.joda.time.ReadablePartial) localTime48);
//        int int52 = offsetDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) localTime48);
//        long long55 = offsetDateTimeField31.set((long) 23, (int) (byte) 100);
//        boolean boolean56 = julianChronology0.equals((java.lang.Object) 23);
//        org.joda.time.DateTimeField dateTimeField57 = julianChronology0.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField58 = julianChronology0.monthOfYear();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86496 + "'", int36 == 86496);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localTime41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localTime48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 97 + "'", int52 == 97);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3023L + "'", long55 == 3023L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime.Property property5 = dateTime3.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime3.minus(readableDuration15);
        org.joda.time.DateTime dateTime18 = dateTime16.withDayOfMonth(6);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime16.minus(readableDuration19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str15 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        long long18 = fixedDateTimeZone14.nextTransition((long) 3200);
        try {
            org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14, 83940062);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 83940062");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3200L + "'", long18 == 3200L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        java.lang.String str6 = property5.getAsShortText();
        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean13 = dateTime11.equals((java.lang.Object) dateTimeFormatter12);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
        org.joda.time.DateTime dateTime19 = dateTime11.withFields((org.joda.time.ReadablePartial) localTime18);
        int int20 = property5.getDifference((org.joda.time.ReadableInstant) dateTime19);
        boolean boolean21 = julianChronology0.equals((java.lang.Object) dateTime19);
        org.joda.time.Chronology chronology22 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((-3599948L));
        long long2 = instant1.getMillis();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3599948L) + "'", long2 == (-3599948L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
        java.lang.String str12 = copticChronology10.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean14 = copticChronology10.equals((java.lang.Object) dateTimeFormatter13);
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) boolean9, (org.joda.time.Chronology) copticChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CopticChronology[UTC]" + "'", str12.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.plus(readableDuration6);
        org.joda.time.Instant instant9 = instant5.plus((long) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        java.lang.String str17 = fixedDateTimeZone14.getName((long) 10);
        java.util.TimeZone timeZone18 = fixedDateTimeZone14.toTimeZone();
        long long21 = fixedDateTimeZone14.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime22 = instant9.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTime dateTime23 = dateTime22.toDateTime();
        try {
            org.joda.time.DateTime dateTime25 = dateTime22.withDayOfMonth(67);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 67 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.010" + "'", str17.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(38, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear(2, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        int int17 = dateTimeZone15.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone15);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        java.lang.String str20 = property19.getName();
//        java.lang.String str21 = property19.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType22, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder10.appendFixedSignedDecimal(dateTimeFieldType22, (int) (short) 100);
//        boolean boolean27 = dateTimeFormatterBuilder10.canBuildParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "dayOfMonth" + "'", str20.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
//        int int16 = offsetDateTimeField9.getMaximumValue((long) (byte) 100);
//        org.joda.time.ReadableInterval readableInterval17 = null;
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval17);
//        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(chronology18);
//        org.joda.time.MonthDay monthDay21 = monthDay19.minusDays((int) (short) 10);
//        java.util.Locale locale22 = null;
//        try {
//            java.lang.String str23 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay19, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86496 + "'", int16 == 86496);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(monthDay21);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        long long42 = remainderDateTimeField39.roundHalfEven(86399990L);
//        long long44 = remainderDateTimeField39.roundHalfCeiling(32L);
//        long long46 = remainderDateTimeField39.roundCeiling((long) 28740);
//        long long48 = remainderDateTimeField39.roundHalfEven(0L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-10L) + "'", long44 == (-10L));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 28990L + "'", long46 == 28990L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-10L) + "'", long48 == (-10L));
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        long long14 = offsetDateTimeField9.roundFloor(10L);
//        int int16 = offsetDateTimeField9.getLeapAmount((long) (-1));
//        long long18 = offsetDateTimeField9.roundHalfFloor((long) 8);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-10L) + "'", long14 == (-10L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-28800000), '#', 86399999, 97, (int) (short) 1, false, 86496);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder0.writeTo("DateTimeField[dayOfMonth]", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DurationField durationField3 = gJChronology2.days();
//        org.joda.time.DurationField durationField4 = gJChronology2.centuries();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        int int11 = delegatedDateTimeField9.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField12 = delegatedDateTimeField9.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 97);
//        long long17 = offsetDateTimeField14.set((long) 19, 9700);
//        java.lang.String str19 = offsetDateTimeField14.getAsText((long) 57600);
//        int int21 = offsetDateTimeField14.getMaximumValue((long) (byte) 100);
//        java.lang.String str23 = offsetDateTimeField14.getAsText((long) 69);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField14, (-1));
//        java.util.Locale locale26 = null;
//        int int27 = offsetDateTimeField14.getMaximumShortTextLength(locale26);
//        int int29 = offsetDateTimeField14.getMaximumValue((long) '4');
//        int int31 = offsetDateTimeField14.getLeapAmount((-32L));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, (-28740052));
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = gJChronology34.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField36 = gJChronology34.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
//        int int40 = delegatedDateTimeField38.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField41 = delegatedDateTimeField38.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, 97);
//        long long46 = offsetDateTimeField43.set((long) 19, 9700);
//        java.lang.String str48 = offsetDateTimeField43.getAsText((long) 57600);
//        int int50 = offsetDateTimeField43.getMaximumValue((long) (byte) 100);
//        java.lang.String str52 = offsetDateTimeField43.getAsText((long) 69);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        java.util.Locale locale54 = dateTimeFormatter53.getLocale();
//        org.joda.time.LocalTime localTime56 = dateTimeFormatter53.parseLocalTime("1");
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = offsetDateTimeField43.getAsShortText((org.joda.time.ReadablePartial) localTime56, locale57);
//        int[] intArray59 = null;
//        int int60 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localTime56, intArray59);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9603019L + "'", long17 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "154" + "'", str19.equals("154"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86496 + "'", int21 == 86496);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "97" + "'", str23.equals("97"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86496 + "'", int29 == 86496);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9603019L + "'", long46 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "154" + "'", str48.equals("154"));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 86496 + "'", int50 == 86496);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "97" + "'", str52.equals("97"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNull(locale54);
//        org.junit.Assert.assertNotNull(localTime56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 86496 + "'", int60 == 86496);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        java.lang.String str5 = property4.getAsShortText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str15 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.Chronology chronology23 = zonedChronology16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(zonedChronology8);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        long long14 = offsetDateTimeField9.roundHalfCeiling(85496L);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType18);
//        int int21 = delegatedDateTimeField19.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField22 = delegatedDateTimeField19.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, 97);
//        long long27 = offsetDateTimeField24.getDifferenceAsLong((long) 10, (long) 59);
//        int int29 = offsetDateTimeField24.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime33 = dateTime31.plusHours((int) (short) -1);
//        int int34 = dateTime33.getSecondOfMinute();
//        org.joda.time.DateTime dateTime36 = dateTime33.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime38 = dateTime36.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder39.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
//        int int45 = dateTimeZone43.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now(dateTimeZone43);
//        org.joda.time.MonthDay.Property property47 = monthDay46.dayOfMonth();
//        java.lang.String str48 = property47.getName();
//        java.lang.String str49 = property47.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property47.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder40.appendFixedSignedDecimal(dateTimeFieldType50, 9700);
//        int int53 = dateTime36.get(dateTimeFieldType50);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24, dateTimeFieldType50, 23);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType50, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 85990L + "'", long14 == 85990L);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86496 + "'", int29 == 86496);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertNotNull(monthDay46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1" + "'", str49.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 31 + "'", int53 == 31);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        long long18 = dateTime16.getMillis();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
//        try {
//            long long30 = limitChronology22.getDateTimeMillis((-28800000), (int) (byte) 10, 1, (int) (short) 0, 23, 0, (-32));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(limitChronology22);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        int int5 = property4.getMaximumValueOverall();
//        org.joda.time.MonthDay monthDay7 = property4.addToCopy(9700);
//        org.joda.time.MonthDay.Property property8 = monthDay7.monthOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(property8);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone10);
//        org.joda.time.MonthDay.Property property14 = monthDay13.dayOfMonth();
//        java.lang.String str15 = property14.getName();
//        java.lang.String str16 = property14.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType17, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType17, 23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap24 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendTimeZoneShortName(strMap24);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendTimeZoneName();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        int int30 = dateTimeZone28.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now(dateTimeZone28);
//        org.joda.time.MonthDay.Property property32 = monthDay31.dayOfMonth();
//        java.lang.String str33 = property32.getName();
//        java.lang.String str34 = property32.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property32.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder27.appendSignedDecimal(dateTimeFieldType35, 2000, 86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder23.appendFixedSignedDecimal(dateTimeFieldType35, 57600);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder22.appendDecimal(dateTimeFieldType35, 0, 67);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder43.appendLiteral("CopticChronology[UTC]");
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "dayOfMonth" + "'", str33.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        java.lang.String str60 = unsupportedDateTimeField59.getName();
//        try {
//            int int62 = unsupportedDateTimeField59.get(3023L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "dayOfMonth" + "'", str60.equals("dayOfMonth"));
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        int int6 = dateTimeZone4.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone4);
//        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
//        java.lang.String str9 = property8.getName();
//        java.lang.String str10 = property8.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType11, 9700);
//        boolean boolean14 = dateTimeFormatterBuilder13.canBuildParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendTimeZoneId();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap17 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTimeZoneShortName(strMap17);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendTimeZoneName();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        int int23 = dateTimeZone21.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now(dateTimeZone21);
//        org.joda.time.MonthDay.Property property25 = monthDay24.dayOfMonth();
//        java.lang.String str26 = property25.getName();
//        java.lang.String str27 = property25.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder20.appendSignedDecimal(dateTimeFieldType28, 2000, 86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder16.appendFixedSignedDecimal(dateTimeFieldType28, 57600);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType28);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter35.withZoneUTC();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder34.append(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "dayOfMonth" + "'", str26.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1" + "'", str27.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
//        java.util.Locale locale10 = null;
//        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
//        int int13 = delegatedDateTimeField4.getLeapAmount((long) (short) 10);
//        long long15 = delegatedDateTimeField4.roundFloor(9603019L);
//        int int17 = delegatedDateTimeField4.getLeapAmount(2763538052L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9602990L + "'", long15 == 9602990L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) 1380, 69);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1380L + "'", long9 == 1380L);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        long long42 = remainderDateTimeField39.roundHalfEven(86399990L);
//        long long44 = remainderDateTimeField39.roundHalfEven((long) 9383392);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9382990L + "'", long44 == 9382990L);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        int int14 = offsetDateTimeField9.getMaximumValue(9602990L);
        long long17 = offsetDateTimeField9.add((long) '#', 32L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86496 + "'", int14 == 86496);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32035L + "'", long17 == 32035L);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
//        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
//        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
//        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
//        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
//        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime12.minus(readableDuration22);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.centuryOfEra();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
//        int int10 = delegatedDateTimeField8.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField11 = delegatedDateTimeField8.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 97);
//        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 10, (long) 59);
//        int int18 = offsetDateTimeField13.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime22 = dateTime20.plusHours((int) (short) -1);
//        int int23 = dateTime22.getSecondOfMinute();
//        org.joda.time.DateTime dateTime25 = dateTime22.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime27 = dateTime25.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        int int34 = dateTimeZone32.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now(dateTimeZone32);
//        org.joda.time.MonthDay.Property property36 = monthDay35.dayOfMonth();
//        java.lang.String str37 = property36.getName();
//        java.lang.String str38 = property36.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder29.appendFixedSignedDecimal(dateTimeFieldType39, 9700);
//        int int42 = dateTime25.get(dateTimeFieldType39);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType39, 23);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType39);
//        int int46 = delegatedDateTimeField45.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86496 + "'", int18 == 86496);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "dayOfMonth" + "'", str37.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1" + "'", str38.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 31 + "'", int42 == 31);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        boolean boolean11 = property6.equals((java.lang.Object) monthDay10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
        java.lang.String str14 = monthDay12.toString("+00:00:00.010");
        org.joda.time.MonthDay monthDay16 = monthDay12.plusDays((int) (byte) 0);
        boolean boolean17 = monthDay10.isAfter((org.joda.time.ReadablePartial) monthDay12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.010" + "'", str14.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(38, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitYear(2, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendWeekyear(59948, (int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendWeekyear(0, 1380);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay((int) (byte) 0);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean19 = dateTime17.equals((java.lang.Object) dateTimeFormatter18);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
        org.joda.time.DateTime dateTime25 = dateTime17.withFields((org.joda.time.ReadablePartial) localTime24);
        org.joda.time.DateTime dateTime27 = dateTime25.minusDays((int) (byte) 1);
        int int28 = dateTime13.compareTo((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime30 = dateTime13.plus((long) (-59));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean11 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        java.util.Locale locale62 = null;
//        try {
//            long long63 = unsupportedDateTimeField59.set((long) 9700, "--12-31", locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 1, 0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        int int19 = dateTime18.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime18.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime11.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        int int20 = fixedDateTimeZone12.getOffsetFromLocal((long) 97);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        int int14 = offsetDateTimeField9.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
//        int int19 = dateTime18.getSecondOfMinute();
//        org.joda.time.DateTime dateTime21 = dateTime18.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime23 = dateTime21.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        int int30 = dateTimeZone28.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now(dateTimeZone28);
//        org.joda.time.MonthDay.Property property32 = monthDay31.dayOfMonth();
//        java.lang.String str33 = property32.getName();
//        java.lang.String str34 = property32.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property32.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder25.appendFixedSignedDecimal(dateTimeFieldType35, 9700);
//        int int38 = dateTime21.get(dateTimeFieldType35);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType35, 23);
//        org.joda.time.DurationField durationField41 = dividedDateTimeField40.getDurationField();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86496 + "'", int14 == 86496);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(monthDay31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "dayOfMonth" + "'", str33.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
//        org.junit.Assert.assertNotNull(durationField41);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        int int6 = dateTimeZone4.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone4);
//        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
//        java.lang.String str9 = property8.getName();
//        java.lang.String str10 = property8.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType11, 9700);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean20 = dateTime18.equals((java.lang.Object) dateTimeFormatter19);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime24 = dateTime22.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime25 = dateTime24.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        int int27 = localTime25.indexOf(dateTimeFieldType26);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime31 = dateTime29.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        int int34 = localTime32.indexOf(dateTimeFieldType33);
//        boolean boolean35 = localTime25.isBefore((org.joda.time.ReadablePartial) localTime32);
//        java.lang.String str36 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) localTime32);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatter19.getParser();
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder1.append(dateTimePrinter14, dateTimeParser37);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localTime25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localTime32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "����-��-��" + "'", str36.equals("����-��-��"));
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(38, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        int int20 = dateTimeZone18.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone18);
//        org.joda.time.MonthDay.Property property22 = monthDay21.dayOfMonth();
//        java.lang.String str23 = property22.getName();
//        java.lang.String str24 = property22.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property22.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType25, 2, 1380);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "dayOfMonth" + "'", str23.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendSecondOfMinute((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
//        java.lang.String str5 = property4.getAsString();
//        org.joda.time.MonthDay monthDay7 = property4.addToCopy(59938);
//        java.lang.String str8 = property4.getAsText();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "January" + "'", str8.equals("January"));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder4.toPrinter();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean11 = dateTime9.equals((java.lang.Object) dateTimeFormatter10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime16 = dateTime15.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        int int18 = localTime16.indexOf(dateTimeFieldType17);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime22 = dateTime20.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime23 = dateTime22.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        int int25 = localTime23.indexOf(dateTimeFieldType24);
        boolean boolean26 = localTime16.isBefore((org.joda.time.ReadablePartial) localTime23);
        java.lang.String str27 = dateTimeFormatter10.print((org.joda.time.ReadablePartial) localTime23);
        org.joda.time.format.DateTimeParser dateTimeParser28 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localTime16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "����-��-��" + "'", str27.equals("����-��-��"));
        org.junit.Assert.assertNotNull(dateTimeParser28);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj2 = null;
        jodaTimePermission1.checkGuard(obj2);
        java.lang.String str4 = jodaTimePermission1.toString();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime15);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime8);
        boolean boolean19 = dateTime8.isBefore((-3599948L));
        org.joda.time.Instant instant20 = dateTime8.toInstant();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(instant20);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone19 = fixedDateTimeZone18.toTimeZone();
        java.lang.String str21 = fixedDateTimeZone18.getName((long) 10);
        boolean boolean22 = fixedDateTimeZone18.isFixed();
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int[] intArray29 = new int[] { 1, 8, 4, 10, 1380 };
        int int30 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay23, intArray29);
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        java.lang.String str34 = monthDay32.toString("+00:00:00.010");
        org.joda.time.DateTimeField[] dateTimeFieldArray35 = monthDay32.getFields();
        int[] intArray36 = monthDay32.getValues();
        int int37 = offsetDateTimeField9.getMaximumValue(readablePartial31, intArray36);
        long long40 = offsetDateTimeField9.getDifferenceAsLong((-3599948L), (long) 67);
        int int41 = offsetDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.010" + "'", str21.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 97 + "'", int30 == 97);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.010" + "'", str34.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 86496 + "'", int37 == 86496);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-3600L) + "'", long40 == (-3600L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 97 + "'", int41 == 97);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        long long42 = remainderDateTimeField39.roundHalfFloor((long) 86399999);
//        boolean boolean43 = remainderDateTimeField39.isLenient();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str2 = monthDay0.toString("+00:00:00.010");
        org.joda.time.DateTimeField[] dateTimeFieldArray3 = monthDay0.getFields();
        int[] intArray4 = monthDay0.getValues();
        org.joda.time.MonthDay monthDay6 = monthDay0.withMonthOfYear((int) (short) 1);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType8 = monthDay6.getFieldType(51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.010" + "'", str2.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        long long5 = buddhistChronology0.add(62L, (long) 59938, 59948);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3593163286L + "'", long5 == 3593163286L);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        long long18 = dateTime16.getMillis();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
//        org.joda.time.DateTime dateTime24 = dateTime10.minusMillis((int) 'a');
//        try {
//            org.joda.time.DateTime dateTime26 = dateTime24.withYearOfCentury(86399);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean21 = dateTime19.equals((java.lang.Object) dateTimeFormatter20);
        org.joda.time.DateTime.Property property22 = dateTime19.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = localTime15.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime31 = dateTime25.withYearOfEra(12);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime25.minus(readableDuration32);
        org.joda.time.DateTime.Property property34 = dateTime33.millisOfDay();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        java.lang.String str7 = delegatedDateTimeField4.getAsShortText((long) 2000);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[secondOfDay]" + "'", str5.equals("DateTimeField[secondOfDay]"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime7 = dateTime5.plusHours((int) (short) -1);
//        int int8 = dateTime7.getSecondOfMinute();
//        org.joda.time.DateTime dateTime10 = dateTime7.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime10.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        int int19 = dateTimeZone17.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now(dateTimeZone17);
//        org.joda.time.MonthDay.Property property21 = monthDay20.dayOfMonth();
//        java.lang.String str22 = property21.getName();
//        java.lang.String str23 = property21.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property21.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder14.appendFixedSignedDecimal(dateTimeFieldType24, 9700);
//        int int27 = dateTime10.get(dateTimeFieldType24);
//        org.joda.time.MonthDay monthDay29 = monthDay2.withField(dateTimeFieldType24, 8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "dayOfMonth" + "'", str22.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
//        org.junit.Assert.assertNotNull(monthDay29);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.Instant instant6 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gJChronology3.add(readablePeriod7, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str16 = fixedDateTimeZone15.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone23 = fixedDateTimeZone22.toTimeZone();
        java.lang.String str25 = fixedDateTimeZone22.getName((long) 10);
        java.util.TimeZone timeZone26 = fixedDateTimeZone22.toTimeZone();
        boolean boolean27 = fixedDateTimeZone22.isFixed();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.Chronology chronology29 = zonedChronology17.withZone(dateTimeZone28);
        java.lang.String str30 = zonedChronology17.toString();
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((long) 3, (org.joda.time.Chronology) zonedChronology17);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.010" + "'", str25.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "ZonedChronology[GJChronology[UTC], ]" + "'", str30.equals("ZonedChronology[GJChronology[UTC], ]"));
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        long long14 = offsetDateTimeField9.roundFloor(10L);
//        int int16 = offsetDateTimeField9.getLeapAmount((long) (-1));
//        java.util.Locale locale19 = null;
//        try {
//            long long20 = offsetDateTimeField9.set(0L, "org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported", locale19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-10L) + "'", long14 == (-10L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        java.lang.String str12 = delegatedDateTimeField4.getName();
        org.joda.time.ReadableInterval readableInterval13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
        org.joda.time.MonthDay monthDay17 = monthDay15.minusDays((int) (short) 10);
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay15);
        org.joda.time.MonthDay monthDay20 = monthDay15.minusDays(59);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfDay" + "'", str12.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399 + "'", int18 == 86399);
        org.junit.Assert.assertNotNull(monthDay20);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
//        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime16 = dateTime12.plusSeconds((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology18 = iSOChronology17.withUTC();
//        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology17);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime28 = dateTime26.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean30 = dateTime28.equals((java.lang.Object) dateTimeFormatter29);
//        org.joda.time.DateTime.Property property31 = dateTime28.minuteOfHour();
//        org.joda.time.DateTime dateTime32 = property31.roundCeilingCopy();
//        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime dateTime34 = localTime24.toDateTime((org.joda.time.ReadableInstant) dateTime32);
//        org.joda.time.DateTime.Property property35 = dateTime34.weekyear();
//        boolean boolean36 = iSOChronology17.equals((java.lang.Object) property35);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        java.util.TimeZone timeZone42 = fixedDateTimeZone41.toTimeZone();
//        java.lang.String str44 = fixedDateTimeZone41.getName((long) 10);
//        java.util.TimeZone timeZone45 = fixedDateTimeZone41.toTimeZone();
//        long long48 = fixedDateTimeZone41.convertLocalToUTC(0L, true);
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone41);
//        org.joda.time.DateTime dateTime51 = dateTime49.plusMillis((-2));
//        int int52 = property35.getDifference((org.joda.time.ReadableInstant) dateTime51);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localTime4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(localTime24);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "+00:00:00.010" + "'", str44.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-10L) + "'", long48 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.JodaTimePermission jodaTimePermission2 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj3 = null;
        jodaTimePermission2.checkGuard(obj3);
        java.lang.String str5 = jodaTimePermission2.toString();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj8 = null;
        jodaTimePermission7.checkGuard(obj8);
        java.lang.String str10 = jodaTimePermission7.toString();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean16 = dateTime14.equals((java.lang.Object) dateTimeFormatter15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime22 = dateTime14.withFields((org.joda.time.ReadablePartial) localTime21);
        jodaTimePermission7.checkGuard((java.lang.Object) dateTime14);
        boolean boolean24 = jodaTimePermission2.equals((java.lang.Object) jodaTimePermission7);
        boolean boolean25 = julianChronology0.equals((java.lang.Object) jodaTimePermission7);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology0.centuryOfEra();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        try {
            int[] intArray30 = julianChronology0.get(readablePeriod28, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str10.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str15 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(chronology17);
        org.joda.time.MonthDay monthDay20 = monthDay18.minusDays(59948);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = monthDay20.getFieldTypes();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        long long18 = dateTime16.getMillis();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology24 = limitChronology22.withZone(dateTimeZone23);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone26 = dateTimeFormatter25.getZone();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime30 = dateTime28.plusHours((int) (short) -1);
//        int int31 = dateTime30.getSecondOfMinute();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone36 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        org.joda.time.MutableDateTime mutableDateTime37 = dateTime30.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
//        boolean boolean39 = dateTime30.isSupported(dateTimeFieldType38);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        org.joda.time.MutableDateTime mutableDateTime45 = dateTime30.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone44);
//        int int48 = dateTimeFormatter25.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime45, "1970-01-01T00:00:00.000+00:00:00.010", (-28800000));
//        boolean boolean49 = limitChronology22.equals((java.lang.Object) mutableDateTime45);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime45);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-28800000) + "'", int48 == (-28800000));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay9);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 3200);
//        long long9 = offsetDateTimeField7.roundCeiling((long) (short) -1);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[secondOfDay]" + "'", str5.equals("DateTimeField[secondOfDay]"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 990L + "'", long9 == 990L);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.clockhourOfHalfday();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone16 = fixedDateTimeZone15.toTimeZone();
        java.lang.String str18 = fixedDateTimeZone15.getName((long) 10);
        java.util.TimeZone timeZone19 = fixedDateTimeZone15.toTimeZone();
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = fixedDateTimeZone15.isLocalDateTimeGap(localDateTime20);
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime10.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.Chronology chronology23 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.010" + "'", str18.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "6");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.util.TimeZone timeZone19 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str21 = fixedDateTimeZone12.getShortName((-3599948L));
        long long24 = fixedDateTimeZone12.adjustOffset((long) 3200, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.010" + "'", str21.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3200L + "'", long24 == 3200L);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra((int) ' ');
//        java.util.GregorianCalendar gregorianCalendar7 = dateTime1.toGregorianCalendar();
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar7);
//        int[] intArray9 = monthDay8.getValues();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneShortName(strMap11);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder10.appendTwoDigitYear(38, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendTwoDigitYear(2, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        int int27 = dateTimeZone25.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now(dateTimeZone25);
//        org.joda.time.MonthDay.Property property29 = monthDay28.dayOfMonth();
//        java.lang.String str30 = property29.getName();
//        java.lang.String str31 = property29.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property29.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder22.appendFixedSignedDecimal(dateTimeFieldType32, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder20.appendFixedSignedDecimal(dateTimeFieldType32, (int) (short) 100);
//        boolean boolean37 = monthDay8.isSupported(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianCalendar7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "dayOfMonth" + "'", str30.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("0");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"0/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        long long4 = copticChronology0.add((long) (-2), 82800052L, 38);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3146401974L + "'", long4 == 3146401974L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTime dateTime4 = dateTime1.plusYears((int) (byte) 0);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        long long9 = delegatedDateTimeField4.roundFloor((long) 15);
//        long long11 = delegatedDateTimeField4.roundCeiling((-28740062L));
//        long long14 = delegatedDateTimeField4.add((-53174879820000L), 2);
//        int int15 = delegatedDateTimeField4.getMinimumValue();
//        java.util.Locale locale16 = null;
//        int int17 = delegatedDateTimeField4.getMaximumShortTextLength(locale16);
//        long long19 = delegatedDateTimeField4.roundHalfEven((long) 83940062);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28740010L) + "'", long11 == (-28740010L));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-53174879818000L) + "'", long14 == (-53174879818000L));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 83939990L + "'", long19 == 83939990L);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 67, (long) 59);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone2);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        java.lang.String str7 = property6.getName();
//        java.lang.String str8 = property6.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property6.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType9, 2000, 86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder1.appendWeekOfWeekyear(6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
//        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder1.append(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimePrinter16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
//        java.util.Locale locale10 = null;
//        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
//        int int13 = delegatedDateTimeField4.getLeapAmount((long) (short) 10);
//        java.lang.String str15 = delegatedDateTimeField4.getAsText(0L);
//        long long17 = delegatedDateTimeField4.roundFloor(0L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-10L) + "'", long17 == (-10L));
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        int int9 = delegatedDateTimeField4.getMaximumValue(9999L);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone10);
//        org.joda.time.MonthDay.Property property14 = monthDay13.monthOfYear();
//        org.joda.time.MonthDay monthDay16 = monthDay13.plusMonths(97);
//        int int17 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay16);
//        long long19 = delegatedDateTimeField4.roundFloor(0L);
//        java.util.Locale locale20 = null;
//        int int21 = delegatedDateTimeField4.getMaximumTextLength(locale20);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 86399 + "'", int9 == 86399);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2, 0);
        java.util.Locale locale5 = null;
        int int6 = skipDateTimeField4.getMaximumTextLength(locale5);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
//        int int8 = delegatedDateTimeField6.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField6.getWrappedField();
//        boolean boolean10 = delegatedDateTimeField6.isSupported();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6, (int) 'a');
//        long long15 = skipUndoDateTimeField12.set((long) 57600, (int) 'a');
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 96600L + "'", long15 == 96600L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime9.getZone();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((int) (short) -1, 0, 12, 3, 1380, 2, dateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1380 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMinutes(19);
        org.joda.time.DateTime.Property property9 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime11 = dateTime3.minusMillis(100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone14);
//        org.joda.time.MonthDay.Property property18 = monthDay17.dayOfMonth();
//        java.lang.String str19 = property18.getName();
//        java.lang.String str20 = property18.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType21, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder8.appendFixedDecimal(dateTimeFieldType21, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType21, 59938);
//        long long31 = dividedDateTimeField28.set((-3599010L), 0);
//        long long34 = dividedDateTimeField28.add((long) (byte) 100, 59);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-3599010L) + "'", long31 == (-3599010L));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2138779641600100L + "'", long34 == 2138779641600100L);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getLeapDurationField();
//        long long16 = offsetDateTimeField9.add(0L, 3200);
//        java.lang.String str17 = offsetDateTimeField9.getName();
//        long long19 = offsetDateTimeField9.roundHalfEven((long) 0);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3200000L + "'", long16 == 3200000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "secondOfDay" + "'", str17.equals("secondOfDay"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-28800000), '#', 86399999, 97, (int) (short) 1, false, 86496);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("JulianChronology[]", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        long long42 = remainderDateTimeField39.roundHalfEven(86399990L);
//        long long44 = remainderDateTimeField39.roundHalfCeiling(32L);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = remainderDateTimeField39.getAsShortText((long) 57600, locale46);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-10L) + "'", long44 == (-10L));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "57" + "'", str47.equals("57"));
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(5, (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1380100L);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
//        long long6 = dateTime4.getMillis();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime4.withDurationAdded(readableDuration7, (int) (short) 100);
//        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear(57600);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-10L) + "'", long6 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone14);
//        org.joda.time.MonthDay.Property property18 = monthDay17.dayOfMonth();
//        java.lang.String str19 = property18.getName();
//        java.lang.String str20 = property18.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType21, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder8.appendFixedDecimal(dateTimeFieldType21, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType21, 59938);
//        long long31 = dividedDateTimeField28.set((-3599010L), 0);
//        int int32 = dividedDateTimeField28.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-3599010L) + "'", long31 == (-3599010L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        long long9 = delegatedDateTimeField4.roundFloor((long) 15);
//        long long11 = delegatedDateTimeField4.roundCeiling((-28740062L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = delegatedDateTimeField4.getType();
//        org.joda.time.ReadableInterval readableInterval13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
//        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
//        org.joda.time.MonthDay monthDay17 = monthDay15.minusDays((int) (short) 10);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.MonthDay monthDay19 = monthDay15.withChronologyRetainFields((org.joda.time.Chronology) gJChronology18);
//        java.util.Locale locale20 = null;
//        try {
//            java.lang.String str21 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay15, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28740010L) + "'", long11 == (-28740010L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(monthDay19);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.Instant instant6 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.plus(readableDuration7);
        org.joda.time.Instant instant10 = instant6.plus((long) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone16 = fixedDateTimeZone15.toTimeZone();
        java.lang.String str18 = fixedDateTimeZone15.getName((long) 10);
        java.util.TimeZone timeZone19 = fixedDateTimeZone15.toTimeZone();
        long long22 = fixedDateTimeZone15.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime23 = instant10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "0", (java.lang.Object) dateTime23);
        long long25 = dateTime23.getMillis();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.010" + "'", str18.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-10L) + "'", long22 == (-10L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-12219292799999L) + "'", long25 == (-12219292799999L));
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.millisOfSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter5.getZone();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
//        int int11 = dateTime10.getSecondOfMinute();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime10.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        boolean boolean19 = dateTime10.isSupported(dateTimeFieldType18);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime10.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone24);
//        int int28 = dateTimeFormatter5.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime25, "1970-01-01T00:00:00.000+00:00:00.010", (-28800000));
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField31, dateTimeFieldType32);
//        int int35 = delegatedDateTimeField33.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField36 = delegatedDateTimeField33.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 97);
//        long long41 = offsetDateTimeField38.getDifferenceAsLong((long) 10, (long) 59);
//        int int43 = offsetDateTimeField38.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime47 = dateTime45.plusHours((int) (short) -1);
//        int int48 = dateTime47.getSecondOfMinute();
//        org.joda.time.DateTime dateTime50 = dateTime47.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime52 = dateTime50.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder53.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder54.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
//        int int59 = dateTimeZone57.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay60 = org.joda.time.MonthDay.now(dateTimeZone57);
//        org.joda.time.MonthDay.Property property61 = monthDay60.dayOfMonth();
//        java.lang.String str62 = property61.getName();
//        java.lang.String str63 = property61.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property61.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder54.appendFixedSignedDecimal(dateTimeFieldType64, 9700);
//        int int67 = dateTime50.get(dateTimeFieldType64);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField38, dateTimeFieldType64, 23);
//        int int70 = mutableDateTime25.get(dateTimeFieldType64);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType64, 9);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86496 + "'", int43 == 86496);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 10 + "'", int59 == 10);
//        org.junit.Assert.assertNotNull(monthDay60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "dayOfMonth" + "'", str62.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1" + "'", str63.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType64);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 31 + "'", int67 == 31);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 31 + "'", int70 == 31);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
//        int int62 = dateTimeZone60.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now(dateTimeZone60);
//        org.joda.time.MonthDay.Property property64 = monthDay63.dayOfMonth();
//        java.lang.String str65 = property64.getName();
//        java.lang.String str66 = property64.getAsString();
//        int int67 = property64.getMaximumValueOverall();
//        org.joda.time.MonthDay monthDay69 = property64.addToCopy((-32));
//        org.joda.time.MonthDay monthDay71 = monthDay69.withMonthOfYear(10);
//        try {
//            int int72 = unsupportedDateTimeField59.getMaximumValue((org.joda.time.ReadablePartial) monthDay69);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "dayOfMonth" + "'", str65.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1" + "'", str66.equals("1"));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 31 + "'", int67 == 31);
//        org.junit.Assert.assertNotNull(monthDay69);
//        org.junit.Assert.assertNotNull(monthDay71);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.dayOfWeek();
        org.joda.time.Chronology chronology5 = gJChronology2.withUTC();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str2 = monthDay0.toString("+00:00:00.010");
        org.joda.time.DateTimeField[] dateTimeFieldArray3 = monthDay0.getFields();
        int[] intArray4 = monthDay0.getValues();
        org.joda.time.MonthDay monthDay6 = monthDay0.withMonthOfYear((int) (short) 1);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = monthDay6.toString("", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.010" + "'", str2.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime.Property property13 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime14 = property13.roundCeilingCopy();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone20 = fixedDateTimeZone19.toTimeZone();
        java.lang.String str22 = fixedDateTimeZone19.getName((long) 10);
        java.util.TimeZone timeZone23 = fixedDateTimeZone19.toTimeZone();
        org.joda.time.LocalDateTime localDateTime24 = null;
        boolean boolean25 = fixedDateTimeZone19.isLocalDateTimeGap(localDateTime24);
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime14.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTime dateTime27 = dateTime3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        int int29 = fixedDateTimeZone19.getStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.010" + "'", str22.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 35 + "'", int29 == 35);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        java.lang.String str6 = property4.toString();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        org.joda.time.DateTime dateTime9 = property4.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "dayOfMonth" + "'", str4.equals("dayOfMonth"));
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        org.joda.time.DateTime dateTime16 = dateTime3.plusMillis((-2));
        boolean boolean17 = dateTime3.isBeforeNow();
        org.joda.time.DateTime dateTime19 = dateTime3.minusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime20 = dateTime3.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay((int) (byte) 0);
        org.joda.time.DateTime dateTime15 = dateTime11.withMonthOfYear(10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone21 = fixedDateTimeZone20.toTimeZone();
        java.lang.String str23 = fixedDateTimeZone20.getName((long) 10);
        java.util.TimeZone timeZone24 = fixedDateTimeZone20.toTimeZone();
        boolean boolean25 = fixedDateTimeZone20.isFixed();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime30 = dateTime28.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean37 = dateTime35.equals((java.lang.Object) dateTimeFormatter36);
        org.joda.time.DateTime.Property property38 = dateTime35.minuteOfHour();
        org.joda.time.DateTime dateTime39 = property38.roundCeilingCopy();
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime dateTime41 = localTime31.toDateTime((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.DateTime dateTime44 = dateTime41.withPeriodAdded(readablePeriod42, (int) '4');
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, (org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DurationField durationField46 = gJChronology45.hours();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology45.year();
        org.joda.time.DateTime dateTime48 = dateTime15.withChronology((org.joda.time.Chronology) gJChronology45);
        org.joda.time.DateTime dateTime50 = dateTime48.plusYears(2000);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+00:00:00.010" + "'", str23.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localTime31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        java.lang.String str60 = unsupportedDateTimeField59.getName();
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime64 = dateTime62.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime65 = dateTime64.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType66 = null;
//        int int67 = localTime65.indexOf(dateTimeFieldType66);
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime71 = dateTime69.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime72 = dateTime71.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = null;
//        int int74 = localTime72.indexOf(dateTimeFieldType73);
//        boolean boolean75 = localTime65.isBefore((org.joda.time.ReadablePartial) localTime72);
//        java.lang.Class<?> wildcardClass76 = localTime72.getClass();
//        try {
//            int int77 = unsupportedDateTimeField59.getMaximumValue((org.joda.time.ReadablePartial) localTime72);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "dayOfMonth" + "'", str60.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(localTime65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localTime72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(wildcardClass76);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-3599958L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3599958) + "'", int1 == (-3599958));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours((-2));
        org.joda.time.DateTime.Property property16 = dateTime15.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DateTime dateTime16 = dateTime11.plusDays(59);
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = dateTime11.toString("DateTimeField[dayOfMonth]", locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(38, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder4.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("57659", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 3200);
//        long long9 = offsetDateTimeField7.roundCeiling((long) 15);
//        long long11 = offsetDateTimeField7.roundHalfEven(31532400062L);
//        long long14 = offsetDateTimeField7.add(32L, 38);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[secondOfDay]" + "'", str5.equals("DateTimeField[secondOfDay]"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 990L + "'", long9 == 990L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31532399990L + "'", long11 == 31532399990L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 38032L + "'", long14 == 38032L);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 3200);
//        long long9 = offsetDateTimeField7.roundHalfFloor((long) (short) 10);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[secondOfDay]" + "'", str5.equals("DateTimeField[secondOfDay]"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.year();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        int int41 = remainderDateTimeField39.getDivisor();
//        int int42 = remainderDateTimeField39.getMaximumValue();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 83940062 + "'", int41 == 83940062);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 83940061 + "'", int42 == 83940061);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        try {
            java.lang.String str21 = dateTime18.toString("CopticChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
//        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property10 = dateTime9.year();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime15 = dateTime12.withTimeAtStartOfDay();
//        int int16 = property10.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
//        boolean boolean18 = instant5.isEqual((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property19 = dateTime15.dayOfWeek();
//        java.lang.String str20 = property19.getAsString();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(instant5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4" + "'", str20.equals("4"));
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property4 = dateTime3.year();
//        long long5 = property4.remainder();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 31532400062L + "'", long5 == 31532400062L);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.minuteOfDay();
        try {
            long long10 = gJChronology2.getDateTimeMillis((long) 1, 59938, 35, 2000, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59938 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        int int15 = offsetDateTimeField9.getDifference((-10L), (long) (short) -1);
//        int int16 = offsetDateTimeField9.getMinimumValue();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime20 = dateTime18.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property21 = dateTime20.year();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime25 = dateTime23.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime26 = dateTime23.withTimeAtStartOfDay();
//        int int27 = property21.compareTo((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.LocalDateTime localDateTime28 = dateTime26.toLocalDateTime();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology30.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32, dateTimeFieldType33);
//        int int36 = delegatedDateTimeField34.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField37 = delegatedDateTimeField34.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, 97);
//        long long42 = offsetDateTimeField39.set((long) 19, 9700);
//        java.lang.String str44 = offsetDateTimeField39.getAsText((long) 57600);
//        org.joda.time.ReadableInterval readableInterval45 = null;
//        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval45);
//        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(chronology46);
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology48.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology48.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50, dateTimeFieldType51);
//        int int54 = delegatedDateTimeField52.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField55 = delegatedDateTimeField52.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, 97);
//        long long60 = offsetDateTimeField57.getDifferenceAsLong((long) 10, (long) 59);
//        int int62 = offsetDateTimeField57.getMaximumValue(9602990L);
//        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now();
//        java.lang.String str65 = monthDay63.toString("+00:00:00.010");
//        org.joda.time.MonthDay monthDay67 = monthDay63.plusDays((int) (byte) 0);
//        org.joda.time.ReadableInterval readableInterval69 = null;
//        org.joda.time.Chronology chronology70 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval69);
//        org.joda.time.MonthDay monthDay71 = new org.joda.time.MonthDay(chronology70);
//        org.joda.time.MonthDay monthDay73 = monthDay71.minusDays((int) (short) 10);
//        int[] intArray74 = monthDay73.getValues();
//        int[] intArray76 = offsetDateTimeField57.add((org.joda.time.ReadablePartial) monthDay63, 57600, intArray74, 0);
//        int int77 = offsetDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) monthDay47, intArray76);
//        try {
//            int[] intArray79 = offsetDateTimeField9.add((org.joda.time.ReadablePartial) localDateTime28, 745200468, intArray76, 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 745200468");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(localDateTime28);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9603019L + "'", long42 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "154" + "'", str44.equals("154"));
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 86496 + "'", int62 == 86496);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "+00:00:00.010" + "'", str65.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(monthDay67);
//        org.junit.Assert.assertNotNull(chronology70);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(intArray74);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 86496 + "'", int77 == 86496);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(59L, (long) 48);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107L + "'", long2 == 107L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(9603019L, 70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 672211330L + "'", long2 == 672211330L);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
//        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
//        int int12 = dateTime3.getCenturyOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime3.millisOfSecond();
//        java.lang.String str14 = property13.getName();
//        java.lang.String str15 = property13.getAsString();
//        org.joda.time.DateTime dateTime16 = property13.roundFloorCopy();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "millisOfSecond" + "'", str14.equals("millisOfSecond"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "62" + "'", str15.equals("62"));
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone14);
//        org.joda.time.MonthDay.Property property18 = monthDay17.dayOfMonth();
//        java.lang.String str19 = property18.getName();
//        java.lang.String str20 = property18.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType21, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder8.appendFixedDecimal(dateTimeFieldType21, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType21, 59938);
//        long long31 = dividedDateTimeField28.set((-3599010L), 0);
//        int int32 = dividedDateTimeField28.getDivisor();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-3599010L) + "'", long31 == (-3599010L));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 59938 + "'", int32 == 59938);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        int int17 = dateTimeZone15.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone15);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        java.lang.String str20 = property19.getName();
//        java.lang.String str21 = property19.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType22, 9700);
//        int int25 = dateTime8.get(dateTimeFieldType22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType22, 2000, 69);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap29 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendTimeZoneShortName(strMap29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "dayOfMonth" + "'", str20.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.lang.String str6 = property5.getName();
//        java.lang.String str7 = property5.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "dayOfMonth" + "'", str6.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(67, 1380, 11, (-3599958), 0, 57600, 1380, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3599958 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str15 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        try {
            long long21 = zonedChronology16.getDateTimeMillis(67, 9383392, 24, 23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9383392 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.halfdays();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("DateTimeField[secondOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[secondOfDay]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime9 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime7.weekyear();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        int int12 = property10.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-292275054) + "'", int12 == (-292275054));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime4 = dateTime2.plusHours((int) (short) -1);
//        int int5 = dateTime4.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        int int8 = dateTimeZone6.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime4.toMutableDateTime(dateTimeZone6);
//        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", (int) (byte) 0);
//        org.joda.time.Instant instant13 = mutableDateTime9.toInstant();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(instant13);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        java.util.Locale locale8 = null;
//        int int9 = delegatedDateTimeField4.getMaximumShortTextLength(locale8);
//        long long11 = delegatedDateTimeField4.roundCeiling(9999L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10990L + "'", long11 == 10990L);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
//        java.lang.String str5 = property4.getAsString();
//        org.joda.time.DateTimeField dateTimeField6 = property4.getField();
//        java.lang.String str7 = property4.getName();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "monthOfYear" + "'", str7.equals("monthOfYear"));
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean21 = dateTime19.equals((java.lang.Object) dateTimeFormatter20);
        org.joda.time.DateTime.Property property22 = dateTime19.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = localTime15.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DurationField durationField30 = gJChronology29.hours();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.year();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology29.secondOfDay();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        boolean boolean13 = offsetDateTimeField9.isLenient();
//        long long15 = offsetDateTimeField9.roundCeiling((-28740010L));
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now(dateTimeZone16);
//        org.joda.time.MonthDay.Property property20 = monthDay19.monthOfYear();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) monthDay19, 59948, locale22);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime27 = dateTime25.plusHours((int) (short) -1);
//        int int28 = dateTime27.getSecondOfMinute();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        org.joda.time.MutableDateTime mutableDateTime34 = dateTime27.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone33);
//        org.joda.time.DateTime.Property property35 = dateTime27.hourOfDay();
//        org.joda.time.DateTime dateTime36 = dateTime27.withLaterOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap38 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendTimeZoneShortName(strMap38);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder37.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap43 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendTimeZoneShortName(strMap43);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder42.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
//        int int49 = dateTimeZone47.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now(dateTimeZone47);
//        org.joda.time.MonthDay.Property property51 = monthDay50.dayOfMonth();
//        java.lang.String str52 = property51.getName();
//        java.lang.String str53 = property51.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property51.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder42.appendSignedDecimal(dateTimeFieldType54, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder41.appendFixedDecimal(dateTimeFieldType54, 23);
//        boolean boolean60 = dateTime36.isSupported(dateTimeFieldType54);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType54, (int) (short) 1, 86496, 3);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = offsetDateTimeField64.getAsShortText(28990L, locale66);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28740010L) + "'", long15 == (-28740010L));
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59948" + "'", str23.equals("59948"));
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
//        org.junit.Assert.assertNotNull(monthDay50);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "dayOfMonth" + "'", str52.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1" + "'", str53.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType54);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "127" + "'", str67.equals("127"));
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.days();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone2);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        java.lang.String str7 = property6.getName();
//        java.util.Locale locale8 = null;
//        int int9 = property6.getMaximumTextLength(locale8);
//        org.joda.time.DurationField durationField10 = property6.getDurationField();
//        org.joda.time.MonthDay monthDay12 = property6.addWrapFieldToCopy(3);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(monthDay12);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        java.lang.String str6 = property4.getAsString();
//        int int7 = property4.getMaximumValueOverall();
//        org.joda.time.DateTimeField dateTimeField8 = property4.getField();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        java.lang.String str60 = unsupportedDateTimeField59.getName();
//        java.util.Locale locale62 = null;
//        try {
//            java.lang.String str63 = unsupportedDateTimeField59.getAsText((long) 9700, locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "dayOfMonth" + "'", str60.equals("dayOfMonth"));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 4, dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withPeriodAdded(readablePeriod3, (-28800000));
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime5.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone10);
//        org.joda.time.MonthDay.Property property14 = monthDay13.dayOfMonth();
//        java.lang.String str15 = property14.getName();
//        java.lang.String str16 = property14.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType17, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType17, 23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 57600);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.appendFractionOfHour((int) 'a', (int) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        int int31 = dateTimeZone29.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now(dateTimeZone29);
//        org.joda.time.MonthDay.Property property33 = monthDay32.dayOfMonth();
//        java.lang.String str34 = property33.getName();
//        java.util.Locale locale35 = null;
//        int int36 = property33.getMaximumTextLength(locale35);
//        org.joda.time.DurationField durationField37 = property33.getDurationField();
//        org.joda.time.DurationField durationField38 = property33.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property33.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder28.appendText(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfMonth" + "'", str34.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        java.lang.String str7 = property6.getAsText();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        int int9 = property6.getMaximumValueOverall();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours((int) (short) -1);
        int int14 = dateTime13.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime13.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.DateTime.Property property21 = dateTime13.hourOfDay();
        int int22 = property6.getDifference((org.joda.time.ReadableInstant) dateTime13);
        java.util.Locale locale23 = null;
        java.lang.String str24 = property6.getAsShortText(locale23);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        java.lang.String str5 = delegatedDateTimeField4.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 3200);
//        long long9 = offsetDateTimeField7.roundCeiling((long) 15);
//        long long11 = offsetDateTimeField7.roundHalfEven(31532400062L);
//        try {
//            long long14 = offsetDateTimeField7.set((long) 86399999, "+00:00:00.010");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.010\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[secondOfDay]" + "'", str5.equals("DateTimeField[secondOfDay]"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 990L + "'", long9 == 990L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31532399990L + "'", long11 == 31532399990L);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours((-2));
        org.joda.time.DateTime.Property property16 = dateTime11.year();
        java.util.Locale locale18 = null;
        try {
            org.joda.time.DateTime dateTime19 = property16.setCopy("Property[minuteOfHour]", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[minuteOfHour]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, readableInstant6);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.monthOfYear();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.era();
        org.joda.time.Instant instant10 = gJChronology7.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology7.halfdayOfDay();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime1.toMutableDateTime((org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean23 = dateTime21.equals((java.lang.Object) dateTimeFormatter22);
        org.joda.time.DateTime.Property property24 = dateTime21.minuteOfHour();
        org.joda.time.DateTime dateTime25 = property24.roundCeilingCopy();
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime27 = localTime17.toDateTime((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.withLaterOffsetAtOverlap();
        boolean boolean29 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) dateTime25);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.plus(readableDuration6);
        org.joda.time.Instant instant9 = instant5.plus((long) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone15 = fixedDateTimeZone14.toTimeZone();
        java.lang.String str17 = fixedDateTimeZone14.getName((long) 10);
        java.util.TimeZone timeZone18 = fixedDateTimeZone14.toTimeZone();
        long long21 = fixedDateTimeZone14.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime22 = instant9.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTime dateTime23 = dateTime22.toDateTime();
        try {
            org.joda.time.DateTime dateTime25 = dateTime22.withDayOfYear(83940061);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 83940061 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.010" + "'", str17.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 51L + "'", long0 == 51L);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "2000", "GregorianChronology[UTC]");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
        org.joda.time.Chronology chronology4 = gJChronology2.withUTC();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-28800000), '#', 86399999, 97, (int) (short) 1, false, 86496);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder0.addCutover((int) (byte) 100, '4', (int) (short) 100, 83940062, 0, false, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        org.joda.time.DateTime dateTime16 = dateTime3.plusMillis((-2));
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
//        java.util.Locale locale10 = null;
//        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
//        java.lang.String str12 = delegatedDateTimeField4.getName();
//        org.joda.time.ReadableInterval readableInterval13 = null;
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval13);
//        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(chronology14);
//        org.joda.time.MonthDay monthDay17 = monthDay15.minusDays((int) (short) 10);
//        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay15);
//        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
//        java.lang.String str21 = delegatedDateTimeField4.getAsText(32L);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfDay" + "'", str12.equals("secondOfDay"));
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399 + "'", int18 == 86399);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        boolean boolean4 = copticChronology0.equals((java.lang.Object) dateTimeFormatter3);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[UTC]" + "'", str2.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime4 = dateTime2.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        java.lang.String str6 = property5.getAsShortText();
//        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean13 = dateTime11.equals((java.lang.Object) dateTimeFormatter12);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        org.joda.time.DateTime dateTime19 = dateTime11.withFields((org.joda.time.ReadablePartial) localTime18);
//        int int20 = property5.getDifference((org.joda.time.ReadableInstant) dateTime19);
//        boolean boolean21 = julianChronology0.equals((java.lang.Object) dateTime19);
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType25);
//        int int28 = delegatedDateTimeField26.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField29 = delegatedDateTimeField26.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 97);
//        long long34 = offsetDateTimeField31.getDifferenceAsLong((long) 10, (long) 59);
//        int int36 = offsetDateTimeField31.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime40 = dateTime38.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime41 = dateTime40.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
//        int int43 = localTime41.indexOf(dateTimeFieldType42);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime47 = dateTime45.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime48 = dateTime47.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        int int50 = localTime48.indexOf(dateTimeFieldType49);
//        boolean boolean51 = localTime41.isBefore((org.joda.time.ReadablePartial) localTime48);
//        int int52 = offsetDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) localTime48);
//        long long55 = offsetDateTimeField31.set((long) 23, (int) (byte) 100);
//        boolean boolean56 = julianChronology0.equals((java.lang.Object) 23);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.Chronology chronology58 = julianChronology0.withZone(dateTimeZone57);
//        org.joda.time.DateTimeField dateTimeField59 = julianChronology0.millisOfDay();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86496 + "'", int36 == 86496);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localTime41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localTime48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 97 + "'", int52 == 97);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3023L + "'", long55 == 3023L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone10);
//        org.joda.time.MonthDay.Property property14 = monthDay13.dayOfMonth();
//        java.lang.String str15 = property14.getName();
//        java.lang.String str16 = property14.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType17, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType17, 23);
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25, dateTimeFieldType26);
//        int int29 = delegatedDateTimeField27.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField30 = delegatedDateTimeField27.getWrappedField();
//        int int32 = delegatedDateTimeField27.getLeapAmount(57600L);
//        java.util.Locale locale33 = null;
//        int int34 = delegatedDateTimeField27.getMaximumTextLength(locale33);
//        org.joda.time.DurationField durationField35 = delegatedDateTimeField27.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType17, durationField35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
//        int int11 = dateTime10.getSecondOfMinute();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime15 = dateTime13.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        int int22 = dateTimeZone20.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now(dateTimeZone20);
//        org.joda.time.MonthDay.Property property24 = monthDay23.dayOfMonth();
//        java.lang.String str25 = property24.getName();
//        java.lang.String str26 = property24.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder17.appendFixedSignedDecimal(dateTimeFieldType27, 9700);
//        int int30 = dateTime13.get(dateTimeFieldType27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder5.appendFraction(dateTimeFieldType27, 2000, 69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "dayOfMonth" + "'", str25.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean6 = dateTime4.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DateTime.Property property7 = dateTime4.minuteOfHour();
        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        java.lang.String str16 = fixedDateTimeZone13.getName((long) 10);
        java.util.TimeZone timeZone17 = fixedDateTimeZone13.toTimeZone();
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = fixedDateTimeZone13.isLocalDateTimeGap(localDateTime18);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime8.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        int int21 = mutableDateTime20.getYearOfCentury();
        int int24 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime20, "����-��-��", (-28800000));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 69);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.010" + "'", str16.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 69 + "'", int21 == 69);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone10);
//        org.joda.time.MonthDay.Property property14 = monthDay13.dayOfMonth();
//        java.lang.String str15 = property14.getName();
//        java.lang.String str16 = property14.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType17, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType17, 23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder22.appendWeekyear(51, 86496);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.appendHalfdayOfDayText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = property6.addWrapFieldToCopy(9700);
        org.joda.time.DateTime dateTime22 = property6.roundFloorCopy();
        org.joda.time.DurationField durationField23 = property6.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNull(durationField23);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        java.lang.String str60 = unsupportedDateTimeField59.toString();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "UnsupportedDateTimeField" + "'", str60.equals("UnsupportedDateTimeField"));
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
//        org.joda.time.ReadableInterval readableInterval15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
//        int int18 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay17);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
//        org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("1");
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, readableInstant5);
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField8 = gJChronology6.era();
//        org.joda.time.Instant instant9 = gJChronology6.getGregorianCutover();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.Instant instant11 = instant9.plus(readableDuration10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology13 = iSOChronology12.withUTC();
//        org.joda.time.Chronology chronology14 = iSOChronology12.withUTC();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean20 = dateTime18.equals((java.lang.Object) dateTimeFormatter19);
//        org.joda.time.DateTime.Property property21 = dateTime18.minuteOfHour();
//        org.joda.time.DateTime dateTime22 = property21.roundCeilingCopy();
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime27 = dateTime25.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime28 = dateTime25.withTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
//        long long30 = dateTime28.getMillis();
//        org.joda.time.ReadableDuration readableDuration31 = null;
//        org.joda.time.DateTime dateTime33 = dateTime28.withDurationAdded(readableDuration31, (int) (short) 100);
//        org.joda.time.chrono.LimitChronology limitChronology34 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology12, (org.joda.time.ReadableDateTime) dateTime22, (org.joda.time.ReadableDateTime) dateTime33);
//        org.joda.time.MutableDateTime mutableDateTime35 = instant11.toMutableDateTime((org.joda.time.Chronology) limitChronology34);
//        try {
//            int int38 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime35, "", 5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 1969-12-31T23:01:00.000Z (ISOChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(locale1);
//        org.junit.Assert.assertNotNull(localTime3);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(instant9);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-10L) + "'", long30 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(limitChronology34);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
//        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
//        boolean boolean8 = fixedDateTimeZone4.isFixed();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, 2);
//        int int13 = monthDay9.getDayOfMonth();
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, 2);
        try {
            org.joda.time.MonthDay monthDay14 = monthDay12.withDayOfMonth((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("57659");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter2.getZone();
        java.lang.String str4 = monthDay1.toString(dateTimeFormatter2);
        int[] intArray5 = monthDay1.getValues();
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "����-01-01" + "'", str4.equals("����-01-01"));
        org.junit.Assert.assertNotNull(intArray5);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
//        int int6 = dateTime5.getSecondOfMinute();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        int int17 = dateTimeZone15.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone15);
//        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
//        java.lang.String str20 = property19.getName();
//        java.lang.String str21 = property19.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType22, 9700);
//        int int25 = dateTime8.get(dateTimeFieldType22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType22, 2000, 69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) '#');
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "dayOfMonth" + "'", str20.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        java.util.Locale locale6 = null;
//        int int7 = property4.getMaximumTextLength(locale6);
//        org.joda.time.DurationField durationField8 = property4.getDurationField();
//        org.joda.time.DurationField durationField9 = property4.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property4.getFieldType();
//        int int11 = property4.getMinimumValueOverall();
//        org.joda.time.MonthDay monthDay12 = property4.getMonthDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(monthDay12);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime4 = dateTime2.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property5 = dateTime4.year();
//        java.lang.String str6 = property5.getAsShortText();
//        org.joda.time.DateTime dateTime7 = property5.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean13 = dateTime11.equals((java.lang.Object) dateTimeFormatter12);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime18 = dateTime17.toLocalTime();
//        org.joda.time.DateTime dateTime19 = dateTime11.withFields((org.joda.time.ReadablePartial) localTime18);
//        int int20 = property5.getDifference((org.joda.time.ReadableInstant) dateTime19);
//        boolean boolean21 = julianChronology0.equals((java.lang.Object) dateTime19);
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType25);
//        int int28 = delegatedDateTimeField26.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField29 = delegatedDateTimeField26.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, 97);
//        long long34 = offsetDateTimeField31.getDifferenceAsLong((long) 10, (long) 59);
//        int int36 = offsetDateTimeField31.getMaximumValue(9602990L);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime40 = dateTime38.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime41 = dateTime40.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
//        int int43 = localTime41.indexOf(dateTimeFieldType42);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime47 = dateTime45.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime48 = dateTime47.toLocalTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
//        int int50 = localTime48.indexOf(dateTimeFieldType49);
//        boolean boolean51 = localTime41.isBefore((org.joda.time.ReadablePartial) localTime48);
//        int int52 = offsetDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) localTime48);
//        long long55 = offsetDateTimeField31.set((long) 23, (int) (byte) 100);
//        boolean boolean56 = julianChronology0.equals((java.lang.Object) 23);
//        org.joda.time.DateTimeZone dateTimeZone57 = null;
//        org.joda.time.Chronology chronology58 = julianChronology0.withZone(dateTimeZone57);
//        java.lang.String str59 = julianChronology0.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(localTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86496 + "'", int36 == 86496);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localTime41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localTime48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 97 + "'", int52 == 97);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3023L + "'", long55 == 3023L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "JulianChronology[UTC]" + "'", str59.equals("JulianChronology[UTC]"));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField4.getMaximumShortTextLength(locale12);
        long long16 = delegatedDateTimeField4.add(31503600052L, (-28740062L));
        org.joda.time.DurationField durationField17 = delegatedDateTimeField4.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2763538052L + "'", long16 == 2763538052L);
        org.junit.Assert.assertNotNull(durationField17);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        try {
//            long long61 = unsupportedDateTimeField59.roundFloor(8L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        int int13 = offsetDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.era();
//        org.joda.time.Instant instant11 = gJChronology8.getGregorianCutover();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.Instant instant13 = instant11.minus(readableDuration12);
//        org.joda.time.Instant instant15 = instant13.plus((long) 59948);
//        int int16 = property4.compareTo((org.joda.time.ReadableInstant) instant15);
//        java.lang.String str17 = property4.getAsShortText();
//        int int18 = property4.getMinimumValue();
//        try {
//            org.joda.time.MonthDay monthDay20 = property4.setCopy("--11-14");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"--11-14\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant13);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
//        int int18 = dateTime17.getSecondOfMinute();
//        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
//        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
//        java.lang.String str32 = property31.getName();
//        java.lang.String str33 = property31.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
//        int int37 = dateTime20.get(dateTimeFieldType34);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
//        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
//        long long42 = remainderDateTimeField39.roundHalfFloor((long) 86399999);
//        int int43 = remainderDateTimeField39.getDivisor();
//        int int44 = remainderDateTimeField39.getMinimumValue();
//        long long46 = remainderDateTimeField39.roundFloor((long) (byte) -1);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 83940062 + "'", int43 == 83940062);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-10L) + "'", long46 == (-10L));
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.dayOfMonth();
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
//        int int11 = delegatedDateTimeField9.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField12 = delegatedDateTimeField9.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 97);
//        long long17 = offsetDateTimeField14.getDifferenceAsLong((long) 10, (long) 59);
//        boolean boolean18 = offsetDateTimeField14.isLenient();
//        long long20 = offsetDateTimeField14.roundCeiling((-28740010L));
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        int int23 = dateTimeZone21.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now(dateTimeZone21);
//        org.joda.time.MonthDay.Property property25 = monthDay24.monthOfYear();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) monthDay24, 59948, locale27);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.ReadableInstant readableInstant30 = null;
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap34 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTimeZoneShortName(strMap34);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap39 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendTimeZoneShortName(strMap39);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder38.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
//        int int45 = dateTimeZone43.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now(dateTimeZone43);
//        org.joda.time.MonthDay.Property property47 = monthDay46.dayOfMonth();
//        java.lang.String str48 = property47.getName();
//        java.lang.String str49 = property47.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property47.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder38.appendSignedDecimal(dateTimeFieldType50, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder37.appendFixedDecimal(dateTimeFieldType50, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField32, dateTimeFieldType50, 59938);
//        org.joda.time.MonthDay.Property property58 = monthDay24.property(dateTimeFieldType50);
//        long long60 = gJChronology2.set((org.joda.time.ReadablePartial) monthDay24, (long) 86399);
//        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray61 = monthDay24.getFieldTypes();
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-28740010L) + "'", long20 == (-28740010L));
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "59948" + "'", str28.equals("59948"));
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertNotNull(monthDay46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1" + "'", str49.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 86399L + "'", long60 == 86399L);
//        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray61);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
//        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
//        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
//        long long18 = dateTime16.getMillis();
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
//        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
//        org.joda.time.DurationField durationField23 = iSOChronology0.millis();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(limitChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        int int62 = unsupportedDateTimeField59.getDifference((long) 83940061, 31532400062L);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-28800000), '#', 86399999, 97, (int) (short) 1, false, 86496);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("59948", (int) (byte) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("82860000", 59, 11, 4, 'a', 9700, 0, 59, false, 2000);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder22);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        int int5 = property4.getMaximumValueOverall();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property4.getAsShortText(locale6);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatterBuilder8.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.append(dateTimePrinter9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder10.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
//        long long12 = offsetDateTimeField9.set((long) 19, 9700);
//        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
//        int int16 = offsetDateTimeField9.getMaximumValue((long) (byte) 100);
//        java.lang.String str18 = offsetDateTimeField9.getAsText((long) 69);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now(dateTimeZone19);
//        org.joda.time.MonthDay.Property property23 = monthDay22.monthOfYear();
//        org.joda.time.MonthDay monthDay25 = monthDay22.plusMonths(97);
//        org.joda.time.ReadableInterval readableInterval26 = null;
//        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
//        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
//        org.joda.time.MonthDay monthDay30 = monthDay28.minusDays((int) (short) 10);
//        int[] intArray31 = monthDay30.getValues();
//        int int32 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay25, intArray31);
//        boolean boolean33 = offsetDateTimeField9.isSupported();
//        long long36 = offsetDateTimeField9.addWrapField((long) 4, 745200468);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86496 + "'", int16 == 86496);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(intArray31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 468004L + "'", long36 == 468004L);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 97);
        try {
            org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.util.TimeZone timeZone19 = fixedDateTimeZone12.toTimeZone();
        boolean boolean21 = fixedDateTimeZone12.isStandardOffset(0L);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime25 = dateTime23.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean27 = dateTime25.equals((java.lang.Object) dateTimeFormatter26);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.clockhourOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone14);
//        org.joda.time.MonthDay.Property property18 = monthDay17.dayOfMonth();
//        java.lang.String str19 = property18.getName();
//        java.lang.String str20 = property18.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType21, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder8.appendFixedDecimal(dateTimeFieldType21, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType21, 59938);
//        try {
//            long long30 = dividedDateTimeField28.roundFloor(10L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitYear(38, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.joda.time.ReadableInterval readableInterval0 = null;
//        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
//        org.joda.time.MonthDay monthDay4 = monthDay2.minusDays((int) (short) 10);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.MonthDay monthDay6 = monthDay2.withChronologyRetainFields((org.joda.time.Chronology) gJChronology5);
//        int int7 = monthDay6.getMonthOfYear();
//        org.joda.time.ReadableInterval readableInterval8 = null;
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
//        org.joda.time.MonthDay monthDay12 = monthDay10.minusDays((int) (short) 10);
//        int[] intArray13 = monthDay12.getValues();
//        boolean boolean14 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay12);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = monthDay6.toString("����-��-��", locale16);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "����-��-��" + "'", str17.equals("����-��-��"));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra((int) ' ');
        java.util.GregorianCalendar gregorianCalendar7 = dateTime1.toGregorianCalendar();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar7);
        int int9 = monthDay8.size();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.DurationField durationField3 = copticChronology0.hours();
        try {
            long long11 = copticChronology0.getDateTimeMillis((-3599958), 83940062, (int) '4', 15, 0, 100, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[UTC]" + "'", str2.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
//        org.joda.time.DateTime dateTime16 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime15);
//        org.joda.time.DateTime dateTime17 = dateTime1.withFields((org.joda.time.ReadablePartial) localTime15);
//        int int18 = dateTime17.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, readableInstant19);
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap23 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendTimeZoneShortName(strMap23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder22.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap28 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendTimeZoneShortName(strMap28);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder27.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        int int34 = dateTimeZone32.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now(dateTimeZone32);
//        org.joda.time.MonthDay.Property property36 = monthDay35.dayOfMonth();
//        java.lang.String str37 = property36.getName();
//        java.lang.String str38 = property36.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property36.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder27.appendSignedDecimal(dateTimeFieldType39, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder26.appendFixedDecimal(dateTimeFieldType39, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(dateTimeField21, dateTimeFieldType39, 59938);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType39, (-32));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -32");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "dayOfMonth" + "'", str37.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1" + "'", str38.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(0);
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour(0);
        org.joda.time.DateTime dateTime6 = dateTime2.plusMinutes(15);
        org.joda.time.DateTime dateTime8 = dateTime2.plusMillis((-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        int int16 = dateTimeZone14.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone14);
//        org.joda.time.MonthDay.Property property18 = monthDay17.dayOfMonth();
//        java.lang.String str19 = property18.getName();
//        java.lang.String str20 = property18.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder9.appendSignedDecimal(dateTimeFieldType21, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder8.appendFixedDecimal(dateTimeFieldType21, 23);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType21, 59938);
//        int int31 = dividedDateTimeField28.getDifference((long) 0, 1L);
//        long long34 = dividedDateTimeField28.add(2138779641600100L, (long) 3);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "dayOfMonth" + "'", str19.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2247531148800100L + "'", long34 == 2247531148800100L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        int int8 = delegatedDateTimeField6.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField9 = delegatedDateTimeField6.getWrappedField();
        boolean boolean10 = delegatedDateTimeField6.isSupported();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6, (int) 'a');
        java.lang.String str13 = delegatedDateTimeField6.getName();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "secondOfDay" + "'", str13.equals("secondOfDay"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.ReadableInterval readableInterval6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-32), 100, (int) 'a', (int) (short) -1, (int) ' ', 9700, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour(0);
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMinutes(15);
//        int int7 = dateTime6.getDayOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str15 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone22 = fixedDateTimeZone21.toTimeZone();
        java.lang.String str24 = fixedDateTimeZone21.getName((long) 10);
        java.util.TimeZone timeZone25 = fixedDateTimeZone21.toTimeZone();
        boolean boolean26 = fixedDateTimeZone21.isFixed();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.Chronology chronology28 = zonedChronology16.withZone(dateTimeZone27);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone27);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone27);
        long long34 = dateTimeZone27.convertLocalToUTC((-28800010L), true, (-3599948L));
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28800020L) + "'", long34 == (-28800020L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.util.TimeZone timeZone19 = fixedDateTimeZone12.toTimeZone();
        boolean boolean20 = fixedDateTimeZone12.isFixed();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis(5);
        long long24 = fixedDateTimeZone12.getMillisKeepLocal(dateTimeZone22, (long) 6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 11L + "'", long24 == 11L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean5 = dateTimeFormatter4.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter4.withPivotYear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str4 = illegalFieldValueException2.toString();
        java.lang.Number number5 = illegalFieldValueException2.getLowerBound();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        illegalFieldValueException2.prependMessage("DateTimeField[dayOfMonth]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported"));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "dayOfMonth" + "'", str6.equals("dayOfMonth"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gJChronology0.seconds();
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
        java.lang.String str6 = monthDay4.toString("+00:00:00.010");
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay4.getFields();
        int[] intArray8 = monthDay4.getValues();
        try {
            gJChronology0.validate(readablePartial3, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(intArray8);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone10);
//        org.joda.time.MonthDay.Property property14 = monthDay13.dayOfMonth();
//        java.lang.String str15 = property14.getName();
//        java.lang.String str16 = property14.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType17, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType17, 23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 57600);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap27 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendTimeZoneShortName(strMap27);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder26.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendTimeZoneShortName(strMap32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder31.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        int int38 = dateTimeZone36.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay39 = org.joda.time.MonthDay.now(dateTimeZone36);
//        org.joda.time.MonthDay.Property property40 = monthDay39.dayOfMonth();
//        java.lang.String str41 = property40.getName();
//        java.lang.String str42 = property40.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder31.appendSignedDecimal(dateTimeFieldType43, 12, 0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder30.appendFixedDecimal(dateTimeFieldType43, 23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder30.appendFractionOfSecond(0, 57600);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder30.appendFractionOfHour((int) 'a', (int) (byte) 1);
//        org.joda.time.format.DateTimeParser dateTimeParser55 = dateTimeFormatterBuilder30.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder25.append(dateTimeParser55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertNotNull(monthDay39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "dayOfMonth" + "'", str41.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertNotNull(dateTimeParser55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
//        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
//        java.util.Locale locale8 = null;
//        int int9 = delegatedDateTimeField4.getMaximumTextLength(locale8);
//        org.joda.time.ReadableInterval readableInterval10 = null;
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval10);
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(chronology11);
//        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (short) 10);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.MonthDay monthDay16 = monthDay12.withChronologyRetainFields((org.joda.time.Chronology) gJChronology15);
//        int int17 = monthDay16.getMonthOfYear();
//        org.joda.time.ReadableInterval readableInterval18 = null;
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval18);
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(chronology19);
//        org.joda.time.MonthDay monthDay22 = monthDay20.minusDays((int) (short) 10);
//        int[] intArray23 = monthDay22.getValues();
//        boolean boolean24 = monthDay16.isEqual((org.joda.time.ReadablePartial) monthDay22);
//        org.joda.time.ReadableInterval readableInterval25 = null;
//        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval25);
//        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(chronology26);
//        org.joda.time.MonthDay monthDay29 = monthDay27.minusDays((int) (short) 10);
//        int[] intArray30 = monthDay29.getValues();
//        int int31 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay16, intArray30);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(monthDay29);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        java.util.Locale locale20 = null;
        int int21 = property6.getMaximumShortTextLength(locale20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, readableInstant23);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.monthOfYear();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.era();
        org.joda.time.DurationField durationField27 = gJChronology24.hours();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime31 = dateTime29.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime32 = dateTime31.toLocalTime();
        long long34 = gJChronology24.set((org.joda.time.ReadablePartial) localTime32, 52L);
        boolean boolean35 = property6.equals((java.lang.Object) 52L);
        org.joda.time.DateTime dateTime36 = property6.roundHalfFloorCopy();
        java.lang.String str37 = property6.getAsShortText();
        java.lang.String str38 = property6.getName();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(localTime32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 82800052L + "'", long34 == 82800052L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "0" + "'", str37.equals("0"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "minuteOfHour" + "'", str38.equals("minuteOfHour"));
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
//        java.util.TimeZone timeZone6 = fixedDateTimeZone5.toTimeZone();
//        java.lang.String str8 = fixedDateTimeZone5.getName((long) 10);
//        boolean boolean9 = fixedDateTimeZone5.isFixed();
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.010" + "'", str8.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "����-01-01T��:��:��" + "'", str11.equals("����-01-01T��:��:��"));
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        int int9 = dateTimeZone7.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay10 = org.joda.time.MonthDay.now(dateTimeZone7);
//        org.joda.time.MonthDay.Property property11 = monthDay10.dayOfMonth();
//        java.lang.String str12 = property11.getName();
//        java.lang.String str13 = property11.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder4.appendFixedSignedDecimal(dateTimeFieldType14, 9700);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType14);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
//        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
//        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
//        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
//        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField27.getWrappedField();
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) (short) -1);
//        int int36 = dateTime35.getSecondOfMinute();
//        org.joda.time.DateTime dateTime38 = dateTime35.minusHours((int) (short) 0);
//        org.joda.time.DateTime dateTime40 = dateTime38.withHourOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder41.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        int int47 = dateTimeZone45.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now(dateTimeZone45);
//        org.joda.time.MonthDay.Property property49 = monthDay48.dayOfMonth();
//        java.lang.String str50 = property49.getName();
//        java.lang.String str51 = property49.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType52 = property49.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder42.appendFixedSignedDecimal(dateTimeFieldType52, 9700);
//        int int55 = dateTime38.get(dateTimeFieldType52);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType52, 83940062);
//        org.joda.time.DurationField durationField58 = remainderDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField58);
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
//        int int62 = dateTimeZone60.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now(dateTimeZone60);
//        org.joda.time.MonthDay.Property property64 = monthDay63.monthOfYear();
//        int int65 = monthDay63.getDayOfMonth();
//        try {
//            int int66 = unsupportedDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay63);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfMonth field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "dayOfMonth" + "'", str12.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertNotNull(monthDay48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "dayOfMonth" + "'", str50.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1" + "'", str51.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType52);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
//        org.junit.Assert.assertNotNull(monthDay63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }
}

