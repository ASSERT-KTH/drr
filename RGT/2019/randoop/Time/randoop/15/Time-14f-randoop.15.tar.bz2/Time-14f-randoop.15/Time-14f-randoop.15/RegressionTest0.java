import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(1, (int) (short) -1, 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-1L));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy("hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 0, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        try {
            long long8 = gJChronology2.getDateTimeMillis(0, (int) (byte) 0, (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        try {
            boolean boolean11 = localDate5.isAfter((org.joda.time.ReadablePartial) localTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.io.Writer writer2 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        int int7 = dateTime6.getSecondOfMinute();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.ReadableInstant readableInstant5 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        int int6 = localTime4.indexOf(dateTimeFieldType5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            int int8 = localTime4.get(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
//        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
//        long long7 = property6.remainder();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', 59, (int) (byte) 100, (int) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        boolean boolean6 = fixedDateTimeZone4.isStandardOffset((long) 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        try {
            long long11 = gJChronology2.getDateTimeMillis(0L, (int) (byte) -1, 0, (int) (byte) 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfDay();
        try {
            long long9 = gJChronology2.getDateTimeMillis((long) 100, (int) '#', (int) ' ', 0, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-1), 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
//        java.io.Writer writer2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        int int5 = dateTimeZone3.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now(dateTimeZone3);
//        try {
//            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) monthDay6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
//        org.junit.Assert.assertNotNull(monthDay6);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.io.Writer writer2 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime13 = dateTime11.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean15 = dateTime13.equals((java.lang.Object) dateTimeFormatter14);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime20 = dateTime19.toLocalTime();
        org.joda.time.DateTime dateTime21 = dateTime13.withFields((org.joda.time.ReadablePartial) localTime20);
        long long22 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
        try {
            dateTimeFormatter1.printTo(writer2, (org.joda.time.ReadableInstant) dateTime21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        try {
//            org.joda.time.MonthDay monthDay5 = monthDay3.withDayOfMonth(59);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
//        org.junit.Assert.assertNotNull(monthDay3);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.DateTime.Property property4 = dateTime3.year();
//        java.lang.String str5 = property4.getAsShortText();
//        long long6 = property4.remainder();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 31503600052L + "'", long6 == 31503600052L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, 0, 59948, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        try {
            org.joda.time.DateTime dateTime6 = property4.setCopy("+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.010\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("1969", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
//        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
//        org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) dateTime1);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekyear();
//        int int7 = dateTime1.getYearOfCentury();
//        int int8 = dateTime1.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57600 + "'", int8 == 57600);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        try {
            org.joda.time.DateTime dateTime20 = dateTime3.withMillisOfSecond(57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
//        java.lang.String str2 = dateTimeFormatter0.print(10L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "12/31/69" + "'", str2.equals("12/31/69"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, readableInstant6);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(10, 0, (-2), 59, (int) (byte) 100, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(31);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withField(dateTimeFieldType3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra((int) ' ');
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) (short) -1, (java.lang.Number) 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '#');
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(69, 57600, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 100, (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        try {
            java.lang.String str3 = dateTimeFormatter0.print(35L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTimeField dateTimeField13 = localTime10.getField(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField16 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType14, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.DateTime dateTime17 = dateTime11.withField(dateTimeFieldType15, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfDay();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.clockhourOfHalfday();
        try {
            long long13 = gJChronology2.getDateTimeMillis((int) (short) -1, 2, (-2), (int) (short) -1, (int) (byte) 100, 59, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = copticChronology0.get(readablePeriod1, (long) (byte) 1, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(59948, (-28800000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28740052) + "'", int2 == (-28740052));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        long long13 = dateTime3.getMillis();
        boolean boolean14 = dateTime3.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3599948L) + "'", long13 == (-3599948L));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("12/31/69");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int int7 = localDate5.compareTo(readablePartial6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime9.withField(dateTimeFieldType10, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        java.util.TimeZone timeZone19 = fixedDateTimeZone12.toTimeZone();
        long long21 = fixedDateTimeZone12.previousTransition((long) 57600);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 57600L + "'", long21 == 57600L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 2, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 1, 3, 0, (-28740052), 0, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28740052 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMinutes(19);
        try {
            org.joda.time.DateTime dateTime13 = dateTime3.withTime((int) '#', 2, (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime15);
        org.joda.time.DateTime dateTime17 = dateTime1.withFields((org.joda.time.ReadablePartial) localTime15);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, readableInstant19);
        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.monthOfYear();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.era();
        org.joda.time.DurationField durationField23 = gJChronology20.hours();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime27 = dateTime25.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime28 = dateTime27.toLocalTime();
        long long30 = gJChronology20.set((org.joda.time.ReadablePartial) localTime28, 52L);
        int int31 = localTime15.compareTo((org.joda.time.ReadablePartial) localTime28);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localTime28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 82800052L + "'", long30 == 82800052L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, (int) (byte) -1, (int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        try {
            org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        org.joda.time.DateTime.Property property15 = dateTime14.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "150000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            long long3 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2, (-2), 0, (int) (byte) 0, (-2), 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.plus(readableDuration6);
        long long8 = instant5.getMillis();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-12219292800000L) + "'", long8 == (-12219292800000L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(100, (int) (short) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        int int5 = dateTime3.getDayOfWeek();
        java.util.Locale locale7 = null;
        java.lang.String str8 = dateTime3.toString("0", locale7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfMinute();
        try {
            long long12 = gJChronology2.getDateTimeMillis((-28800000), 10, (int) '4', (int) (byte) 0, (-2), 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        try {
            long long14 = gJChronology2.getDateTimeMillis(0, 3, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("150000", "1969", 59, 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        java.lang.String str15 = dateTime11.toString("12/31/69");
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12/31/69" + "'", str15.equals("12/31/69"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        java.lang.String str5 = property4.getAsShortText();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        int int19 = property4.getDifference((org.joda.time.ReadableInstant) dateTime18);
        long long20 = property4.remainder();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 31532400062L + "'", long20 == 31532400062L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean7 = dateTime5.equals((java.lang.Object) dateTimeFormatter6);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.joda.time.DateTime dateTime13 = dateTime5.withFields((org.joda.time.ReadablePartial) localTime12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime13.plusHours((-2));
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime17, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str2 = monthDay0.toString("+00:00:00.010");
        org.joda.time.MonthDay monthDay4 = monthDay0.plusDays((int) (byte) 0);
        try {
            java.lang.String str6 = monthDay0.toString("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.010" + "'", str2.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime17 = dateTime12.withCenturyOfEra((int) 'a');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours((-2));
        try {
            org.joda.time.DateTime dateTime19 = dateTime11.withDate((-28740052), 0, (-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        java.lang.String str9 = gJChronology4.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GJChronology[]" + "'", str9.equals("GJChronology[]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        boolean boolean10 = dateTime7.isBefore((long) 12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = dateTime12.plusSeconds((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology18 = iSOChronology17.withUTC();
        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology17);
        try {
            org.joda.time.DateTime dateTime21 = dateTime12.withDayOfMonth(9700);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.era();
        org.joda.time.DurationField durationField13 = gJChronology10.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField14 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField7, durationField13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        int int12 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime.Property property13 = dateTime3.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            int int15 = dateTime3.get(dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = gJChronology4.get(readablePeriod9, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[year]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        org.joda.time.Chronology chronology7 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int8 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField9 = julianChronology0.days();
        try {
            long long14 = julianChronology0.getDateTimeMillis(59948, (int) 'a', 57600, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        org.joda.time.Chronology chronology7 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int8 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadableInterval readableInterval9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval9);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(chronology10);
        int[] intArray18 = new int[] { 9, 0, (short) 100, (short) -1, ' ', 0 };
        try {
            julianChronology0.validate((org.joda.time.ReadablePartial) monthDay11, intArray18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(57600, 69, 0, 97, (int) (byte) 100, (int) (byte) 100, 100, (org.joda.time.Chronology) copticChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.MonthDay monthDay4 = monthDay2.minusDays((int) (short) 10);
        org.joda.time.Chronology chronology5 = monthDay4.getChronology();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay.Property property1 = monthDay0.monthOfYear();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            boolean boolean3 = monthDay0.isBefore(readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime9);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal((long) 10);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.MonthDay monthDay3 = monthDay0.withField(dateTimeFieldType1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime6.withTimeAtStartOfDay();
        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime11 = dateTime9.withLaterOffsetAtOverlap();
        long long12 = dateTime9.getMillis();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-10L) + "'", long12 == (-10L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((-2));
        org.joda.time.DateTime.Property property15 = dateTime12.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime17 = dateTime12.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) 59948, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.MonthDay monthDay4 = monthDay2.minusDays((int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.MonthDay monthDay6 = monthDay2.withChronologyRetainFields((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.MonthDay.Property property8 = monthDay2.property(dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(52L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5200L + "'", long2 == 5200L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean25 = dateTime23.equals((java.lang.Object) dateTimeFormatter24);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime29 = dateTime27.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime30 = dateTime29.toLocalTime();
        org.joda.time.DateTime dateTime31 = dateTime23.withFields((org.joda.time.ReadablePartial) localTime30);
        org.joda.time.DateTime dateTime34 = dateTime31.withDurationAdded((long) (byte) 1, 0);
        long long35 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime34);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone1.isLocalDateTimeGap(localDateTime3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.MonthDay monthDay4 = monthDay2.minusDays((int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.MonthDay monthDay6 = monthDay2.withChronologyRetainFields((org.joda.time.Chronology) gJChronology5);
        try {
            org.joda.time.MonthDay monthDay8 = monthDay2.withDayOfMonth((-28740052));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28740052 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = monthDay3.toString("Property[year]", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        java.util.Locale locale15 = null;
        try {
            long long16 = offsetDateTimeField9.set(0L, "0", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for secondOfDay must be in the range [97,86496]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        try {
            long long11 = gJChronology2.getDateTimeMillis((int) '#', 15, 15, 59948, 59, (int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59948 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        long long9 = property8.remainder();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.clockhourOfHalfday();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str12 = fixedDateTimeZone11.toString();
        org.joda.time.Chronology chronology13 = gJChronology3.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        try {
            org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("150000");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"150000/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.weekyear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        java.util.Locale locale8 = null;
        try {
            org.joda.time.MonthDay monthDay9 = property4.setCopy("hi!", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
        java.lang.String str22 = property8.getAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "82860000" + "'", str22.equals("82860000"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) 12, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay();
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 4, dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-2), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.joda.time.Instant instant10 = instant5.withDurationAdded((long) (byte) 10, 4);
        org.joda.time.Chronology chronology11 = instant5.getChronology();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (-2));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        java.util.Locale locale9 = dateTimeFormatter8.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(locale9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        int int7 = property6.getMaximumValue();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property6.getAsShortText(locale8);
        int int10 = property6.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 59 + "'", int10 == 59);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj2 = null;
        jodaTimePermission1.checkGuard(obj2);
        java.lang.String str4 = jodaTimePermission1.toString();
        jodaTimePermission1.checkGuard((java.lang.Object) (short) 100);
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(permissionCollection7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(copticChronology1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3200 + "'", int2 == 3200);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gJChronology2.get(readablePeriod5, (long) 59948);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DurationField durationField20 = property6.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType1, 31, 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 86496, "DateTimeField[secondOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = dateTime3.minusDays(19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        try {
            long long15 = offsetDateTimeField9.set((long) 12, "millisOfSecond");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"millisOfSecond\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime23 = property8.setCopy(1);
        int int24 = property8.getMaximumValue();
        org.joda.time.DateTime dateTime25 = property8.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 86399999 + "'", int24 == 86399999);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(31503600052L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField4.getMaximumShortTextLength(locale8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        long long15 = dateTime3.getMillis();
        java.lang.String str16 = dateTime3.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3599948L) + "'", long15 == (-3599948L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969-12-31T23:00:00.062+00:00:00.010" + "'", str16.equals("1969-12-31T23:00:00.062+00:00:00.010"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        int int7 = property6.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra((int) ' ');
        java.util.GregorianCalendar gregorianCalendar7 = dateTime1.toGregorianCalendar();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar7);
        try {
            org.joda.time.DateTimeField dateTimeField10 = monthDay8.getField(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            java.lang.String str2 = dateTimeFormatter0.print(readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        long long9 = delegatedDateTimeField4.roundFloor((long) 15);
        long long11 = delegatedDateTimeField4.roundHalfFloor((long) 100);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.era();
//        org.joda.time.Instant instant11 = gJChronology8.getGregorianCutover();
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.Instant instant13 = instant11.minus(readableDuration12);
//        org.joda.time.Instant instant15 = instant13.plus((long) 59948);
//        int int16 = property4.compareTo((org.joda.time.ReadableInstant) instant15);
//        java.util.Locale locale18 = null;
//        try {
//            org.joda.time.MonthDay monthDay19 = property4.setCopy("GJChronology[]", locale18);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[]\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(instant11);
//        org.junit.Assert.assertNotNull(instant13);
//        org.junit.Assert.assertNotNull(instant15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.lang.StringBuffer stringBuffer2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime11.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property15 = dateTime11.yearOfCentury();
        org.joda.time.Interval interval16 = property15.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(interval16);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime1.minusDays(9700);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        org.joda.time.Chronology chronology7 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean18 = dateTime16.equals((java.lang.Object) dateTimeFormatter17);
        org.joda.time.DateTime.Property property19 = dateTime16.minuteOfHour();
        org.joda.time.DateTime dateTime20 = property19.roundCeilingCopy();
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime22 = localTime12.toDateTime((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.plusSeconds((int) (byte) 10);
        try {
            org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6, (org.joda.time.ReadableInstant) dateTime24, (-32));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withDayOfMonth((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter18.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.joda.time.DateTimeField dateTimeField0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now(dateTimeZone1);
//        org.joda.time.MonthDay.Property property5 = monthDay4.dayOfMonth();
//        java.lang.String str6 = property5.getName();
//        java.lang.String str7 = property5.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType8, (int) (short) 1, (-32), 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "dayOfMonth" + "'", str6.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "14" + "'", str7.equals("14"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType8);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("dayOfMonth");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfMonth\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((-2));
        org.joda.time.DateTime.Property property15 = dateTime12.weekOfWeekyear();
        int int16 = dateTime12.getMonthOfYear();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        int int6 = localTime4.indexOf(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime11 = dateTime10.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        int int13 = localTime11.indexOf(dateTimeFieldType12);
        boolean boolean14 = localTime4.isBefore((org.joda.time.ReadablePartial) localTime11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.lang.String str16 = localTime4.toString(dateTimeFormatter15);
        java.lang.StringBuffer stringBuffer17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        int int20 = dateTimeZone18.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now(dateTimeZone18);
        org.joda.time.MonthDay.Property property22 = monthDay21.dayOfMonth();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = monthDay21.getFieldTypes();
        int int24 = monthDay21.getMonthOfYear();
        try {
            dateTimeFormatter15.printTo(stringBuffer17, (org.joda.time.ReadablePartial) monthDay21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "230000" + "'", str16.equals("230000"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField4, (-32), 5, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for secondOfDay must be in the range [5,6]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str2 = monthDay0.toString("+00:00:00.010");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.secondOfDay();
        org.joda.time.MonthDay monthDay6 = monthDay0.withChronologyRetainFields((org.joda.time.Chronology) gJChronology3);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay0.minus(readablePeriod7);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.010" + "'", str2.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendCenturyOfEra((int) (byte) -1, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.millisOfDay();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime23 = property8.setCopy(1);
        int int24 = property8.getMaximumValue();
        java.util.Locale locale26 = null;
        try {
            org.joda.time.DateTime dateTime27 = property8.setCopy("(\"org.joda.time.JodaTimePermission\" \"hi!\")", locale26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"(\"org.joda.time.JodaTimePermission\" \"hi!\")\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 86399999 + "'", int24 == 86399999);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.secondOfDay();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        int int7 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime dateTime9 = dateTime3.minus((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 19 + "'", int7 == 19);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(3200, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3200 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
        java.lang.String str5 = property4.getName();
        java.util.Locale locale6 = null;
        int int7 = property4.getMaximumTextLength(locale6);
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        java.lang.String str9 = property4.getName();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 97);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean9 = dateTime7.equals((java.lang.Object) dateTimeFormatter8);
        org.joda.time.DateTime.Property property10 = dateTime7.millisOfDay();
        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "T23:00:00+00:00:00.010" + "'", str11.equals("T23:00:00+00:00:00.010"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
        java.lang.String str5 = property4.getName();
        java.util.Locale locale6 = null;
        int int7 = property4.getMaximumTextLength(locale6);
        org.joda.time.MonthDay monthDay9 = property4.addToCopy(1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.LocalTime localTime4 = dateTimeFormatter1.parseLocalTime("1");
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(localTime4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        boolean boolean4 = jodaTimePermission1.equals((java.lang.Object) (byte) 100);
        java.lang.Object obj5 = null;
        jodaTimePermission1.checkGuard(obj5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '0' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime.Property property11 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime13 = dateTime3.minusMillis(59);
        int int14 = dateTime3.getCenturyOfEra();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, readableInstant15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 19 + "'", int14 == 19);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(6, (int) (byte) 100, (int) ' ', (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        int int15 = offsetDateTimeField9.getDifference((-10L), (long) (short) -1);
        int int17 = offsetDateTimeField9.get((long) 69);
        long long20 = offsetDateTimeField9.add((long) (short) -1, (int) (short) 10);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField9.getAsText(15, locale22);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9999L + "'", long20 == 9999L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "15" + "'", str23.equals("15"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
        boolean boolean15 = offsetDateTimeField9.isLeap(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1969");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1969/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime11.toMutableDateTimeISO();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.String str16 = mutableDateTime14.toString(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969-12" + "'", str16.equals("1969-12"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((-2));
        int int15 = dateTime12.getMinuteOfHour();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 51 + "'", int15 == 51);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.JodaTimePermission jodaTimePermission2 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj3 = null;
        jodaTimePermission2.checkGuard(obj3);
        java.lang.String str5 = jodaTimePermission2.toString();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj8 = null;
        jodaTimePermission7.checkGuard(obj8);
        java.lang.String str10 = jodaTimePermission7.toString();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean16 = dateTime14.equals((java.lang.Object) dateTimeFormatter15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime22 = dateTime14.withFields((org.joda.time.ReadablePartial) localTime21);
        jodaTimePermission7.checkGuard((java.lang.Object) dateTime14);
        boolean boolean24 = jodaTimePermission2.equals((java.lang.Object) jodaTimePermission7);
        boolean boolean25 = julianChronology0.equals((java.lang.Object) jodaTimePermission7);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology0.clockhourOfHalfday();
        int int27 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str10.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        int int13 = delegatedDateTimeField4.getLeapAmount((long) (short) 10);
        java.util.Locale locale15 = null;
        java.lang.String str16 = delegatedDateTimeField4.getAsShortText(3200, locale15);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3200" + "'", str16.equals("3200"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime12.withTimeAtStartOfDay();
        int int16 = property10.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime dateTime17 = dateTime15.withLaterOffsetAtOverlap();
        boolean boolean18 = instant5.isEqual((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str19 = dateTime15.toString();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime15.minus(readableDuration20);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970-01-01T00:00:00.000+00:00:00.010" + "'", str19.equals("1970-01-01T00:00:00.000+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        int int7 = dateTimeZone5.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone5);
        int[] intArray10 = null;
        try {
            int[] intArray12 = delegatedDateTimeField4.add((org.joda.time.ReadablePartial) monthDay8, (int) (short) -1, intArray10, 59948);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-32), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3104L) + "'", long2 == (-3104L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        try {
            org.joda.time.DateTime dateTime16 = dateTime3.withDayOfWeek(57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMinutes(19);
        int int9 = dateTime8.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 83940062 + "'", int9 == 83940062);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = gregorianChronology0.withUTC();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(31, (int) (byte) 10, 86496, (-28800000), (int) (byte) -1, (int) (byte) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        int int13 = delegatedDateTimeField4.getLeapAmount((long) (short) 10);
        boolean boolean14 = delegatedDateTimeField4.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 97);
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = dateTimeFormatter3.parseMutableDateTime("1969-12");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        java.lang.String str5 = property4.getAsShortText();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        java.lang.String str7 = property4.getAsText();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        org.joda.time.Chronology chronology7 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        int int8 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        try {
            int[] intArray11 = julianChronology0.get(readablePeriod9, (long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DurationField durationField15 = property14.getDurationField();
        java.lang.String str16 = property14.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Property[dayOfMonth]" + "'", str16.equals("Property[dayOfMonth]"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        long long11 = copticChronology3.getDateTimeMillis((int) (byte) 1, 4, 19, 0, 3, 0, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        try {
            long long17 = copticChronology3.getDateTimeMillis(3200, (int) ' ', (-28740052), 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-53174879820000L) + "'", long11 == (-53174879820000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        int int7 = dateTimeZone5.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone5);
//        org.joda.time.MonthDay.Property property9 = monthDay8.dayOfMonth();
//        java.lang.String str10 = property9.getName();
//        java.lang.String str11 = property9.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType12, 12, 0);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, readableInstant17);
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.era();
//        org.joda.time.DurationField durationField21 = gJChronology18.hours();
//        org.joda.time.DurationField durationField22 = gJChronology18.halfdays();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime26 = dateTime24.plusHours((int) (short) -1);
//        org.joda.time.LocalTime localTime27 = dateTime26.toLocalTime();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) '4');
//        org.joda.time.DateTime dateTime31 = dateTime29.plusHours((int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        boolean boolean33 = dateTime31.equals((java.lang.Object) dateTimeFormatter32);
//        org.joda.time.DateTime.Property property34 = dateTime31.minuteOfHour();
//        org.joda.time.DateTime dateTime35 = property34.roundCeilingCopy();
//        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime dateTime37 = localTime27.toDateTime((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime dateTime39 = dateTime35.plusSeconds((int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology41 = iSOChronology40.withUTC();
//        org.joda.time.DateTime dateTime42 = dateTime35.toDateTime((org.joda.time.Chronology) iSOChronology40);
//        org.joda.time.DurationField durationField43 = iSOChronology40.eras();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType12, durationField22, durationField43);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "dayOfMonth" + "'", str10.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "14" + "'", str11.equals("14"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localTime27);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(durationField43);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.fromDateFields(date2);
        java.lang.String str4 = monthDay3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "--12-31" + "'", str4.equals("--12-31"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = dateTime12.plusSeconds((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology18 = iSOChronology17.withUTC();
        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DurationField durationField20 = iSOChronology17.eras();
        try {
            long long23 = durationField20.subtract(5200L, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean21 = dateTime19.equals((java.lang.Object) dateTimeFormatter20);
        org.joda.time.DateTime.Property property22 = dateTime19.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = localTime15.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime25);
        int int30 = dateTime25.getHourOfDay();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 23 + "'", int30 == 23);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay();
        try {
            java.lang.String str2 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMinutes(19);
        org.joda.time.DateTime.Property property9 = dateTime3.centuryOfEra();
        java.lang.Class<?> wildcardClass10 = property9.getClass();
        org.joda.time.DateTime dateTime11 = property9.withMaximumValue();
        org.joda.time.DurationField durationField12 = property9.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.security.Permission permission2 = null;
        boolean boolean3 = jodaTimePermission1.implies(permission2);
        java.lang.String str4 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str8 = jodaTimePermission7.getActions();
        boolean boolean10 = jodaTimePermission7.equals((java.lang.Object) (byte) 100);
        java.security.Permission permission11 = null;
        boolean boolean12 = jodaTimePermission7.implies(permission11);
        boolean boolean13 = jodaTimePermission1.implies(permission11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = dateTime12.plusSeconds((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology18 = iSOChronology17.withUTC();
        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (short) -1);
        int int24 = dateTime23.getSecondOfMinute();
        org.joda.time.DateTime dateTime26 = dateTime23.minusHours((int) (short) 0);
        boolean boolean27 = dateTime19.equals((java.lang.Object) (short) 0);
        try {
            org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((java.lang.Object) boolean27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
        int int16 = offsetDateTimeField9.getMaximumValue((long) (byte) 100);
        java.lang.String str18 = offsetDateTimeField9.getAsText((long) 69);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now(dateTimeZone19);
        org.joda.time.MonthDay.Property property23 = monthDay22.monthOfYear();
        org.joda.time.MonthDay monthDay25 = monthDay22.plusMonths(97);
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.MonthDay monthDay30 = monthDay28.minusDays((int) (short) 10);
        int[] intArray31 = monthDay30.getValues();
        int int32 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay25, intArray31);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime36 = dateTime34.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime37 = dateTime36.toLocalTime();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime41 = dateTime39.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean43 = dateTime41.equals((java.lang.Object) dateTimeFormatter42);
        org.joda.time.DateTime.Property property44 = dateTime41.minuteOfHour();
        org.joda.time.DateTime dateTime45 = property44.roundCeilingCopy();
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime45);
        org.joda.time.DateTime dateTime47 = localTime37.toDateTime((org.joda.time.ReadableInstant) dateTime45);
        try {
            boolean boolean48 = monthDay25.isEqual((org.joda.time.ReadablePartial) localTime37);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86496 + "'", int16 == 86496);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localTime37);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(dateTime47);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(chronology1);
        org.joda.time.MonthDay monthDay4 = monthDay2.minusDays((int) (short) 10);
        int[] intArray5 = monthDay4.getValues();
        java.util.Locale locale7 = null;
        try {
            java.lang.String str8 = monthDay4.toString("DateTimeField[secondOfDay]", locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        boolean boolean10 = offsetDateTimeField9.isSupported();
        long long13 = offsetDateTimeField9.addWrapField((long) 86496, 86399999);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 85496L + "'", long13 == 85496L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((-2));
        org.joda.time.DateTime.Property property15 = dateTime12.weekOfWeekyear();
        java.lang.String str16 = property15.getName();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "weekOfWeekyear" + "'", str16.equals("weekOfWeekyear"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = fixedDateTimeZone4.previousTransition(99L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 99L + "'", long11 == 99L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology2.add(readablePeriod6, (long) (byte) 1, (-28740052));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str15 = fixedDateTimeZone14.toString();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology2.minuteOfHour();
        try {
            long long25 = gJChronology2.getDateTimeMillis((int) 'a', (int) (byte) 1, 3200, (int) (short) 1, 3, 69, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay(2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        int int6 = dateTimeZone4.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone4);
//        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
//        java.lang.String str9 = property8.getName();
//        java.lang.String str10 = property8.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType11, 9700);
//        boolean boolean14 = dateTimeFormatterBuilder1.canBuildParser();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "14" + "'", str10.equals("14"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("dayOfMonth", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfMonth\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        long long11 = copticChronology3.getDateTimeMillis((int) (byte) 1, 4, 19, 0, 3, 0, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withPivotYear(5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-53174879820000L) + "'", long11 == (-53174879820000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone2);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        java.lang.String str7 = property6.getName();
//        java.lang.String str8 = property6.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property6.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType9, 2000, 86399999);
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfWeek((-28740052));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "14" + "'", str8.equals("14"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone2);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        java.lang.String str7 = property6.getName();
//        java.lang.String str8 = property6.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property6.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType9, 2000, 86399999);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap14 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendTimeZoneShortName(strMap14);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendHourOfHalfday((int) ' ');
//        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatterBuilder17.toPrinter();
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray19 = new org.joda.time.format.DateTimeParser[] {};
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder1.append(dateTimePrinter18, dateTimeParserArray19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "14" + "'", str8.equals("14"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimePrinter18);
//        org.junit.Assert.assertNotNull(dateTimeParserArray19);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime22 = property8.roundHalfFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, readableInstant24);
        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.monthOfYear();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.era();
        org.joda.time.Instant instant28 = gJChronology25.getGregorianCutover();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime32 = dateTime30.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property33 = dateTime32.year();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime37 = dateTime35.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime38 = dateTime35.withTimeAtStartOfDay();
        int int39 = property33.compareTo((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime40 = dateTime38.withLaterOffsetAtOverlap();
        boolean boolean41 = instant28.isEqual((org.joda.time.ReadableInstant) dateTime38);
        java.lang.String str42 = dateTime38.toString();
        boolean boolean43 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime38);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(instant28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1970-01-01T00:00:00.000+00:00:00.010" + "'", str42.equals("1970-01-01T00:00:00.000+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        java.util.Locale locale6 = null;
//        int int7 = property4.getMaximumTextLength(locale6);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property4.getAsShortText(locale8);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14" + "'", str9.equals("14"));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        java.lang.Class<?> wildcardClass1 = dateTimeFormatter0.getClass();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendDayOfMonth(19);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYear((int) (short) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"hi!\")", "1969");
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 2, (long) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        int int5 = dateTime3.getDayOfWeek();
        int int6 = dateTime3.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DurationField durationField6 = gJChronology2.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        java.lang.String str14 = fixedDateTimeZone11.getName((long) 10);
        java.util.TimeZone timeZone15 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone17 = zonedChronology16.getZone();
        try {
            long long25 = zonedChronology16.getDateTimeMillis(100, 86399, 59938, 69, 15, 5, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.010" + "'", str14.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeParser dateTimeParser3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.append(dateTimeParser3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getMaximumValueOverall();
        try {
            org.joda.time.MonthDay monthDay9 = property4.setCopy("3200");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"3200\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        java.lang.String str6 = property4.toString();
        java.util.Locale locale7 = null;
        int int8 = property4.getMaximumShortTextLength(locale7);
        java.util.Locale locale9 = null;
        java.lang.String str10 = property4.getAsShortText(locale9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[year]" + "'", str6.equals("Property[year]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        long long18 = dateTime16.getMillis();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology24 = limitChronology22.withZone(dateTimeZone23);
        try {
            long long30 = limitChronology22.getDateTimeMillis((long) (byte) -1, 15, (int) (byte) 10, (-2), (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is above the supported maximum of 1970-01-01T00:00:00.000+00:00:00.010 (ISOChronology[])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = dateTime12.plusSeconds((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology18 = iSOChronology17.withUTC();
        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime21 = dateTime12.withDayOfYear(59);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTime12.toString("3200", locale23);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3200" + "'", str24.equals("3200"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withYearOfEra((int) ' ');
        java.util.GregorianCalendar gregorianCalendar7 = dateTime1.toGregorianCalendar();
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar7);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType10 = monthDay8.getFieldType((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField4.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        long long14 = delegatedDateTimeField4.addWrapField((long) 31, (-28740052));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 31148031L + "'", long14 == 31148031L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        java.lang.String str12 = delegatedDateTimeField4.getName();
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField4.getMaximumShortTextLength(locale13);
        int int16 = delegatedDateTimeField4.getMaximumValue(9602990L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfDay" + "'", str12.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86399 + "'", int16 == 86399);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DurationField durationField15 = property14.getDurationField();
        int int16 = property14.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime8.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime13 = dateTime8.withYearOfEra((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, readableInstant15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.minuteOfDay();
        org.joda.time.DateTime dateTime18 = dateTime13.withChronology((org.joda.time.Chronology) gJChronology16);
        boolean boolean19 = dateTime18.isAfterNow();
        org.joda.time.DateTime.Property property20 = dateTime18.hourOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone26 = fixedDateTimeZone25.toTimeZone();
        java.lang.String str28 = fixedDateTimeZone25.getName((long) 10);
        boolean boolean29 = fixedDateTimeZone25.isFixed();
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTime dateTime31 = dateTime18.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        try {
            org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(0, 59948, 2, 9700, 83940062, 12, 51, (org.joda.time.DateTimeZone) fixedDateTimeZone25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.010" + "'", str28.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMinutes(19);
        org.joda.time.DateTime.Property property9 = dateTime3.centuryOfEra();
        java.lang.Class<?> wildcardClass10 = property9.getClass();
        org.joda.time.DateTime dateTime11 = property9.withMaximumValue();
        java.lang.String str12 = property9.getAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "19" + "'", str12.equals("19"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = dateTime12.plusSeconds((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology18 = iSOChronology17.withUTC();
        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime21 = dateTime12.withDayOfYear(59);
        org.joda.time.DateTime dateTime23 = dateTime21.withCenturyOfEra(59938);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.plus(readableDuration6);
        org.joda.time.Instant instant10 = instant5.withDurationAdded(0L, 69);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.clockhourOfHalfday();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime14.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.MonthDay monthDay12 = monthDay9.withFieldAdded(durationFieldType10, 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfDay();
        java.lang.String str4 = gJChronology2.toString();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology2.add(readablePeriod5, (long) 31, 0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[]" + "'", str4.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31L + "'", long8 == 31L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        java.util.Locale locale20 = null;
        int int21 = property6.getMaximumShortTextLength(locale20);
        java.lang.String str22 = property6.getAsText();
        java.lang.String str23 = property6.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[minuteOfHour]" + "'", str23.equals("Property[minuteOfHour]"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        java.lang.String str5 = property4.getAsString();
        java.util.Locale locale6 = null;
        int int7 = property4.getMaximumTextLength(locale6);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "6" + "'", str5.equals("6"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
//        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
//        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
//        java.lang.String str5 = property4.getName();
//        java.lang.String str6 = property4.getAsString();
//        org.joda.time.DurationField durationField7 = property4.getDurationField();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property4.getAsShortText(locale8);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(monthDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "14" + "'", str6.equals("14"));
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14" + "'", str9.equals("14"));
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendFractionOfSecond(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime23 = property8.setCopy(1);
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(chronology25);
        org.joda.time.MonthDay monthDay28 = monthDay26.minusDays((int) (short) 10);
        try {
            int int29 = property8.compareTo((org.joda.time.ReadablePartial) monthDay28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(monthDay28);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime23 = dateTime12.minusMinutes((int) (short) -1);
        int int24 = dateTime12.getMinuteOfHour();
        int int25 = dateTime12.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 51);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear((int) (byte) 100, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        long long15 = offsetDateTimeField9.roundCeiling((-28740010L));
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now(dateTimeZone16);
        org.joda.time.MonthDay.Property property20 = monthDay19.monthOfYear();
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) monthDay19, 59948, locale22);
        org.joda.time.ReadablePartial readablePartial24 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType29);
        int int32 = delegatedDateTimeField30.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField33 = delegatedDateTimeField30.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 97);
        long long38 = offsetDateTimeField35.getDifferenceAsLong((long) 10, (long) 59);
        int int40 = offsetDateTimeField35.getMaximumValue(9602990L);
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
        java.lang.String str43 = monthDay41.toString("+00:00:00.010");
        org.joda.time.MonthDay monthDay45 = monthDay41.plusDays((int) (byte) 0);
        org.joda.time.ReadableInterval readableInterval47 = null;
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval47);
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(chronology48);
        org.joda.time.MonthDay monthDay51 = monthDay49.minusDays((int) (short) 10);
        int[] intArray52 = monthDay51.getValues();
        int[] intArray54 = offsetDateTimeField35.add((org.joda.time.ReadablePartial) monthDay41, 57600, intArray52, 0);
        java.util.Locale locale56 = null;
        try {
            int[] intArray57 = offsetDateTimeField9.set(readablePartial24, (-2), intArray54, "DateTimeField[secondOfDay]", locale56);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[secondOfDay]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28740010L) + "'", long15 == (-28740010L));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59948" + "'", str23.equals("59948"));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 86496 + "'", int40 == 86496);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+00:00:00.010" + "'", str43.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime6.withTimeAtStartOfDay();
        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime11 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property12 = dateTime9.monthOfYear();
        org.joda.time.DateTime dateTime14 = dateTime9.plusMonths(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.DateTime dateTime6 = dateTime3.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime8 = dateTime6.withHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        int int15 = dateTimeZone13.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone13);
        org.joda.time.MonthDay.Property property17 = monthDay16.dayOfMonth();
        java.lang.String str18 = property17.getName();
        java.lang.String str19 = property17.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder10.appendFixedSignedDecimal(dateTimeFieldType20, 9700);
        int int23 = dateTime6.get(dateTimeFieldType20);
        org.joda.time.DateTime dateTime25 = dateTime6.withMillisOfSecond(100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "dayOfMonth" + "'", str18.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        org.joda.time.MonthDay monthDay6 = monthDay3.plusMonths(97);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.MonthDay monthDay9 = monthDay6.withFieldAdded(durationFieldType7, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        long long18 = dateTime16.getMillis();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology24 = limitChronology22.withZone(dateTimeZone23);
        try {
            long long32 = limitChronology22.getDateTimeMillis(0, (int) 'a', (int) ' ', (int) (byte) 100, (int) (short) -1, (int) (short) 10, 51);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        java.lang.String str5 = property4.getAsShortText();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        int int19 = property4.getDifference((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (short) -1);
        int int24 = dateTime23.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime23.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime23.hourOfDay();
        org.joda.time.DateTime dateTime33 = dateTime23.minusMillis(59);
        boolean boolean35 = dateTime23.isBefore((long) 2);
        int int36 = property4.getDifference((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.Interval interval37 = property4.toInterval();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(interval37);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        try {
            org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 24");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str5 = delegatedDateTimeField4.toString();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        java.lang.String str8 = monthDay6.toString("+00:00:00.010");
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay6, 2000, locale10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[secondOfDay]" + "'", str5.equals("DateTimeField[secondOfDay]"));
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.010" + "'", str8.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2000" + "'", str11.equals("2000"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.era();
        java.lang.String str3 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[]" + "'", str3.equals("JulianChronology[]"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("T23:00:00+00:00:00.010", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"T23:00:00+00:00:00.010/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("secondOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"secondOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.era();
        org.joda.time.Instant instant11 = gJChronology8.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant13 = instant11.minus(readableDuration12);
        org.joda.time.Instant instant15 = instant13.plus((long) 59948);
        int int16 = property4.compareTo((org.joda.time.ReadableInstant) instant15);
        java.lang.String str17 = property4.getAsShortText();
        int int18 = property4.getMinimumValue();
        java.lang.String str19 = property4.getAsShortText();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
        try {
            long long17 = offsetDateTimeField9.set((long) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for secondOfDay must be in the range [97,86496]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str12 = fixedDateTimeZone9.getName(82800052L);
        long long14 = fixedDateTimeZone9.nextTransition((long) 59);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.010" + "'", str12.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 59L + "'", long14 == 59L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2, 24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 48 + "'", int2 == 48);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.security.Permission permission2 = null;
        boolean boolean3 = jodaTimePermission1.implies(permission2);
        java.lang.String str4 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        int int10 = dateTime9.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime9.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTime.Property property17 = dateTime9.hourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime9.minusMillis(59);
        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime9);
        jodaTimePermission1.checkGuard((java.lang.Object) long20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3599948L) + "'", long20 == (-3599948L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getMaximumValueOverall();
        int int8 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(59948, 51, (int) (byte) 1, 69);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 38 + "'", int4 == 38);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        long long15 = offsetDateTimeField9.roundCeiling((long) 12);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 990L + "'", long15 == 990L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getMaximumValueOverall();
        java.util.Locale locale8 = null;
        int int9 = property4.getMaximumShortTextLength(locale8);
        java.lang.String str10 = property4.getAsString();
        org.joda.time.DurationField durationField11 = property4.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.joda.time.Instant instant10 = instant5.withDurationAdded((long) (byte) 10, 4);
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime4 = dateTime3.toLocalTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime14 = localTime4.toDateTime((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime16 = dateTime12.plusSeconds((int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology18 = iSOChronology17.withUTC();
        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime((org.joda.time.Chronology) iSOChronology17);
        org.joda.time.DateTime dateTime21 = dateTime12.withDayOfYear(59);
        org.joda.time.DateTime dateTime23 = dateTime12.withMillisOfSecond((int) '#');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long21 = fixedDateTimeZone12.convertLocalToUTC((long) (-28740052), false);
        java.util.TimeZone timeZone22 = fixedDateTimeZone12.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-28740062L) + "'", long21 == (-28740062L));
        org.junit.Assert.assertNotNull(timeZone22);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType4, (-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 1, 0);
        int int15 = dateTime11.getMonthOfYear();
        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime();
        int int17 = dateTime16.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1380 + "'", int17 == 1380);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.minuteOfDay();
        java.lang.String str4 = gJChronology2.toString();
        org.joda.time.DurationField durationField5 = gJChronology2.minutes();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GJChronology[]" + "'", str4.equals("GJChronology[]"));
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        boolean boolean10 = offsetDateTimeField9.isSupported();
        org.joda.time.DateTimeField dateTimeField11 = offsetDateTimeField9.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(48, 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67 + "'", int2 == 67);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        long long18 = dateTime16.getMillis();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology24 = limitChronology22.withZone(dateTimeZone23);
        try {
            long long32 = limitChronology22.getDateTimeMillis(83940062, 1, 2000, 0, 1, 97, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfDay(67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.JodaTimePermission jodaTimePermission2 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj3 = null;
        jodaTimePermission2.checkGuard(obj3);
        java.lang.String str5 = jodaTimePermission2.toString();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj8 = null;
        jodaTimePermission7.checkGuard(obj8);
        java.lang.String str10 = jodaTimePermission7.toString();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean16 = dateTime14.equals((java.lang.Object) dateTimeFormatter15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime22 = dateTime14.withFields((org.joda.time.ReadablePartial) localTime21);
        jodaTimePermission7.checkGuard((java.lang.Object) dateTime14);
        boolean boolean24 = jodaTimePermission2.equals((java.lang.Object) jodaTimePermission7);
        boolean boolean25 = julianChronology0.equals((java.lang.Object) jodaTimePermission7);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField27 = julianChronology0.millis();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str10.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jun\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.JodaTimePermission jodaTimePermission2 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj3 = null;
        jodaTimePermission2.checkGuard(obj3);
        java.lang.String str5 = jodaTimePermission2.toString();
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj8 = null;
        jodaTimePermission7.checkGuard(obj8);
        java.lang.String str10 = jodaTimePermission7.toString();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean16 = dateTime14.equals((java.lang.Object) dateTimeFormatter15);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime20 = dateTime18.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime21 = dateTime20.toLocalTime();
        org.joda.time.DateTime dateTime22 = dateTime14.withFields((org.joda.time.ReadablePartial) localTime21);
        jodaTimePermission7.checkGuard((java.lang.Object) dateTime14);
        boolean boolean24 = jodaTimePermission2.equals((java.lang.Object) jodaTimePermission7);
        boolean boolean25 = julianChronology0.equals((java.lang.Object) jodaTimePermission7);
        org.joda.time.DateTimeField dateTimeField26 = julianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str10.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
        int int16 = offsetDateTimeField9.getMaximumValue((long) (byte) 100);
        java.lang.String str18 = offsetDateTimeField9.getAsText((long) 69);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now(dateTimeZone19);
        org.joda.time.MonthDay.Property property23 = monthDay22.monthOfYear();
        org.joda.time.MonthDay monthDay25 = monthDay22.plusMonths(97);
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.MonthDay monthDay30 = monthDay28.minusDays((int) (short) 10);
        int[] intArray31 = monthDay30.getValues();
        int int32 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay25, intArray31);
        long long35 = offsetDateTimeField9.addWrapField(100L, 1380);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86496 + "'", int16 == 86496);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1380100L + "'", long35 == 1380100L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        int int14 = offsetDateTimeField9.get(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, readableInstant3);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.monthOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.era();
        org.joda.time.DurationField durationField7 = gJChronology4.hours();
        org.joda.time.DurationField durationField8 = gJChronology4.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        java.lang.String str16 = fixedDateTimeZone13.getName((long) 10);
        java.util.TimeZone timeZone17 = fixedDateTimeZone13.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.monthOfYear();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.era();
        org.joda.time.DurationField durationField26 = gJChronology23.hours();
        org.joda.time.DurationField durationField27 = gJChronology23.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone33 = fixedDateTimeZone32.toTimeZone();
        java.lang.String str35 = fixedDateTimeZone32.getName((long) 10);
        java.util.TimeZone timeZone36 = fixedDateTimeZone32.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology23, (org.joda.time.DateTimeZone) fixedDateTimeZone32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter20.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        long long41 = fixedDateTimeZone32.convertLocalToUTC((long) (-28740052), false);
        long long44 = fixedDateTimeZone32.adjustOffset(0L, true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        long long48 = fixedDateTimeZone32.previousTransition((long) 12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+00:00:00.010" + "'", str16.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.010" + "'", str35.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(zonedChronology37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-28740062L) + "'", long41 == (-28740062L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 12L + "'", long48 == 12L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long5 = copticChronology0.getDateTimeMillis(48, 9700, 59938, 83940062);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        int int14 = offsetDateTimeField9.getMaximumValue(9602990L);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = localTime19.indexOf(dateTimeFieldType20);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime25 = dateTime23.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime26 = dateTime25.toLocalTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        int int28 = localTime26.indexOf(dateTimeFieldType27);
        boolean boolean29 = localTime19.isBefore((org.joda.time.ReadablePartial) localTime26);
        int int30 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) localTime26);
        long long33 = offsetDateTimeField9.set((long) 23, (int) (byte) 100);
        int int34 = offsetDateTimeField9.getOffset();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86496 + "'", int14 == 86496);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localTime26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 97 + "'", int30 == 97);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3023L + "'", long33 == 3023L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.secondOfDay();
        org.joda.time.DateTime dateTime18 = property17.roundFloorCopy();
        try {
            org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime18, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
        int int16 = offsetDateTimeField9.getMaximumValue((long) (byte) 100);
        java.lang.String str18 = offsetDateTimeField9.getAsText((long) 69);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        int int21 = dateTimeZone19.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now(dateTimeZone19);
        org.joda.time.MonthDay.Property property23 = monthDay22.monthOfYear();
        org.joda.time.MonthDay monthDay25 = monthDay22.plusMonths(97);
        org.joda.time.ReadableInterval readableInterval26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval26);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(chronology27);
        org.joda.time.MonthDay monthDay30 = monthDay28.minusDays((int) (short) 10);
        int[] intArray31 = monthDay30.getValues();
        int int32 = offsetDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay25, intArray31);
        int int33 = offsetDateTimeField9.getOffset();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86496 + "'", int16 == 86496);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.weekyear();
        int int6 = gJChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        long long9 = delegatedDateTimeField4.roundFloor((long) 15);
        long long11 = delegatedDateTimeField4.roundCeiling((-28740062L));
        long long14 = delegatedDateTimeField4.add((-53174879820000L), 2);
        long long17 = delegatedDateTimeField4.set(35L, "0");
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28740010L) + "'", long11 == (-28740010L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-53174879818000L) + "'", long14 == (-53174879818000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        long long13 = dateTime3.getMillis();
        org.joda.time.DateTime dateTime15 = dateTime3.withMinuteOfHour(15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3599948L) + "'", long13 == (-3599948L));
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.Instant instant6 = new org.joda.time.Instant((java.lang.Object) dateTime3);
        org.joda.time.Instant instant9 = instant6.withDurationAdded(10L, (int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfDay();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfDay();
        int int14 = property4.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-59) + "'", int14 == (-59));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.MonthDay.Property property4 = monthDay2.property(dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) dateTime1);
        org.joda.time.Instant instant6 = instant5.toInstant();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.clockhourOfHalfday();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "hi!", 100, 10);
        java.lang.String str11 = fixedDateTimeZone10.toString();
        org.joda.time.Chronology chronology12 = gJChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.Chronology chronology16 = gJChronology2.withZone(dateTimeZone14);
        try {
            long long24 = gJChronology2.getDateTimeMillis(100, 38, 1, 86399, 0, 4, 38);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendLiteral("1969-12-31T23:00:00.062+00:00:00.010");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYearOfEra(5, 59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
        org.joda.time.DateTime dateTime14 = dateTime6.withFields((org.joda.time.ReadablePartial) localTime13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property20 = dateTime19.year();
        int int21 = dateTime19.getMinuteOfHour();
        int int22 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime19);
        try {
            org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime19, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-28740062L), 9602990L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-38343052L) + "'", long2 == (-38343052L));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("dayOfMonth", "1");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = dateTime9.getWeekOfWeekyear();
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTime9.toString("1969", locale12);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(julianChronology1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        int int15 = offsetDateTimeField9.getDifference((-10L), (long) (short) -1);
        int int17 = offsetDateTimeField9.get((long) 69);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        java.lang.String str20 = monthDay18.toString("+00:00:00.010");
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        java.lang.String str24 = monthDay22.toString("+00:00:00.010");
        org.joda.time.DateTimeField[] dateTimeFieldArray25 = monthDay22.getFields();
        int[] intArray26 = monthDay22.getValues();
        try {
            int[] intArray28 = offsetDateTimeField9.set((org.joda.time.ReadablePartial) monthDay18, 8, intArray26, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5 for secondOfDay must be in the range [97,86496]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.010" + "'", str20.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.010" + "'", str24.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray25);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 4, dateTimeZone1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.Interval interval6 = property4.toInterval();
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property4.setCopy("Property[minuteOfHour]", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[minuteOfHour]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(interval6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        java.lang.String str14 = offsetDateTimeField9.getAsShortText(31L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "97" + "'", str14.equals("97"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        java.lang.String str5 = property4.getAsShortText();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        int int19 = property4.getDifference((org.joda.time.ReadableInstant) dateTime18);
        int int20 = dateTime18.getMinuteOfHour();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone26 = fixedDateTimeZone25.toTimeZone();
        java.lang.String str28 = fixedDateTimeZone25.getName((long) 10);
        java.util.TimeZone timeZone29 = fixedDateTimeZone25.toTimeZone();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        long long34 = fixedDateTimeZone25.adjustOffset((long) (short) 0, false);
        boolean boolean35 = fixedDateTimeZone25.isFixed();
        org.joda.time.DateTime dateTime36 = dateTime18.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+00:00:00.010" + "'", str28.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime11.plusHours((-2));
        java.util.Locale locale17 = null;
        java.lang.String str18 = dateTime11.toString("6", locale17);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6" + "'", str18.equals("6"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-17337600000L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.days();
        org.joda.time.DurationField durationField4 = gJChronology2.centuries();
        long long7 = durationField4.subtract((long) (short) 0, (long) 2000);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-6311487340800000L) + "'", long7 == (-6311487340800000L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, readableInstant14);
        org.joda.time.DateTimeField dateTimeField16 = gJChronology15.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.secondOfMinute();
        org.joda.time.DateTime dateTime18 = dateTime11.toDateTime((org.joda.time.Chronology) gJChronology15);
        boolean boolean19 = fixedDateTimeZone4.equals((java.lang.Object) dateTime11);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long21 = fixedDateTimeZone12.convertLocalToUTC((long) (-28740052), false);
        long long24 = fixedDateTimeZone12.adjustOffset(0L, true);
        long long27 = fixedDateTimeZone12.adjustOffset((long) (-1), false);
        java.util.TimeZone timeZone28 = fixedDateTimeZone12.toTimeZone();
        int int30 = fixedDateTimeZone12.getOffsetFromLocal((long) 86399);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-28740062L) + "'", long21 == (-28740062L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 0, (long) (-32));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        int int10 = dateTimeZone8.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now(dateTimeZone8);
        org.joda.time.MonthDay.Property property12 = monthDay11.dayOfMonth();
        java.lang.String str13 = property12.getName();
        java.lang.String str14 = property12.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property12.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType15, 9700);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder1.appendText(dateTimeFieldType15);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField19 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dayOfMonth" + "'", str13.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10, dateTimeFieldType11);
        int int14 = delegatedDateTimeField12.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField15 = delegatedDateTimeField12.getWrappedField();
        long long17 = delegatedDateTimeField12.roundFloor((long) 15);
        long long19 = delegatedDateTimeField12.roundCeiling((-28740062L));
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField12.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField22 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType20, (-32));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-10L) + "'", long17 == (-10L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-28740010L) + "'", long19 == (-28740010L));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DurationField durationField6 = gJChronology2.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        java.lang.String str14 = fixedDateTimeZone11.getName((long) 10);
        java.util.TimeZone timeZone15 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.010" + "'", str14.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.plusMonths(4);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone6 = fixedDateTimeZone5.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone5.getName((long) 10);
        java.util.TimeZone timeZone9 = fixedDateTimeZone5.toTimeZone();
        boolean boolean10 = gJChronology0.equals((java.lang.Object) timeZone9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.010" + "'", str8.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendYear(38, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean12 = fixedDateTimeZone4.isStandardOffset((long) 59);
        org.joda.time.Instant instant14 = new org.joda.time.Instant((java.lang.Object) 1L);
        int int15 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) instant14);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        int int6 = dateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone4);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.lang.String str9 = property8.getName();
        java.lang.String str10 = property8.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType11, 9700);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendDayOfMonth((-59));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField6, dateTimeFieldType7);
        int int10 = delegatedDateTimeField8.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField11 = delegatedDateTimeField8.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 97);
        long long16 = offsetDateTimeField13.getDifferenceAsLong((long) 10, (long) 59);
        int int18 = offsetDateTimeField13.getMaximumValue(9602990L);
        boolean boolean19 = jodaTimePermission1.equals((java.lang.Object) offsetDateTimeField13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86496 + "'", int18 == 86496);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean7 = dateTime5.equals((java.lang.Object) dateTimeFormatter6);
        org.joda.time.DateTime.Property property8 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime9 = property8.roundCeilingCopy();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean21 = dateTime19.equals((java.lang.Object) dateTimeFormatter20);
        org.joda.time.DateTime.Property property22 = dateTime19.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = localTime15.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime26 = dateTime23.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology27 = dateTime26.getChronology();
        boolean boolean28 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime26);
        boolean boolean29 = buddhistChronology0.equals((java.lang.Object) dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.lang.Class<?> wildcardClass2 = gregorianChronology0.getClass();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("15", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getMaximumValueOverall();
        java.util.Locale locale8 = null;
        int int9 = property4.getMaximumShortTextLength(locale8);
        java.lang.String str10 = property4.getAsString();
        int int11 = property4.getMinimumValueOverall();
        java.lang.String str12 = property4.getAsShortText();
        try {
            org.joda.time.MonthDay monthDay14 = property4.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Jan" + "'", str12.equals("Jan"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        int int12 = dateTimeZone10.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now(dateTimeZone10);
        org.joda.time.MonthDay.Property property14 = monthDay13.dayOfMonth();
        java.lang.String str15 = property14.getName();
        java.lang.String str16 = property14.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = property14.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType17, 12, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType17, 23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 57600);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType26, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfMonth" + "'", str15.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getLeapDurationField();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField9, 0, 19, (-32));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for secondOfDay must be in the range [19,-32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.lang.Class<?> wildcardClass2 = gregorianChronology0.getClass();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", number1, (java.lang.Number) (-31507200000L), (java.lang.Number) 38);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone8 = fixedDateTimeZone7.toTimeZone();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.Chronology chronology10 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        long long9 = gregorianChronology0.getDateTimeMillis(59948, (int) (byte) 1, 31, 0, 5, (int) ' ', (int) '4');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1829611497932052L + "'", long9 == 1829611497932052L);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime13 = dateTime12.toLocalTime();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean19 = dateTime17.equals((java.lang.Object) dateTimeFormatter18);
        org.joda.time.DateTime.Property property20 = dateTime17.minuteOfHour();
        org.joda.time.DateTime dateTime21 = property20.roundCeilingCopy();
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime23 = localTime13.toDateTime((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime21.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology25 = dateTime24.getChronology();
        boolean boolean26 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime7.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localTime13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, readableInstant7);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.monthOfYear();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.era();
        org.joda.time.Instant instant11 = gJChronology8.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant13 = instant11.minus(readableDuration12);
        org.joda.time.Instant instant15 = instant13.plus((long) 59948);
        int int16 = property4.compareTo((org.joda.time.ReadableInstant) instant15);
        java.lang.String str17 = property4.getAsShortText();
        int int18 = property4.getMinimumValue();
        try {
            org.joda.time.MonthDay monthDay20 = property4.setCopy("97");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfMonth" + "'", str5.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        boolean boolean10 = offsetDateTimeField9.isSupported();
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField9.getMaximumShortTextLength(locale11);
        int int13 = offsetDateTimeField9.getOffset();
        long long15 = offsetDateTimeField9.remainder((-1L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9L + "'", long15 == 9L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(100, 2000, 0, 59);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 4, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        int int15 = offsetDateTimeField9.getDifference((-10L), (long) (short) -1);
        java.util.Locale locale18 = null;
        try {
            long long19 = offsetDateTimeField9.set((long) (short) 1, "Property[dayOfMonth]", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[dayOfMonth]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("Jun", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jun\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-28800000), '#', 86399999, 97, (int) (short) 1, false, 86496);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder8.addRecurringSavings("Property[minuteOfHour]", 0, (-2), (int) (byte) 1, '4', (int) (byte) -1, (int) ' ', 59938, false, 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 1, 0);
        org.joda.time.TimeOfDay timeOfDay15 = dateTime11.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(timeOfDay15);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime23 = dateTime21.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property24 = dateTime23.year();
        java.lang.String str25 = property24.getAsShortText();
        org.joda.time.DateTime dateTime26 = property24.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime30 = dateTime28.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean32 = dateTime30.equals((java.lang.Object) dateTimeFormatter31);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime36 = dateTime34.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime37 = dateTime36.toLocalTime();
        org.joda.time.DateTime dateTime38 = dateTime30.withFields((org.joda.time.ReadablePartial) localTime37);
        int int39 = property24.getDifference((org.joda.time.ReadableInstant) dateTime38);
        boolean boolean40 = julianChronology19.equals((java.lang.Object) dateTime38);
        int int41 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime38);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969" + "'", str25.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = dateTime9.getWeekOfWeekyear();
        try {
            java.lang.String str12 = dateTime9.toString("Property[year]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime6 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        org.joda.time.DateTime dateTime19 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime17);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("T23:00:00+00:00:00.010");
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(4);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        int int6 = dateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone4);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.lang.String str9 = property8.getName();
        java.lang.String str10 = property8.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType11, 9700);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 0.0d, (java.lang.Number) (-3104L), (java.lang.Number) 57600);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-28740052));
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DurationField durationField6 = gJChronology2.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        java.lang.String str14 = fixedDateTimeZone11.getName((long) 10);
        java.util.TimeZone timeZone15 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DurationField durationField17 = gJChronology2.weekyears();
        try {
            long long22 = gJChronology2.getDateTimeMillis(24, 67, 0, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 67 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.010" + "'", str14.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Property[dayOfMonth]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimePrinter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(86399999, (int) (short) 0, 0, (-59));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField4.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        java.util.Locale locale12 = null;
        int int13 = delegatedDateTimeField4.getMaximumTextLength(locale12);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        try {
            java.lang.String str2 = monthDay0.toString("org.joda.time.IllegalFieldValueException: Value \"1\" for dayOfMonth is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        long long9 = delegatedDateTimeField4.roundFloor((long) 15);
        long long11 = delegatedDateTimeField4.roundCeiling((-28740062L));
        long long13 = delegatedDateTimeField4.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-28740010L) + "'", long11 == (-28740010L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        java.util.Date date2 = dateTime1.toDate();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.fromDateFields(date2);
        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.fromDateFields(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay4);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 4, dateTimeZone1);
//        java.lang.String str4 = dateTimeZone1.getShortName(9L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfDay();
        try {
            long long9 = iSOChronology0.getDateTimeMillis(0, 12, (-1), (int) (short) -1, (int) (byte) 100, 12, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = property6.addWrapFieldToCopy(9700);
        org.joda.time.DateTime dateTime22 = property6.roundFloorCopy();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.withDurationAdded(readableDuration23, 86496);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(2);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        long long7 = dateTimeZone3.adjustOffset((long) ' ', true);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(59948, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59958 + "'", int2 == 59958);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.dayOfMonth();
        int int5 = property4.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay7 = property4.addToCopy(9700);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray8 = monthDay7.getFieldTypes();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) dateTime1);
        org.joda.time.Instant instant7 = instant5.withMillis(0L);
        org.joda.time.DateTime dateTime8 = instant5.toDateTimeISO();
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology10 = buddhistChronology9.withUTC();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType14);
        int int17 = delegatedDateTimeField15.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField18 = delegatedDateTimeField15.getWrappedField();
        boolean boolean19 = delegatedDateTimeField15.isSupported();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology9, (org.joda.time.DateTimeField) delegatedDateTimeField15, (int) 'a');
        org.joda.time.MutableDateTime mutableDateTime22 = instant5.toMutableDateTime((org.joda.time.Chronology) buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withDayOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(0, 23, (-28740052), (-1), 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        java.lang.String str2 = monthDay0.toString("+00:00:00.010");
        org.joda.time.DateTimeField[] dateTimeFieldArray3 = monthDay0.getFields();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter4.withZoneUTC();
        boolean boolean6 = monthDay0.equals((java.lang.Object) dateTimeFormatter5);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.010" + "'", str2.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeFieldArray3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3, dateTimeFieldType4);
        int int7 = delegatedDateTimeField5.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField5.getWrappedField();
        long long10 = delegatedDateTimeField5.roundFloor((long) 15);
        long long12 = delegatedDateTimeField5.roundCeiling((-28740062L));
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField5.getType();
        try {
            org.joda.time.MonthDay.Property property14 = monthDay0.property(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-10L) + "'", long10 == (-10L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-28740010L) + "'", long12 == (-28740010L));
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime6.withTimeAtStartOfDay();
        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime9.getDayOfWeek();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime18 = dateTime13.withYearOfEra((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, readableInstant20);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.minuteOfDay();
        org.joda.time.DateTime dateTime23 = dateTime18.withChronology((org.joda.time.Chronology) gJChronology21);
        boolean boolean24 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now(dateTimeZone2);
        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
        java.lang.String str7 = property6.getName();
        java.lang.String str8 = property6.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property6.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendSignedDecimal(dateTimeFieldType9, 2000, 86399999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear(83940062);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "dayOfMonth" + "'", str7.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean21 = dateTime19.equals((java.lang.Object) dateTimeFormatter20);
        org.joda.time.DateTime.Property property22 = dateTime19.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = localTime15.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime31 = dateTime25.withWeekyear(0);
        java.util.Date date32 = dateTime25.toDate();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
        int int18 = dateTime17.getSecondOfMinute();
        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
        java.lang.String str32 = property31.getName();
        java.lang.String str33 = property31.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
        int int37 = dateTime20.get(dateTimeFieldType34);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
        long long42 = remainderDateTimeField39.roundHalfFloor((long) 86399999);
        long long44 = remainderDateTimeField39.roundHalfFloor((-10L));
        java.lang.String str45 = remainderDateTimeField39.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-10L) + "'", long44 == (-10L));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str45.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter1.getZone();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("82860000", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"82860000\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        int int13 = delegatedDateTimeField4.getLeapAmount((long) (short) 10);
        java.lang.String str14 = delegatedDateTimeField4.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[secondOfDay]" + "'", str14.equals("DateTimeField[secondOfDay]"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 10);
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        try {
            org.joda.time.MonthDay monthDay4 = monthDay2.withDayOfMonth((-32));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.DurationField durationField5 = gJChronology2.hours();
        org.joda.time.DurationField durationField6 = gJChronology2.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        java.lang.String str14 = fixedDateTimeZone11.getName((long) 10);
        java.util.TimeZone timeZone15 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        try {
            long long21 = zonedChronology16.getDateTimeMillis(1380, 100, 100, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.010" + "'", str14.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(zonedChronology16);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.era();
        org.joda.time.DurationField durationField13 = gJChronology10.hours();
        org.joda.time.DurationField durationField14 = gJChronology10.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone20 = fixedDateTimeZone19.toTimeZone();
        java.lang.String str22 = fixedDateTimeZone19.getName((long) 10);
        java.util.TimeZone timeZone23 = fixedDateTimeZone19.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeZone) fixedDateTimeZone19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter7.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        java.util.TimeZone timeZone26 = fixedDateTimeZone19.toTimeZone();
        long long28 = fixedDateTimeZone19.previousTransition((long) (byte) 0);
        try {
            org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(1, (-28740052), (int) (short) 1, 69, (-59), 48, (int) '4', (org.joda.time.DateTimeZone) fixedDateTimeZone19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.010" + "'", str22.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        java.util.Locale locale8 = null;
        int int9 = delegatedDateTimeField4.getMaximumShortTextLength(locale8);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean17 = dateTime15.equals((java.lang.Object) dateTimeFormatter16);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime22 = dateTime21.toLocalTime();
        org.joda.time.DateTime dateTime23 = dateTime15.withFields((org.joda.time.ReadablePartial) localTime22);
        org.joda.time.DateTimeField dateTimeField25 = localTime22.getField(0);
        java.util.Locale locale27 = null;
        java.lang.String str28 = delegatedDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime22, 0, locale27);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) (short) -1);
        int int6 = dateTime5.getSecondOfMinute();
        org.joda.time.DateTime dateTime8 = dateTime5.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime10 = dateTime8.withHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        int int17 = dateTimeZone15.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone15);
        org.joda.time.MonthDay.Property property19 = monthDay18.dayOfMonth();
        java.lang.String str20 = property19.getName();
        java.lang.String str21 = property19.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property19.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder12.appendFixedSignedDecimal(dateTimeFieldType22, 9700);
        int int25 = dateTime8.get(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType22, 2000, 69);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, readableInstant30);
        org.joda.time.DateTimeField dateTimeField32 = gJChronology31.weekOfWeekyear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap34 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendTimeZoneShortName(strMap34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder33.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap39 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendTimeZoneShortName(strMap39);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder38.appendHourOfHalfday((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
        int int45 = dateTimeZone43.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now(dateTimeZone43);
        org.joda.time.MonthDay.Property property47 = monthDay46.dayOfMonth();
        java.lang.String str48 = property47.getName();
        java.lang.String str49 = property47.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property47.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder38.appendSignedDecimal(dateTimeFieldType50, 12, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder37.appendFixedDecimal(dateTimeFieldType50, 23);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField(dateTimeField32, dateTimeFieldType50, 59938);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap59 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendTimeZoneShortName(strMap59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder58.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap64 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder63.appendTimeZoneShortName(strMap64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder63.appendHourOfHalfday((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.getDefault();
        int int70 = dateTimeZone68.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay71 = org.joda.time.MonthDay.now(dateTimeZone68);
        org.joda.time.MonthDay.Property property72 = monthDay71.dayOfMonth();
        java.lang.String str73 = property72.getName();
        java.lang.String str74 = property72.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property72.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder63.appendSignedDecimal(dateTimeFieldType75, 12, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder62.appendFixedDecimal(dateTimeFieldType75, 23);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray81 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType22, dateTimeFieldType50, dateTimeFieldType75 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList82 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean83 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList82, dateTimeFieldTypeArray81);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter86 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList82, false, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "dayOfMonth" + "'", str20.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfMonth" + "'", str48.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1" + "'", str49.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 10 + "'", int70 == 10);
        org.junit.Assert.assertNotNull(monthDay71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "dayOfMonth" + "'", str73.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1" + "'", str74.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter86);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime19 = dateTime17.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean21 = dateTime19.equals((java.lang.Object) dateTimeFormatter20);
        org.joda.time.DateTime.Property property22 = dateTime19.minuteOfHour();
        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = localTime15.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) '4');
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime25);
        try {
            long long34 = gJChronology29.getDateTimeMillis(0, 6, 100, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology2);
        int int4 = gJChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj2 = null;
        jodaTimePermission1.checkGuard(obj2);
        java.lang.String str4 = jodaTimePermission1.toString();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime15);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime8);
        java.lang.String str18 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str18.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 1, 0);
        int int15 = dateTime11.getMonthOfYear();
        org.joda.time.DateTime dateTime16 = dateTime11.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) dateTime11, chronology17);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now(dateTimeZone0);
        org.joda.time.MonthDay.Property property4 = monthDay3.monthOfYear();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getMaximumValueOverall();
        java.util.Locale locale8 = null;
        int int9 = property4.getMaximumShortTextLength(locale8);
        java.lang.String str10 = property4.getAsString();
        int int11 = property4.getMinimumValueOverall();
        org.joda.time.DurationField durationField12 = property4.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[]", "dayOfMonth", 59938, 100);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long11 = offsetDateTimeField9.roundHalfFloor(3200000L);
        long long14 = offsetDateTimeField9.add(0L, 0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3199990L + "'", long11 == 3199990L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.secondOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundFloorCopy();
        long long6 = property4.remainder();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 62L + "'", long6 == 62L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone8 = fixedDateTimeZone7.toTimeZone();
        org.joda.time.Chronology chronology9 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        java.lang.String str10 = gregorianChronology0.toString();
        java.lang.String str11 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[UTC]" + "'", str10.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[UTC]" + "'", str11.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        int int14 = offsetDateTimeField9.getMaximumValue(9602990L);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        int int19 = dateTime18.getSecondOfMinute();
        org.joda.time.DateTime dateTime21 = dateTime18.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime23 = dateTime21.withHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder24.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        int int30 = dateTimeZone28.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now(dateTimeZone28);
        org.joda.time.MonthDay.Property property32 = monthDay31.dayOfMonth();
        java.lang.String str33 = property32.getName();
        java.lang.String str34 = property32.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property32.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder25.appendFixedSignedDecimal(dateTimeFieldType35, 9700);
        int int38 = dateTime21.get(dateTimeFieldType35);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField40 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType35, 23);
        long long42 = offsetDateTimeField9.roundCeiling((-3599958L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86496 + "'", int14 == 86496);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "dayOfMonth" + "'", str33.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-3599010L) + "'", long42 == (-3599010L));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getName((long) 10);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long11 = fixedDateTimeZone4.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((-2));
        boolean boolean16 = dateTime14.isEqual((long) 8);
        org.joda.time.DateTime dateTime18 = dateTime14.minusYears(24);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.010" + "'", str7.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-10L) + "'", long11 == (-10L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        long long14 = offsetDateTimeField9.roundFloor(10L);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        int int17 = dateTimeZone15.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone15);
        org.joda.time.MonthDay.Property property19 = monthDay18.monthOfYear();
        java.lang.String str20 = property19.getAsString();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23, dateTimeFieldType24);
        int int27 = delegatedDateTimeField25.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField28 = delegatedDateTimeField25.getWrappedField();
        int int30 = delegatedDateTimeField25.getLeapAmount(57600L);
        java.util.Locale locale31 = null;
        int int32 = delegatedDateTimeField25.getMaximumTextLength(locale31);
        java.lang.String str33 = delegatedDateTimeField25.getName();
        org.joda.time.ReadableInterval readableInterval34 = null;
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval34);
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(chronology35);
        org.joda.time.MonthDay monthDay38 = monthDay36.minusDays((int) (short) 10);
        int int39 = delegatedDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) monthDay36);
        int int40 = property19.compareTo((org.joda.time.ReadablePartial) monthDay36);
        int[] intArray42 = null;
        try {
            int[] intArray44 = offsetDateTimeField9.add((org.joda.time.ReadablePartial) monthDay36, 0, intArray42, 48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-10L) + "'", long14 == (-10L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "secondOfDay" + "'", str33.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 86399 + "'", int39 == 86399);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.centuryOfEra();
        int int4 = gJChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone6 = fixedDateTimeZone5.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone5.getName((long) 10);
        java.util.TimeZone timeZone9 = fixedDateTimeZone5.toTimeZone();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Chronology chronology11 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int13 = fixedDateTimeZone5.getOffsetFromLocal((-1L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.010" + "'", str8.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(32L, 3023L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96736 + "'", int2 == 96736);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
        int int16 = offsetDateTimeField9.getMaximumValue((long) (byte) 100);
        java.lang.String str18 = offsetDateTimeField9.getAsText((long) 69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale20 = dateTimeFormatter19.getLocale();
        org.joda.time.LocalTime localTime22 = dateTimeFormatter19.parseLocalTime("1");
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localTime22, locale23);
        int int26 = offsetDateTimeField9.getLeapAmount((long) 2000);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86496 + "'", int16 == 86496);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97" + "'", str18.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNull(locale20);
        org.junit.Assert.assertNotNull(localTime22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("19");
        org.junit.Assert.assertNotNull(monthDay1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        int int6 = dateTimeZone4.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now(dateTimeZone4);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.lang.String str9 = property8.getName();
        java.lang.String str10 = property8.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType11, 9700);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap15 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTimeZoneShortName(strMap15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatterBuilder18.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.append(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfMonth" + "'", str9.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        long long18 = dateTime16.getMillis();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology24 = limitChronology22.withZone(dateTimeZone23);
        try {
            long long30 = limitChronology22.getDateTimeMillis((long) 86399999, 9700, (int) (short) 0, 0, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is above the supported maximum of 1970-01-01T00:00:00.000+00:00:00.010 (ISOChronology[])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        java.lang.String str12 = delegatedDateTimeField4.getName();
        java.util.Locale locale13 = null;
        int int14 = delegatedDateTimeField4.getMaximumShortTextLength(locale13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField4.getAsText(5, locale16);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "secondOfDay" + "'", str12.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "5" + "'", str17.equals("5"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder4.toPrinter();
        boolean boolean6 = dateTimeFormatterBuilder4.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField9.getWrappedField();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) (short) -1);
        int int18 = dateTime17.getSecondOfMinute();
        org.joda.time.DateTime dateTime20 = dateTime17.minusHours((int) (short) 0);
        org.joda.time.DateTime dateTime22 = dateTime20.withHourOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendClockhourOfDay(2);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        int int29 = dateTimeZone27.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now(dateTimeZone27);
        org.joda.time.MonthDay.Property property31 = monthDay30.dayOfMonth();
        java.lang.String str32 = property31.getName();
        java.lang.String str33 = property31.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder24.appendFixedSignedDecimal(dateTimeFieldType34, 9700);
        int int37 = dateTime20.get(dateTimeFieldType34);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType34, 83940062);
        org.joda.time.DurationField durationField40 = remainderDateTimeField39.getRangeDurationField();
        long long42 = remainderDateTimeField39.roundHalfFloor((long) 86399999);
        long long44 = remainderDateTimeField39.roundHalfFloor((-10L));
        java.util.Locale locale46 = null;
        java.lang.String str47 = remainderDateTimeField39.getAsShortText((-28740062L), locale46);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfMonth" + "'", str32.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 31 + "'", int37 == 31);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 86399990L + "'", long42 == 86399990L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-10L) + "'", long44 == (-10L));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "57659" + "'", str47.equals("57659"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.Object obj2 = null;
        jodaTimePermission1.checkGuard(obj2);
        java.lang.String str4 = jodaTimePermission1.toString();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean10 = dateTime8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime15 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime16 = dateTime8.withFields((org.joda.time.ReadablePartial) localTime15);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime8);
        long long18 = dateTime8.getMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        int int21 = gregorianChronology19.getMinimumDaysInFirstWeek();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone27 = fixedDateTimeZone26.toTimeZone();
        org.joda.time.Chronology chronology28 = gregorianChronology19.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        java.lang.String str29 = gregorianChronology19.toString();
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime8.toMutableDateTime((org.joda.time.Chronology) gregorianChronology19);
        try {
            long long38 = gregorianChronology19.getDateTimeMillis((int) '#', (int) (short) -1, 8, 0, 57600, 59, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3599948L) + "'", long18 == (-3599948L));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "GregorianChronology[UTC]" + "'", str29.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(mutableDateTime30);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getMinimumValue((long) 38);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.set((long) 19, 9700);
        java.lang.String str14 = offsetDateTimeField9.getAsText((long) 57600);
        org.joda.time.ReadableInterval readableInterval15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(chronology16);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20, dateTimeFieldType21);
        int int24 = delegatedDateTimeField22.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField25 = delegatedDateTimeField22.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, 97);
        long long30 = offsetDateTimeField27.getDifferenceAsLong((long) 10, (long) 59);
        int int32 = offsetDateTimeField27.getMaximumValue(9602990L);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        java.lang.String str35 = monthDay33.toString("+00:00:00.010");
        org.joda.time.MonthDay monthDay37 = monthDay33.plusDays((int) (byte) 0);
        org.joda.time.ReadableInterval readableInterval39 = null;
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval39);
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(chronology40);
        org.joda.time.MonthDay monthDay43 = monthDay41.minusDays((int) (short) 10);
        int[] intArray44 = monthDay43.getValues();
        int[] intArray46 = offsetDateTimeField27.add((org.joda.time.ReadablePartial) monthDay33, 57600, intArray44, 0);
        int int47 = offsetDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay17, intArray46);
        long long49 = offsetDateTimeField9.roundHalfEven((long) 59);
        int int52 = offsetDateTimeField9.getDifference((long) 97, (long) (-28740052));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9603019L + "'", long12 == 9603019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "154" + "'", str14.equals("154"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 86496 + "'", int32 == 86496);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.010" + "'", str35.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 86496 + "'", int47 == 86496);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-10L) + "'", long49 == (-10L));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 28740 + "'", int52 == 28740);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "(\"org.joda.time.JodaTimePermission\" \"hi!\")");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gJChronology2.millis();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.monthOfYear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMonths((int) (short) 10);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DurationField durationField15 = property14.getDurationField();
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField18 = new org.joda.time.field.ScaledDurationField(durationField15, durationFieldType16, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean8 = dateTime6.equals((java.lang.Object) dateTimeFormatter7);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        long long18 = dateTime16.getMillis();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime16.withDurationAdded(readableDuration19, (int) (short) 100);
        org.joda.time.chrono.LimitChronology limitChronology22 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology24 = limitChronology22.withZone(dateTimeZone23);
        org.joda.time.Chronology chronology25 = limitChronology22.withUTC();
        org.joda.time.DateTime dateTime26 = limitChronology22.getUpperLimit();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-10L) + "'", long18 == (-10L));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(limitChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        long long11 = copticChronology3.getDateTimeMillis((int) (byte) 1, 4, 19, 0, 3, 0, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withZone(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-53174879820000L) + "'", long11 == (-53174879820000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.era();
        org.joda.time.Instant instant5 = gJChronology2.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.joda.time.Instant instant10 = instant5.withDurationAdded((long) (byte) 10, 4);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant12 = instant5.minus(readableDuration11);
        org.joda.time.Chronology chronology13 = instant12.getChronology();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean14 = dateTime12.equals((java.lang.Object) dateTimeFormatter13);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime19 = dateTime18.toLocalTime();
        org.joda.time.DateTime dateTime20 = dateTime12.withFields((org.joda.time.ReadablePartial) localTime19);
        int int21 = property8.getDifference((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime23 = dateTime12.minusMinutes((int) (short) -1);
        java.util.Date date24 = dateTime23.toDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59938 + "'", int21 == 59938);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean12 = dateTime10.equals((java.lang.Object) dateTimeFormatter11);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime16 = dateTime14.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime17 = dateTime16.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        long long19 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DurationField durationField20 = property6.getRangeDurationField();
        org.joda.time.DurationField durationField21 = property6.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNull(durationField21);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long11 = offsetDateTimeField9.roundHalfFloor(3200000L);
        long long13 = offsetDateTimeField9.roundFloor((-10L));
        long long15 = offsetDateTimeField9.remainder((-3599948L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3199990L + "'", long11 == 3199990L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-10L) + "'", long13 == (-10L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 62L + "'", long15 == 62L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime6.withTimeAtStartOfDay();
        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.LocalDateTime localDateTime11 = dateTime9.toLocalDateTime();
        org.joda.time.DateTime dateTime14 = dateTime9.withDurationAdded(3199990L, 1380);
        org.joda.time.DateTime dateTime16 = dateTime14.plusMillis(19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(chronology3);
        org.joda.time.MonthDay monthDay6 = monthDay4.minusDays((int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.MonthDay monthDay8 = monthDay4.withChronologyRetainFields((org.joda.time.Chronology) gJChronology7);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfMinute((int) (short) 0, 24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime6.withTimeAtStartOfDay();
        int int10 = property4.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime11 = dateTime9.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property12 = dateTime11.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((-28800000), '#', 86399999, 97, (int) (short) 1, false, 86496);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("1969-12-31T23:00:00.062+00:00:00.010", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.Instant instant6 = gJChronology3.getGregorianCutover();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant8 = instant6.plus(readableDuration7);
        org.joda.time.Instant instant10 = instant6.plus((long) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone16 = fixedDateTimeZone15.toTimeZone();
        java.lang.String str18 = fixedDateTimeZone15.getName((long) 10);
        java.util.TimeZone timeZone19 = fixedDateTimeZone15.toTimeZone();
        long long22 = fixedDateTimeZone15.convertLocalToUTC(0L, true);
        org.joda.time.DateTime dateTime23 = instant10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "0", (java.lang.Object) dateTime23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, readableInstant27);
        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.monthOfYear();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology28.era();
        org.joda.time.DurationField durationField31 = gJChronology28.hours();
        org.joda.time.DurationField durationField32 = gJChronology28.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone37 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone38 = fixedDateTimeZone37.toTimeZone();
        java.lang.String str40 = fixedDateTimeZone37.getName((long) 10);
        java.util.TimeZone timeZone41 = fixedDateTimeZone37.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology28, (org.joda.time.DateTimeZone) fixedDateTimeZone37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter25.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone37);
        long long47 = fixedDateTimeZone37.convertLocalToUTC((-3599948L), true, 1L);
        boolean boolean49 = fixedDateTimeZone37.isStandardOffset(0L);
        org.joda.time.DateTime dateTime50 = dateTime23.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone37);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+00:00:00.010" + "'", str18.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-10L) + "'", long22 == (-10L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+00:00:00.010" + "'", str40.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(zonedChronology42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-3599958L) + "'", long47 == (-3599958L));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateTime50);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded((long) (byte) 1, 0);
        int int15 = dateTime11.getMonthOfYear();
        org.joda.time.DateTime dateTime16 = dateTime11.withLaterOffsetAtOverlap();
        int int17 = dateTime16.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 69 + "'", int17 == 69);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.era();
        org.joda.time.DurationField durationField6 = gJChronology3.hours();
        org.joda.time.DurationField durationField7 = gJChronology3.halfdays();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone13 = fixedDateTimeZone12.toTimeZone();
        java.lang.String str15 = fixedDateTimeZone12.getName((long) 10);
        java.util.TimeZone timeZone16 = fixedDateTimeZone12.toTimeZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long21 = fixedDateTimeZone12.convertLocalToUTC((long) (-28740052), false);
        long long24 = fixedDateTimeZone12.adjustOffset(0L, true);
        try {
            org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-28740062L) + "'", long21 == (-28740062L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        boolean boolean13 = offsetDateTimeField9.isLenient();
        long long15 = offsetDateTimeField9.roundCeiling((-28740010L));
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        int int18 = dateTimeZone16.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now(dateTimeZone16);
        org.joda.time.MonthDay.Property property20 = monthDay19.monthOfYear();
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField9.getAsText((org.joda.time.ReadablePartial) monthDay19, 59948, locale22);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime27 = dateTime25.plusHours((int) (short) -1);
        int int28 = dateTime27.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime34 = dateTime27.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime.Property property35 = dateTime27.hourOfDay();
        org.joda.time.DateTime dateTime36 = dateTime27.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap38 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendTimeZoneShortName(strMap38);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder37.appendHourOfHalfday((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap43 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendTimeZoneShortName(strMap43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder42.appendHourOfHalfday((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
        int int49 = dateTimeZone47.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.MonthDay monthDay50 = org.joda.time.MonthDay.now(dateTimeZone47);
        org.joda.time.MonthDay.Property property51 = monthDay50.dayOfMonth();
        java.lang.String str52 = property51.getName();
        java.lang.String str53 = property51.getAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property51.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder42.appendSignedDecimal(dateTimeFieldType54, 12, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder41.appendFixedDecimal(dateTimeFieldType54, 23);
        boolean boolean60 = dateTime36.isSupported(dateTimeFieldType54);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType54, (int) (short) 1, 86496, 3);
        try {
            org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay((java.lang.Object) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28740010L) + "'", long15 == (-28740010L));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "59948" + "'", str23.equals("59948"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "dayOfMonth" + "'", str52.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1" + "'", str53.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean5 = dateTime3.equals((java.lang.Object) dateTimeFormatter4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) (short) -1);
        org.joda.time.LocalTime localTime10 = dateTime9.toLocalTime();
        org.joda.time.DateTime dateTime11 = dateTime3.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (byte) 1);
        int int14 = dateTime13.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) '4');
        org.joda.time.DateTime dateTime3 = dateTime1.plusHours((int) (short) -1);
        int int4 = dateTime3.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime3.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime3.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime14 = dateTime3.plusMillis(0);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime3.minus(readableDuration15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime3.plus(readablePeriod17);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DurationField durationField3 = gJChronology2.days();
        org.joda.time.DurationField durationField4 = gJChronology2.centuries();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7, dateTimeFieldType8);
        int int11 = delegatedDateTimeField9.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField12 = delegatedDateTimeField9.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 97);
        long long17 = offsetDateTimeField14.set((long) 19, 9700);
        java.lang.String str19 = offsetDateTimeField14.getAsText((long) 57600);
        int int21 = offsetDateTimeField14.getMaximumValue((long) (byte) 100);
        java.lang.String str23 = offsetDateTimeField14.getAsText((long) 69);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) offsetDateTimeField14, (-1));
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType29);
        int int32 = delegatedDateTimeField30.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField33 = delegatedDateTimeField30.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 97);
        long long38 = offsetDateTimeField35.getDifferenceAsLong((long) 10, (long) 59);
        org.joda.time.DateTimeField dateTimeField39 = offsetDateTimeField35.getWrappedField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "", 10, (int) '#');
        java.util.TimeZone timeZone45 = fixedDateTimeZone44.toTimeZone();
        java.lang.String str47 = fixedDateTimeZone44.getName((long) 10);
        boolean boolean48 = fixedDateTimeZone44.isFixed();
        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone44);
        int[] intArray55 = new int[] { 1, 8, 4, 10, 1380 };
        int int56 = offsetDateTimeField35.getMinimumValue((org.joda.time.ReadablePartial) monthDay49, intArray55);
        int int57 = skipDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9603019L + "'", long17 == 9603019L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "154" + "'", str19.equals("154"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 86496 + "'", int21 == 86496);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "97" + "'", str23.equals("97"));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "+00:00:00.010" + "'", str47.equals("+00:00:00.010"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 97 + "'", int56 == 97);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 97 + "'", int57 == 97);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("1");
        int int4 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter0.getZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2000 + "'", int4 == 2000);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        java.lang.String str2 = copticChronology0.toString();
        org.joda.time.Chronology chronology3 = copticChronology0.withUTC();
        org.joda.time.DurationField durationField4 = copticChronology0.hours();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CopticChronology[UTC]" + "'", str2.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField2, 0);
        int int6 = skipDateTimeField4.get((long) 96736);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 746 + "'", int6 == 746);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, 97);
        long long12 = offsetDateTimeField9.getDifferenceAsLong((long) 10, (long) 59);
        int int14 = offsetDateTimeField9.getMaximumValue(9602990L);
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now();
        java.lang.String str17 = monthDay15.toString("+00:00:00.010");
        org.joda.time.MonthDay monthDay19 = monthDay15.plusDays((int) (byte) 0);
        org.joda.time.ReadableInterval readableInterval21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval21);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(chronology22);
        org.joda.time.MonthDay monthDay25 = monthDay23.minusDays((int) (short) 10);
        int[] intArray26 = monthDay25.getValues();
        int[] intArray28 = offsetDateTimeField9.add((org.joda.time.ReadablePartial) monthDay15, 57600, intArray26, 0);
        org.joda.time.Chronology chronology29 = monthDay15.getChronology();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86496 + "'", int14 == 86496);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.010" + "'", str17.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        int int6 = delegatedDateTimeField4.getLeapAmount(10L);
        org.joda.time.DateTimeField dateTimeField7 = delegatedDateTimeField4.getWrappedField();
        int int9 = delegatedDateTimeField4.getLeapAmount(57600L);
        java.util.Locale locale10 = null;
        int int11 = delegatedDateTimeField4.getMaximumTextLength(locale10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField4.getRangeDurationField();
        java.lang.String str13 = delegatedDateTimeField4.getName();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "secondOfDay" + "'", str13.equals("secondOfDay"));
    }
}

