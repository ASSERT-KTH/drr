import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test02");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDateTime();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField3 = julianChronology2.centuries();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology6);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        mutableDateTime8.add(readableDuration9);
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) mutableDateTime8);
//        java.lang.String str12 = dateTimeFormatter4.print(readableInstant5);
//        try {
//            org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.parse("5", dateTimeFormatter4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "December 19, 1969 5:43:40 AM UTC" + "'", str12.equals("December 19, 1969 5:43:40 AM UTC"));
//    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        java.lang.Object obj6 = null;
        boolean boolean7 = mutableDateTime2.equals(obj6);
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj6, dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test04");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        int int5 = dateTime1.getYearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
//        int int7 = dateTime1.getWeekyear();
//        org.joda.time.DateTime dateTime9 = dateTime1.withWeekyear((-292275054));
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay(20634600);
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime9.toYearMonthDay();
//        org.joda.time.MutableDateTime mutableDateTime13 = dateTime9.toMutableDateTime();
//        int int14 = mutableDateTime13.getEra();
//        int int15 = mutableDateTime13.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78220583 + "'", int2 == 78220583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int6 = dateTimeFormatter5.getDefaultYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Chronology chronology10 = gregorianChronology7.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.halfdayOfDay();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(20612731, 20631170, 51, 2, 20617900, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20617900 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.monthOfYear();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str2.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test07");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
//        java.lang.String str14 = property13.getAsText();
//        java.util.Locale locale16 = null;
//        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
//        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
//        int[] intArray22 = new int[] { 10, 10, 20612731 };
//        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
//        int int27 = delegatedDateTimeField8.getMaximumValue();
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = delegatedDateTimeField8.getAsShortText((long) 20626614, locale29);
//        java.util.Locale locale31 = null;
//        int int32 = delegatedDateTimeField8.getMaximumTextLength(locale31);
//        long long34 = delegatedDateTimeField8.remainder(41623183098L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78220583 + "'", int11 == 78220583);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(timeOfDay18);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 111 + "'", int27 == 111);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "105" + "'", str30.equals("105"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3583098L + "'", long34 == 3583098L);
//    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test08");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = julianChronology1.months();
//        org.joda.time.DurationField durationField3 = julianChronology1.days();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.halfdayOfDay();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 100);
//        java.lang.String str10 = offsetDateTimeField8.getAsText((long) 20611972);
//        int int12 = offsetDateTimeField8.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8);
//        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getDurationField();
//        long long16 = delegatedDateTimeField13.roundCeiling((long) 20611566);
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
//        java.lang.String str23 = offsetDateTimeField21.getAsText((long) 20611972);
//        int int25 = offsetDateTimeField21.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField21);
//        int int27 = offsetDateTimeField21.getMaximumValue();
//        org.joda.time.DurationField durationField28 = offsetDateTimeField21.getRangeDurationField();
//        java.util.Locale locale29 = null;
//        int int30 = offsetDateTimeField21.getMaximumTextLength(locale29);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField32 = gregorianChronology31.centuries();
//        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology31.getZone();
//        boolean boolean35 = dateTimeZone33.isStandardOffset((long) (byte) -1);
//        org.joda.time.DateTimeZone dateTimeZone36 = null;
//        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime(dateTimeZone36);
//        int int38 = mutableDateTime37.getWeekOfWeekyear();
//        org.joda.time.MutableDateTime.Property property39 = mutableDateTime37.secondOfMinute();
//        int int40 = property39.get();
//        boolean boolean41 = property39.isLeap();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone42);
//        int int44 = dateTime43.getMillisOfDay();
//        org.joda.time.DateTime.Property property45 = dateTime43.dayOfYear();
//        org.joda.time.DateTime.Property property46 = dateTime43.yearOfCentury();
//        java.lang.String str47 = property46.getAsText();
//        java.util.Locale locale49 = null;
//        org.joda.time.DateTime dateTime50 = property46.setCopy("19", locale49);
//        org.joda.time.LocalDateTime localDateTime51 = dateTime50.toLocalDateTime();
//        int int52 = property39.compareTo((org.joda.time.ReadablePartial) localDateTime51);
//        boolean boolean53 = dateTimeZone33.isLocalDateTimeGap(localDateTime51);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone58 = new org.joda.time.tz.FixedDateTimeZone("1980-04-02T12:13:48-08:00", "10:43:37 PM PDT", 20627024, 2019);
//        int int60 = fixedDateTimeZone58.getOffset(20627549L);
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone61);
//        int int63 = dateTime62.getMillisOfDay();
//        org.joda.time.DateTime.Property property64 = dateTime62.dayOfYear();
//        org.joda.time.DateTime.Property property65 = dateTime62.yearOfCentury();
//        int int66 = dateTime62.getYearOfEra();
//        java.lang.String str67 = dateTime62.toString();
//        org.joda.time.DateTime.Property property68 = dateTime62.millisOfSecond();
//        org.joda.time.ReadableDuration readableDuration69 = null;
//        org.joda.time.DateTime dateTime70 = dateTime62.plus(readableDuration69);
//        boolean boolean71 = fixedDateTimeZone58.equals((java.lang.Object) dateTime62);
//        java.lang.String str73 = fixedDateTimeZone58.getNameKey((long) 20626337);
//        java.util.TimeZone timeZone76 = null;
//        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.forTimeZone(timeZone76);
//        org.joda.time.chrono.GregorianChronology gregorianChronology78 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone77);
//        boolean boolean80 = gregorianChronology78.equals((java.lang.Object) 20631224);
//        java.util.Locale locale81 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket82 = new org.joda.time.format.DateTimeParserBucket(74201796000000L, (org.joda.time.Chronology) gregorianChronology78, locale81);
//        java.util.Locale locale83 = dateTimeParserBucket82.getLocale();
//        java.lang.String str84 = fixedDateTimeZone58.getShortName((long) 20612731, locale83);
//        java.lang.String str85 = offsetDateTimeField21.getAsText((org.joda.time.ReadablePartial) localDateTime51, locale83);
//        java.lang.String str86 = delegatedDateTimeField13.getAsText(68400051L, locale83);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField87 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField13);
//        org.joda.time.MutableDateTime mutableDateTime88 = new org.joda.time.MutableDateTime((long) ' ', (org.joda.time.Chronology) julianChronology1);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "105" + "'", str10.equals("105"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 111 + "'", int12 == 111);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 21600000L + "'", long16 == 21600000L);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "105" + "'", str23.equals("105"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 111 + "'", int25 == 111);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 111 + "'", int27 == 111);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 40 + "'", int40 == 40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 78220583 + "'", int44 == 78220583);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "69" + "'", str47.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(localDateTime51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 20627024 + "'", int60 == 20627024);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 78220583 + "'", int63 == 78220583);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1969 + "'", int66 == 1969);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "1969-12-31T21:43:40.583-08:00" + "'", str67.equals("1969-12-31T21:43:40.583-08:00"));
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "10:43:37 PM PDT" + "'", str73.equals("10:43:37 PM PDT"));
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertNotNull(gregorianChronology78);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(locale83);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "+05:43:47.024" + "'", str84.equals("+05:43:47.024"));
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "9" + "'", str85.equals("9"));
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "107" + "'", str86.equals("107"));
//    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        java.lang.String str8 = jodaTimePermission6.toString();
        java.lang.String str9 = jodaTimePermission6.getName();
        org.joda.time.JodaTimePermission jodaTimePermission11 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        org.joda.time.JodaTimePermission jodaTimePermission13 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean14 = jodaTimePermission11.implies((java.security.Permission) jodaTimePermission13);
        org.joda.time.JodaTimePermission jodaTimePermission16 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean17 = jodaTimePermission11.implies((java.security.Permission) jodaTimePermission16);
        java.lang.String str18 = jodaTimePermission16.toString();
        java.lang.String str19 = jodaTimePermission16.getName();
        java.security.PermissionCollection permissionCollection20 = jodaTimePermission16.newPermissionCollection();
        boolean boolean21 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission16);
        java.security.Permission permission22 = null;
        boolean boolean23 = jodaTimePermission16.implies(permission22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"20190529T224336-0700\")" + "'", str8.equals("(\"org.joda.time.JodaTimePermission\" \"20190529T224336-0700\")"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "20190529T224336-0700" + "'", str9.equals("20190529T224336-0700"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"20190529T224336-0700\")" + "'", str18.equals("(\"org.joda.time.JodaTimePermission\" \"20190529T224336-0700\")"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20190529T224336-0700" + "'", str19.equals("20190529T224336-0700"));
        org.junit.Assert.assertNotNull(permissionCollection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test10");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        long long7 = property6.remainder();
//        org.joda.time.DateTime dateTime8 = property6.roundHalfEvenCopy();
//        org.joda.time.Interval interval9 = property6.toInterval();
//        org.joda.time.DateTime dateTime11 = property6.setCopy(20632559);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78220583 + "'", int2 == 78220583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31527820583L + "'", long7 == 31527820583L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(interval9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime3.add(readableDuration4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.yearOfEra();
        mutableDateTime3.addMonths(20612259);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (byte) -1);
        mutableDateTime3.setZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0L, dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(49);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(chronology0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = property2.roundHalfCeiling();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test13");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        long long8 = offsetDateTimeField3.add((long) 20613274, (long) (byte) 10);
//        int int9 = offsetDateTimeField3.getMaximumValue();
//        boolean boolean11 = offsetDateTimeField3.isLeap((long) 20630028);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime14.dayOfYear();
//        long long17 = property16.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology18.clockhourOfHalfday();
//        boolean boolean21 = property16.equals((java.lang.Object) julianChronology18);
//        org.joda.time.DurationField durationField22 = julianChronology18.days();
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology18, locale23);
//        java.lang.Integer int25 = dateTimeParserBucket24.getOffsetInteger();
//        dateTimeParserBucket24.setOffset(20616031);
//        java.lang.Integer int28 = dateTimeParserBucket24.getOffsetInteger();
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 100);
//        java.lang.String str34 = offsetDateTimeField32.getAsText((long) 20611972);
//        int int36 = offsetDateTimeField32.getLeapAmount(56613274L);
//        long long39 = offsetDateTimeField32.addWrapField(1L, 20614526);
//        long long41 = offsetDateTimeField32.roundCeiling((long) 20634867);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField32.getType();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField45 = julianChronology44.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField(chronology43, dateTimeField46, 20612731);
//        org.joda.time.DurationField durationField49 = skipDateTimeField48.getRangeDurationField();
//        long long52 = durationField49.subtract((long) 20619570, 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
//        dateTimeParserBucket24.saveField(dateTimeFieldType42, 31);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType42, 20623758);
//        int int58 = dividedDateTimeField57.getMinimumValue();
//        org.joda.time.DurationField durationField59 = dividedDateTimeField57.getLeapDurationField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 56613274L + "'", long8 == 56613274L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 111 + "'", int9 == 111);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 78220583 + "'", int15 == 78220583);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 78220583L + "'", long17 == 78220583L);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNull(int25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20616031 + "'", int28.equals(20616031));
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "105" + "'", str34.equals("105"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 7200001L + "'", long39 == 7200001L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21600000L + "'", long41 == 21600000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(julianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 20619570L + "'", long52 == 20619570L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNull(durationField59);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(20631023, 20629029, 20628701, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20629029 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 20620313, dateTimeZone1);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 20613353);
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, 14017433842L, 20623867);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20623867");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 20632559);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1571786337600000L + "'", long1 == 1571786337600000L);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1980-04-02T12:13:48-08:00", "10:43:37 PM PDT", 20627024, 2019);
        long long6 = fixedDateTimeZone4.previousTransition((long) 20629923);
        java.lang.Object obj7 = null;
        boolean boolean8 = fixedDateTimeZone4.equals(obj7);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(45814L);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str14 = fixedDateTimeZone4.getNameKey((long) 20626334);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 20629923L + "'", long6 == 20629923L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10:43:37 PM PDT" + "'", str11.equals("10:43:37 PM PDT"));
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10:43:37 PM PDT" + "'", str14.equals("10:43:37 PM PDT"));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 20613353);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime7.add(readableDuration8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime7);
        int int11 = gJChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology12 = gJChronology10.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(chronology12);
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test20");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str1 = dateTimeZone0.toString();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone0);
//        java.lang.Object obj3 = mutableDateTime2.clone();
//        int int4 = mutableDateTime2.getMillisOfDay();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 78220583 + "'", int4 == 78220583);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        long long8 = offsetDateTimeField3.add((long) 20613274, (long) (byte) 10);
        int int9 = offsetDateTimeField3.getMaximumValue();
        int int10 = offsetDateTimeField3.getMinimumValue();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 20633890, locale12);
        long long16 = offsetDateTimeField3.add(0L, 20611610);
        long long19 = offsetDateTimeField3.add((-11554L), 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 56613274L + "'", long8 == 56613274L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 111 + "'", int9 == 111);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "105" + "'", str13.equals("105"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 74201796000000L + "'", long16 == 74201796000000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-11554L) + "'", long19 == (-11554L));
    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test22");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(20613150);
//        org.joda.time.DateTime.Property property8 = dateTime1.dayOfYear();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfFloorCopy();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(readableDuration10, 20612511);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78220583 + "'", int2 == 78220583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test23");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        mutableDateTime8.add((long) 20612115);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        mutableDateTime13.add(readableDuration14);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
//        int int21 = dateTime18.getDayOfYear();
//        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
//        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
//        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
//        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime31 = property30.roundHalfFloor();
//        org.joda.time.DateTimeField dateTimeField32 = property30.getField();
//        org.joda.time.MutableDateTime mutableDateTime34 = property30.add(20612731);
//        mutableDateTime34.addWeeks(20629752);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78220583 + "'", int2 == 78220583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78220583 + "'", int19 == 78220583);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 20631136, (long) 20627110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 425560711696960L + "'", long2 == 425560711696960L);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((-10L));
        org.joda.time.ReadableInstant readableInstant3 = null;
        boolean boolean4 = instant2.isBefore(readableInstant3);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test27");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getRangeDurationField();
//        java.lang.String str4 = delegatedDateTimeField2.getName();
//        org.joda.time.DateTimeField dateTimeField5 = delegatedDateTimeField2.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        long long10 = property9.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.clockhourOfHalfday();
//        boolean boolean14 = property9.equals((java.lang.Object) julianChronology11);
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology11.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.DateTime.Property property19 = dateTime17.dayOfYear();
//        org.joda.time.DateTime.Property property20 = dateTime17.yearOfCentury();
//        java.lang.String str21 = property20.getAsText();
//        java.util.Locale locale23 = null;
//        org.joda.time.DateTime dateTime24 = property20.setCopy("19", locale23);
//        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
//        boolean boolean26 = dateTimeZone15.isLocalDateTimeGap(localDateTime25);
//        boolean boolean27 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) localDateTime25, locale28);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("1980-04-02T12:13:48-08:00", "10:43:37 PM PDT", 20627024, 2019);
//        int int37 = fixedDateTimeZone35.getOffset(20627549L);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
//        int int40 = dateTime39.getMillisOfDay();
//        org.joda.time.DateTime.Property property41 = dateTime39.dayOfYear();
//        org.joda.time.DateTime.Property property42 = dateTime39.yearOfCentury();
//        int int43 = dateTime39.getYearOfEra();
//        java.lang.String str44 = dateTime39.toString();
//        org.joda.time.DateTime.Property property45 = dateTime39.millisOfSecond();
//        org.joda.time.ReadableDuration readableDuration46 = null;
//        org.joda.time.DateTime dateTime47 = dateTime39.plus(readableDuration46);
//        boolean boolean48 = fixedDateTimeZone35.equals((java.lang.Object) dateTime39);
//        java.lang.String str50 = fixedDateTimeZone35.getNameKey((long) 20626337);
//        java.util.TimeZone timeZone53 = null;
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forTimeZone(timeZone53);
//        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone54);
//        boolean boolean57 = gregorianChronology55.equals((java.lang.Object) 20631224);
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket(74201796000000L, (org.joda.time.Chronology) gregorianChronology55, locale58);
//        java.util.Locale locale60 = dateTimeParserBucket59.getLocale();
//        java.lang.String str61 = fixedDateTimeZone35.getShortName((long) 20612731, locale60);
//        java.lang.String str62 = delegatedDateTimeField2.getAsText(0, locale60);
//        java.text.DateFormatSymbols dateFormatSymbols63 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale60);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hourOfHalfday" + "'", str4.equals("hourOfHalfday"));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78220583 + "'", int8 == 78220583);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 78220583L + "'", long10 == 78220583L);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 78220583 + "'", int18 == 78220583);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "69" + "'", str21.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9" + "'", str29.equals("9"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 20627024 + "'", int37 == 20627024);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 78220583 + "'", int40 == 78220583);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1969 + "'", int43 == 1969);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1969-12-31T21:43:40.583-08:00" + "'", str44.equals("1969-12-31T21:43:40.583-08:00"));
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "10:43:37 PM PDT" + "'", str50.equals("10:43:37 PM PDT"));
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(gregorianChronology55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(locale60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "+05:43:47.024" + "'", str61.equals("+05:43:47.024"));
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "0" + "'", str62.equals("0"));
//        org.junit.Assert.assertNotNull(dateFormatSymbols63);
//    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test28");
//        java.lang.Object obj0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        mutableDateTime3.add(readableDuration4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
//        java.lang.String str12 = property11.getAsText();
//        java.util.Locale locale14 = null;
//        org.joda.time.DateTime dateTime15 = property11.setCopy("19", locale14);
//        org.joda.time.DateMidnight dateMidnight16 = dateTime15.toDateMidnight();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField18 = gregorianChronology17.centuries();
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = dateMidnight16.toDateTime(dateTimeZone19);
//        mutableDateTime3.setZoneRetainFields(dateTimeZone19);
//        org.joda.time.MutableDateTime mutableDateTime22 = org.joda.time.MutableDateTime.now(dateTimeZone19);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(obj0, dateTimeZone19);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78220583 + "'", int9 == 78220583);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "69" + "'", str12.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateMidnight16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(mutableDateTime22);
//    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology5 = gregorianChronology2.withUTC();
        try {
            long long13 = gregorianChronology2.getDateTimeMillis(20623248, 20624503, 20627110, 20618206, 20630581, 20620, 20622056);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20618206 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test30");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        int int5 = dateTime1.getYearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
//        mutableDateTime6.setTime((long) 20621099);
//        java.lang.Object obj9 = mutableDateTime6.clone();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78220583 + "'", int2 == 78220583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(obj9);
//    }

//    @Test
//    public void test31() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test31");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        long long5 = property4.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
//        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
//        org.joda.time.DurationField durationField10 = julianChronology6.days();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
//        mutableDateTime15.setTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = gregorianChronology27.centuries();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime30 = dateTime20.toDateTime(dateTimeZone29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone29.getShortName((long) 20612357, locale32);
//        dateTimeParserBucket12.setZone(dateTimeZone29);
//        dateTimeParserBucket12.setOffset((java.lang.Integer) 20616268);
//        int int37 = dateTimeParserBucket12.getOffset();
//        dateTimeParserBucket12.setOffset(20623758);
//        org.joda.time.DateTimeZone dateTimeZone40 = dateTimeParserBucket12.getZone();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78220583 + "'", int3 == 78220583);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 78220583L + "'", long5 == 78220583L);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78220583 + "'", int21 == 78220583);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 20616268 + "'", int37 == 20616268);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.minuteOfDay();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((long) (short) 10);
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 20617342);
        org.joda.time.DurationField durationField14 = julianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField15 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertNotNull(durationField14);
    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test33");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.DateTime dateTime6 = dateTime1.minusHours(20611457);
//        org.joda.time.DateTime dateTime7 = dateTime6.withEarlierOffsetAtOverlap();
//        java.lang.String str8 = dateTime7.toString();
//        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded((long) 20633376, 20614278);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78220583 + "'", int2 == 78220583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-0382-08-28T04:50:42.583-07:52:58" + "'", str8.equals("-0382-08-28T04:50:42.583-07:52:58"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test34");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        int int6 = dateTime5.getWeekOfWeekyear();
//        boolean boolean7 = dateTime5.isAfterNow();
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField9 = julianChronology8.centuries();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology8.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology8.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology8.monthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology14 = julianChronology8.withZone(dateTimeZone13);
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78220583 + "'", int2 == 78220583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test36");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        int int6 = dateTime5.getMillisOfDay();
//        org.joda.time.DateTime.Property property7 = dateTime5.dayOfYear();
//        long long8 = property7.remainder();
//        org.joda.time.DateTimeField dateTimeField9 = property7.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9);
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology11, dateTimeField14, 20612731);
//        org.joda.time.DurationField durationField17 = skipDateTimeField16.getRangeDurationField();
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
//        int int22 = offsetDateTimeField21.getMinimumValue();
//        long long24 = offsetDateTimeField21.roundHalfEven((long) (short) 10);
//        org.joda.time.ReadablePartial readablePartial25 = null;
//        int int26 = offsetDateTimeField21.getMaximumValue(readablePartial25);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone32 = null;
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
//        int int34 = dateTime33.getMillisOfDay();
//        org.joda.time.DateTime.Property property35 = dateTime33.dayOfYear();
//        org.joda.time.DateTime.Property property36 = dateTime33.yearOfCentury();
//        java.lang.String str37 = property36.getAsText();
//        java.util.Locale locale39 = null;
//        org.joda.time.DateTime dateTime40 = property36.setCopy("19", locale39);
//        org.joda.time.LocalDateTime localDateTime41 = dateTime40.toLocalDateTime();
//        long long43 = julianChronology30.set((org.joda.time.ReadablePartial) localDateTime41, 0L);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = delegatedDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, locale44);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, 20624780, locale47);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDateTime41, locale49);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = skipUndoDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, locale51);
//        org.joda.time.DurationField durationField53 = skipUndoDateTimeField10.getDurationField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 78220583 + "'", int6 == 78220583);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 78220583L + "'", long8 == 78220583L);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 111 + "'", int26 == 111);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 78220583 + "'", int34 == 78220583);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "69" + "'", str37.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDateTime41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1576808179417L) + "'", long43 == (-1576808179417L));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9" + "'", str45.equals("9"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "20624780" + "'", str48.equals("20624780"));
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "583" + "'", str50.equals("583"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "365" + "'", str52.equals("365"));
//        org.junit.Assert.assertNotNull(durationField53);
//    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test37");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone16.getShortName((long) 20612357, locale19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        boolean boolean23 = gJChronology21.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.monthOfYear();
//        org.joda.time.Instant instant25 = gJChronology21.getGregorianCutover();
//        org.joda.time.Instant instant28 = instant25.withDurationAdded((long) 20630133, 10);
//        org.joda.time.Instant instant30 = instant28.withMillis((long) 31);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78220583 + "'", int8 == 78220583);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(instant28);
//        org.junit.Assert.assertNotNull(instant30);
//    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology6 = julianChronology0.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology7 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test39");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
//        java.lang.String str11 = property10.getAsText();
//        java.util.Locale locale13 = null;
//        org.joda.time.DateTime dateTime14 = property10.setCopy("19", locale13);
//        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField17 = gregorianChronology16.centuries();
//        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
//        org.joda.time.DateTime dateTime19 = dateMidnight15.toDateTime(dateTimeZone18);
//        mutableDateTime2.setZoneRetainFields(dateTimeZone18);
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime2.dayOfYear();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime2.minuteOfHour();
//        java.lang.String str23 = property22.getName();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78220583 + "'", int8 == 78220583);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateMidnight15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "minuteOfHour" + "'", str23.equals("minuteOfHour"));
//    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test40");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        long long8 = offsetDateTimeField3.add((long) 20613274, (long) (byte) 10);
//        int int9 = offsetDateTimeField3.getMaximumValue();
//        boolean boolean11 = offsetDateTimeField3.isLeap((long) 20630028);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime14.dayOfYear();
//        long long17 = property16.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology18.clockhourOfHalfday();
//        boolean boolean21 = property16.equals((java.lang.Object) julianChronology18);
//        org.joda.time.DurationField durationField22 = julianChronology18.days();
//        java.util.Locale locale23 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket24 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology18, locale23);
//        java.lang.Integer int25 = dateTimeParserBucket24.getOffsetInteger();
//        dateTimeParserBucket24.setOffset(20616031);
//        java.lang.Integer int28 = dateTimeParserBucket24.getOffsetInteger();
//        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) 100);
//        java.lang.String str34 = offsetDateTimeField32.getAsText((long) 20611972);
//        int int36 = offsetDateTimeField32.getLeapAmount(56613274L);
//        long long39 = offsetDateTimeField32.addWrapField(1L, 20614526);
//        long long41 = offsetDateTimeField32.roundCeiling((long) 20634867);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField32.getType();
//        org.joda.time.Chronology chronology43 = null;
//        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField45 = julianChronology44.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.millisOfSecond();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField(chronology43, dateTimeField46, 20612731);
//        org.joda.time.DurationField durationField49 = skipDateTimeField48.getRangeDurationField();
//        long long52 = durationField49.subtract((long) 20619570, 0);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField53 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
//        dateTimeParserBucket24.saveField(dateTimeFieldType42, 31);
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType42, 20623758);
//        int int58 = dividedDateTimeField57.getMinimumValue();
//        org.joda.time.DurationField durationField59 = dividedDateTimeField57.getDurationField();
//        int int62 = dividedDateTimeField57.getDifference((long) 20634869, 0L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 56613274L + "'", long8 == 56613274L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 111 + "'", int9 == 111);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 78220583 + "'", int15 == 78220583);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 78220583L + "'", long17 == 78220583L);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNull(int25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 20616031 + "'", int28.equals(20616031));
//        org.junit.Assert.assertNotNull(julianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "105" + "'", str34.equals("105"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 7200001L + "'", long39 == 7200001L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 21600000L + "'", long41 == 21600000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(julianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 20619570L + "'", long52 == 20619570L);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField53);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test41");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        int int5 = dateTime4.getMillisOfDay();
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
//        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
//        int int8 = dateTime4.getYearOfEra();
//        java.lang.String str9 = dateTime4.toString();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime4);
//        try {
//            long long15 = gJChronology10.getDateTimeMillis(20615673, 20624252, 20614204, 31);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20624252 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 78220583 + "'", int5 == 78220583);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31T21:43:40.583-08:00" + "'", str9.equals("1969-12-31T21:43:40.583-08:00"));
//        org.junit.Assert.assertNotNull(gJChronology10);
//    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test42");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        mutableDateTime3.add(readableDuration4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.minuteOfDay();
//        mutableDateTime3.setTime((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField16 = gregorianChronology15.centuries();
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology15.getZone();
//        org.joda.time.DateTime dateTime18 = dateTime8.toDateTime(dateTimeZone17);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone17.getShortName((long) 20612357, locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone17.getShortName((long) 20613759, locale23);
//        long long28 = dateTimeZone17.convertLocalToUTC((long) 20619914, true, (long) 20620350);
//        org.joda.time.Chronology chronology29 = gregorianChronology0.withZone(dateTimeZone17);
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 100);
//        int int34 = offsetDateTimeField33.getMinimumValue();
//        long long36 = offsetDateTimeField33.roundHalfEven((long) (short) 10);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int int38 = offsetDateTimeField33.getMaximumValue(readablePartial37);
//        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology39.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40);
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = julianChronology42.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        int int46 = dateTime45.getMillisOfDay();
//        org.joda.time.DateTime.Property property47 = dateTime45.dayOfYear();
//        org.joda.time.DateTime.Property property48 = dateTime45.yearOfCentury();
//        java.lang.String str49 = property48.getAsText();
//        java.util.Locale locale51 = null;
//        org.joda.time.DateTime dateTime52 = property48.setCopy("19", locale51);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
//        long long55 = julianChronology42.set((org.joda.time.ReadablePartial) localDateTime53, 0L);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = delegatedDateTimeField41.getAsShortText((org.joda.time.ReadablePartial) localDateTime53, locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) localDateTime53, 20624780, locale59);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField33, 20626151);
//        long long64 = skipUndoDateTimeField62.roundHalfFloor((long) 365);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78220583 + "'", int9 == 78220583);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PST" + "'", str24.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 49419914L + "'", long28 == 49419914L);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 111 + "'", int38 == 111);
//        org.junit.Assert.assertNotNull(julianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 78220583 + "'", int46 == 78220583);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "69" + "'", str49.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-1576808179417L) + "'", long55 == (-1576808179417L));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9" + "'", str57.equals("9"));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "20624780" + "'", str60.equals("20624780"));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
//    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test43");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.DateTime dateTime6 = dateTime1.plusSeconds(0);
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, readableInstant7);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78220583 + "'", int2 == 78220583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(chronology8);
//    }

//    @Test
//    public void test44() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test44");
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        boolean boolean5 = gregorianChronology3.equals((java.lang.Object) 20631224);
//        java.util.Locale locale6 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(74201796000000L, (org.joda.time.Chronology) gregorianChronology3, locale6);
//        org.joda.time.DateTimeField dateTimeField8 = null;
//        dateTimeParserBucket7.saveField(dateTimeField8, 20621724);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) 100);
//        java.lang.String str16 = offsetDateTimeField14.getAsText((long) 20611972);
//        int int18 = offsetDateTimeField14.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        int int22 = dateTime21.getMillisOfDay();
//        org.joda.time.DateTime.Property property23 = dateTime21.dayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime21.yearOfCentury();
//        java.lang.String str25 = property24.getAsText();
//        java.util.Locale locale27 = null;
//        org.joda.time.DateTime dateTime28 = property24.setCopy("19", locale27);
//        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
//        int[] intArray33 = new int[] { 10, 10, 20612731 };
//        int int34 = delegatedDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay29, intArray33);
//        java.util.Locale locale36 = null;
//        java.lang.String str37 = delegatedDateTimeField19.getAsShortText(20622859, locale36);
//        int int38 = delegatedDateTimeField19.getMaximumValue();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = delegatedDateTimeField19.getAsShortText((long) 20626614, locale40);
//        java.util.Locale locale42 = null;
//        int int43 = delegatedDateTimeField19.getMaximumTextLength(locale42);
//        dateTimeParserBucket7.saveField((org.joda.time.DateTimeField) delegatedDateTimeField19, 22);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "105" + "'", str16.equals("105"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 111 + "'", int18 == 111);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 78220583 + "'", int22 == 78220583);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "69" + "'", str25.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(timeOfDay29);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20622859" + "'", str37.equals("20622859"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 111 + "'", int38 == 111);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "105" + "'", str41.equals("105"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
//    }
//}

