import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        try {
            mutableDateTime2.setTime(20611457, 0, (int) (byte) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20611457 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        try {
//            org.joda.time.DateTime dateTime4 = dateTime1.withEra(2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20611945 + "'", int2 == 20611945);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        try {
            long long9 = julianChronology0.getDateTimeMillis(20611758, (int) (short) 100, 20611457, (int) (short) 10, (int) (byte) -1, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test009");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        try {
//            int int4 = dateTime1.get(dateTimeFieldType3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20612083 + "'", int2 == 20612083);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test010");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getMillisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
//        int int6 = dateTime3.getDayOfYear();
//        java.lang.String str7 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime3);
//        try {
//            org.joda.time.Instant instant8 = org.joda.time.Instant.parse("hi!", dateTimeFormatter1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20612295 + "'", int4 == 20612295);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 163 + "'", int6 == 163);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5:43:32 AM PDT" + "'", str7.equals("5:43:32 AM PDT"));
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField6 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType4, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test014");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        int int6 = dateTime5.getMonthOfYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20612578 + "'", int2 == 20612578);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test015");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        try {
//            int int6 = dateTime1.get(dateTimeFieldType5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20612667 + "'", int2 == 20612667);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        long long2 = dateTimeFormatter0.parseMillis("19");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61567603200000L) + "'", long2 == (-61567603200000L));
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test017");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        try {
//            int int7 = dateTime1.compareTo(readableInstant6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20612820 + "'", int2 == 20612820);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        java.util.Locale locale8 = null;
        int int9 = property5.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) false, (java.lang.Object) property4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20613726 + "'", int3 == 20613726);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "163" + "'", str6.equals("163"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        boolean boolean7 = offsetDateTimeField3.isLeap((long) (-1));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        int int6 = mutableDateTime2.getSecondOfDay();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.millisOfSecond();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 45814 + "'", int6 == 45814);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        java.lang.String str5 = property4.getAsText();
//        java.util.Locale locale7 = null;
//        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
//        boolean boolean9 = property4.isLeap();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20614325 + "'", int2 == 20614325);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        java.lang.String str6 = mutableDateTime2.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019-05-30T12:43:34.361Z" + "'", str6.equals("2019-05-30T12:43:34.361Z"));
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
//        int int2 = mutableDateTime1.getWeekOfWeekyear();
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.secondOfMinute();
//        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 0, 20614325, 20613759);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        try {
            long long9 = julianChronology0.getDateTimeMillis((int) (byte) 10, (int) 'a', (int) '4', (int) (byte) 1, (int) (short) -1, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology5);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        mutableDateTime7.add(readableDuration8);
//        boolean boolean10 = dateTime1.isAfter((org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.DateTime.Property property11 = dateTime1.millisOfDay();
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime1.withDayOfMonth(20612731);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20612731 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20615188 + "'", int2 == 20615188);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test039");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        int int7 = property6.getMinimumValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20615301 + "'", int2 == 20615301);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292275054) + "'", int7 == (-292275054));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("5:43:33 AM PDT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5:43:33 AM PDT\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "19", 20615007);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        try {
//            long long13 = julianChronology6.getDateTimeMillis(20613958, 20615301, 20615301, 20611457);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20615301 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20615368 + "'", int2 == 20615368);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        int int14 = dateTime7.getYear();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20615775 + "'", int8 == 20615775);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        mutableDateTime1.setZoneRetainFields(dateTimeZone2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        java.lang.String str9 = offsetDateTimeField7.getAsText((long) 20611972);
        int int11 = offsetDateTimeField7.getLeapAmount(56613274L);
        try {
            mutableDateTime1.setRounding((org.joda.time.DateTimeField) offsetDateTimeField7, 20614623);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 20614623");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "105" + "'", str9.equals("105"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime1.withDayOfMonth(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20615890 + "'", int2 == 20615890);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(20613353, 20613759, 20614882, 20615742);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20613759 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        java.util.Locale locale8 = null;
        try {
            long long9 = offsetDateTimeField3.set((long) 45814, "hi!", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField3.getAsShortText((long) 20612393, locale7);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType9, 2019, 20614526, 20613726);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "105" + "'", str8.equals("105"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 20616031, 20615301, 5, 45813, 0, 20615162);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 45813 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        mutableDateTime8.add((long) 20612115);
//        org.joda.time.DurationFieldType durationFieldType11 = null;
//        try {
//            mutableDateTime8.add(durationFieldType11, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20616460 + "'", int2 == 20616460);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            long long3 = gregorianChronology0.set(readablePartial1, (long) 20613759);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(3, 20612115);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 20612115");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = julianChronology3.months();
        org.joda.time.DurationField durationField5 = julianChronology3.days();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.property(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "2019-06-12T05:43:37.342-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(20611758, 10, (int) '#', 20614623, 20613660, 20613759, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20614623 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime3.add(readableDuration4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.yearOfEra();
        mutableDateTime3.addMonths(20612259);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (byte) -1);
        mutableDateTime3.setZone(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0L, dateTimeZone11);
        org.joda.time.DateTime dateTime15 = dateTime13.plusDays(4);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            long long2 = dateTimeFormatter0.parseMillis("20190529T224336-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"20190529T224336-0700\" is malformed at \"T224336-0700\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(45814, 20616031, (-292275054), 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-271613210) + "'", int4 == (-271613210));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.io.Writer writer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(20613274, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20613277 + "'", int2 == 20613277);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(28800010L);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        int int11 = dateTime8.getDayOfYear();
//        java.lang.String str12 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
//        mutableDateTime15.setTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        mutableDateTime15.setZone(dateTimeZone27);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withDefaultYear(10);
//        java.lang.String str32 = mutableDateTime15.toString(dateTimeFormatter29);
//        java.lang.String str33 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) mutableDateTime15);
//        boolean boolean34 = property5.equals((java.lang.Object) mutableDateTime15);
//        org.joda.time.DateTimeField dateTimeField35 = mutableDateTime15.getRoundingField();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12:00:00 AM PST" + "'", str12.equals("12:00:00 AM PST"));
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "19691218T160000-0800" + "'", str32.equals("19691218T160000-0800"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "4:00:00 PM PST" + "'", str33.equals("4:00:00 PM PST"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNull(dateTimeField35);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("4:00:00 PM PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '4:00:00 PM PST' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.toString();
        int int3 = dateTimeZone0.getOffsetFromLocal((long) 163);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-28800000) + "'", int3 == (-28800000));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(20618206, 20611704);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 20618206");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        long long4 = property3.remainder();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(100);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusHours((int) (short) 10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20619772 + "'", int2 == 20619772);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 20619772L + "'", long4 == 20619772L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 20615742, (long) 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 41623183098L + "'", long2 == 41623183098L);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime1.toDateMidnight();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20620191 + "'", int2 == 20620191);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime1.withMillisOfSecond(20614204);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20614204 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20620241 + "'", int2 == 20620241);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        long long4 = property3.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.clockhourOfHalfday();
//        boolean boolean8 = property3.equals((java.lang.Object) julianChronology5);
//        org.joda.time.DurationField durationField9 = julianChronology5.days();
//        long long12 = durationField9.subtract((long) 20617122, 20619772);
//        long long15 = durationField9.subtract((long) 20618206, 20616268);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20620313 + "'", int2 == 20620313);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 20620313L + "'", long4 == 20620313L);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1781548280182878L) + "'", long12 == (-1781548280182878L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1781245534581794L) + "'", long15 == (-1781245534581794L));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = dateTime1.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
//        int int2 = mutableDateTime1.getWeekOfWeekyear();
//        try {
//            mutableDateTime1.setTime(20615301, 4, 20617303, 20613600);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20615301 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
        java.util.Locale locale12 = null;
        try {
            long long13 = delegatedDateTimeField8.set((long) 1970, "10:43:37 PM PDT", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"10:43:37 PM PDT\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        mutableDateTime2.setYear(20617303);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology5);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        mutableDateTime7.add(readableDuration8);
//        boolean boolean10 = dateTime1.isAfter((org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.DateTime.Property property11 = dateTime1.millisOfDay();
//        int int12 = property11.getMinimumValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20620986 + "'", int2 == 20620986);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant10 = instant9.toInstant();
        boolean boolean11 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) instant9);
        mutableDateTime7.addMonths((int) (short) 1);
        mutableDateTime7.setDate((long) 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.add((long) 2, 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2L + "'", long5 == 2L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant1.minus(readableDuration3);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(20616031, 3, 20620583, 163, 20613600, 0, 20612115, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 163 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 10);
//        boolean boolean9 = dateTime7.isBefore((long) 20611704);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20621362 + "'", int2 == 20621362);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        mutableDateTime8.add((long) 20612115);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        mutableDateTime13.add(readableDuration14);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
//        int int21 = dateTime18.getDayOfYear();
//        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
//        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
//        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
//        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
//        try {
//            mutableDateTime8.setDayOfMonth(20615673);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20615673 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20621391 + "'", int2 == 20621391);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20621394 + "'", int19 == 20621394);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 163 + "'", int21 == 163);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        long long5 = property4.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
//        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
//        org.joda.time.DurationField durationField10 = julianChronology6.days();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        java.util.Locale locale15 = null;
//        try {
//            dateTimeParserBucket12.saveField(dateTimeFieldType13, "20617081", locale15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20621671 + "'", int3 == 20621671);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 20621671L + "'", long5 == 20621671L);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        mutableDateTime8.add((long) 20612115);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        mutableDateTime13.add(readableDuration14);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
//        int int21 = dateTime18.getDayOfYear();
//        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
//        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
//        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
//        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
//        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
//        try {
//            int int32 = mutableDateTime29.get(dateTimeFieldType31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20622176 + "'", int2 == 20622176);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20622179 + "'", int19 == 20622179);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 163 + "'", int21 == 163);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertNotNull(property30);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 20613150L, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.centuries();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.hourOfHalfday();
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(20615007, 0, 20611704, 20620313, 20622228, (int) (byte) 100, 20612115, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20620313 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 20613353);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime7.add(readableDuration8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray14 = gJChronology10.get(readablePeriod11, (long) 20615225, 20619772L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gJChronology10);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsShortText(locale4);
//        org.joda.time.DateTime dateTime7 = property3.addWrapFieldToCopy(24);
//        org.joda.time.Chronology chronology8 = dateTime7.getChronology();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20622827 + "'", int2 == 20622827);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "163" + "'", str5.equals("163"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(chronology8);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withDayOfMonth(20619570);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20619570 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        java.io.Writer writer2 = null;
//        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) 100);
//        java.lang.String str8 = offsetDateTimeField6.getAsText((long) 20611972);
//        int int10 = offsetDateTimeField6.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
//        int int14 = dateTime13.getMillisOfDay();
//        org.joda.time.DateTime.Property property15 = dateTime13.dayOfYear();
//        org.joda.time.DateTime.Property property16 = dateTime13.yearOfCentury();
//        java.lang.String str17 = property16.getAsText();
//        java.util.Locale locale19 = null;
//        org.joda.time.DateTime dateTime20 = property16.setCopy("19", locale19);
//        org.joda.time.TimeOfDay timeOfDay21 = dateTime20.toTimeOfDay();
//        int[] intArray25 = new int[] { 10, 10, 20612731 };
//        int int26 = delegatedDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay21, intArray25);
//        try {
//            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) timeOfDay21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(julianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "105" + "'", str8.equals("105"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 111 + "'", int10 == 111);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20623340 + "'", int14 == 20623340);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(timeOfDay21);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(20615775, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2061577500 + "'", int2 == 2061577500);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        long long8 = offsetDateTimeField3.add((long) 20613274, (long) (byte) 10);
        int int9 = offsetDateTimeField3.getMaximumValue();
        java.util.Locale locale12 = null;
        try {
            long long13 = offsetDateTimeField3.set((long) 20615085, "163", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 163 for hourOfHalfday must be in the range [100,111]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 56613274L + "'", long8 == 56613274L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 111 + "'", int9 == 111);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        mutableDateTime2.setZone(dateTimeZone14);
//        long long19 = dateTimeZone14.convertLocalToUTC((long) 20615301, true, (long) (short) 10);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20623758 + "'", int8 == 20623758);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 49415301L + "'", long19 == 49415301L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant10 = instant9.toInstant();
        boolean boolean11 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) instant9);
        try {
            mutableDateTime7.setDate(20612259, 20613274, 20622412);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20613274 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField3, 20612731);
        try {
            long long8 = skipDateTimeField5.set((long) 20616031, 2061577500);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2061577500 for millisOfSecond must be in the range [-1,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(20622019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 20622019");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        java.lang.String str5 = property4.getAsText();
//        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(20614204);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20614204 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20624489 + "'", int2 == 20624489);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 163);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210852676800000L) + "'", long1 == (-210852676800000L));
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime1.withMillisOfSecond(20622496);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20622496 for millisOfSecond must be in the range [0,999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20624721 + "'", int2 == 20624721);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(20613150);
//        org.joda.time.DurationFieldType durationFieldType8 = null;
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime7.withFieldAdded(durationFieldType8, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20624801 + "'", int2 == 20624801);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 20621728, "-00:01");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 20619914);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        java.lang.String str5 = property4.getAsText();
//        java.util.Locale locale7 = null;
//        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
//        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
//        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(20621322);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20625325 + "'", int2 == 20625325);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateMidnight9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        long long4 = property3.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.clockhourOfHalfday();
//        boolean boolean8 = property3.equals((java.lang.Object) julianChronology5);
//        try {
//            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) property3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20625533 + "'", int2 == 20625533);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 20625533L + "'", long4 == 20625533L);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        int int5 = dateTime2.getDayOfYear();
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology7);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        mutableDateTime9.add(readableDuration10);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime14.dayOfYear();
//        int int17 = dateTime14.getDayOfYear();
//        org.joda.time.DateTime.Property property18 = dateTime14.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime14.minuteOfDay();
//        mutableDateTime9.setTime((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        mutableDateTime9.setZone(dateTimeZone21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withDefaultYear(10);
//        java.lang.String str26 = mutableDateTime9.toString(dateTimeFormatter23);
//        java.lang.String str27 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime9);
//        try {
//            mutableDateTime9.setMonthOfYear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20625548 + "'", int3 == 20625548);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 163 + "'", int5 == 163);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5:43:45 AM PDT" + "'", str6.equals("5:43:45 AM PDT"));
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 20625551 + "'", int15 == 20625551);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 163 + "'", int17 == 163);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20190529T224345-0700" + "'", str26.equals("20190529T224345-0700"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10:43:45 PM PDT" + "'", str27.equals("10:43:45 PM PDT"));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(20621492);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 20621492");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DurationField durationField4 = delegatedDateTimeField3.getRangeDurationField();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) delegatedDateTimeField3);
        try {
            long long8 = delegatedDateTimeField3.set((long) 35, 20619772);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20619772 for hourOfHalfday must be in the range [0,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(20622827, (int) (short) 0, 20623870, 20611758, 2, 20624859);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20611758 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
//        java.lang.String str14 = property13.getAsText();
//        java.util.Locale locale16 = null;
//        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
//        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
//        int[] intArray22 = new int[] { 10, 10, 20612731 };
//        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
//        int int31 = dateTime30.getMillisOfDay();
//        org.joda.time.DateTime.Property property32 = dateTime30.dayOfYear();
//        org.joda.time.DateTime.Property property33 = dateTime30.yearOfCentury();
//        java.lang.String str34 = property33.getAsText();
//        java.util.Locale locale36 = null;
//        org.joda.time.DateTime dateTime37 = property33.setCopy("19", locale36);
//        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
//        long long40 = julianChronology27.set((org.joda.time.ReadablePartial) localDateTime38, 0L);
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = julianChronology42.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) 100);
//        java.lang.String str47 = offsetDateTimeField45.getAsText((long) 20611972);
//        int int49 = offsetDateTimeField45.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField45);
//        org.joda.time.DateTimeZone dateTimeZone51 = null;
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone51);
//        int int53 = dateTime52.getMillisOfDay();
//        org.joda.time.DateTime.Property property54 = dateTime52.dayOfYear();
//        org.joda.time.DateTime.Property property55 = dateTime52.yearOfCentury();
//        java.lang.String str56 = property55.getAsText();
//        java.util.Locale locale58 = null;
//        org.joda.time.DateTime dateTime59 = property55.setCopy("19", locale58);
//        org.joda.time.TimeOfDay timeOfDay60 = dateTime59.toTimeOfDay();
//        int[] intArray64 = new int[] { 10, 10, 20612731 };
//        int int65 = delegatedDateTimeField50.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay60, intArray64);
//        try {
//            int[] intArray67 = delegatedDateTimeField8.add((org.joda.time.ReadablePartial) localDateTime38, 20617122, intArray64, (-292275054));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20617122");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20626784 + "'", int11 == 20626784);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "19" + "'", str14.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(timeOfDay18);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 20626786 + "'", int31 == 20626786);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "19" + "'", str34.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localDateTime38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1561441426786L + "'", long40 == 1561441426786L);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "105" + "'", str47.equals("105"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 111 + "'", int49 == 111);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 20626789 + "'", int53 == 20626789);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "19" + "'", str56.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(timeOfDay60);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
//        long long11 = delegatedDateTimeField8.roundCeiling((long) 20611566);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField13 = gregorianChronology12.centuries();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        int int18 = dateTime17.getMillisOfDay();
//        org.joda.time.DateTime.Property property19 = dateTime17.dayOfYear();
//        org.joda.time.DateTime.Property property20 = dateTime17.yearOfCentury();
//        java.lang.String str21 = property20.getAsText();
//        java.util.Locale locale23 = null;
//        org.joda.time.DateTime dateTime24 = property20.setCopy("19", locale23);
//        org.joda.time.TimeOfDay timeOfDay25 = dateTime24.toTimeOfDay();
//        int[] intArray27 = gregorianChronology12.get((org.joda.time.ReadablePartial) timeOfDay25, (-1781245534581794L));
//        java.util.Locale locale28 = null;
//        try {
//            java.lang.String str29 = delegatedDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) timeOfDay25, locale28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 21600000L + "'", long11 == 21600000L);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 20626885 + "'", int18 == 20626885);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "19" + "'", str21.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(timeOfDay25);
//        org.junit.Assert.assertNotNull(intArray27);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        boolean boolean4 = offsetDateTimeField3.isSupported();
        long long6 = offsetDateTimeField3.roundHalfFloor((long) 20611758);
        int int8 = offsetDateTimeField3.get((long) 2000);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 21600000L + "'", long6 == 21600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(20625169, 0, 20621099, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        int int5 = dateTime1.getYearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
//        org.joda.time.DateTime.Property property7 = dateTime1.yearOfEra();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20627024 + "'", int2 == 20627024);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("20622859");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '20622859' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("5:43:42 AM PDT", 2019, 20626337, 20621430);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for 5:43:42 AM PDT must be in the range [20626337,20621430]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(20617561, 0, 20624301, 20627058, 20620191, (int) (byte) 1, 20622228);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20627058 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 20617122);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20617122 + "'", int1 == 20617122);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
//        java.lang.String str14 = property13.getAsText();
//        java.util.Locale locale16 = null;
//        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
//        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
//        int[] intArray22 = new int[] { 10, 10, 20612731 };
//        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
//        org.joda.time.ReadablePartial readablePartial27 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField30 = gregorianChronology29.centuries();
//        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology29.getZone();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
//        int int35 = dateTime34.getMillisOfDay();
//        org.joda.time.DateTime.Property property36 = dateTime34.dayOfYear();
//        org.joda.time.DateTime.Property property37 = dateTime34.yearOfCentury();
//        java.lang.String str38 = property37.getAsText();
//        java.util.Locale locale40 = null;
//        org.joda.time.DateTime dateTime41 = property37.setCopy("19", locale40);
//        org.joda.time.TimeOfDay timeOfDay42 = dateTime41.toTimeOfDay();
//        int[] intArray44 = gregorianChronology29.get((org.joda.time.ReadablePartial) timeOfDay42, (-1781245534581794L));
//        try {
//            int[] intArray46 = delegatedDateTimeField8.set(readablePartial27, (int) '#', intArray44, 20614526);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20614526 for hourOfHalfday must be in the range [100,111]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20628169 + "'", int11 == 20628169);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "19" + "'", str14.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(timeOfDay18);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 20628172 + "'", int35 == 20628172);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "19" + "'", str38.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(timeOfDay42);
//        org.junit.Assert.assertNotNull(intArray44);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.centuries();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField4 = julianChronology1.seconds();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 20617081);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 20617081");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.DurationField durationField2 = julianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        long long8 = offsetDateTimeField3.add((long) 20613274, (long) (byte) 10);
//        int int9 = offsetDateTimeField3.getMaximumValue();
//        int int10 = offsetDateTimeField3.getMinimumValue();
//        java.util.Locale locale11 = null;
//        int int12 = offsetDateTimeField3.getMaximumShortTextLength(locale11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField14 = gregorianChronology13.centuries();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        int int19 = dateTime18.getMillisOfDay();
//        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
//        org.joda.time.DateTime.Property property21 = dateTime18.yearOfCentury();
//        java.lang.String str22 = property21.getAsText();
//        java.util.Locale locale24 = null;
//        org.joda.time.DateTime dateTime25 = property21.setCopy("19", locale24);
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime25.toTimeOfDay();
//        int[] intArray28 = gregorianChronology13.get((org.joda.time.ReadablePartial) timeOfDay26, (-1781245534581794L));
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 100);
//        java.lang.String str35 = offsetDateTimeField33.getAsText((long) 20611972);
//        int int37 = offsetDateTimeField33.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField33);
//        org.joda.time.DateTimeZone dateTimeZone39 = null;
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
//        int int41 = dateTime40.getMillisOfDay();
//        org.joda.time.DateTime.Property property42 = dateTime40.dayOfYear();
//        org.joda.time.DateTime.Property property43 = dateTime40.yearOfCentury();
//        java.lang.String str44 = property43.getAsText();
//        java.util.Locale locale46 = null;
//        org.joda.time.DateTime dateTime47 = property43.setCopy("19", locale46);
//        org.joda.time.TimeOfDay timeOfDay48 = dateTime47.toTimeOfDay();
//        int[] intArray52 = new int[] { 10, 10, 20612731 };
//        int int53 = delegatedDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay48, intArray52);
//        java.util.Locale locale55 = null;
//        try {
//            int[] intArray56 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) timeOfDay26, (int) (byte) 10, intArray52, "America/Los_Angeles", locale55);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for hourOfHalfday is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 56613274L + "'", long8 == 56613274L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 111 + "'", int9 == 111);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 20628447 + "'", int19 == 20628447);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "19" + "'", str22.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "105" + "'", str35.equals("105"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 111 + "'", int37 == 111);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 20628450 + "'", int41 == 20628450);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "19" + "'", str44.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(timeOfDay48);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 100 + "'", int53 == 100);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "105");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        int int11 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
//        java.lang.String str14 = property13.getAsText();
//        java.util.Locale locale16 = null;
//        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
//        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
//        int[] intArray22 = new int[] { 10, 10, 20612731 };
//        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
//        int int27 = delegatedDateTimeField8.getMaximumValue();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType28, 20611610, 20622657, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20628669 + "'", int11 == 20628669);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "19" + "'", str14.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(timeOfDay18);
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 111 + "'", int27 == 111);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
//        int int8 = mutableDateTime7.getSecondOfMinute();
//        try {
//            mutableDateTime7.setMonthOfYear(20616629);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20616629 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 48 + "'", int8 == 48);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(20612731, 20621362, 20623870, 20628345, 20622387, (int) '4', 20611704);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20628345 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 20616626, 20618233, 20626152, 20613277, (int) (byte) 100, 20619631);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20626152 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-1781548280182878L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-18179184L) + "'", long1 == (-18179184L));
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone16.getShortName((long) 20612357, locale19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        boolean boolean23 = gJChronology21.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology21.getZone();
//        try {
//            long long32 = gJChronology21.getDateTimeMillis(20620986, 20619592, 20614278, (int) (byte) 0, 20624252, 20622228, 20620121);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20624252 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20629557 + "'", int8 == 20629557);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 20616031, 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 61848093L + "'", long2 == 61848093L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 20613759);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 20613600);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        int int11 = dateTime8.getDayOfYear();
//        java.lang.String str12 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
//        mutableDateTime15.setTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        mutableDateTime15.setZone(dateTimeZone27);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withDefaultYear(10);
//        java.lang.String str32 = mutableDateTime15.toString(dateTimeFormatter29);
//        java.lang.String str33 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) mutableDateTime15);
//        boolean boolean34 = property5.equals((java.lang.Object) mutableDateTime15);
//        int int35 = property5.getMinimumValueOverall();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20630131 + "'", int2 == 20630131);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20630131 + "'", int9 == 20630131);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 163 + "'", int11 == 163);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5:43:50 AM PDT" + "'", str12.equals("5:43:50 AM PDT"));
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 20630133 + "'", int21 == 20630133);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 163 + "'", int23 == 163);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "20190529T224350-0700" + "'", str32.equals("20190529T224350-0700"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10:43:50 PM PDT" + "'", str33.equals("10:43:50 PM PDT"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) 100);
//        java.lang.String str16 = offsetDateTimeField14.getAsText((long) 20611972);
//        int int18 = offsetDateTimeField14.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        int int22 = dateTime21.getMillisOfDay();
//        org.joda.time.DateTime.Property property23 = dateTime21.dayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime21.yearOfCentury();
//        java.lang.String str25 = property24.getAsText();
//        java.util.Locale locale27 = null;
//        org.joda.time.DateTime dateTime28 = property24.setCopy("19", locale27);
//        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
//        int[] intArray33 = new int[] { 10, 10, 20612731 };
//        int int34 = delegatedDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay29, intArray33);
//        try {
//            int[] intArray36 = delegatedDateTimeField8.addWrapPartial(readablePartial9, 0, intArray33, 20622859);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "105" + "'", str16.equals("105"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 111 + "'", int18 == 111);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 20630524 + "'", int22 == 20630524);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "19" + "'", str25.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(timeOfDay29);
//        org.junit.Assert.assertNotNull(intArray33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime1.minusMinutes(20618096);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, 20612511);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime13.withEra(20612511);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20612511 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20630554 + "'", int2 == 20630554);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        long long8 = offsetDateTimeField3.add((long) (byte) 100, 24);
        boolean boolean10 = offsetDateTimeField3.isLeap(20619814L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400100L + "'", long8 == 86400100L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        int int6 = dateTime5.getWeekOfWeekyear();
//        boolean boolean7 = dateTime5.isAfterNow();
//        org.joda.time.DateTime.Property property8 = dateTime5.monthOfYear();
//        org.joda.time.DateTime dateTime10 = dateTime5.withWeekyear(20616626);
//        try {
//            org.joda.time.Instant instant11 = new org.joda.time.Instant((java.lang.Object) 20616626);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20630790 + "'", int2 == 20630790);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.monthOfYear();
//        org.joda.time.DateTime dateTime19 = property18.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime21 = dateTime19.plusMonths(20627783);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20630874 + "'", int8 == 20630874);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        try {
//            long long16 = julianChronology6.getDateTimeMillis(20618233, 20630131, 20613277, 20626212, 20621240, 20627549, 20614526);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20626212 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20631053 + "'", int2 == 20631053);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime.Property property6 = dateTime5.year();
//        long long7 = property6.remainder();
//        org.joda.time.DateTime dateTime8 = property6.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime10 = dateTime8.minusYears(20619914);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20631136 + "'", int2 == 20631136);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 14017431136L + "'", long7 == 14017431136L);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime1.withMinuteOfHour(20613759);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20613759 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20631348 + "'", int2 == 20631348);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
//        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
//        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
//        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
//        int int11 = delegatedDateTimeField8.get(0L);
//        long long14 = delegatedDateTimeField8.addWrapField((long) 20620809, 20617081);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) 100);
//        java.lang.String str20 = offsetDateTimeField18.getAsText((long) 20611972);
//        int int22 = offsetDateTimeField18.getMaximumValue((long) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField18);
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
//        int int26 = dateTime25.getMillisOfDay();
//        org.joda.time.DateTime.Property property27 = dateTime25.dayOfYear();
//        org.joda.time.DateTime.Property property28 = dateTime25.yearOfCentury();
//        java.lang.String str29 = property28.getAsText();
//        java.util.Locale locale31 = null;
//        org.joda.time.DateTime dateTime32 = property28.setCopy("19", locale31);
//        org.joda.time.TimeOfDay timeOfDay33 = dateTime32.toTimeOfDay();
//        int[] intArray37 = new int[] { 10, 10, 20612731 };
//        int int38 = delegatedDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay33, intArray37);
//        int[] intArray45 = new int[] { 20615007, 20622019, 20611566, 20622019, 20617900 };
//        try {
//            int[] intArray47 = delegatedDateTimeField8.addWrapField((org.joda.time.ReadablePartial) timeOfDay33, 20619772, intArray45, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20619772");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24220809L + "'", long14 == 24220809L);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "105" + "'", str20.equals("105"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 111 + "'", int22 == 111);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 20631432 + "'", int26 == 20631432);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "19" + "'", str29.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(timeOfDay33);
//        org.junit.Assert.assertNotNull(intArray37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
//        org.junit.Assert.assertNotNull(intArray45);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        java.lang.String str5 = property4.getAsText();
//        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime6.isSupported(dateTimeFieldType7);
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime6.withDayOfMonth(20624780);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20624780 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20631479 + "'", int2 == 20631479);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.lang.String str2 = dateTimeFormatter0.print(20617610L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1969-12-31T21" + "'", str2.equals("1969-12-31T21"));
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        mutableDateTime8.add((long) 20612115);
//        mutableDateTime8.setMillisOfDay(20624132);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20631940 + "'", int2 == 20631940);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(20615162, 20617208, 20625575, 20626828, 20623562, 20620986, 20619570, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20626828 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone16.getShortName((long) 20612357, locale19);
//        java.lang.String str22 = dateTimeZone16.getName(0L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20632377 + "'", int8 == 20632377);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 163 + "'", int10 == 163);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pacific Standard Time" + "'", str22.equals("Pacific Standard Time"));
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
        long long11 = delegatedDateTimeField8.roundCeiling((long) 20611566);
        try {
            long long14 = delegatedDateTimeField8.set((long) 20615162, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 21600000L + "'", long11 == 21600000L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getMillisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
//        int int6 = dateTime3.getDayOfYear();
//        java.lang.String str7 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear(0);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20633443 + "'", int4 == 20633443);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 163 + "'", int6 == 163);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5:43:53 AM PDT" + "'", str7.equals("5:43:53 AM PDT"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(20622019);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("20190529T224338-0700", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        long long4 = property3.remainder();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(100);
//        org.joda.time.DateTime dateTime7 = property3.getDateTime();
//        int int8 = dateTime7.getMinuteOfDay();
//        boolean boolean10 = dateTime7.isAfter((long) 20611610);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20633525 + "'", int2 == 20633525);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 20633525L + "'", long4 == 20633525L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 343 + "'", int8 == 343);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(20613150);
//        org.joda.time.DateTime.Property property8 = dateTime1.dayOfYear();
//        org.joda.time.Interval interval9 = property8.toInterval();
//        org.joda.time.DateTime dateTime10 = property8.roundHalfCeilingCopy();
//        java.lang.String str11 = property8.getName();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20633803 + "'", int2 == 20633803);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(interval9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "dayOfYear" + "'", str11.equals("dayOfYear"));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("America/Los_Angeles", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"America/Los_Angeles\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long4 = dateTimeZone0.convertLocalToUTC((long) 10, true, (long) 20611704);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        int int7 = dateTime6.getMillisOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime6.dayOfYear();
//        org.joda.time.DateTime.Property property9 = dateTime6.yearOfCentury();
//        org.joda.time.DateTime dateTime10 = dateTime6.toDateTimeISO();
//        org.joda.time.DateTime dateTime12 = dateTime6.minusMinutes(20613150);
//        org.joda.time.DateTime.Property property13 = dateTime6.dayOfYear();
//        int int14 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28800010L + "'", long4 == 28800010L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20633890 + "'", int7 == 20633890);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-25200000) + "'", int14 == (-25200000));
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int5 = offsetDateTimeField3.getMaximumValue(1L);
        java.lang.String str7 = offsetDateTimeField3.getAsShortText((long) 20628736);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 111 + "'", int5 == 111);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "105" + "'", str7.equals("105"));
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        long long4 = property3.remainder();
//        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(100);
//        org.joda.time.DateTime dateTime7 = property3.getDateTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
//        int int10 = dateTime9.getMillisOfDay();
//        org.joda.time.DateTime.Property property11 = dateTime9.dayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
//        org.joda.time.DateTime dateTime13 = dateTime9.toDateTimeISO();
//        org.joda.time.DateTime dateTime15 = dateTime9.minusMinutes(20613150);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime9.toDateTime(dateTimeZone16);
//        boolean boolean18 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.DateTime dateTime20 = dateTime17.minusMillis((int) 'a');
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20633997 + "'", int2 == 20633997);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 20633997L + "'", long4 == 20633997L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20633998 + "'", int10 == 20633998);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime5.add(readableDuration6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) (short) 0);
        boolean boolean11 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            mutableDateTime2.add(durationFieldType12, 20633747);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        int int4 = dateTime3.getMillisOfDay();
//        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
//        org.joda.time.DateTime.Property property6 = dateTime3.yearOfCentury();
//        java.lang.String str7 = property6.getAsText();
//        java.util.Locale locale9 = null;
//        org.joda.time.DateTime dateTime10 = property6.setCopy("19", locale9);
//        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
//        long long13 = julianChronology0.set((org.joda.time.ReadablePartial) localDateTime11, 0L);
//        org.joda.time.DateTimeField dateTimeField14 = null;
//        try {
//            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20634096 + "'", int4 == 20634096);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "19" + "'", str7.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(localDateTime11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561441434096L + "'", long13 == 1561441434096L);
//    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfDay();
//        org.joda.time.DateTime dateTime8 = dateTime1.minusMinutes(20618096);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (short) -1);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime10.minus(readablePeriod11);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
//        org.joda.time.DateTime dateTime16 = dateTime12.withDurationAdded((long) 20633928, 20624252);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20634176 + "'", int2 == 20634176);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant10 = instant9.toInstant();
        boolean boolean11 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) instant9);
        org.joda.time.MutableDateTime mutableDateTime12 = instant9.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.millisOfSecond();
        java.util.Locale locale15 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime16 = property13.set("2019-06-12T05:43:48.346-07:00", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T05:43:48.346-07:00\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getLeapAmount(56613274L);
        long long10 = offsetDateTimeField3.addWrapField(1L, 20614526);
        boolean boolean12 = offsetDateTimeField3.isLeap(20622225L);
        int int14 = offsetDateTimeField3.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7200001L + "'", long10 == 7200001L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.longDateTime();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = julianChronology5.centuries();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) julianChronology5);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology5);
//        int int9 = property3.compareTo((org.joda.time.ReadableInstant) dateTime8);
//        java.lang.String str10 = dateTime8.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20634505 + "'", int2 == 20634505);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-05-30T12:43:54.506Z" + "'", str10.equals("2019-05-30T12:43:54.506Z"));
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        java.lang.String str5 = property4.getAsText();
//        java.util.Locale locale7 = null;
//        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
//        java.util.Locale locale10 = null;
//        try {
//            org.joda.time.DateTime dateTime11 = property4.setCopy("10:43:38 PM PDT", locale10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"10:43:38 PM PDT\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20634572 + "'", int2 == 20634572);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19" + "'", str5.equals("19"));
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(20613150);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime1.toDateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfDay((int) (short) 100);
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime1.withCenturyOfEra(20625169);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20625169 for centuryOfEra must be in the range [0,2922789]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20634583 + "'", int2 == 20634583);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        int int2 = dateTime1.getMillisOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
//        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField11 = julianChronology9.clockhourOfHalfday();
//        int int12 = mutableDateTime8.get(dateTimeField11);
//        try {
//            mutableDateTime8.setDateTime(12, 20623511, 20615085, 20624298, 20622228, 20611566, 20613277);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20624298 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20634797 + "'", int2 == 20634797);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        long long11 = property10.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.clockhourOfHalfday();
//        boolean boolean15 = property10.equals((java.lang.Object) julianChronology12);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(20615225, 0, 20630131, 20612731, 3, 20617342, 20630874, (org.joda.time.Chronology) julianChronology12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20612731 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 20635195 + "'", int9 == 20635195);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 20635195L + "'", long11 == 20635195L);
//        org.junit.Assert.assertNotNull(julianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        try {
            long long7 = julianChronology0.getDateTimeMillis(20630459, 20614882, 20613726, 43);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20614882 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("70");
        try {
            mutableDateTime1.setDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 20629522);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 20613353);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        mutableDateTime1.setZoneRetainFields(dateTimeZone2);
        int int4 = mutableDateTime1.getYearOfEra();
        mutableDateTime1.addYears(20611457);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1969 + "'", int4 == 1969);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int5 = offsetDateTimeField3.getMaximumValue(1L);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        java.lang.String str13 = property12.getAsText();
        java.util.Locale locale15 = null;
        org.joda.time.DateTime dateTime16 = property12.setCopy("19", locale15);
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        long long19 = julianChronology6.set((org.joda.time.ReadablePartial) localDateTime17, 0L);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) 100);
        java.lang.String str26 = offsetDateTimeField24.getAsText((long) 20611972);
        int int28 = offsetDateTimeField24.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField24);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        int int32 = dateTime31.getMillisOfDay();
        org.joda.time.DateTime.Property property33 = dateTime31.dayOfYear();
        org.joda.time.DateTime.Property property34 = dateTime31.yearOfCentury();
        java.lang.String str35 = property34.getAsText();
        java.util.Locale locale37 = null;
        org.joda.time.DateTime dateTime38 = property34.setCopy("19", locale37);
        org.joda.time.TimeOfDay timeOfDay39 = dateTime38.toTimeOfDay();
        int[] intArray43 = new int[] { 10, 10, 20612731 };
        int int44 = delegatedDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay39, intArray43);
        try {
            int[] intArray46 = offsetDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDateTime17, (int) (short) 100, intArray43, 20632509);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 111 + "'", int5 == 111);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 78229522 + "'", int10 == 78229522);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "69" + "'", str13.equals("69"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1576808170478L) + "'", long19 == (-1576808170478L));
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "105" + "'", str26.equals("105"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 111 + "'", int28 == 111);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 78229522 + "'", int32 == 78229522);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "69" + "'", str35.equals("69"));
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(timeOfDay39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("12:00:00 AM PST", (java.lang.Number) 20612731L, (java.lang.Number) 20620986, (java.lang.Number) 0.0d);
        java.lang.String str5 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 20612731 for 12:00:00 AM PST must be in the range [20620986,0.0]" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value 20612731 for 12:00:00 AM PST must be in the range [20620986,0.0]"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(20625487, 20622516, 43, 20627549, 20613726, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20627549 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.DurationField durationField2 = julianChronology0.days();
        org.joda.time.DurationField durationField3 = julianChronology0.months();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = iSOChronology3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[-00:01]" + "'", str4.equals("ISOChronology[-00:01]"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply(20626210, 20629172);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: 20626210 * 20629172");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsText(20631384, locale25);
        try {
            long long29 = delegatedDateTimeField8.set((long) 20625212, 20628346);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20628346 for hourOfHalfday must be in the range [100,111]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20631384" + "'", str26.equals("20631384"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
        java.lang.String str27 = delegatedDateTimeField8.getName();
        int int28 = delegatedDateTimeField8.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hourOfHalfday" + "'", str27.equals("hourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 111 + "'", int28 == 111);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        int int10 = dateTime7.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        mutableDateTime2.setZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withDefaultYear(10);
        java.lang.String str19 = mutableDateTime2.toString(dateTimeFormatter16);
        long long20 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "19691219T134349-0800" + "'", str19.equals("19691219T134349-0800"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 78229522L + "'", long20 == 78229522L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int4 = offsetDateTimeField3.getMinimumValue();
        long long6 = offsetDateTimeField3.roundHalfEven((long) (short) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getLeapDurationField();
        boolean boolean9 = offsetDateTimeField3.isLeap((long) 20612357);
        int int10 = offsetDateTimeField3.getMaximumValue();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsShortText((long) 20617208, locale12);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 111 + "'", int10 == 111);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "105" + "'", str13.equals("105"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant10 = instant9.toInstant();
        boolean boolean11 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) instant9);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant13 = instant9.plus(readableDuration12);
        org.joda.time.Instant instant15 = instant9.minus(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            int int17 = instant9.get(dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant15);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        long long5 = property4.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
//        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
//        org.joda.time.DurationField durationField10 = julianChronology6.days();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
//        mutableDateTime15.setTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = gregorianChronology27.centuries();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime30 = dateTime20.toDateTime(dateTimeZone29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone29.getShortName((long) 20612357, locale32);
//        dateTimeParserBucket12.setZone(dateTimeZone29);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 78229522L + "'", long5 == 78229522L);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78229522 + "'", int21 == 78229522);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(20627316, 20613660, 0, 52, 20628402, 20619972, 20628736);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(20622019);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("4:00:00 PM PST", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (long) 20629674, 20622853);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20622853");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        int int4 = dateTime3.getMillisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.dayOfYear();
        org.joda.time.DateTime.Property property6 = dateTime3.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime7.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime7.minusYears(1970);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 78229522 + "'", int4 == 78229522);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        int int10 = dateTime7.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            int int20 = dateTime18.get(dateTimeFieldType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("20190529T224350-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        int int21 = dateTime18.getDayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
        mutableDateTime8.addMonths(20626068);
        int int32 = mutableDateTime8.getYearOfEra();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1720808 + "'", int32 == 1720808);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("12:00:00 AM PST", (java.lang.Number) 20612731L, (java.lang.Number) 20620986, (java.lang.Number) 0.0d);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("12:00:00 AM PST", (java.lang.Number) 20612731L, (java.lang.Number) 20620986, (java.lang.Number) 0.0d);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12:00:00 AM PST" + "'", str5.equals("12:00:00 AM PST"));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("GregorianChronology[America/Los_Angeles]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GregorianChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(20624298, 20617366, 20634347);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20624298 + "'", int3 == 20624298);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.Chronology chronology5 = iSOChronology3.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = instant1.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(20626337, 20620809, 0, 20616495, (int) ' ', 20620350, 343);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20616495 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        long long8 = dateTimeZone4.convertLocalToUTC((long) (-1), false, (long) 20613900);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.Chronology chronology10 = gregorianChronology0.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMillis(20631940);
        org.joda.time.DateTime.Property property11 = dateTime8.year();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsShortText(locale4);
        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
        org.joda.time.DurationField durationField7 = property3.getLeapDurationField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "365" + "'", str5.equals("365"));
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNull(durationField7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsText(20631384, locale25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField28 = gregorianChronology27.centuries();
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
        int int33 = dateTime32.getMillisOfDay();
        org.joda.time.DateTime.Property property34 = dateTime32.dayOfYear();
        org.joda.time.DateTime.Property property35 = dateTime32.yearOfCentury();
        java.lang.String str36 = property35.getAsText();
        java.util.Locale locale38 = null;
        org.joda.time.DateTime dateTime39 = property35.setCopy("19", locale38);
        org.joda.time.TimeOfDay timeOfDay40 = dateTime39.toTimeOfDay();
        int[] intArray42 = gregorianChronology27.get((org.joda.time.ReadablePartial) timeOfDay40, (-1781245534581794L));
        int[] intArray48 = new int[] { 20634176, 20632316, 20634244, 20633998 };
        java.util.Locale locale50 = null;
        try {
            int[] intArray51 = delegatedDateTimeField8.set((org.joda.time.ReadablePartial) timeOfDay40, 0, intArray48, "org.joda.time.IllegalFieldValueException: Value 20612731 for 12:00:00 AM PST must be in the range [20620986,0.0]", locale50);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value 20612731 for 12:00:00 AM PST must be in the range [20620986,0.0]\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20631384" + "'", str26.equals("20631384"));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 78229522 + "'", int33 == 78229522);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "69" + "'", str36.equals("69"));
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(timeOfDay40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(20634505, 20632559, 20633073);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20632960 + "'", int3 == 20632960);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        java.lang.String str8 = jodaTimePermission6.toString();
        java.lang.String str9 = jodaTimePermission6.getActions();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"20190529T224336-0700\")" + "'", str8.equals("(\"org.joda.time.JodaTimePermission\" \"20190529T224336-0700\")"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField11 = gregorianChronology10.centuries();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateMidnight9.toDateTime(dateTimeZone12);
        java.lang.String str14 = dateTimeZone12.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime5.add(readableDuration6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) (short) 0);
        boolean boolean11 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        try {
            mutableDateTime10.setYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.clockhourOfHalfday();
        boolean boolean8 = property3.equals((java.lang.Object) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology5.centuryOfEra();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField4 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.clockhourOfHalfday();
        org.joda.time.Chronology chronology6 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.util.Locale locale5 = null;
        java.lang.String str6 = offsetDateTimeField3.getAsText(163, locale5);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        int int9 = dateTime8.getMillisOfDay();
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
        long long11 = property10.remainder();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.clockhourOfHalfday();
        boolean boolean15 = property10.equals((java.lang.Object) julianChronology12);
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        org.joda.time.DateTime.Property property21 = dateTime18.yearOfCentury();
        java.lang.String str22 = property21.getAsText();
        java.util.Locale locale24 = null;
        org.joda.time.DateTime dateTime25 = property21.setCopy("19", locale24);
        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
        boolean boolean27 = dateTimeZone16.isLocalDateTimeGap(localDateTime26);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField30 = gregorianChronology29.centuries();
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology29.getZone();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology29.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
        int int35 = dateTime34.getMillisOfDay();
        org.joda.time.DateTime.Property property36 = dateTime34.dayOfYear();
        org.joda.time.DateTime.Property property37 = dateTime34.yearOfCentury();
        java.lang.String str38 = property37.getAsText();
        java.util.Locale locale40 = null;
        org.joda.time.DateTime dateTime41 = property37.setCopy("19", locale40);
        org.joda.time.TimeOfDay timeOfDay42 = dateTime41.toTimeOfDay();
        int[] intArray44 = gregorianChronology29.get((org.joda.time.ReadablePartial) timeOfDay42, (-1781245534581794L));
        try {
            int[] intArray46 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDateTime26, 20612357, intArray44, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for hourOfHalfday must be in the range [100,111]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "163" + "'", str6.equals("163"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78229522 + "'", int9 == 78229522);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 78229522L + "'", long11 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "69" + "'", str22.equals("69"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 78229522 + "'", int35 == 78229522);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "69" + "'", str38.equals("69"));
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(timeOfDay42);
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1781245534581794L), 20619772);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -1781245534581794 * 20619772");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        long long5 = property4.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
//        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
//        org.joda.time.DurationField durationField10 = julianChronology6.days();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
//        mutableDateTime15.setTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = gregorianChronology27.centuries();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime30 = dateTime20.toDateTime(dateTimeZone29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone29.getShortName((long) 20612357, locale32);
//        dateTimeParserBucket12.setZone(dateTimeZone29);
//        long long35 = dateTimeParserBucket12.computeMillis();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 78229522L + "'", long5 == 78229522L);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78229522 + "'", int21 == 78229522);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28800100L + "'", long35 == 28800100L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfYear();
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime8.add(readableDuration10);
        int int12 = mutableDateTime8.getCenturyOfEra();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 20 + "'", int12 == 20);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(20623616, 20620583, (int) (short) 100, 1969, 20624298, 20626828);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
        long long5 = property4.remainder();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
        org.joda.time.DurationField durationField10 = julianChronology6.days();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
        java.lang.Integer int13 = dateTimeParserBucket12.getOffsetInteger();
        java.lang.Object obj14 = dateTimeParserBucket12.saveState();
        org.joda.time.DateTimeField dateTimeField15 = null;
        dateTimeParserBucket12.saveField(dateTimeField15, 43);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 78229522L + "'", long5 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNull(int13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getRoundingMode();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        mutableDateTime0.add(readablePeriod2);
        int int4 = mutableDateTime0.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        int int10 = dateTime7.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
        org.joda.time.DateTime.Property property18 = dateTime17.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            org.joda.time.DateTime dateTime21 = dateTime17.withField(dateTimeFieldType19, 20632827);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.weekyear();
        org.joda.time.DurationField durationField4 = julianChronology0.years();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        boolean boolean3 = dateTime1.isAfterNow();
        try {
            org.joda.time.DateTime dateTime5 = dateTime1.withEra(20629522);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20629522 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField11 = gregorianChronology10.centuries();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateMidnight9.toDateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime13.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property15 = dateTime13.hourOfDay();
        org.joda.time.DateTime dateTime16 = property15.roundHalfCeilingCopy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        int int21 = dateTime18.getDayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime8.weekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        try {
            org.joda.time.MutableDateTime.Property property32 = mutableDateTime8.property(dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property30);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("70");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 20612115);
        org.joda.time.DateTime dateTime8 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTimeField dateTimeField9 = null;
        try {
            int int10 = dateTime8.get(dateTimeField9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(20613150);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.toDateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime1.withMillisOfDay((int) (short) 100);
        try {
            org.joda.time.DateTime dateTime16 = dateTime11.withTime(20620313, 20618206, (-25200000), 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20620313 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
        java.lang.String str27 = delegatedDateTimeField8.getName();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
        int int30 = dateTime29.getMillisOfDay();
        org.joda.time.DateTime.Property property31 = dateTime29.dayOfYear();
        long long32 = property31.remainder();
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology33.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology33.clockhourOfHalfday();
        boolean boolean36 = property31.equals((java.lang.Object) julianChronology33);
        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology33.getZone();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
        int int40 = dateTime39.getMillisOfDay();
        org.joda.time.DateTime.Property property41 = dateTime39.dayOfYear();
        org.joda.time.DateTime.Property property42 = dateTime39.yearOfCentury();
        java.lang.String str43 = property42.getAsText();
        java.util.Locale locale45 = null;
        org.joda.time.DateTime dateTime46 = property42.setCopy("19", locale45);
        org.joda.time.LocalDateTime localDateTime47 = dateTime46.toLocalDateTime();
        boolean boolean48 = dateTimeZone37.isLocalDateTimeGap(localDateTime47);
        boolean boolean49 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime47);
        int[] intArray55 = new int[] { 20629029, 2061577500, 20629674, 20631689 };
        try {
            int[] intArray57 = delegatedDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDateTime47, 20614278, intArray55, 20633747);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20614278");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hourOfHalfday" + "'", str27.equals("hourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 78229522 + "'", int30 == 78229522);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 78229522L + "'", long32 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 78229522 + "'", int40 == 78229522);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "69" + "'", str43.equals("69"));
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(localDateTime47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(intArray55);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField3, 20612731);
        org.joda.time.DurationField durationField6 = skipDateTimeField5.getRangeDurationField();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) 100);
        java.lang.String str12 = offsetDateTimeField10.getAsText((long) 20611972);
        long long15 = offsetDateTimeField10.add((long) (byte) 100, 24);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        int int18 = dateTime17.getMillisOfDay();
        org.joda.time.DateTime.Property property19 = dateTime17.dayOfYear();
        org.joda.time.DateTime.Property property20 = dateTime17.yearOfCentury();
        java.lang.String str21 = property20.getAsText();
        java.util.Locale locale23 = null;
        org.joda.time.DateTime dateTime24 = property20.setCopy("19", locale23);
        org.joda.time.TimeOfDay timeOfDay25 = dateTime24.toTimeOfDay();
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) timeOfDay25, 20617081, locale27);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 100);
        java.lang.String str35 = offsetDateTimeField33.getAsText((long) 20611972);
        int int37 = offsetDateTimeField33.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField33);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
        int int41 = dateTime40.getMillisOfDay();
        org.joda.time.DateTime.Property property42 = dateTime40.dayOfYear();
        org.joda.time.DateTime.Property property43 = dateTime40.yearOfCentury();
        java.lang.String str44 = property43.getAsText();
        java.util.Locale locale46 = null;
        org.joda.time.DateTime dateTime47 = property43.setCopy("19", locale46);
        org.joda.time.TimeOfDay timeOfDay48 = dateTime47.toTimeOfDay();
        int[] intArray52 = new int[] { 10, 10, 20612731 };
        int int53 = delegatedDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay48, intArray52);
        try {
            int[] intArray55 = skipDateTimeField5.addWrapField((org.joda.time.ReadablePartial) timeOfDay25, 20622056, intArray52, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20622056");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "105" + "'", str12.equals("105"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 86400100L + "'", long15 == 86400100L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 78229522 + "'", int18 == 78229522);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "69" + "'", str21.equals("69"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(timeOfDay25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "20617081" + "'", str28.equals("20617081"));
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "105" + "'", str35.equals("105"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 111 + "'", int37 == 111);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 78229522 + "'", int41 == 78229522);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "69" + "'", str44.equals("69"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(timeOfDay48);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 100 + "'", int53 == 100);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        int int9 = offsetDateTimeField3.getMaximumValue();
        long long11 = offsetDateTimeField3.roundCeiling((long) 20622827);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 111 + "'", int9 == 111);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 21600000L + "'", long11 == 21600000L);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        long long5 = property4.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
//        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
//        org.joda.time.DurationField durationField10 = julianChronology6.days();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
//        mutableDateTime15.setTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = gregorianChronology27.centuries();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime30 = dateTime20.toDateTime(dateTimeZone29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone29.getShortName((long) 20612357, locale32);
//        dateTimeParserBucket12.setZone(dateTimeZone29);
//        int int36 = dateTimeZone29.getOffsetFromLocal((long) 66436);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 78229522L + "'", long5 == 78229522L);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78229522 + "'", int21 == 78229522);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField11 = gregorianChronology10.centuries();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        org.joda.time.DateTime dateTime13 = dateMidnight9.toDateTime(dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime14 = dateMidnight9.toMutableDateTime();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 20621724);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1570850193600000L + "'", long1 == 1570850193600000L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property4.getAsShortText(locale6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "69" + "'", str7.equals("69"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        int int10 = dateTime7.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        mutableDateTime2.setZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withDefaultYear(10);
        java.lang.String str19 = mutableDateTime2.toString(dateTimeFormatter16);
        java.lang.Object obj20 = mutableDateTime2.clone();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            mutableDateTime2.add(durationFieldType21, 20630105);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "19691219T134349-0800" + "'", str19.equals("19691219T134349-0800"));
        org.junit.Assert.assertNotNull(obj20);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        int int5 = dateTime2.getDayOfYear();
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear(0);
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
//        int int11 = mutableDateTime10.getRoundingMode();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        mutableDateTime10.add(readablePeriod12);
//        java.lang.String str14 = dateTimeFormatter7.print((org.joda.time.ReadableInstant) mutableDateTime10);
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter7.withLocale(locale15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9:43:49 PM PST" + "'", str6.equals("9:43:49 PM PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9:43:49 PM PST" + "'", str14.equals("9:43:49 PM PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        boolean boolean8 = property5.isLeap();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        mutableDateTime1.setZoneRetainFields(dateTimeZone2);
        try {
            mutableDateTime1.setTime(105, (int) (byte) 0, 45813, 20624655);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 105 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
        org.joda.time.DateTime dateTime10 = property4.addToCopy((long) 20627058);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(20622019);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover(20628474, ' ', 2, 20629607, 20628474, false, 20626210);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
        int int11 = delegatedDateTimeField8.get(0L);
        long long14 = delegatedDateTimeField8.addWrapField((long) 20620809, 20617081);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType15, 20633376);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24220809L + "'", long14 == 24220809L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
        java.lang.String str11 = property10.getAsText();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("19", locale13);
        org.joda.time.LocalDateTime localDateTime15 = dateTime14.toLocalDateTime();
        long long17 = julianChronology4.set((org.joda.time.ReadablePartial) localDateTime15, 0L);
        int[] intArray20 = new int[] { 20627598 };
        try {
            int[] intArray22 = offsetDateTimeField3.addWrapPartial((org.joda.time.ReadablePartial) localDateTime15, 20634960, intArray20, 20613353);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20634960");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1576808170478L) + "'", long17 == (-1576808170478L));
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField3, 20612731);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) 100);
        java.lang.String str13 = offsetDateTimeField11.getAsText((long) 20611972);
        int int15 = offsetDateTimeField11.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField11);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        int int22 = dateTime21.getMillisOfDay();
        org.joda.time.DateTime.Property property23 = dateTime21.dayOfYear();
        org.joda.time.DateTime.Property property24 = dateTime21.yearOfCentury();
        java.lang.String str25 = property24.getAsText();
        java.util.Locale locale27 = null;
        org.joda.time.DateTime dateTime28 = property24.setCopy("19", locale27);
        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
        int int30 = property19.compareTo((org.joda.time.ReadablePartial) localDateTime29);
        int[] intArray31 = new int[] {};
        int int32 = delegatedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDateTime29, intArray31);
        try {
            int[] intArray34 = skipDateTimeField5.addWrapPartial(readablePartial6, 20626828, intArray31, 20633747);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20626828");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "105" + "'", str13.equals("105"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 111 + "'", int15 == 111);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 78229522 + "'", int22 == 78229522);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "69" + "'", str25.equals("69"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
        int int27 = delegatedDateTimeField8.getMaximumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, dateTimeFieldType28, 20624503);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 111 + "'", int27 == 111);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone16.getShortName((long) 20612357, locale19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        boolean boolean23 = gJChronology21.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology21.getZone();
//        try {
//            long long29 = gJChronology21.getDateTimeMillis(0, 20620350, 20617610, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20620350 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = mutableDateTime8.getRoundingField();
        try {
            mutableDateTime8.setWeekOfWeekyear(20619772);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20619772 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNull(dateTimeField9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission3.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "20190529T224336-0700" + "'", str5.equals("20190529T224336-0700"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.months();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField3, 20612731);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 100);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 20611972);
        int int13 = offsetDateTimeField9.getMaximumValue((long) (short) 1);
        long long16 = offsetDateTimeField9.add((long) 20614325, (int) (byte) -1);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) (byte) 100);
        java.lang.String str22 = offsetDateTimeField20.getAsText((long) 20611972);
        int int24 = offsetDateTimeField20.getLeapAmount(56613274L);
        long long27 = offsetDateTimeField20.addWrapField(1L, 20614526);
        long long29 = offsetDateTimeField20.roundCeiling((long) 20634867);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 100);
        java.lang.String str35 = offsetDateTimeField33.getAsText((long) 20611972);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField33.getAsShortText((long) 20612393, locale37);
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = julianChronology39.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone41);
        int int43 = dateTime42.getMillisOfDay();
        org.joda.time.DateTime.Property property44 = dateTime42.dayOfYear();
        org.joda.time.DateTime.Property property45 = dateTime42.yearOfCentury();
        java.lang.String str46 = property45.getAsText();
        java.util.Locale locale48 = null;
        org.joda.time.DateTime dateTime49 = property45.setCopy("19", locale48);
        org.joda.time.LocalDateTime localDateTime50 = dateTime49.toLocalDateTime();
        long long52 = julianChronology39.set((org.joda.time.ReadablePartial) localDateTime50, 0L);
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) localDateTime50, 0, locale54);
        int int56 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDateTime50);
        int int57 = offsetDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) localDateTime50);
        int[] intArray63 = new int[] { (short) 0, 20621240, 20631069, 20630459 };
        try {
            int[] intArray65 = skipDateTimeField5.set((org.joda.time.ReadablePartial) localDateTime50, 20616031, intArray63, 20626151);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20626151 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "105" + "'", str11.equals("105"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 111 + "'", int13 == 111);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 17014325L + "'", long16 == 17014325L);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "105" + "'", str22.equals("105"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 7200001L + "'", long27 == 7200001L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 21600000L + "'", long29 == 21600000L);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "105" + "'", str35.equals("105"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "105" + "'", str38.equals("105"));
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 78229522 + "'", int43 == 78229522);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "69" + "'", str46.equals("69"));
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-1576808170478L) + "'", long52 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 111 + "'", int56 == 111);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 111 + "'", int57 == 111);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
        java.lang.String str27 = delegatedDateTimeField8.getName();
        java.lang.String str29 = delegatedDateTimeField8.getAsShortText((long) 20630581);
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField8.getAsShortText((long) 20628759, locale31);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hourOfHalfday" + "'", str27.equals("hourOfHalfday"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "105" + "'", str29.equals("105"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "105" + "'", str32.equals("105"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = iSOChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean9 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission8);
        boolean boolean10 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 105, (long) 20632827);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-20632722L) + "'", long2 == (-20632722L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
        org.joda.time.DateMidnight dateMidnight9 = dateTime8.toDateMidnight();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withField(dateTimeFieldType10, 20624132);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
        int int27 = delegatedDateTimeField8.getMaximumValue();
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField8.getAsShortText((long) 20626614, locale29);
        java.util.Locale locale31 = null;
        int int32 = delegatedDateTimeField8.getMaximumTextLength(locale31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = delegatedDateTimeField8.getAsText(0L, locale34);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 111 + "'", int27 == 111);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "105" + "'", str30.equals("105"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        java.lang.String str4 = dateTimeZone3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField3 = julianChronology0.hours();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology4.getZone();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) julianChronology0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
        mutableDateTime6.setTime((long) 20621099);
        int int9 = mutableDateTime6.getRoundingMode();
        mutableDateTime6.addDays(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField3 = julianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField5 = julianChronology0.millis();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(45814);
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) 20623153, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfDay();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 20631384, (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) 20634347);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField4 = julianChronology0.months();
        org.joda.time.DurationField durationField5 = julianChronology0.millis();
        try {
            long long10 = julianChronology0.getDateTimeMillis(20626658, 20633377, 8, 20627112);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20633377 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundHalfCeiling();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.weekyear();
        try {
            mutableDateTime6.setTime(20616626, 8, 20620191, 20615225);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20616626 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        boolean boolean6 = property4.isLeap();
        org.joda.time.DateTime dateTime7 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withMonthOfYear((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        int int2 = mutableDateTime1.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.secondOfMinute();
        int int4 = property3.get();
        boolean boolean5 = property3.isLeap();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
        java.lang.String str11 = property10.getAsText();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("19", locale13);
        org.joda.time.LocalDateTime localDateTime15 = dateTime14.toLocalDateTime();
        int int16 = property3.compareTo((org.joda.time.ReadablePartial) localDateTime15);
        long long17 = property3.remainder();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 49 + "'", int4 == 49);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 522L + "'", long17 == 522L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(20622019);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("5:43:38 AM PDT", 0, 20615775, 20634244, '4', 2000, 20634596, 0, false, 20635292);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) 20618206, dateTimeZone4);
        try {
            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (long) 20618237, 20631023);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20631023");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        long long5 = property4.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
//        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
//        org.joda.time.DurationField durationField10 = julianChronology6.days();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
//        mutableDateTime15.setTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = gregorianChronology27.centuries();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime30 = dateTime20.toDateTime(dateTimeZone29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone29.getShortName((long) 20612357, locale32);
//        dateTimeParserBucket12.setZone(dateTimeZone29);
//        dateTimeParserBucket12.setOffset((java.lang.Integer) 20616268);
//        int int37 = dateTimeParserBucket12.getOffset();
//        java.lang.Integer int38 = dateTimeParserBucket12.getOffsetInteger();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 78229522L + "'", long5 == 78229522L);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78229522 + "'", int21 == 78229522);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 20616268 + "'", int37 == 20616268);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 20616268 + "'", int38.equals(20616268));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        int int10 = dateTime7.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        mutableDateTime2.setZone(dateTimeZone14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withDefaultYear(10);
        java.lang.String str19 = mutableDateTime2.toString(dateTimeFormatter16);
        java.lang.Object obj20 = mutableDateTime2.clone();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            org.joda.time.MutableDateTime.Property property22 = mutableDateTime2.property(dateTimeFieldType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "19691219T134349-0800" + "'", str19.equals("19691219T134349-0800"));
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("JulianChronology[America/Los_Angeles]", (java.lang.Number) 20614204, (java.lang.Number) 20626933, (java.lang.Number) 20631977);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
        int int11 = delegatedDateTimeField8.get(0L);
        long long14 = delegatedDateTimeField8.addWrapField((long) 20620809, 20617081);
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField8.getAsText((long) 20631980, locale16);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24220809L + "'", long14 == 24220809L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "105" + "'", str17.equals("105"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField4 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.halfdayOfDay();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) julianChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        int int21 = dateTime18.getDayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.yearOfEra();
        mutableDateTime29.addMillis(20623870);
        int int33 = mutableDateTime29.getHourOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        int int6 = dateTime5.getWeekOfWeekyear();
        boolean boolean7 = dateTime5.isAfterNow();
        org.joda.time.DateTime.Property property8 = dateTime5.monthOfYear();
        org.joda.time.DateTime dateTime10 = dateTime5.withWeekyear(20616626);
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfCentury(0);
        org.joda.time.DateTime dateTime14 = dateTime10.plusYears(20620809);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        int int21 = dateTime18.getDayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
        mutableDateTime8.addMonths(20626068);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        int int34 = dateTime33.getMillisOfDay();
        org.joda.time.DateTime.Property property35 = dateTime33.dayOfYear();
        org.joda.time.DateTime.Property property36 = dateTime33.yearOfCentury();
        org.joda.time.DateTime dateTime37 = dateTime33.toDateTimeISO();
        org.joda.time.DateTime dateTime39 = dateTime37.minusYears((int) (byte) 10);
        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime39);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 78229522 + "'", int34 == 78229522);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        java.util.Locale locale7 = null;
        org.joda.time.DateTime dateTime8 = property4.setCopy("19", locale7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMillis(20631940);
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone16.getShortName((long) 20612357, locale19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        boolean boolean23 = gJChronology21.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DurationField durationField24 = gJChronology21.months();
//        int int25 = gJChronology21.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField26 = gJChronology21.hours();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology21.yearOfEra();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100L, (java.lang.Number) 44, (java.lang.Number) 20612578);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant10 = instant9.toInstant();
        boolean boolean11 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) instant9);
        mutableDateTime7.addMonths((int) (short) 1);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime7.weekOfWeekyear();
        mutableDateTime7.setTime((long) 20620121);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("20190529T224336-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str5 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long4 = dateTimeZone0.convertLocalToUTC((long) (-1), false, (long) 20613900);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        try {
            long long14 = julianChronology6.getDateTimeMillis(20623758, 20634867, 20623153, 20617122, 0, 20627314, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20617122 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
        org.junit.Assert.assertNotNull(julianChronology6);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime7 = property3.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime dateTime15 = dateTime9.minusMinutes(20613150);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime9.toDateTime(dateTimeZone16);
        boolean boolean18 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime19 = dateTime17.toDateTimeISO();
        org.joda.time.DateTime dateTime21 = dateTime17.plusWeeks(20632559);
        try {
            org.joda.time.DateTime dateTime23 = dateTime17.withSecondOfMinute(20611758);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20611758 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 78229522 + "'", int10 == 78229522);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        int int4 = dateTime1.getDayOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime1.minusMinutes(20618096);
        boolean boolean10 = dateTime1.isAfter((long) 20612259);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int4 = offsetDateTimeField3.getMinimumValue();
        long long6 = offsetDateTimeField3.roundHalfEven((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMaximumValue(readablePartial7);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField(chronology9, dateTimeField12, 20612731);
        org.joda.time.DurationField durationField15 = skipDateTimeField14.getRangeDurationField();
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) 100);
        int int20 = offsetDateTimeField19.getMinimumValue();
        long long22 = offsetDateTimeField19.roundHalfEven((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField19.getMaximumValue(readablePartial23);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology28.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        int int32 = dateTime31.getMillisOfDay();
        org.joda.time.DateTime.Property property33 = dateTime31.dayOfYear();
        org.joda.time.DateTime.Property property34 = dateTime31.yearOfCentury();
        java.lang.String str35 = property34.getAsText();
        java.util.Locale locale37 = null;
        org.joda.time.DateTime dateTime38 = property34.setCopy("19", locale37);
        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
        long long41 = julianChronology28.set((org.joda.time.ReadablePartial) localDateTime39, 0L);
        java.util.Locale locale42 = null;
        java.lang.String str43 = delegatedDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) localDateTime39, locale42);
        java.util.Locale locale45 = null;
        java.lang.String str46 = offsetDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) localDateTime39, 20624780, locale45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDateTime39, locale47);
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = julianChronology50.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) (byte) 100);
        java.lang.String str55 = offsetDateTimeField53.getAsText((long) 20611972);
        int int57 = offsetDateTimeField53.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField53);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(dateTimeZone59);
        int int61 = dateTime60.getMillisOfDay();
        org.joda.time.DateTime.Property property62 = dateTime60.dayOfYear();
        org.joda.time.DateTime.Property property63 = dateTime60.yearOfCentury();
        java.lang.String str64 = property63.getAsText();
        java.util.Locale locale66 = null;
        org.joda.time.DateTime dateTime67 = property63.setCopy("19", locale66);
        org.joda.time.TimeOfDay timeOfDay68 = dateTime67.toTimeOfDay();
        int[] intArray72 = new int[] { 10, 10, 20612731 };
        int int73 = delegatedDateTimeField58.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay68, intArray72);
        java.util.Locale locale75 = null;
        try {
            int[] intArray76 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDateTime39, 20614204, intArray72, "0", locale75);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for hourOfHalfday must be in the range [100,111]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 111 + "'", int8 == 111);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 111 + "'", int24 == 111);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 78229522 + "'", int32 == 78229522);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "69" + "'", str35.equals("69"));
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(localDateTime39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1576808170478L) + "'", long41 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "9" + "'", str43.equals("9"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "20624780" + "'", str46.equals("20624780"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "522" + "'", str48.equals("522"));
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "105" + "'", str55.equals("105"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 111 + "'", int57 == 111);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 78229522 + "'", int61 == 78229522);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "69" + "'", str64.equals("69"));
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(timeOfDay68);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 100 + "'", int73 == 100);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.minus(readableDuration7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 20619814);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
        int int11 = delegatedDateTimeField8.get(0L);
        long long14 = delegatedDateTimeField8.addWrapField((long) 20620809, 20617081);
        long long16 = delegatedDateTimeField8.roundHalfEven((long) 20615775);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField8.getAsShortText(20627058, locale18);
        java.util.Locale locale21 = null;
        java.lang.String str22 = delegatedDateTimeField8.getAsText((long) 20627316, locale21);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24220809L + "'", long14 == 24220809L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 21600000L + "'", long16 == 21600000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20627058" + "'", str19.equals("20627058"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "105" + "'", str22.equals("105"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology5 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.halfdayOfDay();
        try {
            long long14 = gregorianChronology2.getDateTimeMillis(0, (int) (byte) 1, 20619592, 20628801, 20629197, 24, 20615225);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20628801 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant10 = instant9.toInstant();
        boolean boolean11 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) instant9);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant13 = instant9.plus(readableDuration12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Instant instant15 = instant13.minus(readableDuration14);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant15);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        int int21 = dateTime18.getDayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime8.weekyear();
        java.lang.String str31 = mutableDateTime8.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969-12-19T11:27:21.637Z" + "'", str31.equals("1969-12-19T11:27:21.637Z"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getRoundingMode();
        mutableDateTime0.addMonths(20612393);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 54205358042629522L + "'", long5 == 54205358042629522L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 20613353);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime7.add(readableDuration8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime7);
        int int11 = gJChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.weekOfWeekyear();
        try {
            long long20 = gJChronology10.getDateTimeMillis(20626658, 20626334, 20623153, 20623758, 20634505, 20633998, 78229522);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20623758 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        int int4 = dateTime1.getDayOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime6 = property5.roundHalfEvenCopy();
        int int7 = property5.getLeapAmount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.centuries();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) julianChronology1);
        org.joda.time.LocalTime localTime5 = dateTime4.toLocalTime();
        org.joda.time.DateTime dateTime7 = dateTime4.minusWeeks(20611972);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int4 = offsetDateTimeField3.getMinimumValue();
        long long6 = offsetDateTimeField3.roundHalfEven((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMaximumValue(readablePartial7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((long) 20616495, locale10);
        java.lang.String str12 = offsetDateTimeField3.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 111 + "'", int8 == 111);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "105" + "'", str11.equals("105"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hourOfHalfday" + "'", str12.equals("hourOfHalfday"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant10 = instant9.toInstant();
        boolean boolean11 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) instant9);
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime7.toMutableDateTime();
        boolean boolean13 = mutableDateTime12.isEqualNow();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        mutableDateTime2.addMonths(20612259);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (byte) -1);
        mutableDateTime2.setZone(dateTimeZone10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime2.minuteOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property12);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology7);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        mutableDateTime9.add(readableDuration10);
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime14.dayOfYear();
//        int int17 = dateTime14.getDayOfYear();
//        org.joda.time.DateTime.Property property18 = dateTime14.yearOfEra();
//        org.joda.time.DateTime.Property property19 = dateTime14.minuteOfDay();
//        mutableDateTime9.setTime((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField22 = gregorianChronology21.centuries();
//        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology21.getZone();
//        org.joda.time.DateTime dateTime24 = dateTime14.toDateTime(dateTimeZone23);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone23.getShortName((long) 20612357, locale26);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((int) (short) 10, 0, 20624298, 20631687, 20622225, 20628402, 0, (org.joda.time.Chronology) gJChronology28);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20631687 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 78229522 + "'", int15 == 78229522);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 365 + "'", int17 == 365);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PST" + "'", str27.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology28);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        int int21 = dateTime18.getDayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime31 = property30.roundHalfFloor();
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime34 = property32.add((long) 20626152);
        org.joda.time.DateTimeField dateTimeField35 = property32.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        mutableDateTime8.add(readableDuration9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        int int14 = dateTime13.getMillisOfDay();
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfYear();
        org.joda.time.DateTime.Property property16 = dateTime13.yearOfCentury();
        java.lang.String str17 = property16.getAsText();
        java.util.Locale locale19 = null;
        org.joda.time.DateTime dateTime20 = property16.setCopy("19", locale19);
        org.joda.time.DateMidnight dateMidnight21 = dateTime20.toDateMidnight();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField23 = gregorianChronology22.centuries();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
        org.joda.time.DateTime dateTime25 = dateMidnight21.toDateTime(dateTimeZone24);
        mutableDateTime8.setZoneRetainFields(dateTimeZone24);
        try {
            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((-28800000), 20611566, 20621362, 0, 20617303, 20622225, dateTimeZone24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20617303 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 78229522 + "'", int14 == 78229522);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "69" + "'", str17.equals("69"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(20617342);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (long) 20631384);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        long long11 = dateTimeZone7.convertLocalToUTC((long) (-1), false, (long) 20613900);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone7);
        java.lang.String str13 = dateTimeZone7.getID();
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(20628801, 10, (int) (byte) 10, 20619849, 20631069, 49, 20620553, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20619849 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(22, 100, 20617122, 20623248, 0, 20630105, 20627110);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20623248 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime7 = property3.roundHalfEvenCopy();
        long long8 = property3.remainder();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 78229522L + "'", long8 == 78229522L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int4 = offsetDateTimeField3.getMinimumValue();
        long long6 = offsetDateTimeField3.roundHalfEven((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(dateTimeZone7);
        int int9 = mutableDateTime8.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.secondOfMinute();
        int int11 = property10.get();
        boolean boolean12 = property10.isLeap();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        int int15 = dateTime14.getMillisOfDay();
        org.joda.time.DateTime.Property property16 = dateTime14.dayOfYear();
        org.joda.time.DateTime.Property property17 = dateTime14.yearOfCentury();
        java.lang.String str18 = property17.getAsText();
        java.util.Locale locale20 = null;
        org.joda.time.DateTime dateTime21 = property17.setCopy("19", locale20);
        org.joda.time.LocalDateTime localDateTime22 = dateTime21.toLocalDateTime();
        int int23 = property10.compareTo((org.joda.time.ReadablePartial) localDateTime22);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) 100);
        java.lang.String str30 = offsetDateTimeField28.getAsText((long) 20611972);
        int int32 = offsetDateTimeField28.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField28);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
        org.joda.time.DateTime.Property property36 = dateTime35.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(dateTimeZone37);
        int int39 = dateTime38.getMillisOfDay();
        org.joda.time.DateTime.Property property40 = dateTime38.dayOfYear();
        org.joda.time.DateTime.Property property41 = dateTime38.yearOfCentury();
        java.lang.String str42 = property41.getAsText();
        java.util.Locale locale44 = null;
        org.joda.time.DateTime dateTime45 = property41.setCopy("19", locale44);
        org.joda.time.LocalDateTime localDateTime46 = dateTime45.toLocalDateTime();
        int int47 = property36.compareTo((org.joda.time.ReadablePartial) localDateTime46);
        int[] intArray48 = new int[] {};
        int int49 = delegatedDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDateTime46, intArray48);
        try {
            int[] intArray51 = offsetDateTimeField3.addWrapField((org.joda.time.ReadablePartial) localDateTime22, 20626933, intArray48, 20626068);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20626933");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 49 + "'", int11 == 49);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 78229522 + "'", int15 == 78229522);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "69" + "'", str18.equals("69"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "105" + "'", str30.equals("105"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 111 + "'", int32 == 111);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 78229522 + "'", int39 == 78229522);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "69" + "'", str42.equals("69"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(localDateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField(chronology0, dateTimeField3, 20612731);
        org.joda.time.DurationField durationField6 = skipDateTimeField5.getRangeDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) 100);
        java.lang.String str13 = offsetDateTimeField11.getAsText((long) 20611972);
        long long16 = offsetDateTimeField11.add((long) (byte) 100, 24);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        org.joda.time.DateTime.Property property21 = dateTime18.yearOfCentury();
        java.lang.String str22 = property21.getAsText();
        java.util.Locale locale24 = null;
        org.joda.time.DateTime dateTime25 = property21.setCopy("19", locale24);
        org.joda.time.TimeOfDay timeOfDay26 = dateTime25.toTimeOfDay();
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) timeOfDay26, 20617081, locale28);
        java.lang.String str30 = dateTimeFormatter7.print((org.joda.time.ReadablePartial) timeOfDay26);
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) (byte) 100);
        java.lang.String str37 = offsetDateTimeField35.getAsText((long) 20611972);
        int int39 = offsetDateTimeField35.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField35);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone41);
        int int43 = dateTime42.getMillisOfDay();
        org.joda.time.DateTime.Property property44 = dateTime42.dayOfYear();
        org.joda.time.DateTime.Property property45 = dateTime42.yearOfCentury();
        java.lang.String str46 = property45.getAsText();
        java.util.Locale locale48 = null;
        org.joda.time.DateTime dateTime49 = property45.setCopy("19", locale48);
        org.joda.time.TimeOfDay timeOfDay50 = dateTime49.toTimeOfDay();
        int[] intArray54 = new int[] { 10, 10, 20612731 };
        int int55 = delegatedDateTimeField40.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay50, intArray54);
        try {
            int[] intArray57 = skipDateTimeField5.addWrapField((org.joda.time.ReadablePartial) timeOfDay26, 0, intArray54, (-271613210));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "105" + "'", str13.equals("105"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 86400100L + "'", long16 == 86400100L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "69" + "'", str22.equals("69"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(timeOfDay26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20617081" + "'", str29.equals("20617081"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "����-��" + "'", str30.equals("����-��"));
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "105" + "'", str37.equals("105"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 111 + "'", int39 == 111);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 78229522 + "'", int43 == 78229522);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "69" + "'", str46.equals("69"));
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(timeOfDay50);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 100 + "'", int55 == 100);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 20622019);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.era();
        mutableDateTime1.addYears(20621728);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.millisOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
        int int27 = delegatedDateTimeField8.getMaximumValue();
        java.lang.String str28 = delegatedDateTimeField8.getName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 100);
        java.lang.String str35 = offsetDateTimeField33.getAsText((long) 20611972);
        long long38 = offsetDateTimeField33.add((long) (byte) 100, 24);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
        int int41 = dateTime40.getMillisOfDay();
        org.joda.time.DateTime.Property property42 = dateTime40.dayOfYear();
        org.joda.time.DateTime.Property property43 = dateTime40.yearOfCentury();
        java.lang.String str44 = property43.getAsText();
        java.util.Locale locale46 = null;
        org.joda.time.DateTime dateTime47 = property43.setCopy("19", locale46);
        org.joda.time.TimeOfDay timeOfDay48 = dateTime47.toTimeOfDay();
        java.util.Locale locale50 = null;
        java.lang.String str51 = offsetDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) timeOfDay48, 20617081, locale50);
        java.lang.String str52 = dateTimeFormatter29.print((org.joda.time.ReadablePartial) timeOfDay48);
        java.util.Locale locale53 = null;
        try {
            java.lang.String str54 = delegatedDateTimeField8.getAsText((org.joda.time.ReadablePartial) timeOfDay48, locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 111 + "'", int27 == 111);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hourOfHalfday" + "'", str28.equals("hourOfHalfday"));
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "105" + "'", str35.equals("105"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 86400100L + "'", long38 == 86400100L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 78229522 + "'", int41 == 78229522);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "69" + "'", str44.equals("69"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(timeOfDay48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "20617081" + "'", str51.equals("20617081"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "����-��" + "'", str52.equals("����-��"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        mutableDateTime5.add(readableDuration6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.set((int) (short) 0);
        boolean boolean11 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) mutableDateTime10);
        mutableDateTime10.setWeekyear(20633842);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        int int5 = dateTime2.getDayOfYear();
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear(0);
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
//        int int11 = mutableDateTime10.getRoundingMode();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        mutableDateTime10.add(readablePeriod12);
//        java.lang.String str14 = dateTimeFormatter7.print((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.Chronology chronology15 = dateTimeFormatter7.getChronolgy();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9:43:49 PM PST" + "'", str6.equals("9:43:49 PM PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9:43:49 PM PST" + "'", str14.equals("9:43:49 PM PST"));
//        org.junit.Assert.assertNull(chronology15);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("163");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 163");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.clockhourOfHalfday();
        boolean boolean8 = property3.equals((java.lang.Object) julianChronology5);
        org.joda.time.DurationField durationField9 = julianChronology5.days();
        long long12 = durationField9.subtract((long) 20617122, 20619772);
        long long15 = durationField9.subtract((long) 20612578, 20617208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1781548280182878L) + "'", long12 == (-1781548280182878L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1781326750587422L) + "'", long15 == (-1781326750587422L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        int int4 = dateTime1.getDayOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime1.minusMinutes(20618096);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, 20612511);
        org.joda.time.DateTime dateTime15 = dateTime10.minusHours(0);
        try {
            org.joda.time.DateTime dateTime17 = dateTime10.withMillisOfSecond(20631558);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20631558 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.dayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.io.Writer writer2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readableInstant3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) 20622019);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.era();
        mutableDateTime1.addYears(20621728);
        int int5 = mutableDateTime1.getSecondOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 78222 + "'", int5 == 78222);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("20190529T224343-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.clockhourOfHalfday();
        boolean boolean8 = property3.equals((java.lang.Object) julianChronology5);
        org.joda.time.DurationField durationField9 = julianChronology5.days();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology5.dayOfYear();
        org.joda.time.DurationField durationField11 = julianChronology5.seconds();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
        int int11 = delegatedDateTimeField8.get(0L);
        try {
            long long14 = delegatedDateTimeField8.set(20617081L, 20614623);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20614623 for hourOfHalfday must be in the range [100,111]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 20613353);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology5);
        org.joda.time.ReadableDuration readableDuration8 = null;
        mutableDateTime7.add(readableDuration8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.hourOfDay();
        boolean boolean13 = gJChronology10.equals((java.lang.Object) 20626151);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        try {
            int[] intArray16 = gJChronology10.get(readablePeriod14, 20620121L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.DateTimeField dateTimeField11 = mutableDateTime8.getRoundingField();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime8.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        int int14 = mutableDateTime13.getRoundingMode();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        mutableDateTime13.add(readablePeriod15);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.millisOfSecond();
        org.joda.time.DurationField durationField20 = julianChronology17.seconds();
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology17.getZone();
        mutableDateTime13.setZoneRetainFields(dateTimeZone21);
        java.lang.String str23 = mutableDateTime13.toString();
        int int24 = property12.compareTo((org.joda.time.ReadableInstant) mutableDateTime13);
        mutableDateTime13.addWeekyears(20627024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNull(dateTimeField11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969-12-31T21:43:49.522Z" + "'", str23.equals("1969-12-31T21:43:49.522Z"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("10:43:50 PM PDT");
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        java.lang.Appendable appendable5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 100);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 20611972);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField9.getAsShortText((long) 20612393, locale13);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        org.joda.time.DateTime.Property property21 = dateTime18.yearOfCentury();
        java.lang.String str22 = property21.getAsText();
        java.util.Locale locale24 = null;
        org.joda.time.DateTime dateTime25 = property21.setCopy("19", locale24);
        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
        long long28 = julianChronology15.set((org.joda.time.ReadablePartial) localDateTime26, 0L);
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) localDateTime26, 0, locale30);
        try {
            dateTimeFormatter0.printTo(appendable5, (org.joda.time.ReadablePartial) localDateTime26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "105" + "'", str11.equals("105"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "105" + "'", str14.equals("105"));
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "69" + "'", str22.equals("69"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1576808170478L) + "'", long28 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        try {
            mutableDateTime0.setDayOfMonth(20628474);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20628474 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int4 = offsetDateTimeField3.getMinimumValue();
        long long6 = offsetDateTimeField3.roundHalfEven((long) (short) 10);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText((int) (short) 1, locale8);
        org.joda.time.DurationField durationField10 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 20633551, (long) 20633377);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 425739836631727");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getLeapAmount(56613274L);
        long long10 = offsetDateTimeField3.addWrapField(1L, 20614526);
        boolean boolean12 = offsetDateTimeField3.isLeap(20622225L);
        java.util.Locale locale15 = null;
        try {
            long long16 = offsetDateTimeField3.set((long) 20631023, "9", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for hourOfHalfday must be in the range [100,111]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7200001L + "'", long10 == 7200001L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        int int10 = dateTime7.getDayOfYear();
        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime15 = dateTime7.plusYears(20619772);
        try {
            org.joda.time.DateTime dateTime17 = dateTime15.withEra(20616268);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20616268 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 20611972);
        int int9 = offsetDateTimeField5.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        int int16 = dateTime15.getMillisOfDay();
        org.joda.time.DateTime.Property property17 = dateTime15.dayOfYear();
        org.joda.time.DateTime.Property property18 = dateTime15.yearOfCentury();
        java.lang.String str19 = property18.getAsText();
        java.util.Locale locale21 = null;
        org.joda.time.DateTime dateTime22 = property18.setCopy("19", locale21);
        org.joda.time.LocalDateTime localDateTime23 = dateTime22.toLocalDateTime();
        int int24 = property13.compareTo((org.joda.time.ReadablePartial) localDateTime23);
        int[] intArray25 = new int[] {};
        int int26 = delegatedDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDateTime23, intArray25);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "105" + "'", str7.equals("105"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 111 + "'", int9 == 111);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 78229522 + "'", int16 == 78229522);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "69" + "'", str19.equals("69"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(20626210L, (long) 20631224);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 425543958781040");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
        java.lang.String str11 = property10.getAsText();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("19", locale13);
        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField17 = gregorianChronology16.centuries();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTime dateTime19 = dateMidnight15.toDateTime(dateTimeZone18);
        mutableDateTime2.setZoneRetainFields(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime(dateTimeZone18);
        mutableDateTime21.addDays(20618616);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("12:00:00 AM PST", (java.lang.Number) 20612731L, (java.lang.Number) 20620986, (java.lang.Number) 0.0d);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.String str6 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12:00:00 AM PST" + "'", str5.equals("12:00:00 AM PST"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 20612731 for 12:00:00 AM PST must be in the range [20620986,0.0]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 20612731 for 12:00:00 AM PST must be in the range [20620986,0.0]"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        long long8 = offsetDateTimeField3.add(0L, (int) (byte) 100);
        java.lang.String str10 = offsetDateTimeField3.getAsText(20624655L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 360000000L + "'", long8 == 360000000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "105" + "'", str10.equals("105"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(20622019);
        java.io.OutputStream outputStream4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("2019-06-12T05:43:46.152-07:00", outputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("20631384", 20623867, 20631136, 20618237);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20623867 for 20631384 must be in the range [20631136,20618237]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getMinimumValue((long) 20632509);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int4 = offsetDateTimeField3.getMinimumValue();
        long long6 = offsetDateTimeField3.roundHalfEven((long) (short) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getLeapDurationField();
        int int8 = offsetDateTimeField3.getOffset();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        boolean boolean6 = property4.isLeap();
        org.joda.time.DateTime dateTime7 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = dateTime7.toString("2019-06-12T05:43:46.152-07:00", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("0", 20620809, 20623758, 20611566);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20620809 for 0 must be in the range [20623758,20611566]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-271613210), (long) 20628621);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -5603005967683410");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
        int int7 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime1.withWeekyear((-292275054));
        try {
            org.joda.time.DateTime dateTime11 = dateTime1.withDayOfWeek(20631980);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20631980 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTime();
        int int7 = dateTime1.getWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime1.minusHours(0);
        java.util.GregorianCalendar gregorianCalendar10 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(20613660, 20615742, 0, 20623248, 0, 20626334, 20631940);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20623248 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        mutableDateTime3.add(readableDuration4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        int int11 = dateTime8.getDayOfYear();
//        java.lang.String str12 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime8);
//        mutableDateTime3.setMillis((org.joda.time.ReadableInstant) dateTime8);
//        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78229522 + "'", int9 == 78229522);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9:43:49 PM PST" + "'", str12.equals("9:43:49 PM PST"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-W01-3" + "'", str14.equals("1970-W01-3"));
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        int int21 = dateTime18.getDayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.yearOfEra();
        mutableDateTime29.addMillis(20623870);
        org.joda.time.DateTimeField dateTimeField33 = mutableDateTime29.getRoundingField();
        try {
            mutableDateTime29.setMillisOfDay(2061577500);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2061577500 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNull(dateTimeField33);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        int int4 = dateTime1.getDayOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime1.minusMinutes(20618096);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        long long13 = dateTimeZone9.convertLocalToUTC((long) (-1), false, (long) 20613900);
        org.joda.time.DateTime dateTime14 = dateTime1.toDateTime(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        org.joda.time.DateTime.Property property10 = dateTime7.yearOfCentury();
        java.lang.String str11 = property10.getAsText();
        java.util.Locale locale13 = null;
        org.joda.time.DateTime dateTime14 = property10.setCopy("19", locale13);
        org.joda.time.DateMidnight dateMidnight15 = dateTime14.toDateMidnight();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField17 = gregorianChronology16.centuries();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTime dateTime19 = dateMidnight15.toDateTime(dateTimeZone18);
        mutableDateTime2.setZoneRetainFields(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime(dateTimeZone18);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "69" + "'", str11.equals("69"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateMidnight15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) 100);
        java.lang.String str7 = offsetDateTimeField5.getAsText((long) 20611972);
        int int9 = offsetDateTimeField5.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.DateTime.Property property14 = dateTime12.dayOfYear();
        org.joda.time.DateTime.Property property15 = dateTime12.yearOfCentury();
        java.lang.String str16 = property15.getAsText();
        java.util.Locale locale18 = null;
        org.joda.time.DateTime dateTime19 = property15.setCopy("19", locale18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        int[] intArray24 = new int[] { 10, 10, 20612731 };
        int int25 = delegatedDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay20, intArray24);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) timeOfDay20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "105" + "'", str7.equals("105"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 111 + "'", int9 == 111);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 78229522 + "'", int13 == 78229522);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "69" + "'", str16.equals("69"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.centuries();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        boolean boolean6 = dateTimeZone4.isStandardOffset((long) 20613353);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology7);
        org.joda.time.ReadableDuration readableDuration10 = null;
        mutableDateTime9.add(readableDuration10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime9);
        long long14 = dateTimeZone0.getMillisKeepLocal(dateTimeZone4, (long) 20626210);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "America/Los_Angeles" + "'", str1.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 20626210L + "'", long14 == 20626210L);
        org.junit.Assert.assertNotNull(julianChronology15);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField4 = julianChronology0.months();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getRangeDurationField();
        long long6 = delegatedDateTimeField2.add((long) 20628346, (long) 20617081);
        int int8 = delegatedDateTimeField2.getLeapAmount((long) 20620257);
        long long10 = delegatedDateTimeField2.roundHalfEven((long) 2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 74221512228346L + "'", long6 == 74221512228346L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone16.getShortName((long) 20612357, locale19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        boolean boolean23 = gJChronology21.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.monthOfYear();
//        org.joda.time.Instant instant25 = gJChronology21.getGregorianCutover();
//        org.joda.time.Instant instant28 = instant25.withDurationAdded((long) 20630133, 10);
//        org.joda.time.DateTime dateTime29 = instant28.toDateTime();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(instant28);
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        int int2 = mutableDateTime1.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.secondOfMinute();
        int int4 = property3.get();
        boolean boolean5 = property3.isLeap();
        org.joda.time.ReadableInstant readableInstant6 = null;
        int int7 = property3.getDifference(readableInstant6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 49 + "'", int4 == 49);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField3 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("5:43:50 AM PDT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"5:43:50 AM PDT\" is malformed at \":43:50 AM PDT\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology2.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        int int8 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
        long long10 = property9.remainder();
        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology2, dateTimeField11);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology14.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField(chronology13, dateTimeField16, 20612731);
        org.joda.time.DurationField durationField19 = skipDateTimeField18.getRangeDurationField();
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) 100);
        int int24 = offsetDateTimeField23.getMinimumValue();
        long long26 = offsetDateTimeField23.roundHalfEven((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField23.getMaximumValue(readablePartial27);
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
        int int36 = dateTime35.getMillisOfDay();
        org.joda.time.DateTime.Property property37 = dateTime35.dayOfYear();
        org.joda.time.DateTime.Property property38 = dateTime35.yearOfCentury();
        java.lang.String str39 = property38.getAsText();
        java.util.Locale locale41 = null;
        org.joda.time.DateTime dateTime42 = property38.setCopy("19", locale41);
        org.joda.time.LocalDateTime localDateTime43 = dateTime42.toLocalDateTime();
        long long45 = julianChronology32.set((org.joda.time.ReadablePartial) localDateTime43, 0L);
        java.util.Locale locale46 = null;
        java.lang.String str47 = delegatedDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) localDateTime43, locale46);
        java.util.Locale locale49 = null;
        java.lang.String str50 = offsetDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) localDateTime43, 20624780, locale49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipDateTimeField18.getAsText((org.joda.time.ReadablePartial) localDateTime43, locale51);
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipUndoDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDateTime43, locale53);
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology55.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) (byte) 100);
        java.lang.String str60 = offsetDateTimeField58.getAsText((long) 20611972);
        int int62 = offsetDateTimeField58.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField63 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField58);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime(dateTimeZone64);
        int int66 = dateTime65.getMillisOfDay();
        org.joda.time.DateTime.Property property67 = dateTime65.dayOfYear();
        org.joda.time.DateTime.Property property68 = dateTime65.yearOfCentury();
        java.lang.String str69 = property68.getAsText();
        java.util.Locale locale71 = null;
        org.joda.time.DateTime dateTime72 = property68.setCopy("19", locale71);
        org.joda.time.TimeOfDay timeOfDay73 = dateTime72.toTimeOfDay();
        int[] intArray77 = new int[] { 10, 10, 20612731 };
        int int78 = delegatedDateTimeField63.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay73, intArray77);
        try {
            julianChronology0.validate((org.joda.time.ReadablePartial) localDateTime43, intArray77);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20612731 for dayOfMonth must not be larger than 31");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 78229522L + "'", long10 == 78229522L);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 111 + "'", int28 == 111);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 78229522 + "'", int36 == 78229522);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "69" + "'", str39.equals("69"));
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1576808170478L) + "'", long45 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "9" + "'", str47.equals("9"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "20624780" + "'", str50.equals("20624780"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "522" + "'", str52.equals("522"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "365" + "'", str54.equals("365"));
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "105" + "'", str60.equals("105"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 111 + "'", int62 == 111);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 78229522 + "'", int66 == 78229522);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "69" + "'", str69.equals("69"));
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(timeOfDay73);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 100 + "'", int78 == 100);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(20634596, 20633803);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 20634596");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property4.getDateTime();
        int int8 = property4.getMinimumValueOverall();
        org.joda.time.DateTime dateTime9 = property4.roundHalfEvenCopy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        mutableDateTime8.add((long) 20612115);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology11);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime13.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        int int19 = dateTime18.getMillisOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfYear();
        int int21 = dateTime18.getDayOfYear();
        org.joda.time.DateTime.Property property22 = dateTime18.yearOfEra();
        org.joda.time.DateTime.Property property23 = dateTime18.minuteOfDay();
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField26 = gregorianChronology25.centuries();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTime dateTime28 = dateTime18.toDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime8.toMutableDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime31 = property30.roundHalfFloor();
        int int32 = property30.getMaximumValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 78229522 + "'", int19 == 78229522);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 292272992 + "'", int32 == 292272992);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        int int2 = mutableDateTime1.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.secondOfMinute();
        mutableDateTime1.add((long) 20628736);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.monthOfYear();
        java.lang.String str5 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JulianChronology[UTC]" + "'", str5.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField3.getAsShortText((long) 20612393, locale7);
        long long10 = offsetDateTimeField3.roundHalfFloor((long) 20612115);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.DateTime.Property property14 = dateTime12.dayOfYear();
        org.joda.time.DateTime.Property property15 = dateTime12.yearOfCentury();
        java.lang.String str16 = property15.getAsText();
        java.util.Locale locale18 = null;
        org.joda.time.DateTime dateTime19 = property15.setCopy("19", locale18);
        org.joda.time.TimeOfDay timeOfDay20 = dateTime19.toTimeOfDay();
        int[] intArray27 = new int[] { (byte) -1, 20613660, 5, 20626933, 20628345 };
        try {
            int[] intArray29 = offsetDateTimeField3.add((org.joda.time.ReadablePartial) timeOfDay20, 20617208, intArray27, 20613277);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20617208");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "105" + "'", str8.equals("105"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 21600000L + "'", long10 == 21600000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 78229522 + "'", int13 == 78229522);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "69" + "'", str16.equals("69"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(timeOfDay20);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
        java.lang.String str27 = delegatedDateTimeField8.getName();
        java.lang.String str29 = delegatedDateTimeField8.getAsShortText((long) 20630581);
        long long31 = delegatedDateTimeField8.roundFloor(28799999L);
        long long34 = delegatedDateTimeField8.add(1570850193600000L, 20624655L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hourOfHalfday" + "'", str27.equals("hourOfHalfday"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "105" + "'", str29.equals("105"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 25200000L + "'", long31 == 25200000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1645098951600000L + "'", long34 == 1645098951600000L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime5.minusYears((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withField(dateTimeFieldType8, 20633747);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.months();
        org.joda.time.DurationField durationField2 = julianChronology0.days();
        org.joda.time.DurationField durationField3 = julianChronology0.millis();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 20620924);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20620924 + "'", int1 == 20620924);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        int int6 = mutableDateTime2.getMillisOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20629522 + "'", int6 == 20629522);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        int int5 = dateTime2.getDayOfYear();
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, 20612731);
//        org.joda.time.DateTime dateTime11 = dateTime2.plusHours(20634600);
//        org.joda.time.DateTime dateTime13 = dateTime2.withYearOfEra(20627598);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9:43:49 PM PST" + "'", str6.equals("9:43:49 PM PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsShortText(20622859, locale25);
        int int27 = delegatedDateTimeField8.getMaximumValue();
        long long29 = delegatedDateTimeField8.roundHalfEven((long) 20620809);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20622859" + "'", str26.equals("20622859"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 111 + "'", int27 == 111);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 21600000L + "'", long29 == 21600000L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        boolean boolean6 = property4.isLeap();
        org.joda.time.DateTime dateTime7 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.minus(readablePeriod10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 20612115);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours(20617898);
        org.joda.time.DateTime dateTime11 = dateTime7.minusHours(20633746);
        org.joda.time.DateTime dateTime13 = dateTime7.withWeekyear(20613600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 20633062);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.set((int) (short) 0);
        org.joda.time.Instant instant9 = new org.joda.time.Instant((long) (byte) -1);
        org.joda.time.Instant instant10 = instant9.toInstant();
        boolean boolean11 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) instant9);
        mutableDateTime7.addMonths((int) (short) 1);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime7.weekOfWeekyear();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime7.hourOfDay();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeZoneBuilder16.toDateTimeZone("", false);
        org.joda.time.DateTime dateTime20 = mutableDateTime7.toDateTime(dateTimeZone19);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19, 20612393);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20612393");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        long long8 = offsetDateTimeField3.add((long) (byte) 100, 24);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) timeOfDay18, 20617081, locale20);
        boolean boolean23 = offsetDateTimeField3.isLeap(5L);
        int int25 = offsetDateTimeField3.get(0L);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        int int28 = dateTime27.getMillisOfDay();
        org.joda.time.DateTime.Property property29 = dateTime27.dayOfYear();
        org.joda.time.DateTime.Property property30 = dateTime27.yearOfCentury();
        int int31 = dateTime27.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime32 = dateTime27.toMutableDateTime();
        int int33 = dateTime27.getWeekyear();
        org.joda.time.DateTime dateTime35 = dateTime27.withWeekyear((-292275054));
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfDay(20634600);
        org.joda.time.YearMonthDay yearMonthDay38 = dateTime35.toYearMonthDay();
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay38, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400100L + "'", long8 == 86400100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "20617081" + "'", str21.equals("20617081"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 78229522 + "'", int28 == 78229522);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1969 + "'", int31 == 1969);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1970 + "'", int33 == 1970);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(yearMonthDay38);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(20627549L, 20624301);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 425428779468249L + "'", long2 == 425428779468249L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfMonth();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.dayOfYear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 20616268);
        long long2 = instant1.getMillis();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20616268L + "'", long2 == 20616268L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.minuteOfDay();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) 100);
        int int8 = offsetDateTimeField7.getMinimumValue();
        long long10 = offsetDateTimeField7.roundHalfEven((long) (short) 10);
        org.joda.time.DurationField durationField11 = offsetDateTimeField7.getLeapDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField7, 20617342);
        long long15 = offsetDateTimeField7.roundHalfCeiling((long) 20629029);
        long long18 = offsetDateTimeField7.add(522L, (long) 1970);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 21600000L + "'", long15 == 21600000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 7092000522L + "'", long18 == 7092000522L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getRoundingMode();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        mutableDateTime0.add(readablePeriod2);
        try {
            mutableDateTime0.setWeekOfWeekyear(20631384);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20631384 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime1.toMutableDateTime((org.joda.time.Chronology) julianChronology6);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfYear();
        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime8.toGregorianCalendar();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.monthOfYear();
        mutableDateTime8.setMillis(0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getRangeDurationField();
        long long6 = delegatedDateTimeField2.getDifferenceAsLong((long) 20622853, (long) 10);
        java.util.Locale locale7 = null;
        int int8 = delegatedDateTimeField2.getMaximumShortTextLength(locale7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 20634243L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1571931835200000L + "'", long1 == 1571931835200000L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getDurationField();
        int int11 = delegatedDateTimeField8.get(0L);
        long long14 = delegatedDateTimeField8.addWrapField((long) 20620809, 20617081);
        long long16 = delegatedDateTimeField8.roundHalfEven((long) 20615775);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField8.getAsShortText(20627058, locale18);
        try {
            long long22 = delegatedDateTimeField8.set((long) 20633803, "10:43:37 PM PDT");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"10:43:37 PM PDT\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24220809L + "'", long14 == 24220809L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 21600000L + "'", long16 == 21600000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "20627058" + "'", str19.equals("20627058"));
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        int int5 = dateTime2.getDayOfYear();
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, 20612731);
//        org.joda.time.DateTime dateTime11 = dateTime2.plusHours(20634600);
//        boolean boolean13 = dateTime2.isAfter(425428779468249L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9:43:49 PM PST" + "'", str6.equals("9:43:49 PM PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 20629522L + "'", long0 == 20629522L);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime2.add(readableDuration3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        int int8 = dateTime7.getMillisOfDay();
//        org.joda.time.DateTime.Property property9 = dateTime7.dayOfYear();
//        int int10 = dateTime7.getDayOfYear();
//        org.joda.time.DateTime.Property property11 = dateTime7.yearOfEra();
//        org.joda.time.DateTime.Property property12 = dateTime7.minuteOfDay();
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
//        org.joda.time.DateTime dateTime17 = dateTime7.toDateTime(dateTimeZone16);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone16.getShortName((long) 20612357, locale19);
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        boolean boolean23 = gJChronology21.equals((java.lang.Object) (byte) 100);
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.monthOfYear();
//        org.joda.time.Instant instant25 = gJChronology21.getGregorianCutover();
//        org.joda.time.DateTimeField dateTimeField26 = gJChronology21.millisOfDay();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        try {
//            int[] intArray30 = gJChronology21.get(readablePeriod27, (long) 20629197, (long) 20621099);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 78229522 + "'", int8 == 78229522);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(instant25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        int int4 = dateTime1.getDayOfYear();
        int int5 = dateTime1.getWeekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3, 20626828);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDateTime();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField3 = julianChronology2.centuries();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) julianChronology2);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology6);
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        mutableDateTime8.add(readableDuration9);
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) mutableDateTime8);
//        java.lang.String str12 = dateTimeFormatter4.print(readableInstant5);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.parse("JulianChronology[America/Los_Angeles]", dateTimeFormatter4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[America/Los_Angeles]\" is malformed at \"ianChronology[America/Los_Angeles]\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "December 19, 1969 5:43:49 AM UTC" + "'", str12.equals("December 19, 1969 5:43:49 AM UTC"));
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        try {
            org.joda.time.DateTime dateTime6 = dateTimeFormatter4.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        long long8 = offsetDateTimeField3.add((long) (byte) 100, 24);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) timeOfDay18, 20617081, locale20);
        boolean boolean23 = offsetDateTimeField3.isLeap(5L);
        long long26 = offsetDateTimeField3.add((long) 20615673, 20612357);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400100L + "'", long8 == 86400100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "20617081" + "'", str21.equals("20617081"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74204505815673L + "'", long26 == 74204505815673L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str7 = dateTimeZone6.toString();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(20629197, 20632559, 20631558, 20618235, 20631980, 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20618235 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "America/Los_Angeles" + "'", str7.equals("America/Los_Angeles"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        boolean boolean4 = offsetDateTimeField3.isSupported();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 100);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 20611972);
        long long14 = offsetDateTimeField9.add((long) (byte) 100, 24);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        int int17 = dateTime16.getMillisOfDay();
        org.joda.time.DateTime.Property property18 = dateTime16.dayOfYear();
        org.joda.time.DateTime.Property property19 = dateTime16.yearOfCentury();
        java.lang.String str20 = property19.getAsText();
        java.util.Locale locale22 = null;
        org.joda.time.DateTime dateTime23 = property19.setCopy("19", locale22);
        org.joda.time.TimeOfDay timeOfDay24 = dateTime23.toTimeOfDay();
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) timeOfDay24, 20617081, locale26);
        java.lang.String str28 = dateTimeFormatter5.print((org.joda.time.ReadablePartial) timeOfDay24);
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) timeOfDay24, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "105" + "'", str11.equals("105"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400100L + "'", long14 == 86400100L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 78229522 + "'", int17 == 78229522);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "69" + "'", str20.equals("69"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(timeOfDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "20617081" + "'", str27.equals("20617081"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "����-��" + "'", str28.equals("����-��"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime7 = property3.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        int int10 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfYear();
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime dateTime15 = dateTime9.minusMinutes(20613150);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime9.toDateTime(dateTimeZone16);
        boolean boolean18 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime19 = dateTime17.toDateTimeISO();
        boolean boolean20 = dateTime19.isEqualNow();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 78229522 + "'", int10 == 78229522);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime dateTime5 = dateTime1.minus(2L);
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withHourOfDay((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.centuries();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        java.lang.Appendable appendable4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (byte) 100);
        java.lang.String str10 = offsetDateTimeField8.getAsText((long) 20611972);
        int int12 = offsetDateTimeField8.getLeapAmount(56613274L);
        long long15 = offsetDateTimeField8.addWrapField(1L, 20614526);
        long long17 = offsetDateTimeField8.roundCeiling((long) 20634867);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
        java.lang.String str23 = offsetDateTimeField21.getAsText((long) 20611972);
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField21.getAsShortText((long) 20612393, locale25);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        int int31 = dateTime30.getMillisOfDay();
        org.joda.time.DateTime.Property property32 = dateTime30.dayOfYear();
        org.joda.time.DateTime.Property property33 = dateTime30.yearOfCentury();
        java.lang.String str34 = property33.getAsText();
        java.util.Locale locale36 = null;
        org.joda.time.DateTime dateTime37 = property33.setCopy("19", locale36);
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        long long40 = julianChronology27.set((org.joda.time.ReadablePartial) localDateTime38, 0L);
        java.util.Locale locale42 = null;
        java.lang.String str43 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDateTime38, 0, locale42);
        int int44 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) localDateTime38);
        try {
            dateTimeFormatter3.printTo(appendable4, (org.joda.time.ReadablePartial) localDateTime38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "105" + "'", str10.equals("105"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 7200001L + "'", long15 == 7200001L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 21600000L + "'", long17 == 21600000L);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "105" + "'", str23.equals("105"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "105" + "'", str26.equals("105"));
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 78229522 + "'", int31 == 78229522);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "69" + "'", str34.equals("69"));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1576808170478L) + "'", long40 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "0" + "'", str43.equals("0"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 111 + "'", int44 == 111);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("5:43:37 AM PDT", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 20611758, 56613274L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1166899103275692L + "'", long2 == 1166899103275692L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.hours();
        long long5 = durationField2.subtract((long) 20626212, 20623417);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) 100);
        java.lang.String str11 = offsetDateTimeField9.getAsText((long) 20611972);
        int int13 = offsetDateTimeField9.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField14.getDurationField();
        long long17 = delegatedDateTimeField14.roundCeiling((long) 20611566);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField14.getRangeDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField19 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-74244280573788L) + "'", long5 == (-74244280573788L));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "105" + "'", str11.equals("105"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 111 + "'", int13 == 111);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 21600000L + "'", long17 == 21600000L);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime7 = property3.getDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            int int9 = dateTime7.get(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime7 = property4.getDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        int int9 = dateTime7.getMillisOfSecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 522 + "'", int9 == 522);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.clockhourOfHalfday();
        boolean boolean8 = property3.equals((java.lang.Object) julianChronology5);
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology5.secondOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        boolean boolean6 = property4.isLeap();
        org.joda.time.DateTime dateTime7 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int11 = dateTimeFormatter10.getDefaultYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.Chronology chronology15 = gregorianChronology12.withUTC();
        org.joda.time.DateTime dateTime16 = dateTime7.withChronology(chronology15);
        try {
            org.joda.time.DateTime dateTime18 = dateTime7.withMinuteOfHour(20632509);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20632509 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2000 + "'", int11 == 2000);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        long long5 = property4.remainder();
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
//        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
//        org.joda.time.DurationField durationField10 = julianChronology6.days();
//        java.util.Locale locale11 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology13);
//        org.joda.time.ReadableDuration readableDuration16 = null;
//        mutableDateTime15.add(readableDuration16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime15.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        int int21 = dateTime20.getMillisOfDay();
//        org.joda.time.DateTime.Property property22 = dateTime20.dayOfYear();
//        int int23 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime.Property property24 = dateTime20.yearOfEra();
//        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
//        mutableDateTime15.setTime((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField28 = gregorianChronology27.centuries();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime30 = dateTime20.toDateTime(dateTimeZone29);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone29.getShortName((long) 20612357, locale32);
//        dateTimeParserBucket12.setZone(dateTimeZone29);
//        dateTimeParserBucket12.setOffset((java.lang.Integer) 20616268);
//        java.lang.Integer int37 = dateTimeParserBucket12.getOffsetInteger();
//        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) 100);
//        java.lang.String str43 = offsetDateTimeField41.getAsText((long) 20611972);
//        boolean boolean44 = dateTimeParserBucket12.restoreState((java.lang.Object) str43);
//        dateTimeParserBucket12.setOffset(20630105);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 78229522L + "'", long5 == 78229522L);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 78229522 + "'", int21 == 78229522);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 20616268 + "'", int37.equals(20616268));
//        org.junit.Assert.assertNotNull(julianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "105" + "'", str43.equals("105"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.days();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = julianChronology1.centuries();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology5);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        mutableDateTime7.add(readableDuration8);
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, (org.joda.time.ReadableInstant) mutableDateTime7);
//        java.lang.String str11 = dateTimeFormatter3.print(readableInstant4);
//        java.lang.StringBuffer stringBuffer12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        int int15 = dateTime14.getMillisOfDay();
//        org.joda.time.DateTime.Property property16 = dateTime14.dayOfYear();
//        int int17 = dateTime14.getDayOfYear();
//        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology18);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        mutableDateTime20.add(readableDuration21);
//        boolean boolean23 = dateTime14.isAfter((org.joda.time.ReadableInstant) mutableDateTime20);
//        org.joda.time.DateTime.Property property24 = dateTime14.millisOfDay();
//        java.util.Locale locale25 = null;
//        int int26 = property24.getMaximumShortTextLength(locale25);
//        java.util.Locale locale28 = null;
//        org.joda.time.DateTime dateTime29 = property24.setCopy("0", locale28);
//        try {
//            dateTimeFormatter3.printTo(stringBuffer12, (org.joda.time.ReadableInstant) dateTime29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "December 19, 1969 5:43:49 AM UTC" + "'", str11.equals("December 19, 1969 5:43:49 AM UTC"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 78229522 + "'", int15 == 78229522);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 365 + "'", int17 == 365);
//        org.junit.Assert.assertNotNull(julianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 8 + "'", int26 == 8);
//        org.junit.Assert.assertNotNull(dateTime29);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        int int4 = offsetDateTimeField3.getMinimumValue();
        long long6 = offsetDateTimeField3.roundHalfEven((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMaximumValue(readablePartial7);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField3.getMaximumShortTextLength(locale9);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) 100);
        java.lang.String str16 = offsetDateTimeField14.getAsText((long) 20611972);
        int int18 = offsetDateTimeField14.getMaximumValue((long) (short) 1);
        long long21 = offsetDateTimeField14.add((long) 20614325, (int) (byte) -1);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = julianChronology22.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) 100);
        java.lang.String str27 = offsetDateTimeField25.getAsText((long) 20611972);
        int int29 = offsetDateTimeField25.getLeapAmount(56613274L);
        long long32 = offsetDateTimeField25.addWrapField(1L, 20614526);
        long long34 = offsetDateTimeField25.roundCeiling((long) 20634867);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) 100);
        java.lang.String str40 = offsetDateTimeField38.getAsText((long) 20611972);
        java.util.Locale locale42 = null;
        java.lang.String str43 = offsetDateTimeField38.getAsShortText((long) 20612393, locale42);
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = julianChronology44.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone46);
        int int48 = dateTime47.getMillisOfDay();
        org.joda.time.DateTime.Property property49 = dateTime47.dayOfYear();
        org.joda.time.DateTime.Property property50 = dateTime47.yearOfCentury();
        java.lang.String str51 = property50.getAsText();
        java.util.Locale locale53 = null;
        org.joda.time.DateTime dateTime54 = property50.setCopy("19", locale53);
        org.joda.time.LocalDateTime localDateTime55 = dateTime54.toLocalDateTime();
        long long57 = julianChronology44.set((org.joda.time.ReadablePartial) localDateTime55, 0L);
        java.util.Locale locale59 = null;
        java.lang.String str60 = offsetDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDateTime55, 0, locale59);
        int int61 = offsetDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDateTime55);
        int int62 = offsetDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) localDateTime55);
        org.joda.time.chrono.JulianChronology julianChronology64 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField65 = julianChronology64.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, (int) (byte) 100);
        java.lang.String str69 = offsetDateTimeField67.getAsText((long) 20611972);
        int int71 = offsetDateTimeField67.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField67);
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime(dateTimeZone73);
        org.joda.time.DateTime.Property property75 = dateTime74.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime(dateTimeZone76);
        int int78 = dateTime77.getMillisOfDay();
        org.joda.time.DateTime.Property property79 = dateTime77.dayOfYear();
        org.joda.time.DateTime.Property property80 = dateTime77.yearOfCentury();
        java.lang.String str81 = property80.getAsText();
        java.util.Locale locale83 = null;
        org.joda.time.DateTime dateTime84 = property80.setCopy("19", locale83);
        org.joda.time.LocalDateTime localDateTime85 = dateTime84.toLocalDateTime();
        int int86 = property75.compareTo((org.joda.time.ReadablePartial) localDateTime85);
        int[] intArray87 = new int[] {};
        int int88 = delegatedDateTimeField72.getMinimumValue((org.joda.time.ReadablePartial) localDateTime85, intArray87);
        try {
            int[] intArray90 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDateTime55, 0, intArray87, 20631023);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20631023 for hourOfHalfday must be in the range [100,111]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 111 + "'", int8 == 111);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "105" + "'", str16.equals("105"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 111 + "'", int18 == 111);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 17014325L + "'", long21 == 17014325L);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "105" + "'", str27.equals("105"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 7200001L + "'", long32 == 7200001L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 21600000L + "'", long34 == 21600000L);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "105" + "'", str40.equals("105"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "105" + "'", str43.equals("105"));
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 78229522 + "'", int48 == 78229522);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "69" + "'", str51.equals("69"));
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDateTime55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-1576808170478L) + "'", long57 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "0" + "'", str60.equals("0"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 111 + "'", int61 == 111);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 111 + "'", int62 == 111);
        org.junit.Assert.assertNotNull(julianChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "105" + "'", str69.equals("105"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 111 + "'", int71 == 111);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 78229522 + "'", int78 == 78229522);
        org.junit.Assert.assertNotNull(property79);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "69" + "'", str81.equals("69"));
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertNotNull(localDateTime85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 100 + "'", int88 == 100);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField3.getAsShortText((long) 20612393, locale7);
        int int10 = offsetDateTimeField3.getMaximumValue((long) 20616031);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) 100);
        java.lang.String str17 = offsetDateTimeField15.getAsText((long) 20611972);
        long long20 = offsetDateTimeField15.add((long) (byte) 100, 24);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        int int23 = dateTime22.getMillisOfDay();
        org.joda.time.DateTime.Property property24 = dateTime22.dayOfYear();
        org.joda.time.DateTime.Property property25 = dateTime22.yearOfCentury();
        java.lang.String str26 = property25.getAsText();
        java.util.Locale locale28 = null;
        org.joda.time.DateTime dateTime29 = property25.setCopy("19", locale28);
        org.joda.time.TimeOfDay timeOfDay30 = dateTime29.toTimeOfDay();
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) timeOfDay30, 20617081, locale32);
        java.lang.String str34 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) timeOfDay30);
        int[] intArray36 = null;
        try {
            int[] intArray38 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) timeOfDay30, 20631023, intArray36, 20633073);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20633073 for hourOfHalfday must be in the range [100,111]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "105" + "'", str8.equals("105"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 111 + "'", int10 == 111);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "105" + "'", str17.equals("105"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86400100L + "'", long20 == 86400100L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 78229522 + "'", int23 == 78229522);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "69" + "'", str26.equals("69"));
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(timeOfDay30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "20617081" + "'", str33.equals("20617081"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "����-��" + "'", str34.equals("����-��"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        int int6 = dateTime5.getWeekOfWeekyear();
        boolean boolean7 = dateTime5.isAfterNow();
        org.joda.time.DateTime.Property property8 = dateTime5.monthOfYear();
        org.joda.time.DateTime dateTime10 = dateTime5.withWeekyear(20616626);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone11);
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.DateTime.Property property14 = dateTime12.dayOfYear();
        org.joda.time.DateTime.Property property15 = dateTime12.yearOfCentury();
        int int16 = dateTime12.getYearOfEra();
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime12.toMutableDateTime();
        int int18 = dateTime12.getWeekyear();
        org.joda.time.DateTime dateTime20 = dateTime12.withWeekyear((-292275054));
        boolean boolean21 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime20);
        java.lang.String str22 = dateTime5.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 78229522 + "'", int13 == 78229522);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1970 + "'", int18 == 1970);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969-12-31T21:43:49.522-08:00" + "'", str22.equals("1969-12-31T21:43:49.522-08:00"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        int int4 = dateTime1.getDayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime1.minusHours(20611457);
        org.joda.time.DateTime dateTime7 = dateTime6.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTime();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        int int3 = dateTime2.getMillisOfDay();
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
        long long5 = property4.remainder();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.clockhourOfHalfday();
        boolean boolean9 = property4.equals((java.lang.Object) julianChronology6);
        org.joda.time.DurationField durationField10 = julianChronology6.days();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology6, locale11);
        java.lang.Integer int13 = dateTimeParserBucket12.getOffsetInteger();
        int int14 = dateTimeParserBucket12.getOffset();
        dateTimeParserBucket12.setOffset(20627549);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            dateTimeParserBucket12.saveField(dateTimeFieldType17, 20617366);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 78229522L + "'", long5 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNull(int13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(20630131, (int) (short) 100, 20622827, 20634596, 20616626);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20634596 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfYear();
        long long8 = property7.remainder();
        org.joda.time.DateTimeField dateTimeField9 = property7.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology11, dateTimeField14, 20612731);
        org.joda.time.DurationField durationField17 = skipDateTimeField16.getRangeDurationField();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
        int int22 = offsetDateTimeField21.getMinimumValue();
        long long24 = offsetDateTimeField21.roundHalfEven((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = offsetDateTimeField21.getMaximumValue(readablePartial25);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        int int34 = dateTime33.getMillisOfDay();
        org.joda.time.DateTime.Property property35 = dateTime33.dayOfYear();
        org.joda.time.DateTime.Property property36 = dateTime33.yearOfCentury();
        java.lang.String str37 = property36.getAsText();
        java.util.Locale locale39 = null;
        org.joda.time.DateTime dateTime40 = property36.setCopy("19", locale39);
        org.joda.time.LocalDateTime localDateTime41 = dateTime40.toLocalDateTime();
        long long43 = julianChronology30.set((org.joda.time.ReadablePartial) localDateTime41, 0L);
        java.util.Locale locale44 = null;
        java.lang.String str45 = delegatedDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, locale44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, 20624780, locale47);
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDateTime41, locale49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipUndoDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, locale51);
        int int53 = skipUndoDateTimeField10.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 78229522 + "'", int6 == 78229522);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 78229522L + "'", long8 == 78229522L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 111 + "'", int26 == 111);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 78229522 + "'", int34 == 78229522);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "69" + "'", str37.equals("69"));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(localDateTime41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1576808170478L) + "'", long43 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9" + "'", str45.equals("9"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "20624780" + "'", str48.equals("20624780"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "522" + "'", str50.equals("522"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "365" + "'", str52.equals("365"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        java.lang.String str5 = property4.getAsText();
        int int6 = property4.getLeapAmount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getRoundingMode();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        mutableDateTime0.add(readablePeriod2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.millisOfSecond();
        org.joda.time.DurationField durationField7 = julianChronology4.seconds();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology4.getZone();
        mutableDateTime0.setZoneRetainFields(dateTimeZone8);
        java.lang.String str10 = mutableDateTime0.toString();
        try {
            mutableDateTime0.setSecondOfMinute(20611704);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20611704 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12-31T21:43:49.522Z" + "'", str10.equals("1969-12-31T21:43:49.522Z"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) 1, (java.lang.Number) 20620191, (java.lang.Number) 20622516);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.clockhourOfHalfday();
        boolean boolean8 = property3.equals((java.lang.Object) julianChronology5);
        org.joda.time.DurationField durationField9 = julianChronology5.days();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology5.dayOfYear();
        org.joda.time.DurationField durationField11 = julianChronology5.years();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTimeISO();
        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(20613150);
        org.joda.time.DateTime.Property property8 = dateTime1.dayOfYear();
        org.joda.time.Interval interval9 = property8.toInterval();
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval9);
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(readableInterval11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        int int4 = dateTime1.getDayOfYear();
        org.joda.time.DateTime.Property property5 = dateTime1.yearOfEra();
        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime8 = dateTime1.minusMinutes(20618096);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (short) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        try {
            org.joda.time.DateTime dateTime13 = property11.setCopy("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology5 = gregorianChronology2.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology6);
        org.joda.time.ReadableDuration readableDuration9 = null;
        mutableDateTime8.add(readableDuration9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        int int14 = dateTime13.getMillisOfDay();
        org.joda.time.DateTime.Property property15 = dateTime13.dayOfYear();
        int int16 = dateTime13.getDayOfYear();
        org.joda.time.DateTime.Property property17 = dateTime13.yearOfEra();
        org.joda.time.DateTime.Property property18 = dateTime13.minuteOfDay();
        mutableDateTime8.setTime((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology20.getZone();
        org.joda.time.DateTime dateTime23 = dateTime13.toDateTime(dateTimeZone22);
        org.joda.time.DateTime.Property property24 = dateTime23.monthOfYear();
        org.joda.time.DateTime dateTime25 = property24.roundHalfFloorCopy();
        int int26 = dateTime25.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, (int) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        long long33 = dateTimeZone29.adjustOffset((long) 20613759, false);
        org.joda.time.DateTime dateTime34 = dateTime25.toDateTime(dateTimeZone29);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) 100);
        java.lang.String str40 = offsetDateTimeField38.getAsText((long) 20611972);
        int int42 = offsetDateTimeField38.getMaximumValue((long) (short) 1);
        long long45 = offsetDateTimeField38.add((long) 20614325, (int) (byte) -1);
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField47 = julianChronology46.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) (byte) 100);
        java.lang.String str51 = offsetDateTimeField49.getAsText((long) 20611972);
        int int53 = offsetDateTimeField49.getLeapAmount(56613274L);
        long long56 = offsetDateTimeField49.addWrapField(1L, 20614526);
        long long58 = offsetDateTimeField49.roundCeiling((long) 20634867);
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = julianChronology59.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, (int) (byte) 100);
        java.lang.String str64 = offsetDateTimeField62.getAsText((long) 20611972);
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField62.getAsShortText((long) 20612393, locale66);
        org.joda.time.chrono.JulianChronology julianChronology68 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField69 = julianChronology68.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(dateTimeZone70);
        int int72 = dateTime71.getMillisOfDay();
        org.joda.time.DateTime.Property property73 = dateTime71.dayOfYear();
        org.joda.time.DateTime.Property property74 = dateTime71.yearOfCentury();
        java.lang.String str75 = property74.getAsText();
        java.util.Locale locale77 = null;
        org.joda.time.DateTime dateTime78 = property74.setCopy("19", locale77);
        org.joda.time.LocalDateTime localDateTime79 = dateTime78.toLocalDateTime();
        long long81 = julianChronology68.set((org.joda.time.ReadablePartial) localDateTime79, 0L);
        java.util.Locale locale83 = null;
        java.lang.String str84 = offsetDateTimeField62.getAsShortText((org.joda.time.ReadablePartial) localDateTime79, 0, locale83);
        int int85 = offsetDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) localDateTime79);
        int int86 = offsetDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDateTime79);
        org.joda.time.DateTime dateTime87 = dateTime25.withFields((org.joda.time.ReadablePartial) localDateTime79);
        boolean boolean88 = gregorianChronology2.equals((java.lang.Object) dateTime25);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 78229522 + "'", int14 == 78229522);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 20613759L + "'", long33 == 20613759L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "105" + "'", str40.equals("105"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 111 + "'", int42 == 111);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 17014325L + "'", long45 == 17014325L);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "105" + "'", str51.equals("105"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 7200001L + "'", long56 == 7200001L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 21600000L + "'", long58 == 21600000L);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "105" + "'", str64.equals("105"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "105" + "'", str67.equals("105"));
        org.junit.Assert.assertNotNull(julianChronology68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 78229522 + "'", int72 == 78229522);
        org.junit.Assert.assertNotNull(property73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "69" + "'", str75.equals("69"));
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(localDateTime79);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-1576808170478L) + "'", long81 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "0" + "'", str84.equals("0"));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 111 + "'", int85 == 111);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 111 + "'", int86 == 111);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        long long4 = property3.remainder();
        org.joda.time.DateTime dateTime6 = property3.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime7 = property3.getDateTime();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int int9 = property3.compareTo(readablePartial8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 78229522L + "'", long4 == 78229522L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("(\"org.joda.time.JodaTimePermission\" \"20190529T224336-0700\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DurationField durationField4 = delegatedDateTimeField3.getRangeDurationField();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) delegatedDateTimeField3);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        long long8 = offsetDateTimeField3.add(0L, (int) (byte) 100);
        long long11 = offsetDateTimeField3.getDifferenceAsLong((long) 20634867, 0L);
        long long14 = offsetDateTimeField3.add(0L, 20618235);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 360000000L + "'", long8 == 360000000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 74225646000000L + "'", long14 == 74225646000000L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        long long8 = offsetDateTimeField3.add((long) (byte) 100, 24);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField3.getAsShortText((org.joda.time.ReadablePartial) timeOfDay18, 20617081, locale20);
        boolean boolean23 = offsetDateTimeField3.isLeap(5L);
        org.joda.time.DurationField durationField24 = offsetDateTimeField3.getLeapDurationField();
        java.lang.String str25 = offsetDateTimeField3.getName();
        org.joda.time.DurationField durationField26 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400100L + "'", long8 == 86400100L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "20617081" + "'", str21.equals("20617081"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hourOfHalfday" + "'", str25.equals("hourOfHalfday"));
        org.junit.Assert.assertNull(durationField26);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getRangeDurationField();
        int int4 = delegatedDateTimeField2.getMaximumValue();
        long long7 = delegatedDateTimeField2.getDifferenceAsLong((long) 20614750, (long) 20630493);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.monthOfYear();
        mutableDateTime1.addDays(20635292);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        boolean boolean4 = offsetDateTimeField3.isSupported();
        java.lang.String str5 = offsetDateTimeField3.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str5.equals("DateTimeField[hourOfHalfday]"));
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        mutableDateTime3.add(readableDuration4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.yearOfEra();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        int int9 = dateTime8.getMillisOfDay();
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfYear();
//        int int11 = dateTime8.getDayOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.yearOfEra();
//        org.joda.time.DateTime.Property property13 = dateTime8.minuteOfDay();
//        mutableDateTime3.setTime((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField16 = gregorianChronology15.centuries();
//        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology15.getZone();
//        org.joda.time.DateTime dateTime18 = dateTime8.toDateTime(dateTimeZone17);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone17.getShortName((long) 20612357, locale20);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone17.getShortName((long) 20613759, locale23);
//        long long28 = dateTimeZone17.convertLocalToUTC((long) 20619914, true, (long) 20620350);
//        org.joda.time.Chronology chronology29 = gregorianChronology0.withZone(dateTimeZone17);
//        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) 100);
//        int int34 = offsetDateTimeField33.getMinimumValue();
//        long long36 = offsetDateTimeField33.roundHalfEven((long) (short) 10);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        int int38 = offsetDateTimeField33.getMaximumValue(readablePartial37);
//        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField40 = julianChronology39.hourOfHalfday();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40);
//        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = julianChronology42.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone44 = null;
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
//        int int46 = dateTime45.getMillisOfDay();
//        org.joda.time.DateTime.Property property47 = dateTime45.dayOfYear();
//        org.joda.time.DateTime.Property property48 = dateTime45.yearOfCentury();
//        java.lang.String str49 = property48.getAsText();
//        java.util.Locale locale51 = null;
//        org.joda.time.DateTime dateTime52 = property48.setCopy("19", locale51);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
//        long long55 = julianChronology42.set((org.joda.time.ReadablePartial) localDateTime53, 0L);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = delegatedDateTimeField41.getAsShortText((org.joda.time.ReadablePartial) localDateTime53, locale56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = offsetDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) localDateTime53, 20624780, locale59);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField62 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField33, 20626151);
//        int int64 = skipUndoDateTimeField62.get((long) 105);
//        org.joda.time.DateTimeZone dateTimeZone65 = null;
//        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime(dateTimeZone65);
//        int int67 = dateTime66.getMillisOfDay();
//        org.joda.time.DateTime.Property property68 = dateTime66.dayOfYear();
//        org.joda.time.DateTime.Property property69 = dateTime66.yearOfCentury();
//        java.lang.String str70 = property69.getAsText();
//        java.util.Locale locale72 = null;
//        org.joda.time.DateTime dateTime73 = property69.setCopy("19", locale72);
//        org.joda.time.LocalDateTime localDateTime74 = dateTime73.toLocalDateTime();
//        int[] intArray76 = new int[] {};
//        try {
//            int[] intArray78 = skipUndoDateTimeField62.add((org.joda.time.ReadablePartial) localDateTime74, 20633803, intArray76, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20633803");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 78229522 + "'", int9 == 78229522);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "PST" + "'", str21.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PST" + "'", str24.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 49419914L + "'", long28 == 49419914L);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(julianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 111 + "'", int38 == 111);
//        org.junit.Assert.assertNotNull(julianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(julianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 78229522 + "'", int46 == 78229522);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "69" + "'", str49.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-1576808170478L) + "'", long55 == (-1576808170478L));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9" + "'", str57.equals("9"));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "20624780" + "'", str60.equals("20624780"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 101 + "'", int64 == 101);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 78229522 + "'", int67 == 78229522);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "69" + "'", str70.equals("69"));
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(localDateTime74);
//        org.junit.Assert.assertNotNull(intArray76);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getRangeDurationField();
        long long6 = delegatedDateTimeField2.getDifferenceAsLong((long) 20622853, (long) 10);
        int int8 = delegatedDateTimeField2.getMinimumValue((long) 20629923);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
        int int2 = mutableDateTime1.getWeekOfWeekyear();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.secondOfMinute();
        mutableDateTime1.addYears(44);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (byte) 100);
        java.lang.String str5 = offsetDateTimeField3.getAsText((long) 20611972);
        int int7 = offsetDateTimeField3.getMaximumValue((long) (short) 1);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        int int11 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime10.dayOfYear();
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        java.lang.String str14 = property13.getAsText();
        java.util.Locale locale16 = null;
        org.joda.time.DateTime dateTime17 = property13.setCopy("19", locale16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime17.toTimeOfDay();
        int[] intArray22 = new int[] { 10, 10, 20612731 };
        int int23 = delegatedDateTimeField8.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay18, intArray22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField8.getAsText(20631384, locale25);
        java.util.Locale locale28 = null;
        java.lang.String str29 = delegatedDateTimeField8.getAsShortText(20630581, locale28);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "105" + "'", str5.equals("105"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 111 + "'", int7 == 111);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 78229522 + "'", int11 == 78229522);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20631384" + "'", str26.equals("20631384"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "20630581" + "'", str29.equals("20630581"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getRangeDurationField();
        long long6 = delegatedDateTimeField2.add((long) 20628346, (long) 20617081);
        int int8 = delegatedDateTimeField2.getLeapAmount((long) 20620257);
        int int9 = delegatedDateTimeField2.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 74221512228346L + "'", long6 == 74221512228346L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfYear();
        long long8 = property7.remainder();
        org.joda.time.DateTimeField dateTimeField9 = property7.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField9);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField(chronology11, dateTimeField14, 20612731);
        org.joda.time.DurationField durationField17 = skipDateTimeField16.getRangeDurationField();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) 100);
        int int22 = offsetDateTimeField21.getMinimumValue();
        long long24 = offsetDateTimeField21.roundHalfEven((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = offsetDateTimeField21.getMaximumValue(readablePartial25);
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.hourOfHalfday();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone32);
        int int34 = dateTime33.getMillisOfDay();
        org.joda.time.DateTime.Property property35 = dateTime33.dayOfYear();
        org.joda.time.DateTime.Property property36 = dateTime33.yearOfCentury();
        java.lang.String str37 = property36.getAsText();
        java.util.Locale locale39 = null;
        org.joda.time.DateTime dateTime40 = property36.setCopy("19", locale39);
        org.joda.time.LocalDateTime localDateTime41 = dateTime40.toLocalDateTime();
        long long43 = julianChronology30.set((org.joda.time.ReadablePartial) localDateTime41, 0L);
        java.util.Locale locale44 = null;
        java.lang.String str45 = delegatedDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, locale44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, 20624780, locale47);
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipDateTimeField16.getAsText((org.joda.time.ReadablePartial) localDateTime41, locale49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipUndoDateTimeField10.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, locale51);
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology53.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, (int) (byte) 100);
        java.lang.String str58 = offsetDateTimeField56.getAsText((long) 20611972);
        int int60 = offsetDateTimeField56.getLeapAmount(56613274L);
        long long63 = offsetDateTimeField56.addWrapField(1L, 20614526);
        long long65 = offsetDateTimeField56.roundCeiling((long) 20634867);
        org.joda.time.chrono.JulianChronology julianChronology66 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = julianChronology66.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, (int) (byte) 100);
        java.lang.String str71 = offsetDateTimeField69.getAsText((long) 20611972);
        java.util.Locale locale73 = null;
        java.lang.String str74 = offsetDateTimeField69.getAsShortText((long) 20612393, locale73);
        org.joda.time.chrono.JulianChronology julianChronology75 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField76 = julianChronology75.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone77 = null;
        org.joda.time.DateTime dateTime78 = new org.joda.time.DateTime(dateTimeZone77);
        int int79 = dateTime78.getMillisOfDay();
        org.joda.time.DateTime.Property property80 = dateTime78.dayOfYear();
        org.joda.time.DateTime.Property property81 = dateTime78.yearOfCentury();
        java.lang.String str82 = property81.getAsText();
        java.util.Locale locale84 = null;
        org.joda.time.DateTime dateTime85 = property81.setCopy("19", locale84);
        org.joda.time.LocalDateTime localDateTime86 = dateTime85.toLocalDateTime();
        long long88 = julianChronology75.set((org.joda.time.ReadablePartial) localDateTime86, 0L);
        java.util.Locale locale90 = null;
        java.lang.String str91 = offsetDateTimeField69.getAsShortText((org.joda.time.ReadablePartial) localDateTime86, 0, locale90);
        int int92 = offsetDateTimeField56.getMaximumValue((org.joda.time.ReadablePartial) localDateTime86);
        java.util.Locale locale93 = null;
        java.lang.String str94 = skipUndoDateTimeField10.getAsText((org.joda.time.ReadablePartial) localDateTime86, locale93);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 78229522 + "'", int6 == 78229522);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 78229522L + "'", long8 == 78229522L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 111 + "'", int26 == 111);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 78229522 + "'", int34 == 78229522);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "69" + "'", str37.equals("69"));
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(localDateTime41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1576808170478L) + "'", long43 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "9" + "'", str45.equals("9"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "20624780" + "'", str48.equals("20624780"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "522" + "'", str50.equals("522"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "365" + "'", str52.equals("365"));
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "105" + "'", str58.equals("105"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 7200001L + "'", long63 == 7200001L);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 21600000L + "'", long65 == 21600000L);
        org.junit.Assert.assertNotNull(julianChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "105" + "'", str71.equals("105"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "105" + "'", str74.equals("105"));
        org.junit.Assert.assertNotNull(julianChronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 78229522 + "'", int79 == 78229522);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertNotNull(property81);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "69" + "'", str82.equals("69"));
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(localDateTime86);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-1576808170478L) + "'", long88 == (-1576808170478L));
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "0" + "'", str91.equals("0"));
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 111 + "'", int92 == 111);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "365" + "'", str94.equals("365"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("1930-10-23T05:13:49-08:00", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology0);
        org.joda.time.ReadableDuration readableDuration3 = null;
        mutableDateTime2.add(readableDuration3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.millisOfSecond();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.hourOfHalfday();
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.minuteOfHour();
        mutableDateTime2.setChronology((org.joda.time.Chronology) julianChronology6);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        int int3 = dateTime2.getMillisOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfYear();
//        int int5 = dateTime2.getDayOfYear();
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, 20612731);
//        org.joda.time.DateTime dateTime11 = dateTime2.plusHours(20634600);
//        org.joda.time.DurationFieldType durationFieldType12 = null;
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime11.withFieldAdded(durationFieldType12, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78229522 + "'", int3 == 78229522);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "9:43:49 PM PST" + "'", str6.equals("9:43:49 PM PST"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.centuries();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        int int5 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfYear();
        org.joda.time.DateTime.Property property7 = dateTime4.yearOfCentury();
        int int8 = dateTime4.getYearOfEra();
        java.lang.String str9 = dateTime4.toString();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (byte) 100);
        java.lang.String str16 = offsetDateTimeField14.getAsText((long) 20611972);
        int int18 = offsetDateTimeField14.getLeapAmount(56613274L);
        long long21 = offsetDateTimeField14.addWrapField(1L, 20614526);
        long long23 = offsetDateTimeField14.roundCeiling((long) 20634867);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        try {
            org.joda.time.DateTime dateTime26 = dateTime4.withField(dateTimeFieldType24, 20622056);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 20622056 for hourOfHalfday must be in the range [0,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 78229522 + "'", int5 == 78229522);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31T21:43:49.522-08:00" + "'", str9.equals("1969-12-31T21:43:49.522-08:00"));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "105" + "'", str16.equals("105"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 7200001L + "'", long21 == 7200001L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 21600000L + "'", long23 == 21600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        int int2 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfYear();
        org.joda.time.DateTime.Property property4 = dateTime1.yearOfCentury();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) 20631558);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 78229522 + "'", int2 == 78229522);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }
}

