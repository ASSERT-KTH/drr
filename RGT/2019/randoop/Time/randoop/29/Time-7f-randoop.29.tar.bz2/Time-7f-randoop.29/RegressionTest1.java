import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        mutableDateTime8.setDayOfYear((int) '#');
        mutableDateTime8.addMillis(16);
        mutableDateTime8.add(510L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '0' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withZone(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        mutableDateTime11.setZone(dateTimeZone12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.yearOfEra();
        int int17 = dateTimeFormatter9.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "GregorianChronology[UTC]", 2922789);
        int int18 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setYear(4);
        org.joda.time.ReadableDuration readableDuration21 = null;
        mutableDateTime11.add(readableDuration21, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2922790) + "'", int17 == (-2922790));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-25200000) + "'", int18 == (-25200000));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        long long19 = skipDateTimeField16.roundCeiling((long) 2);
        long long21 = skipDateTimeField16.roundCeiling((long) (short) 0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600000L + "'", long19 == 3600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime5 = property1.set(0);
        org.joda.time.MutableDateTime mutableDateTime7 = property1.add((int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime8 = property1.getMutableDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2922789 + "'", int2 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2066);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2066) + "'", int1 == (-2066));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        int int8 = dateTimeParserBucket7.getOffset();
        long long11 = dateTimeParserBucket7.computeMillis(false, "1970-01-01T00:00:05.199Z");
        long long14 = dateTimeParserBucket7.computeMillis(false, "Coordinated Universal Time");
        long long16 = dateTimeParserBucket7.computeMillis(true);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.withYearOfCentury((int) '4');
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withDayOfMonth((-8));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -8 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"4\")", "");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        boolean boolean19 = skipDateTimeField16.isLeap((long) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime dateTime5 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property6 = dateTime1.dayOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(510L, (org.joda.time.Chronology) julianChronology2);
        int int5 = julianChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.yearOfEra();
        org.joda.time.DurationField durationField4 = property3.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.roundCeiling();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNull(durationField4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        long long28 = remainderDateTimeField22.roundHalfCeiling(57600560L);
        long long30 = remainderDateTimeField22.roundHalfCeiling((long) 57599999);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 57600000L + "'", long28 == 57600000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 57600000L + "'", long30 == 57600000L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        long long25 = remainderDateTimeField22.add(207359999991L, 1560345104283L);
        java.util.Locale locale27 = null;
        java.lang.String str28 = remainderDateTimeField22.getAsText(2116, locale27);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 93620913616979991L + "'", long25 == 93620913616979991L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2116" + "'", str28.equals("2116"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readableDuration5);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime9.toGregorianCalendar();
        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", (int) (byte) 1);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.dayOfYear();
        org.joda.time.DateTimeField dateTimeField15 = mutableDateTime9.getRoundingField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNull(dateTimeField15);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
//        int int4 = instant0.get(dateTimeField3);
//        org.joda.time.Instant instant6 = instant0.plus(0L);
//        long long7 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560345103951L + "'", long7 == 1560345103951L);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        java.util.Locale locale1 = null;
//        java.util.Calendar calendar2 = mutableDateTime0.toCalendar(locale1);
//        int int3 = mutableDateTime0.getWeekOfWeekyear();
//        mutableDateTime0.setMonthOfYear(11);
//        org.junit.Assert.assertNotNull(calendar2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        int int7 = fixedDateTimeZone5.getStandardOffset((long) (short) -1);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long10 = fixedDateTimeZone5.previousTransition(1560344400000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560344400000L + "'", long10 == 1560344400000L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gJChronology8.weeks();
        boolean boolean11 = gJChronology8.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.dayOfYear();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(57600100, 999, (int) (byte) 100, 58528, 24, 69, 0, (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58528 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        java.lang.String str18 = skipDateTimeField16.getAsText(1036800010L);
        long long20 = skipDateTimeField16.roundHalfEven(57600560L);
        int int22 = skipDateTimeField16.getMinimumValue((long) 57599999);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "4" + "'", str18.equals("4"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 57600000L + "'", long20 == 57600000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        int int8 = offsetDateTimeField3.get(921600L);
        long long11 = offsetDateTimeField3.add((long) 1969, 0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1968 + "'", int8 == 1968);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays(4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        boolean boolean17 = gJChronology14.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.dayOfYear();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology14.hourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime12.toDateTime((org.joda.time.Chronology) gJChronology14);
        boolean boolean21 = dateTime20.isAfterNow();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = property5.setCopy(1);
        org.joda.time.DateTime dateTime10 = property5.roundFloorCopy();
        int int11 = property5.getMinimumValueOverall();
        java.util.Locale locale13 = null;
        try {
            org.joda.time.DateTime dateTime14 = property5.setCopy("JulianChronology[UTC]", locale13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[UTC]\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears(1969);
        int int6 = dateTime3.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("1970-01-01T00:00:05.199Z", "1969-12", (-28800000), (-9));
        long long11 = fixedDateTimeZone9.previousTransition(133225L);
        long long13 = fixedDateTimeZone9.nextTransition((-6051600000L));
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(0, 6, 0, 2019, 24, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 133225L + "'", long11 == 133225L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-6051600000L) + "'", long13 == (-6051600000L));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime1.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime1.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks(22296758);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = property5.getDateTime();
        boolean boolean9 = property5.isLeap();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property5.setCopy("2019-06-12T06:11:43.500-07:00", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-12T06:11:43.500-07:00\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("4");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"4\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"4\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"4\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"4\")"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-2922790));
        java.util.Locale locale12 = null;
        java.util.Calendar calendar13 = dateTime11.toCalendar(locale12);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(calendar13);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        int int4 = instant0.get(dateTimeField3);
        org.joda.time.Instant instant6 = instant0.plus(0L);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant0.withDurationAdded(readableDuration7, 31);
        org.joda.time.Instant instant11 = instant0.withMillis((long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-1971), (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1961L) + "'", long2 == (-1961L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 100);
        int int8 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        long long11 = dateTime10.getMillis();
        java.lang.String str12 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime13.setZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology16.seconds();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.year();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = gJChronology20.weeks();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22, 0);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField24.getAsShortText(readablePartial25, (int) (short) 1, locale27);
        mutableDateTime13.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTime.Property property31 = dateTime10.property(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType30, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendCenturyOfEra(1969, 2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.appendFractionOfSecond(2116, (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31" + "'", str12.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        int int1 = mutableDateTime0.getDayOfMonth();
//        mutableDateTime0.addWeekyears(0);
//        int int4 = mutableDateTime0.getWeekOfWeekyear();
//        try {
//            mutableDateTime0.setDayOfWeek(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendSecondOfMinute((-9));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, 1560345098484L, (-2066));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -2066");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        java.lang.String str4 = property3.getName();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        long long12 = offsetDateTimeField10.roundHalfCeiling((-210865896000000L));
        long long14 = offsetDateTimeField10.remainder((long) 2019);
        long long16 = offsetDateTimeField10.roundHalfEven(1560345104283L);
        int int17 = dateTime5.get((org.joda.time.DateTimeField) offsetDateTimeField10);
        long long19 = offsetDateTimeField10.roundHalfCeiling((long) (-25200000));
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "yearOfEra" + "'", str4.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210866803200000L) + "'", long12 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30499202019L + "'", long14 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1547424000000L + "'", long16 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292272990 + "'", int17 == 292272990);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 950400000L + "'", long19 == 950400000L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-1L));
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.year();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.add((int) (byte) 1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.addWrapField(100);
//        mutableDateTime6.addDays(9);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345103951L + "'", long3 == 1560345103951L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.months();
        long long6 = durationField3.subtract((long) (-25200000), (int) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-136796400000L) + "'", long6 == (-136796400000L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.seconds();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.year();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = gJChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField23, 0);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField25.getAsText((int) (short) 1, locale27);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField30 = gregorianChronology29.seconds();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.year();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = gJChronology33.weeks();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField35, 0);
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipUndoDateTimeField37.getAsShortText(readablePartial38, (int) (short) 1, locale40);
        long long44 = skipUndoDateTimeField37.add((long) (byte) -1, 0);
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField37.getAsText(1560345069015L, locale46);
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = julianChronology48.weekyear();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration52 = null;
        org.joda.time.DateTime dateTime53 = dateTime51.minus(readableDuration52);
        int int54 = dateTime53.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay55 = dateTime53.toYearMonthDay();
        long long57 = julianChronology48.set((org.joda.time.ReadablePartial) yearMonthDay55, (long) 10);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField37.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay55, 31, locale59);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField63 = gregorianChronology62.seconds();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology62.year();
        org.joda.time.DateTimeZone dateTimeZone65 = null;
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone65);
        org.joda.time.DurationField durationField67 = gJChronology66.weeks();
        org.joda.time.DateTimeField dateTimeField68 = gJChronology66.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField70 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology62, dateTimeField68, 0);
        org.joda.time.ReadablePartial readablePartial71 = null;
        int[] intArray78 = new int[] { 3, 2000, 3, 9, (byte) 100, 100 };
        int int79 = skipUndoDateTimeField70.getMinimumValue(readablePartial71, intArray78);
        java.util.Locale locale81 = null;
        int[] intArray82 = skipUndoDateTimeField25.set((org.joda.time.ReadablePartial) yearMonthDay55, (int) (short) 0, intArray78, "4", locale81);
        int int83 = skipDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay55);
        long long85 = skipDateTimeField16.roundCeiling((long) (-28800000));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "6" + "'", str47.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1970 + "'", int54 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1036800010L + "'", long57 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31" + "'", str60.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-28800000L) + "'", long85 == (-28800000L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        int int2 = property1.getMaximumValueOverall();
        int int3 = property1.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField4 = property1.getField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2922789 + "'", int2 == 2922789);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-62105094000000L), (java.lang.Number) (-62159155621981L), (java.lang.Number) 57599999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "1970-01-01T00:00:05.199Z", "16");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, (-9));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -9");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withZone(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100);
        int int12 = dateTime11.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readableDuration13);
        org.joda.time.DateTime.Property property15 = dateTime11.secondOfMinute();
        int int16 = property15.getMaximumValue();
        org.joda.time.DateTime dateTime17 = property15.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime18 = property15.getDateTime();
        boolean boolean19 = property15.isLeap();
        org.joda.time.DateTime dateTime21 = property15.addToCopy((long) 100);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.minus(readablePeriod22);
        mutableDateTime9.setTime((org.joda.time.ReadableInstant) dateTime21);
        mutableDateTime9.setYear(31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property1.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType4, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "");
        java.lang.String str12 = illegalFieldValueException11.getFieldName();
        illegalFieldValueException11.prependMessage("");
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "");
        java.lang.Number number18 = illegalFieldValueException17.getUpperBound();
        illegalFieldValueException11.addSuppressed((java.lang.Throwable) illegalFieldValueException17);
        illegalFieldValueException8.addSuppressed((java.lang.Throwable) illegalFieldValueException11);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2922789 + "'", int2 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[UTC]" + "'", str12.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime11 = property10.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
        org.joda.time.DateTime dateTime4 = dateTime1.plusHours(292272991);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(julianChronology5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setStandardOffset((-2));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder2.setStandardOffset(10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder2.setStandardOffset((int) (byte) 1);
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100);
        int int3 = dateTime2.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        long long6 = dateTime5.getMillis();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        mutableDateTime8.setZone(dateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = gregorianChronology11.seconds();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.year();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = gJChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField17, 0);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField19.getAsShortText(readablePartial20, (int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField19);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = skipUndoDateTimeField19.getType();
        org.joda.time.DateTime.Property property26 = dateTime5.property(dateTimeFieldType25);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 100);
        int int29 = dateTime28.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime28.plus(readableDuration30);
        long long32 = dateTime31.getMillis();
        org.joda.time.DateTime dateTime34 = dateTime31.plusHours(0);
        org.joda.time.DateTime.Property property35 = dateTime31.weekyear();
        long long36 = property26.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime31);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31" + "'", str7.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        org.joda.time.Instant instant4 = new org.joda.time.Instant();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology5.seconds();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        int int8 = instant4.get(dateTimeField7);
        org.joda.time.Instant instant10 = instant4.minus((long) '4');
        long long11 = property1.getDifferenceAsLong((org.joda.time.ReadableInstant) instant4);
        org.joda.time.MutableDateTime mutableDateTime12 = property1.roundFloor();
        java.util.Locale locale14 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime15 = property1.set("UTC", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2922789 + "'", int2 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DurationField durationField17 = gJChronology1.hours();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology1.hourOfDay();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        int int7 = dateTime6.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.withWeekyear((int) (byte) 1);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
        int int12 = dateTime9.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime11 = dateTime3.plusYears(22296758);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.eras();
        try {
            org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) julianChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        mutableDateTime0.addHours(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str8 = gregorianChronology7.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weeks();
//        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(0);
//        java.util.Date date17 = dateTime14.toDate();
//        org.joda.time.DateTime dateTime19 = dateTime14.withYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate20 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime22 = dateTime14.plusMinutes((int) (byte) 10);
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone26 = julianChronology24.getZone();
//        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = dateTime22.toDateTime(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345103951L + "'", long3 == 1560345103951L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(57599999, false);
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.DurationField durationField3 = property1.getLeapDurationField();
        org.joda.time.MutableDateTime mutableDateTime4 = property1.roundHalfEven();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths((int) (byte) 1);
        int int11 = property1.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2922789 + "'", int2 == 2922789);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gJChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 59, (org.joda.time.Chronology) gJChronology2);
        long long7 = mutableDateTime6.getMillis();
        boolean boolean9 = mutableDateTime6.isEqual((long) 1969);
        int int10 = mutableDateTime6.getCenturyOfEra();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 59L + "'", long7 == 59L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 20 + "'", int10 == 20);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100);
//        int int3 = dateTime2.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime2.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime5.withZoneRetainFields(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone7);
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(obj0, dateTimeZone7);
//        java.lang.String str13 = dateTimeZone7.getName(42L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 365 + "'", int3 == 365);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.plus(readableDuration3);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        long long12 = skipUndoDateTimeField8.add((long) (short) 1, 0L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText(31, locale14);
        java.util.Locale locale16 = null;
        int int17 = skipUndoDateTimeField8.getMaximumTextLength(locale16);
        java.lang.String str18 = skipUndoDateTimeField8.getName();
        long long20 = skipUndoDateTimeField8.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31" + "'", str15.equals("31"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hourOfHalfday" + "'", str18.equals("hourOfHalfday"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", (java.lang.Number) 22296758, (java.lang.Number) (-210865896000000L), (java.lang.Number) 10.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        long long25 = remainderDateTimeField22.add(207359999991L, 1560345104283L);
        long long27 = remainderDateTimeField22.roundHalfEven((long) (short) 10);
        int int28 = remainderDateTimeField22.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 93620913616979991L + "'", long25 == 93620913616979991L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        mutableDateTime0.setWeekyear(16);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345103951L + "'", long3 == 1560345103951L);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        long long5 = dateTimeZone2.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology7 = buddhistChronology0.withZone(dateTimeZone2);
        java.lang.String str8 = buddhistChronology0.toString();
        java.lang.String str9 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology10 = buddhistChronology0.withUTC();
        org.joda.time.DurationField durationField11 = buddhistChronology0.months();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str8.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str9.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        java.lang.String str4 = offsetDateTimeField3.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTimeField[weekyear]" + "'", str4.equals("DateTimeField[weekyear]"));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.monthOfYear();
//        java.lang.String str5 = property4.toString();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property4.getAsShortText(locale6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345103951L + "'", long3 == 1560345103951L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[monthOfYear]" + "'", str5.equals("Property[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset(1036800010L);
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime();
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = mutableDateTime5.toCalendar(locale6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime5.dayOfWeek();
        org.joda.time.DateTime dateTime9 = mutableDateTime5.toDateTimeISO();
        int int10 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) mutableDateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(calendar7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime4 = dateTime1.withDayOfMonth((-9));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = gJChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.seconds();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.year();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gJChronology18.weeks();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField20, 0);
        boolean boolean23 = skipUndoDateTimeField22.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, (org.joda.time.DateTimeField) skipUndoDateTimeField22);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField22, 4);
        java.lang.String str28 = skipDateTimeField26.getAsText(0L);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds(0);
        java.util.Date date33 = dateTime30.toDate();
        org.joda.time.DateTime dateTime35 = dateTime30.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate36 = dateTime30.toLocalDate();
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipDateTimeField26.getAsText((org.joda.time.ReadablePartial) localDate36, 2019, locale38);
        long long42 = skipDateTimeField26.getDifferenceAsLong(30499202019L, 0L);
        long long45 = skipDateTimeField26.add((long) 90, (-6051600000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "4" + "'", str28.equals("4"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 8472L + "'", long42 == 8472L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-21785759999999910L) + "'", long45 == (-21785759999999910L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear((int) (short) 100, (-2));
        boolean boolean8 = dateTimeFormatterBuilder4.canBuildParser();
        dateTimeFormatterBuilder4.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        int int3 = mutableDateTime0.getMillisOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.millisOfSecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22303951 + "'", int3 == 22303951);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.hourOfDay();
        try {
            long long9 = gJChronology1.getDateTimeMillis(22296758, 6, (-2922790), 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2922790 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime9.toGregorianCalendar();
        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        mutableDateTime9.setZoneRetainFields(dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        long long31 = skipUndoDateTimeField27.add((long) (short) 1, 0L);
        long long34 = skipUndoDateTimeField27.add(0L, 0L);
        int int37 = skipUndoDateTimeField27.getDifference(0L, (long) 4);
        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField27);
        try {
            mutableDateTime9.setMillisOfSecond((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        boolean boolean5 = property4.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(3);
//        int int8 = mutableDateTime7.getMillisOfDay();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345103951L + "'", long3 == 1560345103951L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 22303951 + "'", int8 == 22303951);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(11, 0, 57600, 22296758, 69, (org.joda.time.Chronology) gJChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 22296758 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-12T06:11:43.500-07:00", (java.lang.Number) 0, (java.lang.Number) 100.0d, number3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("hourOfHalfday", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hourOfHalfday\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays(4);
        int int13 = dateTime12.getDayOfWeek();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        java.util.Locale locale1 = null;
        java.util.Calendar calendar2 = mutableDateTime0.toCalendar(locale1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.dayOfWeek();
        try {
            org.joda.time.MutableDateTime mutableDateTime5 = property3.set("1969-12-31");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(calendar2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        mutableDateTime0.setMillisOfSecond((int) (byte) 100);
        mutableDateTime0.setDayOfYear((int) ' ');
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime0.dayOfYear();
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusMillis((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime1.plus(readablePeriod9);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        int int13 = dateTime12.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readableDuration14);
        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
        int int17 = property16.getMaximumValue();
        org.joda.time.DateTime dateTime18 = property16.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime19 = property16.getDateTime();
        boolean boolean20 = property16.isLeap();
        org.joda.time.DateTime dateTime22 = property16.addToCopy((long) 100);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.minus(readablePeriod23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime1, (org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property26 = dateTime24.minuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) property26, (org.joda.time.Chronology) gregorianChronology27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        mutableDateTime0.setMillisOfSecond((int) (byte) 100);
        try {
            mutableDateTime0.setMinuteOfDay((-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.plusSeconds((int) 'a');
        try {
            java.lang.String str8 = dateTime6.toString("Friday, December 31, -0001");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: F");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds(0);
        java.util.Date date7 = dateTime4.toDate();
        org.joda.time.DateTime dateTime9 = dateTime4.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime4.minusMillis((int) ' ');
        org.joda.time.DateTime dateTime13 = dateTime4.withCenturyOfEra((int) '#');
        org.joda.time.LocalDate localDate14 = dateTime4.toLocalDate();
        boolean boolean15 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate14);
        java.lang.String str16 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) localDate14);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969-12" + "'", str16.equals("1969-12"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral("Property[year]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-2066), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: -2066");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gJChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 59, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.Chronology chronology7 = gJChronology2.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology2.getZone();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime9.toGregorianCalendar();
        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", (int) (byte) 1);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.dayOfYear();
        boolean boolean16 = mutableDateTime9.isAfter(921600L);
        java.lang.String str17 = mutableDateTime9.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0004-10-01T04:03:10.365-07:52:58" + "'", str17.equals("0004-10-01T04:03:10.365-07:52:58"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set(2922789);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gJChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.year();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gJChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField19, 0);
        boolean boolean22 = skipUndoDateTimeField21.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, (org.joda.time.DateTimeField) skipUndoDateTimeField21);
        int int24 = skipDateTimeField23.getMinimumValue();
        long long26 = skipDateTimeField23.roundFloor((long) 1970);
        long long28 = skipDateTimeField23.roundHalfCeiling((long) 16);
        boolean boolean29 = skipDateTimeField23.isLenient();
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.centuryOfEra();
        int int32 = property31.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField33 = property31.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType34);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime5.property(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType34, 69, (-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendSecondOfMinute(2116);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendTwoDigitWeekyear((int) (short) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder45.appendMonthOfYear((-2922790));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2922789 + "'", int32 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int11 = dateTime7.getDayOfWeek();
        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-59074531621900L) + "'", long12 == (-59074531621900L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(57599999, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond(22303, 999);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendDayOfMonth((-2066));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (-9), 3);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(59);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        boolean boolean14 = dateTime11.isAfter((long) (short) -1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        java.lang.String str19 = skipDateTimeField16.getAsText(0L);
        int int21 = skipDateTimeField16.get((long) 365);
        long long23 = skipDateTimeField16.roundCeiling((long) 31);
        long long25 = skipDateTimeField16.roundHalfCeiling((long) 57600);
        java.lang.String str27 = skipDateTimeField16.getAsShortText((long) 6);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4" + "'", str19.equals("4"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3600000L + "'", long23 == 3600000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "4" + "'", str27.equals("4"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        java.lang.Appendable appendable4 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfSecond(100);
        org.joda.time.LocalDate localDate11 = dateTime6.toLocalDate();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.weekyear();
        org.joda.time.DateTime dateTime14 = dateTime6.withChronology((org.joda.time.Chronology) julianChronology12);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        try {
            dateTimeFormatter0.printTo(appendable4, (org.joda.time.ReadablePartial) localDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology8 = dateTimeParserBucket7.getChronology();
        dateTimeParserBucket7.setOffset((java.lang.Integer) 0);
        dateTimeParserBucket7.setPivotYear((java.lang.Integer) 57599999);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundFloor();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) julianChronology14);
        long long19 = julianChronology14.add((long) (-1), 0L, 0);
        org.joda.time.DateTimeZone dateTimeZone20 = julianChronology14.getZone();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((java.lang.Object) dateTime12, dateTimeZone20);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds(1968);
        org.joda.time.DateTime dateTime11 = dateTime7.withMillisOfDay(19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withZone(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        mutableDateTime11.setZone(dateTimeZone12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.yearOfEra();
        int int17 = dateTimeFormatter9.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "GregorianChronology[UTC]", 2922789);
        int int18 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setYear(4);
        mutableDateTime11.addWeekyears((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2922790) + "'", int17 == (-2922790));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-25200000) + "'", int18 == (-25200000));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute((-1971), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        org.joda.time.DateTime dateTime5 = dateTime1.plus((long) 57599);
        int int6 = dateTime1.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime19 = property17.set(2922789);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gJChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology22.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = gregorianChronology27.seconds();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.year();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = gJChronology31.weeks();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField33, 0);
        boolean boolean36 = skipUndoDateTimeField35.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        int int38 = skipDateTimeField37.getMinimumValue();
        long long40 = skipDateTimeField37.roundFloor((long) 1970);
        long long42 = skipDateTimeField37.roundHalfCeiling((long) 16);
        boolean boolean43 = skipDateTimeField37.isLenient();
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.centuryOfEra();
        int int46 = property45.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField47 = property45.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property45.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField37, dateTimeFieldType48);
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime19.property(dateTimeFieldType48);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType48);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType48, 0, 90, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [90,5]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2922789 + "'", int46 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(property50);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant5 = instant2.withDurationAdded(readableDuration3, 292272990);
        org.joda.time.Instant instant7 = instant5.plus((long) 24);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) julianChronology8);
        org.joda.time.DurationField durationField10 = julianChronology8.hours();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology8.clockhourOfHalfday();
        try {
            org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(22303951, 58528, (int) '#', 1969, 0, 9, 6, (org.joda.time.Chronology) julianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        org.joda.time.MutableDateTime mutableDateTime5 = property1.set(0);
        org.joda.time.MutableDateTime mutableDateTime7 = property1.add((int) (byte) 1);
        java.lang.String str8 = property1.toString();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2922789 + "'", int2 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[centuryOfEra]" + "'", str8.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (-9), 3);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(59);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.year();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gJChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField19, 0);
        org.joda.time.ReadablePartial readablePartial22 = null;
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField21.getAsShortText(readablePartial22, (int) (short) 1, locale24);
        long long28 = skipUndoDateTimeField21.add((long) (byte) -1, 0);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField21.getAsText(1560345069015L, locale30);
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.weekyear();
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime37 = dateTime35.minus(readableDuration36);
        int int38 = dateTime37.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay39 = dateTime37.toYearMonthDay();
        long long41 = julianChronology32.set((org.joda.time.ReadablePartial) yearMonthDay39, (long) 10);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipUndoDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay39, 31, locale43);
        boolean boolean45 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay39);
        try {
            int int46 = property12.compareTo((org.joda.time.ReadablePartial) yearMonthDay39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "6" + "'", str31.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1970 + "'", int38 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1036800010L + "'", long41 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, true);
        boolean boolean13 = dateTimeZone8.isStandardOffset((-28800000L));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) julianChronology15);
        long long20 = julianChronology15.add((long) (-1), 0L, 0);
        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology15.getZone();
        long long23 = dateTimeZone8.getMillisKeepLocal(dateTimeZone21, (long) 59);
        try {
            org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime((-28800000), (-292269056), 59, 0, 365, 6, 8, dateTimeZone21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 59L + "'", long23 == 59L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfSecond((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (-57600L), 6);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = property5.setCopy(1);
        org.joda.time.DateTime dateTime10 = property5.roundFloorCopy();
        org.joda.time.DateTimeField dateTimeField11 = property5.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        int int44 = zeroIsMaxDateTimeField43.getMinimumValue();
        int int47 = zeroIsMaxDateTimeField43.getDifference(1036800000L, 57600000L);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (byte) 100);
        int int50 = dateTime49.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.DateTime dateTime52 = dateTime49.plus(readableDuration51);
        org.joda.time.DateTime.Property property53 = dateTime49.secondOfMinute();
        org.joda.time.DateTime dateTime55 = dateTime49.minusMinutes(0);
        java.util.Date date56 = dateTime55.toDate();
        org.joda.time.TimeOfDay timeOfDay57 = dateTime55.toTimeOfDay();
        int[] intArray59 = null;
        try {
            int[] intArray61 = zeroIsMaxDateTimeField43.addWrapField((org.joda.time.ReadablePartial) timeOfDay57, 2000, intArray59, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 16320 + "'", int47 == 16320);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeOfDay57);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
//        int int2 = property1.getMaximumValueOverall();
//        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
//        long long4 = property1.remainder();
//        java.lang.String str5 = property1.getAsShortText();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2922789 + "'", int2 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1595440096049L) + "'", long4 == (-1595440096049L));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "20" + "'", str5.equals("20"));
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100);
        int int3 = dateTime2.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime8 = dateTime2.withHourOfDay(0);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.LocalDate localDate10 = dateTime2.toLocalDate();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime13 = dateTime2.withPeriodAdded(readablePeriod11, 2922789);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "16" + "'", str9.equals("16"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100);
        int int3 = dateTime2.getWeekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100);
        int int3 = dateTime2.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime8 = dateTime2.withHourOfDay(0);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property10 = dateTime2.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "16" + "'", str9.equals("16"));
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 10);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.centuryOfEra();
        int int12 = property11.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField13 = property11.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = property11.set(0);
        try {
            org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime15, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2922789 + "'", int12 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology8.weekOfWeekyear();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((int) ' ', (int) (byte) 100, 1968, (-2066), 8, (-25200000), 2, (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2066 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        int int2 = gJChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField4 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Instant instant2 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        mutableDateTime3.setZone(dateTimeZone4);
//        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime3);
//        boolean boolean7 = instant2.isBefore((org.joda.time.ReadableInstant) mutableDateTime3);
//        mutableDateTime3.addYears((int) 'a');
//        int int10 = mutableDateTime3.getWeekyear();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.year();
//        java.lang.String str12 = property11.toString();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.getMutableDateTime();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560345103951L + "'", long6 == 1560345103951L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2116 + "'", int10 == 2116);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[year]" + "'", str12.equals("Property[year]"));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gJChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) 1, locale14);
        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField11);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField11.getAsShortText((-2L), locale18);
        long long22 = skipUndoDateTimeField11.getDifferenceAsLong(1560345097204L, (long) 960);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3" + "'", str19.equals("3"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 433429L + "'", long22 == 433429L);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = julianChronology0.eras();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        java.lang.String str4 = dateTimeZone2.getName(57600000L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordinated Universal Time" + "'", str4.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime9.toGregorianCalendar();
        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        mutableDateTime9.setZoneRetainFields(dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        long long31 = skipUndoDateTimeField27.add((long) (short) 1, 0L);
        long long34 = skipUndoDateTimeField27.add(0L, 0L);
        int int37 = skipUndoDateTimeField27.getDifference(0L, (long) 4);
        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField27);
        int int39 = mutableDateTime9.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 240 + "'", int39 == 240);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("4");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("4");
        java.lang.String str4 = jodaTimePermission3.toString();
        java.lang.String str5 = jodaTimePermission3.getName();
        java.lang.String str6 = jodaTimePermission3.getName();
        boolean boolean7 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        boolean boolean9 = jodaTimePermission3.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"4\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"4\")"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4" + "'", str5.equals("4"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4" + "'", str6.equals("4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        int int13 = dateTime12.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readableDuration14);
        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
        org.joda.time.DateTime dateTime18 = dateTime12.minusMinutes(0);
        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime8.minuteOfDay();
        long long21 = mutableDateTime8.getMillis();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-43009635L) + "'", long21 == (-43009635L));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        org.joda.time.ReadableDuration readableDuration25 = null;
        mutableDateTime8.add(readableDuration25, (-1));
        mutableDateTime8.addWeeks(69);
        int int30 = mutableDateTime8.getMillisOfSecond();
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime9.toGregorianCalendar();
        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        mutableDateTime9.setZoneRetainFields(dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        long long31 = skipUndoDateTimeField27.add((long) (short) 1, 0L);
        long long34 = skipUndoDateTimeField27.add(0L, 0L);
        int int37 = skipUndoDateTimeField27.getDifference(0L, (long) 4);
        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField27);
        org.joda.time.ReadableDuration readableDuration39 = null;
        mutableDateTime9.add(readableDuration39, (int) ' ');
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        mutableDateTime9.setChronology((org.joda.time.Chronology) julianChronology42);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(julianChronology42);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        org.joda.time.ReadableDuration readableDuration25 = null;
        mutableDateTime8.add(readableDuration25, (-1));
        org.joda.time.ReadableInterval readableInterval28 = null;
        org.joda.time.ReadableInterval readableInterval29 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval28);
        org.joda.time.ReadableInterval readableInterval30 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval28);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) mutableDateTime8, chronology31);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertNotNull(readableInterval29);
        org.junit.Assert.assertNotNull(readableInterval30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("(\"org.joda.time.JodaTimePermission\" \"4\")", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"(\"org.joda.time.JodaTimePermission\" \"4\")/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set(2922789);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gJChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.year();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gJChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField19, 0);
        boolean boolean22 = skipUndoDateTimeField21.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, (org.joda.time.DateTimeField) skipUndoDateTimeField21);
        int int24 = skipDateTimeField23.getMinimumValue();
        long long26 = skipDateTimeField23.roundFloor((long) 1970);
        long long28 = skipDateTimeField23.roundHalfCeiling((long) 16);
        boolean boolean29 = skipDateTimeField23.isLenient();
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.centuryOfEra();
        int int32 = property31.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField33 = property31.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType34);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime5.property(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType34, 69, (-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder43.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder44.appendFractionOfHour(2066, (int) 'a');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2922789 + "'", int32 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.withFields(readablePartial7);
        boolean boolean10 = dateTime6.isBefore((long) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime6.plusYears(2000);
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600100 + "'", int13 == 57600100);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        mutableDateTime0.addHours(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str8 = gregorianChronology7.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weeks();
//        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(0);
//        java.util.Date date17 = dateTime14.toDate();
//        org.joda.time.DateTime dateTime19 = dateTime14.withYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate20 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime22 = dateTime14.plusMinutes((int) (byte) 10);
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime25 = dateTime22.plusSeconds(5);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345103951L + "'", long3 == 1560345103951L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        int int3 = dateTimeFormatter0.getDefaultYear();
        java.lang.String str5 = dateTimeFormatter0.print((long) 2);
        java.lang.Appendable appendable6 = null;
        try {
            dateTimeFormatter0.printTo(appendable6, (-12959983159412L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12" + "'", str5.equals("1969-12"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = julianChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gJChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField7 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField5, 0);
        int int8 = skipUndoDateTimeField7.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        int int13 = dateTime12.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readableDuration14);
        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
        org.joda.time.DateTime dateTime18 = dateTime12.minusMinutes(0);
        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime12);
        long long20 = dateTime12.getMillis();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        long long35 = remainderDateTimeField22.roundHalfFloor((long) 57600);
        java.util.Locale locale37 = null;
        java.lang.String str38 = remainderDateTimeField22.getAsShortText(1547424000000L, locale37);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 60000L + "'", long35 == 60000L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "0" + "'", str38.equals("0"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "0", "1969-12-31T15:59:59.999-08:00");
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "0", "0");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getName(locale10, "16", "1969-12-31T15:59:59.999-08:00");
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withDefaultYear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter2.parseLocalDateTime("9");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(localDateTime4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.withFields(readablePartial7);
        boolean boolean10 = dateTime6.isBefore((long) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime6.plusDays((int) (short) 10);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
        java.util.Locale locale15 = null;
        try {
            org.joda.time.DateTime dateTime16 = property13.setCopy("", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        long long28 = remainderDateTimeField22.roundHalfCeiling(57600560L);
        java.lang.String str30 = remainderDateTimeField22.getAsShortText((long) (short) -1);
        long long32 = remainderDateTimeField22.roundFloor(1560345103593L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 57600000L + "'", long28 == 57600000L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9" + "'", str30.equals("9"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560345060000L + "'", long32 == 1560345060000L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        dateTimeParserBucket7.setOffset(16);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsText((int) (short) 1, locale10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipUndoDateTimeField20.getAsShortText(readablePartial21, (int) (short) 1, locale23);
        long long27 = skipUndoDateTimeField20.add((long) (byte) -1, 0);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipUndoDateTimeField20.getAsText(1560345069015L, locale29);
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology31.weekyear();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        int int37 = dateTime36.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay38 = dateTime36.toYearMonthDay();
        long long40 = julianChronology31.set((org.joda.time.ReadablePartial) yearMonthDay38, (long) 10);
        java.util.Locale locale42 = null;
        java.lang.String str43 = skipUndoDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay38, 31, locale42);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField46 = gregorianChronology45.seconds();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology45.year();
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48);
        org.joda.time.DurationField durationField50 = gJChronology49.weeks();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology49.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology45, dateTimeField51, 0);
        org.joda.time.ReadablePartial readablePartial54 = null;
        int[] intArray61 = new int[] { 3, 2000, 3, 9, (byte) 100, 100 };
        int int62 = skipUndoDateTimeField53.getMinimumValue(readablePartial54, intArray61);
        java.util.Locale locale64 = null;
        int[] intArray65 = skipUndoDateTimeField8.set((org.joda.time.ReadablePartial) yearMonthDay38, (int) (short) 0, intArray61, "4", locale64);
        long long67 = skipUndoDateTimeField8.roundHalfCeiling((long) 1);
        java.util.Locale locale69 = null;
        java.lang.String str70 = skipUndoDateTimeField8.getAsShortText(97, locale69);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "6" + "'", str30.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1970 + "'", int37 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1036800010L + "'", long40 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "31" + "'", str43.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "97" + "'", str70.equals("97"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.LocalDate localDate6 = dateTime1.toLocalDate();
        org.joda.time.DateTime dateTime8 = dateTime1.withWeekyear((-1971));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
        org.joda.time.DurationField durationField3 = julianChronology0.millis();
        java.lang.Object obj4 = null;
        boolean boolean5 = julianChronology0.equals(obj4);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long5 = dateTimeZone2.adjustOffset((long) (byte) -1, false);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.hourOfDay();
        org.joda.time.DurationField durationField5 = gJChronology1.millis();
        org.joda.time.DurationField durationField6 = gJChronology1.days();
        org.joda.time.DurationField durationField7 = gJChronology1.minutes();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        int int4 = dateTime3.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        try {
            org.joda.time.DateTime dateTime11 = dateTime3.withTime(57600100, 6, 2000, 292272991);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears(1969);
        int int6 = dateTime5.getMillisOfDay();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket7.getZone();
        int int9 = dateTimeParserBucket7.getOffset();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        java.io.Writer writer4 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime8.minusWeeks(365);
        boolean boolean11 = dateTime8.isAfterNow();
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadableInstant) dateTime8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.set(2922789);
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = mutableDateTime4.toCalendar(locale5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.era();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(57600, 3, 365, 19, 0, 57600100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "31");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(57599999, 0);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 100);
        int int10 = dateTime9.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime9.secondOfMinute();
        boolean boolean14 = mutableDateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime6.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gJChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology17.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology17.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField27 = gJChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField28, 0);
        boolean boolean31 = skipUndoDateTimeField30.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, (org.joda.time.DateTimeField) skipUndoDateTimeField30);
        int int33 = skipDateTimeField32.getMinimumValue();
        long long35 = skipDateTimeField32.roundFloor((long) 1970);
        long long37 = skipDateTimeField32.roundHalfCeiling((long) 16);
        boolean boolean38 = skipDateTimeField32.isLenient();
        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.centuryOfEra();
        int int41 = property40.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField42 = property40.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField32, dateTimeFieldType43);
        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, "UTC");
        int int47 = mutableDateTime6.get(dateTimeFieldType43);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder5.appendDecimal(dateTimeFieldType43, (-292269056), 2066);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922789 + "'", int41 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 20 + "'", int47 == 20);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.withFields(readablePartial7);
        int int9 = dateTime6.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfDay();
        java.lang.String str11 = property10.getAsShortText();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57600" + "'", str11.equals("57600"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-1L));
        mutableDateTime1.setWeekyear(5);
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime1.add(readableDuration4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusMillis((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime1.plus(readablePeriod9);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks(31);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        long long12 = skipUndoDateTimeField8.add((long) (short) 1, 0L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText(31, locale14);
        java.lang.String str17 = skipUndoDateTimeField8.getAsText(1560345104513L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31" + "'", str15.equals("31"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "6" + "'", str17.equals("6"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        long long19 = skipDateTimeField16.roundFloor((long) 1970);
        long long21 = skipDateTimeField16.roundHalfCeiling((long) 16);
        boolean boolean22 = skipDateTimeField16.isLenient();
        try {
            long long25 = skipDateTimeField16.set((-3599996L), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfHalfday must be in the range [1,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        mutableDateTime8.setDayOfYear((int) (short) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str28 = gregorianChronology27.toString();
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
        boolean boolean31 = dateTimeZone29.isStandardOffset(1036800010L);
        org.joda.time.DateTime dateTime32 = mutableDateTime8.toDateTime(dateTimeZone29);
        mutableDateTime8.setWeekyear(22303951);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "GregorianChronology[UTC]" + "'", str28.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTime32);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
//        int int2 = dateTime1.getWeekOfWeekyear();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
//        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
//        int int6 = property5.getMaximumValue();
//        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime8 = property5.getDateTime();
//        org.joda.time.Instant instant9 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        mutableDateTime10.setZone(dateTimeZone11);
//        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime10);
//        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) mutableDateTime10);
//        mutableDateTime10.addYears((int) 'a');
//        int int17 = mutableDateTime10.getWeekyear();
//        long long18 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560345103951L + "'", long13 == 1560345103951L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2116 + "'", int17 == 2116);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-4621410703L) + "'", long18 == (-4621410703L));
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readableDuration11);
        int int13 = dateTime12.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        int[] intArray20 = new int[] { (byte) 1, 5, ' ', (short) -1 };
        int[] intArray22 = skipUndoDateTimeField8.addWrapField((org.joda.time.ReadablePartial) yearMonthDay14, 0, intArray20, 4);
        long long24 = skipUndoDateTimeField8.roundCeiling((long) (short) -1);
        long long27 = skipUndoDateTimeField8.addWrapField((long) (-2), 999);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10799998L + "'", long27 == 10799998L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("BuddhistChronology[America/Los_Angeles]", "UTC");
        illegalFieldValueException2.prependMessage("");
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DurationField durationField5 = gregorianChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.hourOfDay();
        try {
            long long14 = gregorianChronology2.getDateTimeMillis((int) 'a', 100, 11, 2000, (int) (short) 1, (int) (short) -1, (-9));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder7.setFixedSavings("1969-12-31T15:59:59.999-08:00", (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        int int14 = fixedDateTimeZone12.getStandardOffset((long) (short) -1);
        org.joda.time.DateTime dateTime15 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = julianChronology16.eras();
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology16.getZone();
        long long20 = dateTimeZone18.convertUTCToLocal((long) 5);
        long long22 = fixedDateTimeZone12.getMillisKeepLocal(dateTimeZone18, (long) 999);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 5L + "'", long20 == 5L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 999L + "'", long22 == 999L);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        long long5 = gregorianChronology1.add(0L, (long) (short) 10, 2);
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        mutableDateTime6.setZone(dateTimeZone7);
//        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime6);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime6.dayOfMonth();
//        boolean boolean11 = property10.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime13 = property10.add(3);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        int int17 = property10.compareTo((org.joda.time.ReadablePartial) localDateTime16);
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        int int20 = gJChronology19.getMinimumDaysInFirstWeek();
//        org.joda.time.MutableDateTime mutableDateTime21 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.centuryOfEra();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (byte) 100);
//        int int25 = dateTime24.getWeekOfWeekyear();
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime24.plus(readableDuration26);
//        org.joda.time.DateTime.Property property28 = dateTime24.secondOfMinute();
//        boolean boolean29 = mutableDateTime21.isBefore((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime.Property property30 = dateTime24.millisOfSecond();
//        org.joda.time.DateTime dateTime32 = dateTime24.minusHours((int) (byte) 100);
//        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
//        int int37 = dateTime36.getWeekyear();
//        org.joda.time.YearMonthDay yearMonthDay38 = dateTime36.toYearMonthDay();
//        org.joda.time.DateTime dateTime39 = dateTime32.withFields((org.joda.time.ReadablePartial) yearMonthDay38);
//        int[] intArray41 = gJChronology19.get((org.joda.time.ReadablePartial) yearMonthDay38, (-359999900L));
//        try {
//            gregorianChronology1.validate((org.joda.time.ReadablePartial) localDateTime16, intArray41);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 20L + "'", long5 == 20L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560345124179L + "'", long9 == 1560345124179L);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1970 + "'", int37 == 1970);
//        org.junit.Assert.assertNotNull(yearMonthDay38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(intArray41);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        int int3 = dateTimeFormatter0.getDefaultYear();
        java.lang.String str5 = dateTimeFormatter0.print((long) 2);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("1970-01-01T00:00:05.199Z", "1969-12", (-28800000), (-9));
        long long13 = fixedDateTimeZone11.previousTransition(133225L);
        long long15 = fixedDateTimeZone11.nextTransition((-6051600000L));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.StringBuffer stringBuffer17 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime21 = dateTime19.minusSeconds(0);
        java.util.Date date22 = dateTime19.toDate();
        org.joda.time.DateTime dateTime24 = dateTime19.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime27 = dateTime24.withDurationAdded((long) (-9), 3);
        org.joda.time.DateTime dateTime29 = dateTime27.withYearOfCentury(59);
        try {
            dateTimeFormatter16.printTo(stringBuffer17, (org.joda.time.ReadableInstant) dateTime27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12" + "'", str5.equals("1969-12"));
        org.junit.Assert.assertNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 133225L + "'", long13 == 133225L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-6051600000L) + "'", long15 == (-6051600000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 433429L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj0, dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gregorianChronology10.seconds();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.year();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField16, 0);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField18.getAsText((int) (short) 1, locale20);
        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField18);
        org.joda.time.DurationField durationField23 = skipUndoDateTimeField18.getLeapDurationField();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.minus(readableDuration26);
        org.joda.time.DateTime dateTime29 = dateTime25.withMillisOfSecond(100);
        org.joda.time.LocalDate localDate30 = dateTime25.toLocalDate();
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate30, 22296758, locale32);
        long long35 = skipUndoDateTimeField18.roundHalfCeiling((long) 57600100);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "22296758" + "'", str33.equals("22296758"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 57600000L + "'", long35 == 57600000L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(26005751L, (-6051600000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6025594249L) + "'", long2 == (-6025594249L));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(0);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property12 = dateTime6.secondOfMinute();
        org.joda.time.DurationField durationField13 = property12.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.weekyear();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = julianChronology1.get(readablePartial4, 1560345097204L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        int int1 = mutableDateTime0.getDayOfWeek();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.weekyear();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        mutableDateTime0.add(readableDuration3, 2922789);
//        mutableDateTime0.setTime((long) (-1));
//        mutableDateTime0.addDays((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
//        org.junit.Assert.assertNotNull(property2);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology8 = dateTimeParserBucket7.getChronology();
        dateTimeParserBucket7.setPivotYear((java.lang.Integer) 292272990);
        dateTimeParserBucket7.setOffset(57599);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        long long7 = durationField4.subtract(20L, 58528);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-5056819621980L) + "'", long7 == (-5056819621980L));
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        mutableDateTime1.setZone(dateTimeZone2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
//        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
//        mutableDateTime1.addYears((int) 'a');
//        int int8 = mutableDateTime1.getWeekyear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField14 = gJChronology13.weeks();
//        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField15, 0);
//        boolean boolean18 = skipUndoDateTimeField17.isSupported();
//        long long21 = skipUndoDateTimeField17.add(2440588L, 0);
//        java.util.Locale locale22 = null;
//        int int23 = skipUndoDateTimeField17.getMaximumTextLength(locale22);
//        mutableDateTime1.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField17);
//        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.centuryOfEra();
//        int int27 = property26.getMaximumValueOverall();
//        org.joda.time.DateTimeField dateTimeField28 = property26.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField17, dateTimeFieldType29, 1, 22296758, 12);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 921600L, (java.lang.Number) (-1L), (java.lang.Number) 20);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560345125158L + "'", long4 == 1560345125158L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2116 + "'", int8 == 2116);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2440588L + "'", long21 == 2440588L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2922789 + "'", int27 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.millisOfSecond();
        java.lang.String str4 = julianChronology2.toString();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeParserBucket8.getZone();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((-719528L), dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        boolean boolean11 = dateTimeZone3.isLocalDateTimeGap(localDateTime10);
        java.lang.String str12 = dateTimeZone3.getID();
        java.util.TimeZone timeZone13 = dateTimeZone3.toTimeZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.millisOfDay();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) 1, (org.joda.time.Chronology) gregorianChronology1, locale4, (java.lang.Integer) 31);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeParserBucket6.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime7 = dateTime1.minusMinutes(0);
        org.joda.time.DateTime dateTime9 = dateTime1.minus((long) 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 1968, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipUndoDateTimeField14.getMinimumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField14.getAsText(292272990, locale19);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "292272990" + "'", str20.equals("292272990"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        boolean boolean9 = dateTime3.isBeforeNow();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set(2922789);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gJChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.year();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gJChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField19, 0);
        boolean boolean22 = skipUndoDateTimeField21.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, (org.joda.time.DateTimeField) skipUndoDateTimeField21);
        int int24 = skipDateTimeField23.getMinimumValue();
        long long26 = skipDateTimeField23.roundFloor((long) 1970);
        long long28 = skipDateTimeField23.roundHalfCeiling((long) 16);
        boolean boolean29 = skipDateTimeField23.isLenient();
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.centuryOfEra();
        int int32 = property31.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField33 = property31.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType34);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime5.property(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType34, 69, (-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder42.appendHourOfDay(19);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2922789 + "'", int32 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.monthOfYear();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        long long5 = dateTime4.getMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology6.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        mutableDateTime9.setZone(dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        org.joda.time.ReadablePartial readablePartial21 = null;
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipUndoDateTimeField20.getAsShortText(readablePartial21, (int) (short) 1, locale23);
        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = skipUndoDateTimeField20.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dateTimeField8, dateTimeFieldType26, (int) (short) 10);
        boolean boolean30 = remainderDateTimeField28.isLeap(0L);
        long long32 = remainderDateTimeField28.roundHalfEven(207359999991L);
        java.lang.String str34 = remainderDateTimeField28.getAsText((-12959983159412L));
        boolean boolean36 = remainderDateTimeField28.isLeap((long) (short) 0);
        long long39 = remainderDateTimeField28.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime40.centuryOfEra();
        int int42 = property41.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField43 = property41.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property41.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType44, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField49 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField28, dateTimeFieldType44);
        org.joda.time.DateTime.Property property50 = dateTime4.property(dateTimeFieldType44);
        org.joda.time.DateTime dateTime52 = property50.addWrapFieldToCopy((-9));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 207360000000L + "'", long32 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "7" + "'", str34.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2922789 + "'", int42 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime52);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        mutableDateTime0.addHours(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str8 = gregorianChronology7.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weeks();
//        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(0);
//        java.util.Date date17 = dateTime14.toDate();
//        org.joda.time.DateTime dateTime19 = dateTime14.withYear((int) (byte) 1);
//        org.joda.time.LocalDate localDate20 = dateTime14.toLocalDate();
//        org.joda.time.DateTime dateTime22 = dateTime14.plusMinutes((int) (byte) 10);
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime.Property property24 = dateTime22.dayOfWeek();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560345126719L + "'", long3 == 1560345126719L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField8.getAsShortText(readablePartial9, (int) (short) 1, locale11);
        long long15 = skipUndoDateTimeField8.add((long) (byte) -1, 0);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField8.getAsText(1560345069015L, locale17);
        int int20 = skipUndoDateTimeField8.getMaximumValue((long) 58528);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField8.getAsText((-1961L), locale22);
        long long26 = skipUndoDateTimeField8.add(0L, 26005751L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6" + "'", str18.equals("6"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "3" + "'", str23.equals("3"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 93620703600000L + "'", long26 == 93620703600000L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = gJChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.seconds();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.year();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gJChronology18.weeks();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField20, 0);
        boolean boolean23 = skipUndoDateTimeField22.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, (org.joda.time.DateTimeField) skipUndoDateTimeField22);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField22, 4);
        java.lang.String str28 = skipDateTimeField26.getAsText(0L);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds(0);
        java.util.Date date33 = dateTime30.toDate();
        org.joda.time.DateTime dateTime35 = dateTime30.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate36 = dateTime30.toLocalDate();
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipDateTimeField26.getAsText((org.joda.time.ReadablePartial) localDate36, 2019, locale38);
        long long42 = skipDateTimeField26.getDifferenceAsLong(30499202019L, 0L);
        int int43 = skipDateTimeField26.getMinimumValue();
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (byte) 100);
        int int46 = dateTime45.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration47 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.plus(readableDuration47);
        org.joda.time.DateTime.Property property49 = dateTime45.secondOfMinute();
        org.joda.time.DateTime dateTime51 = dateTime45.minusMinutes(0);
        java.util.Date date52 = dateTime51.toDate();
        org.joda.time.TimeOfDay timeOfDay53 = dateTime51.toTimeOfDay();
        java.util.Locale locale54 = null;
        try {
            java.lang.String str55 = skipDateTimeField26.getAsText((org.joda.time.ReadablePartial) timeOfDay53, locale54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "4" + "'", str28.equals("4"));
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 8472L + "'", long42 == 8472L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeOfDay53);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology1.years();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DurationField durationField8 = julianChronology6.hours();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears(1969);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfYear();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((-2));
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        java.lang.Object obj4 = null;
        boolean boolean5 = gJChronology1.equals(obj4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology1.add(readablePeriod6, (long) 31, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology1.getZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31L + "'", long9 == 31L);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException("BuddhistChronology[America/Los_Angeles]", "UTC");
        illegalFieldValueException3.prependMessage("1969-12-31");
        boolean boolean6 = gJChronology0.equals((java.lang.Object) "1969-12-31");
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = property5.getDateTime();
        boolean boolean9 = property5.isLeap();
        org.joda.time.DateTime dateTime11 = property5.addToCopy((long) 100);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime11.plusMillis(0);
        org.joda.time.DateTime dateTime17 = dateTime15.withMonthOfYear(6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1970-01-01T00:00:05.199Z", "1969-12", (-28800000), (-9));
        java.lang.String str5 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970-01-01T00:00:05.199Z" + "'", str5.equals("1970-01-01T00:00:05.199Z"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-210865896000000L));
        java.util.Locale locale8 = null;
        try {
            long long9 = offsetDateTimeField3.set(0L, "1969-12", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210866803200000L) + "'", long5 == (-210866803200000L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        long long19 = skipDateTimeField16.roundFloor((long) 1970);
        long long21 = skipDateTimeField16.roundHalfCeiling((long) 16);
        org.joda.time.DateTimeField dateTimeField22 = skipDateTimeField16.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        int int3 = dateTime1.getHourOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        org.joda.time.DateTime.Property property5 = dateTime1.era();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0", "57599999");
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 10);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) 31);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        mutableDateTime0.addMonths(2000);
        org.joda.time.DateTimeZone dateTimeZone3 = mutableDateTime0.getZone();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        int int6 = dateTime5.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withZone(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime5.minusHours(57600);
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 365 + "'", int6 == 365);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.withFields(readablePartial7);
        boolean boolean10 = dateTime6.isBefore((long) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime6.plusDays((int) (short) 10);
        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withMonthOfYear(2116);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2116 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        boolean boolean6 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gJChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) 1, locale14);
        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField11);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField11.getAsShortText((-2L), locale18);
        long long22 = skipUndoDateTimeField11.add(5L, 5);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3" + "'", str19.equals("3"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 18000005L + "'", long22 == 18000005L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        long long25 = remainderDateTimeField22.add(207359999991L, 1560345104283L);
        long long27 = remainderDateTimeField22.roundHalfEven((long) (short) 10);
        long long30 = remainderDateTimeField22.addWrapField(18059L, (-8));
        try {
            long long33 = remainderDateTimeField22.set((long) 5, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfHalfday must be in the range [0,9]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 93620913616979991L + "'", long25 == 93620913616979991L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 138059L + "'", long30 == 138059L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears(1969);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfYear();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.withFields(readablePartial7);
        boolean boolean10 = dateTime6.isBefore((long) (short) 100);
        int int11 = dateTime6.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 57600 + "'", int11 == 57600);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField8 = gregorianChronology0.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime16 = dateTime12.withDurationAdded(10L, 6);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1817658810576002000L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        try {
            org.joda.time.DateTime dateTime14 = dateTime3.withMonthOfYear((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
        mutableDateTime0.addHours(0);
        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime0.getRoundingField();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1817658810576002000L + "'", long3 == 1817658810576002000L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(dateTimeField7);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        long long7 = dateTimeZone4.adjustOffset((long) 365, true);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 365L + "'", long7 == 365L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getDayOfWeek();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.weekyear();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100);
        int int5 = dateTime4.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.plus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime4.secondOfMinute();
        int int9 = property8.getMaximumValue();
        org.joda.time.DateTime dateTime10 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = property8.getDateTime();
        boolean boolean12 = property8.isLeap();
        org.joda.time.DateTime dateTime14 = property8.addToCopy((long) 100);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.minus(readablePeriod15);
        org.joda.time.DateTime dateTime18 = dateTime14.plusMillis(0);
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 59 + "'", int9 == 59);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = property5.setCopy(1);
        org.joda.time.DateTime.Property property10 = dateTime9.weekyear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        java.lang.String str7 = offsetDateTimeField3.toString();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[weekyear]" + "'", str7.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) 'a');
        int int7 = dateTime6.getEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = dateTime6.withZoneRetainFields(dateTimeZone9);
        int int12 = dateTimeZone9.getOffsetFromLocal((long) 16);
        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone9);
        try {
            org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 960");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gJChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = gregorianChronology8.seconds();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = gJChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField14, 0);
        boolean boolean17 = skipUndoDateTimeField16.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField16);
        int int19 = skipDateTimeField18.getMinimumValue();
        long long21 = skipDateTimeField18.roundFloor((long) 1970);
        long long23 = skipDateTimeField18.roundHalfCeiling((long) 16);
        mutableDateTime1.setRounding((org.joda.time.DateTimeField) skipDateTimeField18);
        org.joda.time.ReadableDuration readableDuration25 = null;
        mutableDateTime1.add(readableDuration25, 0);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 'a');
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = mutableDateTime3.toCalendar(locale4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.dayOfWeek();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(0);
        java.util.Date date11 = dateTime8.toDate();
        org.joda.time.DateTime dateTime13 = dateTime8.withYear((int) (byte) 1);
        mutableDateTime3.setDate((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) dateTime8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(calendar5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"4\")", "");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(0);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property12 = dateTime6.secondOfMinute();
        try {
            org.joda.time.DateTime dateTime14 = dateTime6.withYearOfCentury((-1971));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1971 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(57599999, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendClockhourOfDay((int) (byte) 10);
        boolean boolean8 = dateTimeFormatterBuilder2.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology3 = julianChronology1.withUTC();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (byte) 0, (org.joda.time.Chronology) julianChronology1, locale4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        boolean boolean4 = gJChronology1.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology1);
        try {
            mutableDateTime7.setDate(0, 0, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology1.years();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DurationField durationField8 = julianChronology6.hours();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9);
        int int12 = skipUndoDateTimeField10.get((long) 22303951);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) -1);
        long long18 = offsetDateTimeField16.roundHalfCeiling((-210865896000000L));
        java.util.Locale locale21 = null;
        long long22 = offsetDateTimeField16.set((long) (byte) 1, "0", locale21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField24 = gregorianChronology23.seconds();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.year();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
        org.joda.time.DurationField durationField28 = gJChronology27.weeks();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, dateTimeField29, 0);
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField31.getAsText((int) (short) 1, locale33);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField36 = gregorianChronology35.seconds();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.year();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38);
        org.joda.time.DurationField durationField40 = gJChronology39.weeks();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology39.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology35, dateTimeField41, 0);
        org.joda.time.ReadablePartial readablePartial44 = null;
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField43.getAsShortText(readablePartial44, (int) (short) 1, locale46);
        long long50 = skipUndoDateTimeField43.add((long) (byte) -1, 0);
        java.util.Locale locale52 = null;
        java.lang.String str53 = skipUndoDateTimeField43.getAsText(1560345069015L, locale52);
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = julianChronology54.weekyear();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration58 = null;
        org.joda.time.DateTime dateTime59 = dateTime57.minus(readableDuration58);
        int int60 = dateTime59.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay61 = dateTime59.toYearMonthDay();
        long long63 = julianChronology54.set((org.joda.time.ReadablePartial) yearMonthDay61, (long) 10);
        java.util.Locale locale65 = null;
        java.lang.String str66 = skipUndoDateTimeField43.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay61, 31, locale65);
        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField69 = gregorianChronology68.seconds();
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology68.year();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.chrono.GJChronology gJChronology72 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone71);
        org.joda.time.DurationField durationField73 = gJChronology72.weeks();
        org.joda.time.DateTimeField dateTimeField74 = gJChronology72.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField76 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology68, dateTimeField74, 0);
        org.joda.time.ReadablePartial readablePartial77 = null;
        int[] intArray84 = new int[] { 3, 2000, 3, 9, (byte) 100, 100 };
        int int85 = skipUndoDateTimeField76.getMinimumValue(readablePartial77, intArray84);
        java.util.Locale locale87 = null;
        int[] intArray88 = skipUndoDateTimeField31.set((org.joda.time.ReadablePartial) yearMonthDay61, (int) (short) 0, intArray84, "4", locale87);
        int int89 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay61);
        int int90 = skipUndoDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay61);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-210866803200000L) + "'", long18 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62105097599999L) + "'", long22 == (-62105097599999L));
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1L) + "'", long50 == (-1L));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "6" + "'", str53.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1970 + "'", int60 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay61);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1036800010L + "'", long63 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "31" + "'", str66.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology68);
        org.junit.Assert.assertNotNull(durationField69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(gJChronology72);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-292269056) + "'", int89 == (-292269056));
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 12 + "'", int90 == 12);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipUndoDateTimeField14.getMinimumValue();
        int int18 = skipUndoDateTimeField14.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 11 + "'", int18 == 11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        int int44 = zeroIsMaxDateTimeField43.getMinimumValue();
        try {
            long long47 = zeroIsMaxDateTimeField43.add((-210866846400000L), (long) 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000-07:52:58 (BuddhistChronology[America/Los_Angeles])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (-9), 3);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(59);
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        org.joda.time.DateTime.Property property13 = dateTime11.millisOfSecond();
        boolean boolean14 = dateTime11.isEqualNow();
        java.util.Locale locale15 = null;
        java.util.Calendar calendar16 = dateTime11.toCalendar(locale15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(calendar16);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder0.setStandardOffset(0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder7.addCutover((-2), ' ', 10, (int) (byte) 1, 1969, true, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter6.withOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.append(dateTimeFormatter6);
        java.io.Writer writer9 = null;
        try {
            dateTimeFormatter6.printTo(writer9, (-359999900L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology8 = dateTimeParserBucket7.getChronology();
        long long9 = dateTimeParserBucket7.computeMillis();
        long long10 = dateTimeParserBucket7.computeMillis();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeParserBucket7.getZone();
        long long14 = dateTimeParserBucket7.computeMillis(true, "yearOfEra");
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        int int13 = dateTime12.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readableDuration14);
        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
        org.joda.time.DateTime dateTime18 = dateTime12.minusMinutes(0);
        mutableDateTime8.setDate((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime8.minuteOfDay();
        mutableDateTime8.add(1L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(225L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 225 + "'", int1 == 225);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withZone(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        mutableDateTime11.setZone(dateTimeZone12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.yearOfEra();
        int int17 = dateTimeFormatter9.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "GregorianChronology[UTC]", 2922789);
        int int18 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setYear(4);
        try {
            mutableDateTime11.setMinuteOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2922790) + "'", int17 == (-2922790));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-25200000) + "'", int18 == (-25200000));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withZone(dateTimeZone3);
        int int5 = dateTime4.getMinuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((int) 'a');
        java.lang.Integer int9 = dateTimeFormatter6.getPivotYear();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.weekyear();
        org.joda.time.DateTimeZone dateTimeZone12 = julianChronology10.getZone();
        long long15 = dateTimeZone12.adjustOffset((long) (byte) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter6.withZone(dateTimeZone12);
        org.joda.time.DateTime dateTime17 = dateTime4.toDateTime(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(int9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("ISOChronology[UTC]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (-8), 22296758, (-292269056), 5, 292272990);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292269056 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        boolean boolean26 = skipUndoDateTimeField20.isLeap((long) 22303951);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-210865896000000L));
        long long7 = offsetDateTimeField3.remainder((long) 2019);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) -1);
        long long13 = offsetDateTimeField11.roundHalfCeiling((-210865896000000L));
        long long15 = offsetDateTimeField11.remainder((long) 2019);
        long long17 = offsetDateTimeField11.roundHalfEven(1560345104283L);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField19 = gregorianChronology18.seconds();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.year();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gJChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology18, dateTimeField24, 0);
        org.joda.time.ReadablePartial readablePartial27 = null;
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipUndoDateTimeField26.getAsShortText(readablePartial27, (int) (short) 1, locale29);
        long long33 = skipUndoDateTimeField26.add((long) (byte) -1, 0);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField26.getAsText(1560345069015L, locale35);
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology37.weekyear();
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.minus(readableDuration41);
        int int43 = dateTime42.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay44 = dateTime42.toYearMonthDay();
        long long46 = julianChronology37.set((org.joda.time.ReadablePartial) yearMonthDay44, (long) 10);
        java.util.Locale locale48 = null;
        java.lang.String str49 = skipUndoDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay44, 31, locale48);
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50);
        org.joda.time.DurationField durationField52 = gJChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField54 = gJChronology51.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology55.weekyear();
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration59 = null;
        org.joda.time.DateTime dateTime60 = dateTime58.minus(readableDuration59);
        int int61 = dateTime60.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay62 = dateTime60.toYearMonthDay();
        long long64 = julianChronology55.set((org.joda.time.ReadablePartial) yearMonthDay62, (long) 10);
        int[] intArray66 = gJChronology51.get((org.joda.time.ReadablePartial) yearMonthDay62, 100L);
        int int67 = offsetDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay44, intArray66);
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField3.getAsText((org.joda.time.ReadablePartial) yearMonthDay44, 57599999, locale69);
        java.lang.String str72 = offsetDateTimeField3.getAsText((long) (-28800000));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210866803200000L) + "'", long5 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 30499202019L + "'", long7 == 30499202019L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-210866803200000L) + "'", long13 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 30499202019L + "'", long15 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1547424000000L + "'", long17 == 1547424000000L);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1" + "'", str30.equals("1"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "6" + "'", str36.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1970 + "'", int43 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1036800010L + "'", long46 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "31" + "'", str49.equals("31"));
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1970 + "'", int61 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1036800010L + "'", long64 == 1036800010L);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-292269056) + "'", int67 == (-292269056));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "57599999" + "'", str70.equals("57599999"));
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "1968" + "'", str72.equals("1968"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        long long19 = skipDateTimeField16.roundFloor((long) 1970);
        long long21 = skipDateTimeField16.roundHalfCeiling((long) 16);
        boolean boolean22 = skipDateTimeField16.isLenient();
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.centuryOfEra();
        int int25 = property24.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField26 = property24.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, dateTimeFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, "UTC");
        java.lang.Throwable[] throwableArray31 = illegalFieldValueException30.getSuppressed();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2922789 + "'", int25 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        java.lang.String str1 = gJChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gJChronology0.get(readablePeriod2, (long) (-194));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str1.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        int int4 = instant0.get(dateTimeField3);
        org.joda.time.Instant instant6 = instant0.minus((long) '4');
        org.joda.time.Instant instant7 = instant0.toInstant();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57601284 + "'", int4 == 57601284);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        java.lang.String str19 = skipDateTimeField16.getAsText(0L);
        int int21 = skipDateTimeField16.get((long) 365);
        long long23 = skipDateTimeField16.roundCeiling((long) 31);
        long long25 = skipDateTimeField16.remainder((long) (-2066));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4" + "'", str19.equals("4"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3600000L + "'", long23 == 3600000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3597934L + "'", long25 == 3597934L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.add((-12959982422000L), 0);
        try {
            long long42 = dividedDateTimeField36.set((long) 57599999, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for centuryOfEra must be in the range [0,5]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-12959982422000L) + "'", long39 == (-12959982422000L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(0);
        java.util.Date date5 = dateTime2.toDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime2.plus((long) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        int int15 = fixedDateTimeZone13.getStandardOffset((long) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime2.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) (-1), (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.weekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        long long9 = dateTimeZone6.adjustOffset((long) (byte) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withDefaultYear(240);
        try {
            long long14 = dateTimeFormatter10.parseMillis("+00:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        long long6 = gregorianChronology2.add((long) (short) 10, (long) 5, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gJChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField13, 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField15.getAsShortText(readablePartial16, (int) (short) 1, locale18);
        long long22 = skipUndoDateTimeField15.add((long) (byte) -1, 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField15.getAsText(1560345069015L, locale24);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.weekyear();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.minus(readableDuration30);
        int int32 = dateTime31.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        long long35 = julianChronology26.set((org.joda.time.ReadablePartial) yearMonthDay33, (long) 10);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay33, 31, locale37);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField15, 59);
        long long42 = skipUndoDateTimeField15.roundHalfEven(1036800001L);
        java.util.Locale locale43 = null;
        int int44 = skipUndoDateTimeField15.getMaximumShortTextLength(locale43);
        try {
            long long47 = skipUndoDateTimeField15.set((long) 20, "GJChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[America/Los_Angeles]\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 510L + "'", long6 == 510L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "6" + "'", str25.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1970 + "'", int32 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1036800010L + "'", long35 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31" + "'", str38.equals("31"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1036800000L + "'", long42 == 1036800000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 100);
        int int8 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        long long11 = dateTime10.getMillis();
        java.lang.String str12 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime13.setZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology16.seconds();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.year();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = gJChronology20.weeks();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22, 0);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField24.getAsShortText(readablePartial25, (int) (short) 1, locale27);
        mutableDateTime13.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTime.Property property31 = dateTime10.property(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType30, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendCenturyOfEra(1969, 2922789);
        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder36.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31" + "'", str12.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeParser37);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getDayOfMonth();
        mutableDateTime0.addWeekyears(0);
        int int4 = mutableDateTime0.getWeekOfWeekyear();
        int int5 = mutableDateTime0.getYearOfCentury();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 39 + "'", int4 == 39);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 84 + "'", int5 == 84);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        java.lang.Object obj4 = null;
        boolean boolean5 = gJChronology1.equals(obj4);
        org.joda.time.DurationField durationField6 = gJChronology1.days();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        int int3 = dateTimeFormatter0.getDefaultYear();
        java.lang.String str5 = dateTimeFormatter0.print((long) 2);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("1970-01-01T00:00:05.199Z", "1969-12", (-28800000), (-9));
        long long13 = fixedDateTimeZone11.previousTransition(133225L);
        long long15 = fixedDateTimeZone11.nextTransition((-6051600000L));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        try {
            org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1970");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12" + "'", str5.equals("1969-12"));
        org.junit.Assert.assertNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 133225L + "'", long13 == 133225L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-6051600000L) + "'", long15 == (-6051600000L));
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        long long19 = skipDateTimeField16.roundFloor((long) 1970);
        long long21 = skipDateTimeField16.roundHalfCeiling((long) 16);
        boolean boolean22 = skipDateTimeField16.isLenient();
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.centuryOfEra();
        int int25 = property24.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField26 = property24.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, dateTimeFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, "");
        illegalFieldValueException30.prependMessage("JulianChronology[UTC]");
        java.lang.Number number33 = illegalFieldValueException30.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2922789 + "'", int25 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNull(number33);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        int int2 = property1.getMaximumValueOverall();
        org.joda.time.DurationField durationField3 = property1.getLeapDurationField();
        int int4 = property1.getMaximumValue();
        org.joda.time.MutableDateTime mutableDateTime6 = property1.addWrapField(20);
        try {
            mutableDateTime6.setMinuteOfDay(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2922789 + "'", int2 == 2922789);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2922789 + "'", int4 == 2922789);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusMillis((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime1.withSecondOfMinute(6);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.hours();
        long long6 = durationField3.subtract((long) 4, 1);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType7, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599996L) + "'", long6 == (-3599996L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        java.lang.String str4 = property3.getName();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        long long12 = offsetDateTimeField10.roundHalfCeiling((-210865896000000L));
        long long14 = offsetDateTimeField10.remainder((long) 2019);
        long long16 = offsetDateTimeField10.roundHalfEven(1560345104283L);
        int int17 = dateTime5.get((org.joda.time.DateTimeField) offsetDateTimeField10);
        int int19 = offsetDateTimeField10.getLeapAmount((-210866846400000L));
        long long22 = offsetDateTimeField10.add(20L, 0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "yearOfEra" + "'", str4.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210866803200000L) + "'", long12 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30499202019L + "'", long14 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1547424000000L + "'", long16 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292272991 + "'", int17 == 292272991);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 20L + "'", long22 == 20L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes(3);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.centuryOfEra();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 100);
        int int16 = dateTime15.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.plus(readableDuration17);
        org.joda.time.DateTime.Property property19 = dateTime15.secondOfMinute();
        boolean boolean20 = mutableDateTime12.isBefore((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime12.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology23.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology23.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField29 = gregorianChronology28.seconds();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.year();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField33 = gJChronology32.weeks();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology32.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology28, dateTimeField34, 0);
        boolean boolean37 = skipUndoDateTimeField36.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, (org.joda.time.DateTimeField) skipUndoDateTimeField36);
        int int39 = skipDateTimeField38.getMinimumValue();
        long long41 = skipDateTimeField38.roundFloor((long) 1970);
        long long43 = skipDateTimeField38.roundHalfCeiling((long) 16);
        boolean boolean44 = skipDateTimeField38.isLenient();
        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime45.centuryOfEra();
        int int47 = property46.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField48 = property46.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property46.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField38, dateTimeFieldType49);
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, "UTC");
        int int53 = mutableDateTime12.get(dateTimeFieldType49);
        int int54 = dateTime11.get(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2922789 + "'", int47 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 576012 + "'", int53 == 576012);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getDayOfMonth();
        mutableDateTime0.addWeekyears(0);
        mutableDateTime0.addHours((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        mutableDateTime0.add(readablePeriod6, 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        java.lang.String str5 = gregorianChronology2.toString();
        long long10 = gregorianChronology2.getDateTimeMillis(0, 4, 3, 19);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.millisOfSecond();
        java.lang.String str14 = julianChronology12.toString();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology12, locale15, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology19 = dateTimeParserBucket18.getChronology();
        long long20 = dateTimeParserBucket18.computeMillis();
        long long21 = dateTimeParserBucket18.computeMillis();
        long long24 = dateTimeParserBucket18.computeMillis(true, "-9");
        boolean boolean25 = gregorianChronology2.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles,mdfw=1]" + "'", str5.equals("GregorianChronology[America/Los_Angeles,mdfw=1]"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62159155621981L) + "'", long10 == (-62159155621981L));
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JulianChronology[UTC]" + "'", str14.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipUndoDateTimeField8.getAsShortText(readablePartial9, (int) (short) 1, locale11);
        long long15 = skipUndoDateTimeField8.add((long) (byte) -1, 0);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField8.getAsText(1560345069015L, locale17);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.weekyear();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.minus(readableDuration23);
        int int25 = dateTime24.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay26 = dateTime24.toYearMonthDay();
        long long28 = julianChronology19.set((org.joda.time.ReadablePartial) yearMonthDay26, (long) 10);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay26, 31, locale30);
        int int33 = skipUndoDateTimeField8.get(59L);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipUndoDateTimeField8.getAsText((long) 20, locale35);
        int int37 = skipUndoDateTimeField8.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6" + "'", str18.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1036800010L + "'", long28 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31" + "'", str31.equals("31"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "4" + "'", str36.equals("4"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.nextTransition((long) 1);
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.util.Locale locale28 = null;
        java.lang.String str29 = remainderDateTimeField22.getAsText(16, locale28);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "16" + "'", str29.equals("16"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.minuteOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-210865896000000L));
        long long7 = offsetDateTimeField3.remainder((long) 2019);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        int int11 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) localDateTime10);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        mutableDateTime12.setZone(dateTimeZone13);
        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime12.dayOfMonth();
        boolean boolean17 = property16.isLeap();
        org.joda.time.MutableDateTime mutableDateTime19 = property16.add(3);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.LocalDateTime localDateTime22 = dateTime21.toLocalDateTime();
        int int23 = property16.compareTo((org.joda.time.ReadablePartial) localDateTime22);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField26 = gregorianChronology25.seconds();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.year();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = gJChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology25, dateTimeField31, 0);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray41 = new int[] { 3, 2000, 3, 9, (byte) 100, 100 };
        int int42 = skipUndoDateTimeField33.getMinimumValue(readablePartial34, intArray41);
        java.util.Locale locale44 = null;
        int[] intArray45 = offsetDateTimeField3.set((org.joda.time.ReadablePartial) localDateTime22, 0, intArray41, "3", locale44);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210866803200000L) + "'", long5 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 30499202019L + "'", long7 == 30499202019L);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292272991 + "'", int11 == 292272991);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1817658810576002000L + "'", long15 == 1817658810576002000L);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime9.toGregorianCalendar();
        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", (int) (byte) 1);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime9.dayOfYear();
        try {
            mutableDateTime9.setMinuteOfDay(57600100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600100 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.String str5 = dateTimeFormatter3.print((-1L));
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology13 = buddhistChronology6.withZone(dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter3.withChronology(chronology13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withDefaultYear(57599999);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter14.withZoneUTC();
        boolean boolean18 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "19691231T155959-0800" + "'", str5.equals("19691231T155959-0800"));
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(dateTimeZone1);
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) (-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.dayOfMonth();
        boolean boolean8 = dateTime4.equals((java.lang.Object) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology6.weekyearOfCentury();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-24) + "'", int1 == (-24));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("31");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"31/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(57599999, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendClockhourOfDay((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(19, 11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology12 = buddhistChronology5.withZone(dateTimeZone7);
        java.lang.String str13 = buddhistChronology5.toString();
        java.lang.String str14 = buddhistChronology5.toString();
        org.joda.time.Chronology chronology15 = buddhistChronology5.withUTC();
        org.joda.time.Chronology chronology16 = buddhistChronology5.withUTC();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (byte) 0, 0, 0, 0, 69, chronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str13.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str14.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(57599999, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendCenturyOfEra(100, (-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.millisOfSecond();
        java.lang.String str13 = julianChronology11.toString();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology11, locale14, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology18 = dateTimeParserBucket17.getChronology();
        boolean boolean19 = buddhistChronology9.equals((java.lang.Object) dateTimeParserBucket17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = gJChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology21.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = gregorianChronology26.seconds();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.year();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = gJChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, dateTimeField32, 0);
        boolean boolean35 = skipUndoDateTimeField34.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField34);
        int int37 = skipDateTimeField36.getMinimumValue();
        long long39 = skipDateTimeField36.roundFloor((long) 1970);
        long long41 = skipDateTimeField36.roundHalfCeiling((long) 16);
        boolean boolean42 = skipDateTimeField36.isLenient();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.centuryOfEra();
        int int45 = property44.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField46 = property44.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property44.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType47);
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, "");
        dateTimeParserBucket17.saveField(dateTimeFieldType47, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType47, 1968, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder8.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder58.appendDayOfWeek((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap63 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap63);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder58.appendTimeZoneShortName(strMap63);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder8.appendTimeZoneName(strMap63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JulianChronology[UTC]" + "'", str13.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2922789 + "'", int45 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(strMap63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) '#');
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("GregorianChronology[America/Los_Angeles,mdfw=1]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = gJChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology9.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.seconds();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.year();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gJChronology18.weeks();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField20, 0);
        boolean boolean23 = skipUndoDateTimeField22.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, (org.joda.time.DateTimeField) skipUndoDateTimeField22);
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField22, 4);
        org.joda.time.Chronology chronology27 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        mutableDateTime4.setZone(dateTimeZone5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.yearOfEra();
        int int10 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "GregorianChronology[UTC]", 2922789);
        boolean boolean11 = buddhistChronology0.equals((java.lang.Object) "GregorianChronology[UTC]");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long18 = fixedDateTimeZone16.nextTransition((long) (-2));
        int int20 = fixedDateTimeZone16.getStandardOffset((long) 10);
        org.joda.time.Chronology chronology21 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.dayOfMonth();
        int int32 = fixedDateTimeZone16.getOffset((org.joda.time.ReadableInstant) mutableDateTime30);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-2922790) + "'", int10 == (-2922790));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2L) + "'", long18 == (-2L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.Instant instant3 = dateTime1.toInstant();
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withTime((int) 'a', 69, (-1971), 27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime19 = property17.set(2922789);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gJChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology22.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = gregorianChronology27.seconds();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.year();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = gJChronology31.weeks();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField33, 0);
        boolean boolean36 = skipUndoDateTimeField35.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        int int38 = skipDateTimeField37.getMinimumValue();
        long long40 = skipDateTimeField37.roundFloor((long) 1970);
        long long42 = skipDateTimeField37.roundHalfCeiling((long) 16);
        boolean boolean43 = skipDateTimeField37.isLenient();
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.centuryOfEra();
        int int46 = property45.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField47 = property45.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property45.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField37, dateTimeFieldType48);
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime19.property(dateTimeFieldType48);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType48);
        long long54 = zeroIsMaxDateTimeField51.getDifferenceAsLong((long) 22303951, (long) 12);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2922789 + "'", int46 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        try {
            long long12 = gregorianChronology2.getDateTimeMillis(59, 59, 0, (int) (byte) 100, 69, (int) (short) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.weekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        long long9 = dateTimeZone6.adjustOffset((long) (byte) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1969-12-31T16:40:40.588-08:00");
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) ' ', dateTimeZone1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone4);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology1, locale9, (java.lang.Integer) 57599);
        java.lang.Object obj12 = dateTimeParserBucket11.saveState();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone13);
        java.util.GregorianCalendar gregorianCalendar15 = mutableDateTime14.toGregorianCalendar();
        int int18 = dateTimeFormatter5.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime14, "", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        mutableDateTime14.setZoneRetainFields(dateTimeZone22);
        boolean boolean24 = julianChronology1.equals((java.lang.Object) dateTimeZone22);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology25.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (short) -1);
        long long30 = offsetDateTimeField28.roundHalfCeiling((-210865896000000L));
        long long32 = offsetDateTimeField28.remainder((long) 2019);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
        int int36 = offsetDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) localDateTime35);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2) + "'", int18 == (-2));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-210866803200000L) + "'", long30 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 30499202019L + "'", long32 == 30499202019L);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 292272991 + "'", int36 == 292272991);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        mutableDateTime1.setZone(dateTimeZone2);
        mutableDateTime1.setMillisOfSecond((int) (byte) 100);
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime1, "6", 57599999);
        mutableDateTime1.add((long) 365);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-57600000) + "'", int8 == (-57600000));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("UTC", true);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder5.addCutover((-8), '#', 90, (int) 'a', 22303, true, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("100");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1969-12");
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant5 = instant1.withDurationAdded(readableDuration3, (int) (short) 10);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        org.joda.time.DateTime dateTime13 = property11.addToCopy(0);
        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(1969);
        org.joda.time.DateTime.Property property16 = dateTime13.dayOfMonth();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readableDuration11);
        int int13 = dateTime12.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        int[] intArray20 = new int[] { (byte) 1, 5, ' ', (short) -1 };
        int[] intArray22 = skipUndoDateTimeField8.addWrapField((org.joda.time.ReadablePartial) yearMonthDay14, 0, intArray20, 4);
        org.joda.time.DurationField durationField23 = skipUndoDateTimeField8.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1970 + "'", int13 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        java.lang.String str8 = property5.getAsShortText();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        java.lang.String str7 = offsetDateTimeField3.toString();
        long long9 = offsetDateTimeField3.roundCeiling((long) 12);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[weekyear]" + "'", str7.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 950400000L + "'", long9 == 950400000L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(57601284, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57601284 + "'", int2 == 57601284);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.eras();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 59, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.Interval interval5 = property4.toInterval();
        org.joda.time.DateTime dateTime7 = property4.setCopy(16);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.centuryOfEra();
        int int6 = property5.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField7);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2922789 + "'", int6 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "hourOfHalfday", "");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        mutableDateTime1.setZone(dateTimeZone2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime1.dayOfMonth();
        java.lang.String str6 = property5.getAsString();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText(59L, locale10);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1817658810576002000L + "'", long4 == 1817658810576002000L);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "27" + "'", str6.equals("27"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31" + "'", str11.equals("31"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays(4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        boolean boolean17 = gJChronology14.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.dayOfYear();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology14.hourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime12.toDateTime((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTime dateTime22 = dateTime12.withWeekyear(365);
        try {
            org.joda.time.DateTime dateTime24 = dateTime22.withDayOfYear(292272990);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272990 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.eras();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 59, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.Interval interval5 = property4.toInterval();
        org.joda.time.ReadableInterval readableInterval6 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval5);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(readableInterval6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone4.getID();
        long long10 = fixedDateTimeZone4.nextTransition((long) 1);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
        java.lang.String str5 = property4.getAsString();
        org.joda.time.DurationField durationField6 = property4.getDurationField();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1817658810576002000L + "'", long3 == 1817658810576002000L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "27" + "'", str5.equals("27"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.getDifferenceAsLong(1560345103593L, 6975L);
        java.lang.String str47 = zeroIsMaxDateTimeField43.getName();
        long long49 = zeroIsMaxDateTimeField43.remainder(1560345097963L);
        boolean boolean50 = zeroIsMaxDateTimeField43.isSupported();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 26005751L + "'", long46 == 26005751L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "centuryOfEra" + "'", str47.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 37963L + "'", long49 == 37963L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 100);
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        mutableDateTime1.setZone(dateTimeZone2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
        mutableDateTime1.addYears((int) 'a');
        int int8 = mutableDateTime1.getWeekyear();
        mutableDateTime1.setMillisOfSecond(0);
        try {
            mutableDateTime1.setDayOfYear(57599);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1817658810576002000L + "'", long4 == 1817658810576002000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57601381 + "'", int8 == 57601381);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = gregorianChronology2.days();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfMinute((-24));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getDayOfMonth();
        mutableDateTime0.addWeekyears(0);
        mutableDateTime0.addHours((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 100);
        int int10 = dateTime9.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime9.secondOfMinute();
        boolean boolean14 = mutableDateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime16 = dateTime9.withYear((int) (byte) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.dayOfMonth();
        int int18 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime20 = dateTime16.minusSeconds((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gJChronology22.weeks();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.DateTimeFormat.fullDate();
        boolean boolean25 = gJChronology22.equals((java.lang.Object) dateTimeFormatter24);
        java.lang.String str26 = dateTime20.toString(dateTimeFormatter24);
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Friday, December 31, -0001" + "'", str26.equals("Friday, December 31, -0001"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.getDifferenceAsLong(1560345103593L, 6975L);
        long long49 = zeroIsMaxDateTimeField43.add((long) 31, (long) 16320);
        org.joda.time.DurationField durationField50 = zeroIsMaxDateTimeField43.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 26005751L + "'", long46 == 26005751L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 979200031L + "'", long49 == 979200031L);
        org.junit.Assert.assertNull(durationField50);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime3 = dateTimeFormatter1.parseMutableDateTime("9");
        long long4 = mutableDateTime3.getMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 61200000L + "'", long4 == 61200000L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.year();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getDayOfMonth();
        mutableDateTime0.addWeekyears(0);
        mutableDateTime0.addMillis((int) (byte) 0);
        mutableDateTime0.addYears((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = gJChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfHalfday();
        org.joda.time.DurationField durationField12 = gJChronology9.years();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) julianChronology14);
        org.joda.time.DurationField durationField16 = julianChronology14.hours();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology14.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField17);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField18.getAsShortText((long) 57599, locale20);
        int int22 = mutableDateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField18);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "12" + "'", str21.equals("12"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        java.lang.String str3 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime19 = property17.set(2922789);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gJChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology22.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = gregorianChronology27.seconds();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.year();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = gJChronology31.weeks();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField33, 0);
        boolean boolean36 = skipUndoDateTimeField35.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        int int38 = skipDateTimeField37.getMinimumValue();
        long long40 = skipDateTimeField37.roundFloor((long) 1970);
        long long42 = skipDateTimeField37.roundHalfCeiling((long) 16);
        boolean boolean43 = skipDateTimeField37.isLenient();
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.centuryOfEra();
        int int46 = property45.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField47 = property45.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property45.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField37, dateTimeFieldType48);
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime19.property(dateTimeFieldType48);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType48);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType48, (int) '#', 292272991, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for centuryOfEra must be in the range [292272991,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2922789 + "'", int46 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(property50);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear(69);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime1.plusMillis(960);
        int int10 = dateTime1.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weeks();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology2.get(readablePeriod5, (-3599996L), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        java.lang.String str19 = skipDateTimeField16.getAsText(0L);
        int int21 = skipDateTimeField16.get((long) 365);
        long long23 = skipDateTimeField16.roundCeiling((long) 31);
        long long25 = skipDateTimeField16.roundHalfCeiling((long) 57600);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipDateTimeField16.getAsText((long) (-9), locale27);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4" + "'", str19.equals("4"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3600000L + "'", long23 == 3600000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "3" + "'", str28.equals("3"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 10, chronology1, locale2, (java.lang.Integer) (-1971));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-210865896000000L));
        long long7 = offsetDateTimeField3.remainder((long) 2019);
        long long9 = offsetDateTimeField3.roundHalfEven(1560345104283L);
        long long11 = offsetDateTimeField3.roundHalfCeiling((long) (-2922790));
        long long14 = offsetDateTimeField3.set((long) 2000, 57600100);
        int int16 = offsetDateTimeField3.get((long) (short) 100);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210866803200000L) + "'", long5 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 30499202019L + "'", long7 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1547424000000L + "'", long9 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 950400000L + "'", long11 == 950400000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1817658810576002000L + "'", long14 == 1817658810576002000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1968 + "'", int16 == 1968);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime0.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.roundHalfFloor();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.dayOfYear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gJChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) 1, locale14);
        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField11);
        java.lang.String str17 = mutableDateTime0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "57601284-09-27T17:00:00.000-07:00" + "'", str17.equals("57601284-09-27T17:00:00.000-07:00"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 10);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str11 = fixedDateTimeZone4.getNameKey((long) 5);
        boolean boolean12 = fixedDateTimeZone4.isFixed();
        long long16 = fixedDateTimeZone4.convertLocalToUTC(18000005L, false, 1560345104090L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "GregorianChronology[UTC]" + "'", str11.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 18000005L + "'", long16 == 18000005L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        int int4 = dateTime3.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime3.minus((long) 960);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withFieldAdded(durationFieldType8, 84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        long long12 = skipUndoDateTimeField8.add(2440588L, 0);
        java.util.Locale locale13 = null;
        int int14 = skipUndoDateTimeField8.getMaximumTextLength(locale13);
        java.util.Locale locale17 = null;
        try {
            long long18 = skipUndoDateTimeField8.set((long) 5, "hi!", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2440588L + "'", long12 == 2440588L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = property5.getDateTime();
        org.joda.time.DateTime dateTime10 = dateTime8.minusHours((-28800000));
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(22303951);
        org.joda.time.DateTime.Property property13 = dateTime10.millisOfSecond();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        try {
            long long27 = remainderDateTimeField22.set((long) 240, 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for hourOfHalfday must be in the range [0,9]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder0.setStandardOffset(10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder7.setStandardOffset(5);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder7.addRecurringSavings("DateTimeField[weekyear]", 4, 9, 0, '#', 0, (int) (short) -1, 1969, false, 58528);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder20);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        int int7 = dateTime6.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.withWeekyear((int) (byte) 1);
        org.joda.time.DateTime.Property property10 = dateTime6.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        long long35 = remainderDateTimeField22.roundHalfFloor((long) 57600);
        int int38 = remainderDateTimeField22.getDifference(42L, (long) 69);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 60000L + "'", long35 == 60000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime.Property property2 = dateTime1.minuteOfDay();
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusMillis((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime1.withCenturyOfEra((int) '#');
        int int11 = dateTime1.getMinuteOfDay();
        org.joda.time.DateTime dateTime13 = dateTime1.minusMinutes(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 960 + "'", int11 == 960);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder5.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendDayOfWeek((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((-1L));
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        long long8 = dateTimeZone5.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology10 = buddhistChronology3.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withChronology(chronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12, (int) (byte) 1);
        long long18 = gregorianChronology14.add((long) (short) 10, (long) 5, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        org.joda.time.ReadablePartial readablePartial28 = null;
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField27.getAsShortText(readablePartial28, (int) (short) 1, locale30);
        long long34 = skipUndoDateTimeField27.add((long) (byte) -1, 0);
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipUndoDateTimeField27.getAsText(1560345069015L, locale36);
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.weekyear();
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.DateTime dateTime43 = dateTime41.minus(readableDuration42);
        int int44 = dateTime43.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        long long47 = julianChronology38.set((org.joda.time.ReadablePartial) yearMonthDay45, (long) 10);
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipUndoDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay45, 31, locale49);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, (org.joda.time.DateTimeField) skipUndoDateTimeField27, 59);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, (org.joda.time.DateTimeField) skipUndoDateTimeField27);
        java.util.Locale locale55 = null;
        java.lang.String str56 = skipUndoDateTimeField27.getAsText((-2922790), locale55);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "19691231T155959-0800" + "'", str2.equals("19691231T155959-0800"));
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 510L + "'", long18 == 510L);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "6" + "'", str37.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1970 + "'", int44 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1036800010L + "'", long47 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31" + "'", str50.equals("31"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "-2922790" + "'", str56.equals("-2922790"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        java.util.Locale locale1 = null;
        java.util.Calendar calendar2 = mutableDateTime0.toCalendar(locale1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
        int int8 = dateTime7.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime7.toYearMonthDay();
        long long10 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) julianChronology13);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(510L, (org.joda.time.Chronology) julianChronology13);
        boolean boolean16 = property3.equals((java.lang.Object) julianChronology13);
        org.joda.time.MutableDateTime mutableDateTime17 = property3.roundHalfCeiling();
        org.junit.Assert.assertNotNull(calendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 21037717715L + "'", long10 == 21037717715L);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        mutableDateTime1.setZone(dateTimeZone2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime1.add(readablePeriod7, 57600100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1817658810576002000L + "'", long4 == 1817658810576002000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gJChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gJChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField13, 0);
        boolean boolean16 = skipUndoDateTimeField15.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField15);
        java.lang.String str18 = skipDateTimeField17.toString();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        mutableDateTime19.setZone(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField27 = gJChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField28, 0);
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField30.getAsShortText(readablePartial31, (int) (short) 1, locale33);
        mutableDateTime19.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField30);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipUndoDateTimeField30.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField17, dateTimeFieldType36, 59);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str18.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("4");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gJChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField9, 0);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField11.getAsText((int) (short) 1, locale13);
        jodaTimePermission1.checkGuard((java.lang.Object) str14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) str14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.set(2922789);
        int int5 = property2.getMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2922789 + "'", int5 == 2922789);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        try {
            long long10 = julianChronology0.getDateTimeMillis(3, 0, 69, 59, (-2), 9, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        java.lang.String str17 = skipDateTimeField16.toString();
        org.joda.time.DurationField durationField18 = skipDateTimeField16.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str17.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(4);
        org.joda.time.Chronology chronology5 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(chronology5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1969-12");
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTimeISO();
        try {
            mutableDateTime2.setDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        java.util.GregorianCalendar gregorianCalendar10 = mutableDateTime9.toGregorianCalendar();
        int int13 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        mutableDateTime9.setZoneRetainFields(dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        long long31 = skipUndoDateTimeField27.add((long) (short) 1, 0L);
        long long34 = skipUndoDateTimeField27.add(0L, 0L);
        int int37 = skipUndoDateTimeField27.getDifference(0L, (long) 4);
        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField27);
        org.joda.time.ReadableDuration readableDuration39 = null;
        mutableDateTime9.add(readableDuration39, (int) ' ');
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime9.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(property42);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        java.lang.Object obj4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        long long10 = dateTimeZone7.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology12 = buddhistChronology5.withZone(dateTimeZone7);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(obj4, dateTimeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.seconds();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.year();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField19 = gJChronology18.weeks();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField20, 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField22.getAsText((int) (short) 1, locale24);
        mutableDateTime13.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField22);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = gregorianChronology27.seconds();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.year();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = gJChronology31.weeks();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField33, 0);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.minus(readableDuration38);
        int int40 = dateTime39.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime39.toYearMonthDay();
        int[] intArray47 = new int[] { (byte) 1, 5, ' ', (short) -1 };
        int[] intArray49 = skipUndoDateTimeField35.addWrapField((org.joda.time.ReadablePartial) yearMonthDay41, 0, intArray47, 4);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipUndoDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay41, 1970, locale51);
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField54 = gregorianChronology53.seconds();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology53.year();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone56);
        org.joda.time.DurationField durationField58 = gJChronology57.weeks();
        org.joda.time.DateTimeField dateTimeField59 = gJChronology57.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology53, dateTimeField59, 0);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration64 = null;
        org.joda.time.DateTime dateTime65 = dateTime63.minus(readableDuration64);
        int int66 = dateTime65.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay67 = dateTime65.toYearMonthDay();
        int[] intArray73 = new int[] { (byte) 1, 5, ' ', (short) -1 };
        int[] intArray75 = skipUndoDateTimeField61.addWrapField((org.joda.time.ReadablePartial) yearMonthDay67, 0, intArray73, 4);
        gregorianChronology0.validate((org.joda.time.ReadablePartial) yearMonthDay41, intArray73);
        int int77 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1" + "'", str25.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1970 + "'", int40 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1970" + "'", str52.equals("1970"));
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1970 + "'", int66 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay67);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 4 + "'", int77 == 4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(921600L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((-1L));
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        long long8 = dateTimeZone5.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology10 = buddhistChronology3.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withChronology(chronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withDefaultYear(57599999);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter11.withZoneUTC();
        try {
            org.joda.time.LocalTime localTime16 = dateTimeFormatter14.parseLocalTime("1969-12-31T16:40:40.588-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:40:40.588-08:00\" is malformed at \"-12-31T16:40:40.588-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "19691231T155959-0800" + "'", str2.equals("19691231T155959-0800"));
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-210865896000000L));
        java.util.Locale locale8 = null;
        long long9 = offsetDateTimeField3.set((long) (byte) 1, "0", locale8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gregorianChronology10.seconds();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.year();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField16, 0);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField18.getAsText((int) (short) 1, locale20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField27 = gJChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField28, 0);
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField30.getAsShortText(readablePartial31, (int) (short) 1, locale33);
        long long37 = skipUndoDateTimeField30.add((long) (byte) -1, 0);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipUndoDateTimeField30.getAsText(1560345069015L, locale39);
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField42 = julianChronology41.weekyear();
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration45 = null;
        org.joda.time.DateTime dateTime46 = dateTime44.minus(readableDuration45);
        int int47 = dateTime46.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        long long50 = julianChronology41.set((org.joda.time.ReadablePartial) yearMonthDay48, (long) 10);
        java.util.Locale locale52 = null;
        java.lang.String str53 = skipUndoDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay48, 31, locale52);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField56 = gregorianChronology55.seconds();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology55.year();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58);
        org.joda.time.DurationField durationField60 = gJChronology59.weeks();
        org.joda.time.DateTimeField dateTimeField61 = gJChronology59.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField63 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology55, dateTimeField61, 0);
        org.joda.time.ReadablePartial readablePartial64 = null;
        int[] intArray71 = new int[] { 3, 2000, 3, 9, (byte) 100, 100 };
        int int72 = skipUndoDateTimeField63.getMinimumValue(readablePartial64, intArray71);
        java.util.Locale locale74 = null;
        int[] intArray75 = skipUndoDateTimeField18.set((org.joda.time.ReadablePartial) yearMonthDay48, (int) (short) 0, intArray71, "4", locale74);
        int int76 = offsetDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay48);
        org.joda.time.DurationField durationField77 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210866803200000L) + "'", long5 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105097599999L) + "'", long9 == (-62105097599999L));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "6" + "'", str40.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1970 + "'", int47 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1036800010L + "'", long50 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31" + "'", str53.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-292269056) + "'", int76 == (-292269056));
        org.junit.Assert.assertNotNull(durationField77);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 42L, (java.lang.Number) 2066, number3);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "42" + "'", str5.equals("42"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.getMutableDateTime();
        int int5 = mutableDateTime4.getDayOfMonth();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime4.millisOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        boolean boolean4 = gJChronology1.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.hourOfDay();
        try {
            long long14 = gJChronology1.getDateTimeMillis((-24), 0, 59, 1968, 57601381, 0, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1968 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 100);
        int int8 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        long long11 = dateTime10.getMillis();
        java.lang.String str12 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime13.setZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology16.seconds();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.year();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = gJChronology20.weeks();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22, 0);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField24.getAsShortText(readablePartial25, (int) (short) 1, locale27);
        mutableDateTime13.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTime.Property property31 = dateTime10.property(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType30, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendCenturyOfEra(1969, 2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendPattern("57599999");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31" + "'", str12.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        long long6 = gregorianChronology2.add((long) (short) 10, (long) 5, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gJChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField13, 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField15.getAsShortText(readablePartial16, (int) (short) 1, locale18);
        long long22 = skipUndoDateTimeField15.add((long) (byte) -1, 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField15.getAsText(1560345069015L, locale24);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.weekyear();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.minus(readableDuration30);
        int int32 = dateTime31.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        long long35 = julianChronology26.set((org.joda.time.ReadablePartial) yearMonthDay33, (long) 10);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay33, 31, locale37);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField15, 59);
        org.joda.time.DurationField durationField41 = gregorianChronology2.days();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology2.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField42);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 510L + "'", long6 == 510L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "6" + "'", str25.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1970 + "'", int32 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1036800010L + "'", long35 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31" + "'", str38.equals("31"));
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        int int7 = dateTime6.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime6.withWeekyear((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(0);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.withYearOfCentury((int) '4');
        int int8 = dateTime7.getDayOfWeek();
        org.joda.time.DateTime dateTime10 = dateTime7.plusMinutes((-2066));
        org.joda.time.DateTime dateTime12 = dateTime7.withSecondOfMinute(27);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        long long12 = skipUndoDateTimeField8.add((long) (short) 1, 0L);
        long long15 = skipUndoDateTimeField8.add(0L, 0L);
        boolean boolean16 = skipUndoDateTimeField8.isSupported();
        long long18 = skipUndoDateTimeField8.roundFloor((long) 2066);
        long long20 = skipUndoDateTimeField8.roundFloor(1560345103290L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560344400000L + "'", long20 == 1560344400000L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        mutableDateTime8.setDayOfYear((int) '#');
        mutableDateTime8.addMillis(16);
        try {
            org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime1.plusMillis(960);
        org.joda.time.DateMidnight dateMidnight10 = dateTime9.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateMidnight10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.millisOfSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        boolean boolean8 = julianChronology0.equals((java.lang.Object) dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gJChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7, 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.set(2922789);
        org.joda.time.MutableDateTime mutableDateTime5 = property2.roundFloor();
        try {
            mutableDateTime5.setMinuteOfHour(57601284);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57601284 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        long long25 = remainderDateTimeField22.add(207359999991L, 1560345104283L);
        long long27 = remainderDateTimeField22.roundHalfEven(0L);
        java.util.Locale locale30 = null;
        try {
            long long31 = remainderDateTimeField22.set((long) 57601381, "Pacific Standard Time", locale30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 93620913616979991L + "'", long25 == 93620913616979991L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.add((-12959982422000L), 0);
        int int40 = dividedDateTimeField36.getMinimumValue();
        long long43 = dividedDateTimeField36.add(1560345103951L, 61200000L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-12959982422000L) + "'", long39 == (-12959982422000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 38280345103951L + "'", long43 == 38280345103951L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (-9), 3);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(59);
        org.joda.time.DateTime.Property property12 = dateTime9.secondOfDay();
        org.joda.time.DateTime dateTime13 = property12.roundCeilingCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(0);
        org.joda.time.DateTime.Property property16 = dateTime13.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(225, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 225 + "'", int2 == 225);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField4 = gJChronology1.years();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) julianChronology6);
        org.joda.time.DurationField durationField8 = julianChronology6.hours();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology6.clockhourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField10.getAsText((long) 90, locale12);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12" + "'", str13.equals("12"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime19 = property17.set(2922789);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gJChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology22.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = gregorianChronology27.seconds();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.year();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = gJChronology31.weeks();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField33, 0);
        boolean boolean36 = skipUndoDateTimeField35.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        int int38 = skipDateTimeField37.getMinimumValue();
        long long40 = skipDateTimeField37.roundFloor((long) 1970);
        long long42 = skipDateTimeField37.roundHalfCeiling((long) 16);
        boolean boolean43 = skipDateTimeField37.isLenient();
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.centuryOfEra();
        int int46 = property45.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField47 = property45.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property45.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField37, dateTimeFieldType48);
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime19.property(dateTimeFieldType48);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType48);
        boolean boolean53 = zeroIsMaxDateTimeField51.isLeap(921600L);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2922789 + "'", int46 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        java.util.Locale locale1 = null;
        java.util.Calendar calendar2 = mutableDateTime0.toCalendar(locale1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        java.util.Date date8 = dateTime5.toDate();
        org.joda.time.DateTime dateTime10 = dateTime5.withYear((int) (byte) 1);
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, (org.joda.time.DateTimeField) skipUndoDateTimeField27);
        int int30 = skipDateTimeField29.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, (org.joda.time.DateTimeField) skipDateTimeField29, 0);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.minus(readableDuration35);
        org.joda.time.DateTime dateTime38 = dateTime36.minusWeeks(365);
        org.joda.time.DateTime.Property property39 = dateTime38.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.LocalDateTime localDateTime42 = dateTimeFormatter40.parseLocalDateTime("1969-12");
        int int43 = property39.compareTo((org.joda.time.ReadablePartial) localDateTime42);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44);
        int int46 = gJChronology45.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.centuryOfEra();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) (byte) 100);
        int int51 = dateTime50.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration52 = null;
        org.joda.time.DateTime dateTime53 = dateTime50.plus(readableDuration52);
        org.joda.time.DateTime.Property property54 = dateTime50.secondOfMinute();
        boolean boolean55 = mutableDateTime47.isBefore((org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.DateTime.Property property56 = dateTime50.millisOfSecond();
        org.joda.time.DateTime dateTime58 = dateTime50.minusHours((int) (byte) 100);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.DateTime dateTime62 = dateTime60.minus(readableDuration61);
        int int63 = dateTime62.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay64 = dateTime62.toYearMonthDay();
        org.joda.time.DateTime dateTime65 = dateTime58.withFields((org.joda.time.ReadablePartial) yearMonthDay64);
        int[] intArray67 = gJChronology45.get((org.joda.time.ReadablePartial) yearMonthDay64, (-359999900L));
        try {
            int int68 = skipDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDateTime42, intArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(calendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(localDateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1970 + "'", int63 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(intArray67);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        illegalFieldValueException2.prependMessage("");
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("UTC", true);
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant5 = instant2.withDurationAdded(readableDuration3, 292272990);
        org.joda.time.DateTime dateTime6 = instant2.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        mutableDateTime4.setZone(dateTimeZone5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.yearOfEra();
        int int10 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "GregorianChronology[UTC]", 2922789);
        boolean boolean11 = buddhistChronology0.equals((java.lang.Object) "GregorianChronology[UTC]");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long18 = fixedDateTimeZone16.nextTransition((long) (-2));
        int int20 = fixedDateTimeZone16.getStandardOffset((long) 10);
        org.joda.time.Chronology chronology21 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-2922790) + "'", int10 == (-2922790));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2L) + "'", long18 == (-2L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.withYearOfCentury((int) '4');
        org.joda.time.DateTime.Property property8 = dateTime1.year();
        org.joda.time.Instant instant9 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        mutableDateTime10.setZone(dateTimeZone11);
        long long13 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime10);
        boolean boolean14 = instant9.isBefore((org.joda.time.ReadableInstant) mutableDateTime10);
        mutableDateTime10.addYears((int) 'a');
        int int17 = mutableDateTime10.getWeekyear();
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime10.year();
        java.lang.String str19 = property18.toString();
        org.joda.time.DurationField durationField20 = property18.getRangeDurationField();
        org.joda.time.MutableDateTime mutableDateTime22 = property18.add((-2));
        boolean boolean23 = property8.equals((java.lang.Object) (-2));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1817658810576002000L + "'", long13 == 1817658810576002000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 57601381 + "'", int17 == 57601381);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[year]" + "'", str19.equals("Property[year]"));
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(mutableDateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.monthOfYear();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime0.centuryOfEra();
        int int6 = mutableDateTime0.getCenturyOfEra();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1817658810576002000L + "'", long3 == 1817658810576002000L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 576012 + "'", int6 == 576012);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.add((-719528L), 1560345102464L);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField43.getLeapDurationField();
        try {
            long long50 = zeroIsMaxDateTimeField43.set((long) 1969, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [1,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 93620706147120472L + "'", long46 == 93620706147120472L);
        org.junit.Assert.assertNull(durationField47);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.add((-719528L), 1560345102464L);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField43.getLeapDurationField();
        int int49 = zeroIsMaxDateTimeField43.getMaximumValue((long) 1968);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 93620706147120472L + "'", long46 == 93620706147120472L);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        long long25 = remainderDateTimeField22.add(207359999991L, 1560345104283L);
        long long27 = remainderDateTimeField22.roundHalfEven((long) (short) 10);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = remainderDateTimeField22.getMaximumValue(readablePartial28);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology32.millisOfSecond();
        java.lang.String str34 = julianChronology32.toString();
        java.util.Locale locale35 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology32, locale35, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology39 = dateTimeParserBucket38.getChronology();
        boolean boolean40 = buddhistChronology30.equals((java.lang.Object) dateTimeParserBucket38);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField43 = gJChronology42.weeks();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology42.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology42.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField46 = gJChronology42.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField48 = gregorianChronology47.seconds();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.year();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50);
        org.joda.time.DurationField durationField52 = gJChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology47, dateTimeField53, 0);
        boolean boolean56 = skipUndoDateTimeField55.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology42, (org.joda.time.DateTimeField) skipUndoDateTimeField55);
        int int58 = skipDateTimeField57.getMinimumValue();
        long long60 = skipDateTimeField57.roundFloor((long) 1970);
        long long62 = skipDateTimeField57.roundHalfCeiling((long) 16);
        boolean boolean63 = skipDateTimeField57.isLenient();
        org.joda.time.MutableDateTime mutableDateTime64 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property65 = mutableDateTime64.centuryOfEra();
        int int66 = property65.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField67 = property65.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property65.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField57, dateTimeFieldType68);
        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType68, "");
        dateTimeParserBucket38.saveField(dateTimeFieldType68, (int) (short) 1);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType68, 8);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 93620913616979991L + "'", long25 == 93620913616979991L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "JulianChronology[UTC]" + "'", str34.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2922789 + "'", int66 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (-9), 3);
        org.joda.time.Chronology chronology10 = dateTime9.getChronology();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test429");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        long long4 = dateTimeZone1.convertLocalToUTC((long) (short) 10, true);
//        boolean boolean6 = dateTimeZone1.isStandardOffset((-28800000L));
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = dateTimeZone1.getShortName((long) 292272991, locale8);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks(365);
        org.joda.time.DateTime dateTime7 = dateTime3.plusMinutes((int) '#');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
        boolean boolean5 = property4.isLeap();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundCeiling();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.add((int) (short) 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (byte) 100);
        int int11 = dateTime10.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withZone(dateTimeZone12);
        org.joda.time.DateTime.Property property14 = dateTime13.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime13.withZoneRetainFields(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now(dateTimeZone15);
        mutableDateTime8.setZone(dateTimeZone15);
        int int20 = mutableDateTime8.getWeekOfWeekyear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1817658810576002000L + "'", long3 == 1817658810576002000L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 39 + "'", int20 == 39);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset((long) 20);
        long long10 = fixedDateTimeZone4.convertLocalToUTC(1560347071176L, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560347071176L + "'", long10 == 1560347071176L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        java.lang.String str17 = skipDateTimeField16.toString();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        mutableDateTime18.setZone(dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.seconds();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.year();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField26 = gJChronology25.weeks();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField27, 0);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField29.getAsShortText(readablePartial30, (int) (short) 1, locale32);
        mutableDateTime18.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField29);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, dateTimeFieldType35, 59);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38);
        int int40 = gJChronology39.getMinimumDaysInFirstWeek();
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime41.centuryOfEra();
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (byte) 100);
        int int45 = dateTime44.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.DateTime dateTime47 = dateTime44.plus(readableDuration46);
        org.joda.time.DateTime.Property property48 = dateTime44.secondOfMinute();
        boolean boolean49 = mutableDateTime41.isBefore((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTime.Property property50 = dateTime44.millisOfSecond();
        org.joda.time.DateTime dateTime52 = dateTime44.minusHours((int) (byte) 100);
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration55 = null;
        org.joda.time.DateTime dateTime56 = dateTime54.minus(readableDuration55);
        int int57 = dateTime56.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay58 = dateTime56.toYearMonthDay();
        org.joda.time.DateTime dateTime59 = dateTime52.withFields((org.joda.time.ReadablePartial) yearMonthDay58);
        int[] intArray61 = gJChronology39.get((org.joda.time.ReadablePartial) yearMonthDay58, (-359999900L));
        int[] intArray63 = new int[] {};
        try {
            int[] intArray65 = offsetDateTimeField37.add((org.joda.time.ReadablePartial) yearMonthDay58, 31, intArray63, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str17.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1970 + "'", int57 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "0", "1969-12-31T15:59:59.999-08:00");
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "0", "0");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getShortName(locale10, "2116", "BuddhistChronology[America/Los_Angeles]");
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (short) -1);
        long long10 = offsetDateTimeField8.roundHalfCeiling((-210865896000000L));
        long long12 = offsetDateTimeField8.remainder((long) 2019);
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) -1);
        long long18 = offsetDateTimeField16.roundHalfCeiling((-210865896000000L));
        long long20 = offsetDateTimeField16.remainder((long) 2019);
        long long22 = offsetDateTimeField16.roundHalfEven(1560345104283L);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField24 = gregorianChronology23.seconds();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.year();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
        org.joda.time.DurationField durationField28 = gJChronology27.weeks();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, dateTimeField29, 0);
        org.joda.time.ReadablePartial readablePartial32 = null;
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipUndoDateTimeField31.getAsShortText(readablePartial32, (int) (short) 1, locale34);
        long long38 = skipUndoDateTimeField31.add((long) (byte) -1, 0);
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipUndoDateTimeField31.getAsText(1560345069015L, locale40);
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = julianChronology42.weekyear();
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.DateTime dateTime47 = dateTime45.minus(readableDuration46);
        int int48 = dateTime47.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay49 = dateTime47.toYearMonthDay();
        long long51 = julianChronology42.set((org.joda.time.ReadablePartial) yearMonthDay49, (long) 10);
        java.util.Locale locale53 = null;
        java.lang.String str54 = skipUndoDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay49, 31, locale53);
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone55);
        org.joda.time.DurationField durationField57 = gJChronology56.weeks();
        org.joda.time.DateTimeField dateTimeField58 = gJChronology56.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField59 = gJChronology56.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField61 = julianChronology60.weekyear();
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration64 = null;
        org.joda.time.DateTime dateTime65 = dateTime63.minus(readableDuration64);
        int int66 = dateTime65.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay67 = dateTime65.toYearMonthDay();
        long long69 = julianChronology60.set((org.joda.time.ReadablePartial) yearMonthDay67, (long) 10);
        int[] intArray71 = gJChronology56.get((org.joda.time.ReadablePartial) yearMonthDay67, 100L);
        int int72 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay49, intArray71);
        java.util.Locale locale74 = null;
        java.lang.String str75 = offsetDateTimeField8.getAsText((org.joda.time.ReadablePartial) yearMonthDay49, 57599999, locale74);
        try {
            dateTimeFormatter3.printTo(stringBuffer4, (org.joda.time.ReadablePartial) yearMonthDay49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-210866803200000L) + "'", long10 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 30499202019L + "'", long12 == 30499202019L);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-210866803200000L) + "'", long18 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 30499202019L + "'", long20 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1547424000000L + "'", long22 == 1547424000000L);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1" + "'", str35.equals("1"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1L) + "'", long38 == (-1L));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "6" + "'", str41.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1970 + "'", int48 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1036800010L + "'", long51 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31" + "'", str54.equals("31"));
        org.junit.Assert.assertNotNull(gJChronology56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1970 + "'", int66 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1036800010L + "'", long69 == 1036800010L);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-292269056) + "'", int72 == (-292269056));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "57599999" + "'", str75.equals("57599999"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        boolean boolean4 = mutableDateTime0.isEqual((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime6 = dateTime3.withWeekyear(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '#');
        java.lang.Appendable appendable3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, readableInstant4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        int int26 = skipUndoDateTimeField20.get(1560345060000L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        int int1 = mutableDateTime0.getDayOfMonth();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.minuteOfHour();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        java.lang.String str7 = property5.getAsText();
        org.joda.time.DateTime dateTime9 = property5.addToCopy(58528);
        int int10 = property5.get();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
        int int5 = property4.get();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1817658810576002000L + "'", long3 == 1817658810576002000L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hourOfHalfday");
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime7.minusMillis((int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
        int int13 = mutableDateTime12.getDayOfMonth();
        mutableDateTime12.addWeekyears(0);
        int int16 = mutableDateTime12.getWeekOfWeekyear();
        mutableDateTime12.setMinuteOfDay((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        long long31 = skipUndoDateTimeField27.add((long) (short) 1, 0L);
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField27.getAsText(31, locale33);
        mutableDateTime12.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField27);
        int int36 = dateTime11.get((org.joda.time.DateTimeField) skipUndoDateTimeField27);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 27 + "'", int13 == 27);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 39 + "'", int16 == 39);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "31" + "'", str34.equals("31"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gJChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.dayOfMonth();
        org.joda.time.DurationField durationField6 = gJChronology2.weekyears();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-210865896000000L));
        long long7 = offsetDateTimeField3.remainder((long) 2019);
        long long9 = offsetDateTimeField3.roundHalfEven(1560345104283L);
        long long11 = offsetDateTimeField3.roundFloor(1560345103146L);
        long long13 = offsetDateTimeField3.roundHalfEven(921600L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210866803200000L) + "'", long5 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 30499202019L + "'", long7 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1547424000000L + "'", long9 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1547424000000L + "'", long11 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.set(2922789);
        java.util.Locale locale5 = null;
        java.util.Calendar calendar6 = mutableDateTime4.toCalendar(locale5);
        int int7 = mutableDateTime4.getSecondOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(calendar6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 61202 + "'", int7 == 61202);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(chronology3);
        mutableDateTime4.setMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.centuryOfEra();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime12 = property10.set(2922789);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = gJChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology15.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = gregorianChronology20.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.year();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = gJChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField26, 0);
        boolean boolean29 = skipUndoDateTimeField28.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, (org.joda.time.DateTimeField) skipUndoDateTimeField28);
        int int31 = skipDateTimeField30.getMinimumValue();
        long long33 = skipDateTimeField30.roundFloor((long) 1970);
        long long35 = skipDateTimeField30.roundHalfCeiling((long) 16);
        boolean boolean36 = skipDateTimeField30.isLenient();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.centuryOfEra();
        int int39 = property38.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField40 = property38.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField30, dateTimeFieldType41);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime12.property(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType41, 69, (-9));
        boolean boolean47 = mutableDateTime4.isSupported(dateTimeFieldType41);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType41, 240, 2, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 240 for centuryOfEra must be in the range [2,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2922789 + "'", int39 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.weekyear();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        int int11 = dateTime10.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
        long long14 = julianChronology5.set((org.joda.time.ReadablePartial) yearMonthDay12, (long) 10);
        int[] intArray16 = gJChronology1.get((org.joda.time.ReadablePartial) yearMonthDay12, 100L);
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology1.getZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1036800010L + "'", long14 == 1036800010L);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays(4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        boolean boolean17 = gJChronology14.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.dayOfYear();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology14.hourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime12.toDateTime((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        org.joda.time.DateTime.Property property22 = dateTime20.minuteOfHour();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        try {
            org.joda.time.DateTime dateTime16 = dateTime3.withDate(57599, (int) 'a', 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        boolean boolean25 = remainderDateTimeField22.isSupported();
        org.joda.time.DurationField durationField26 = remainderDateTimeField22.getDurationField();
        long long28 = remainderDateTimeField22.roundHalfFloor(42L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime7 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property8 = dateTime1.dayOfYear();
        java.lang.Class<?> wildcardClass9 = property8.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long5 = offsetDateTimeField3.roundHalfCeiling((-210865896000000L));
        long long7 = offsetDateTimeField3.remainder((long) 2019);
        long long9 = offsetDateTimeField3.roundHalfEven(52L);
        long long11 = offsetDateTimeField3.remainder(3120690201828L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-210866803200000L) + "'", long5 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 30499202019L + "'", long7 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 950400000L + "'", long9 == 950400000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 26792601828L + "'", long11 == 26792601828L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder5.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendClockhourOfDay(22303);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (byte) 100);
        int int18 = dateTime17.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.plus(readableDuration19);
        long long21 = dateTime20.getMillis();
        java.lang.String str22 = dateTimeFormatter15.print((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        mutableDateTime23.setZone(dateTimeZone24);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = gregorianChronology26.seconds();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.year();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = gJChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, dateTimeField32, 0);
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField34.getAsShortText(readablePartial35, (int) (short) 1, locale37);
        mutableDateTime23.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField34);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = skipUndoDateTimeField34.getType();
        org.joda.time.DateTime.Property property41 = dateTime20.property(dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType40, 2);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder9.appendDecimal(dateTimeFieldType40, (-24), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969-12-31" + "'", str22.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1" + "'", str38.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks(365);
        int int6 = dateTime5.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600100 + "'", int6 == 57600100);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        java.lang.String str7 = offsetDateTimeField3.toString();
        long long9 = offsetDateTimeField3.remainder((-136796400000L));
        long long11 = offsetDateTimeField3.roundHalfEven((long) (short) 0);
        long long14 = offsetDateTimeField3.add(1560345103290L, (-9));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[weekyear]" + "'", str7.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 20106000000L + "'", long9 == 20106000000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 950400000L + "'", long11 == 950400000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1276089103290L + "'", long14 == 1276089103290L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 100);
        int int8 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        long long11 = dateTime10.getMillis();
        java.lang.String str12 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime13.setZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology16.seconds();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.year();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = gJChronology20.weeks();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22, 0);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField24.getAsShortText(readablePartial25, (int) (short) 1, locale27);
        mutableDateTime13.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTime.Property property31 = dateTime10.property(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType30, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendCenturyOfEra(1969, 2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder36.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendFractionOfHour(0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31" + "'", str12.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        java.lang.String str4 = dateTimeFormatter0.print(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12" + "'", str4.equals("1969-12"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        java.util.Locale locale1 = null;
        java.util.Calendar calendar2 = mutableDateTime0.toCalendar(locale1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        java.util.Date date8 = dateTime5.toDate();
        org.joda.time.DateTime dateTime10 = dateTime5.withYear((int) (byte) 1);
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, (org.joda.time.DateTimeField) skipUndoDateTimeField27);
        int int30 = skipDateTimeField29.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, (org.joda.time.DateTimeField) skipDateTimeField29, 0);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getChronology(chronology12);
        org.junit.Assert.assertNotNull(calendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(chronology33);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        int int3 = dateTime1.getHourOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withMinuteOfHour((int) (short) 10);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readableDuration6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        org.joda.time.DateTime dateTime4 = dateTime3.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("42");
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        int int8 = offsetDateTimeField3.get(921600L);
        long long11 = offsetDateTimeField3.add(0L, 57599);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1968 + "'", int8 == 1968);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1817686483200000L + "'", long11 == 1817686483200000L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        java.lang.String str19 = skipDateTimeField16.getAsText(0L);
        try {
            long long22 = skipDateTimeField16.set((long) 10, 240);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 240 for hourOfHalfday must be in the range [1,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4" + "'", str19.equals("4"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        java.lang.String str7 = offsetDateTimeField3.toString();
        long long9 = offsetDateTimeField3.remainder((-136796400000L));
        long long11 = offsetDateTimeField3.roundHalfEven((long) (short) 0);
        long long13 = offsetDateTimeField3.roundFloor(1036800001L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[weekyear]" + "'", str7.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 20106000000L + "'", long9 == 20106000000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 950400000L + "'", long11 == 950400000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 950400000L + "'", long13 == 950400000L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withZone(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        mutableDateTime11.setZone(dateTimeZone12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime11.yearOfEra();
        int int17 = dateTimeFormatter9.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "GregorianChronology[UTC]", 2922789);
        int int18 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) mutableDateTime11);
        mutableDateTime11.setYear(4);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime11.monthOfYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-2922790) + "'", int17 == (-2922790));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-25200000) + "'", int18 == (-25200000));
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        mutableDateTime1.setZone(dateTimeZone2);
        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
        mutableDateTime1.addYears((int) 'a');
        int int8 = mutableDateTime1.getWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gJChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField15, 0);
        boolean boolean18 = skipUndoDateTimeField17.isSupported();
        long long21 = skipUndoDateTimeField17.add(2440588L, 0);
        java.util.Locale locale22 = null;
        int int23 = skipUndoDateTimeField17.getMaximumTextLength(locale22);
        mutableDateTime1.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField17);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField17.getAsText(readablePartial25, 8, locale27);
        org.joda.time.Instant instant29 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        mutableDateTime30.setZone(dateTimeZone31);
        long long33 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime30);
        boolean boolean34 = instant29.isBefore((org.joda.time.ReadableInstant) mutableDateTime30);
        mutableDateTime30.addYears((int) 'a');
        int int37 = mutableDateTime30.getWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField39 = gregorianChronology38.seconds();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology38.year();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField43 = gJChronology42.weeks();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology42.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology38, dateTimeField44, 0);
        boolean boolean47 = skipUndoDateTimeField46.isSupported();
        long long50 = skipUndoDateTimeField46.add(2440588L, 0);
        java.util.Locale locale51 = null;
        int int52 = skipUndoDateTimeField46.getMaximumTextLength(locale51);
        mutableDateTime30.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField46);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime57 = dateTime55.minusSeconds(0);
        java.util.Date date58 = dateTime55.toDate();
        org.joda.time.DateTime dateTime60 = dateTime55.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime62 = dateTime55.minusMillis((int) ' ');
        org.joda.time.DateTime dateTime64 = dateTime55.withCenturyOfEra((int) '#');
        org.joda.time.LocalDate localDate65 = dateTime55.toLocalDate();
        boolean boolean66 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate65);
        int int67 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) localDate65);
        java.util.Locale locale68 = null;
        try {
            java.lang.String str69 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate65, locale68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'hourOfHalfday' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1817658810576002000L + "'", long4 == 1817658810576002000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57601381 + "'", int8 == 57601381);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2440588L + "'", long21 == 2440588L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "8" + "'", str28.equals("8"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1817658810576002000L + "'", long33 == 1817658810576002000L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 57601381 + "'", int37 == 57601381);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2440588L + "'", long50 == 2440588L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((long) 59, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(921600L, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) 292272990, (org.joda.time.Chronology) gJChronology4);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.year();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.clockhourOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 100);
        int int10 = dateTime9.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.plus(readableDuration11);
        org.joda.time.DateTime.Property property13 = dateTime9.secondOfMinute();
        boolean boolean14 = mutableDateTime6.isBefore((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = mutableDateTime6.isSupported(dateTimeFieldType15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime6.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
        java.util.Locale locale19 = null;
        java.util.Calendar calendar20 = mutableDateTime18.toCalendar(locale19);
        try {
            org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.ReadableDateTime) mutableDateTime6, (org.joda.time.ReadableDateTime) mutableDateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(calendar20);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        java.lang.String str17 = skipDateTimeField16.toString();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        mutableDateTime18.setZone(dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.seconds();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.year();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField26 = gJChronology25.weeks();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField27, 0);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField29.getAsShortText(readablePartial30, (int) (short) 1, locale32);
        mutableDateTime18.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField29);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, dateTimeFieldType35, 59);
        int int39 = offsetDateTimeField37.get(5L);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str17.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 63 + "'", int39 == 63);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder0.setStandardOffset(10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder7.setStandardOffset(5);
        java.io.DataOutput dataOutput11 = null;
        try {
            dateTimeZoneBuilder9.writeTo("centuryOfEra", dataOutput11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.yearOfEra();
        int int4 = mutableDateTime0.getSecondOfDay();
        mutableDateTime0.setMillisOfDay(2066);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime0.add(readablePeriod7);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 61202 + "'", int4 == 61202);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        try {
            mutableDateTime8.setMinuteOfDay((-1971));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1971 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set(2922789);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gJChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.year();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gJChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField19, 0);
        boolean boolean22 = skipUndoDateTimeField21.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, (org.joda.time.DateTimeField) skipUndoDateTimeField21);
        int int24 = skipDateTimeField23.getMinimumValue();
        long long26 = skipDateTimeField23.roundFloor((long) 1970);
        long long28 = skipDateTimeField23.roundHalfCeiling((long) 16);
        boolean boolean29 = skipDateTimeField23.isLenient();
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.centuryOfEra();
        int int32 = property31.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField33 = property31.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType34);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime5.property(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType34, 69, (-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendSecondOfMinute(2116);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder0.appendFractionOfMinute(39, (-8));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2922789 + "'", int32 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100);
        int int3 = dateTime2.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        org.joda.time.DateTime.Property property6 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime8 = dateTime2.withHourOfDay(0);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.LocalDate localDate10 = dateTime2.toLocalDate();
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime2.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "16" + "'", str9.equals("16"));
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        long long28 = remainderDateTimeField22.roundHalfCeiling(57600560L);
        java.lang.String str30 = remainderDateTimeField22.getAsShortText((long) (short) -1);
        long long32 = remainderDateTimeField22.remainder((long) 100);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 57600000L + "'", long28 == 57600000L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9" + "'", str30.equals("9"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        int int12 = dateTime10.getMinuteOfHour();
        org.joda.time.DateTime dateTime14 = dateTime10.minusSeconds((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours(0);
        try {
            org.joda.time.DateTime dateTime18 = dateTime14.withSecondOfMinute(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-1L));
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.year();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds(0);
        java.util.Date date7 = dateTime4.toDate();
        org.joda.time.DateTime dateTime9 = dateTime4.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate10 = dateTime4.toLocalDate();
        mutableDateTime1.setMillis((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(26792601828L, 1560345097933L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1587137699761L + "'", long2 == 1587137699761L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        int int13 = dateTime12.getDayOfMonth();
        org.joda.time.LocalTime localTime14 = dateTime12.toLocalTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(localTime14);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(57599999, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("4");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology4.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gJChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField15, 0);
        boolean boolean18 = skipUndoDateTimeField17.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology4, (org.joda.time.DateTimeField) skipUndoDateTimeField17);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = gregorianChronology20.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.year();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = gJChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField26, 0);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField28.getAsText((int) (short) 1, locale30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField33 = gregorianChronology32.seconds();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.year();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35);
        org.joda.time.DurationField durationField37 = gJChronology36.weeks();
        org.joda.time.DateTimeField dateTimeField38 = gJChronology36.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology32, dateTimeField38, 0);
        org.joda.time.ReadablePartial readablePartial41 = null;
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipUndoDateTimeField40.getAsShortText(readablePartial41, (int) (short) 1, locale43);
        long long47 = skipUndoDateTimeField40.add((long) (byte) -1, 0);
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipUndoDateTimeField40.getAsText(1560345069015L, locale49);
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = julianChronology51.weekyear();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration55 = null;
        org.joda.time.DateTime dateTime56 = dateTime54.minus(readableDuration55);
        int int57 = dateTime56.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay58 = dateTime56.toYearMonthDay();
        long long60 = julianChronology51.set((org.joda.time.ReadablePartial) yearMonthDay58, (long) 10);
        java.util.Locale locale62 = null;
        java.lang.String str63 = skipUndoDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay58, 31, locale62);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField66 = gregorianChronology65.seconds();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology65.year();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68);
        org.joda.time.DurationField durationField70 = gJChronology69.weeks();
        org.joda.time.DateTimeField dateTimeField71 = gJChronology69.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology65, dateTimeField71, 0);
        org.joda.time.ReadablePartial readablePartial74 = null;
        int[] intArray81 = new int[] { 3, 2000, 3, 9, (byte) 100, 100 };
        int int82 = skipUndoDateTimeField73.getMinimumValue(readablePartial74, intArray81);
        java.util.Locale locale84 = null;
        int[] intArray85 = skipUndoDateTimeField28.set((org.joda.time.ReadablePartial) yearMonthDay58, (int) (short) 0, intArray81, "4", locale84);
        int int86 = skipDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay58);
        jodaTimePermission1.checkGuard((java.lang.Object) skipDateTimeField19);
        int int89 = skipDateTimeField19.get((-6025594249L));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"4\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"4\")"));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1" + "'", str44.equals("1"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1L) + "'", long47 == (-1L));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "6" + "'", str50.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1970 + "'", int57 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1036800010L + "'", long60 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "31" + "'", str63.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 11 + "'", int89 == 11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.fullDate();
        boolean boolean4 = gJChronology1.equals((java.lang.Object) dateTimeFormatter3);
        java.io.Writer writer5 = null;
        try {
            dateTimeFormatter3.printTo(writer5, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.add((-12959982422000L), 0);
        try {
            long long42 = dividedDateTimeField36.set((-59074531621900L), 57601381);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57601381 for centuryOfEra must be in the range [0,5]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-12959982422000L) + "'", long39 == (-12959982422000L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        boolean boolean10 = mutableDateTime0.isSupported(dateTimeFieldType9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        long long17 = dateTimeZone14.convertLocalToUTC((long) (short) 10, true);
        long long21 = dateTimeZone14.convertLocalToUTC((long) 31, false, (long) 2);
        org.joda.time.Chronology chronology22 = gJChronology12.withZone(dateTimeZone14);
        mutableDateTime0.setZoneRetainFields(dateTimeZone14);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31L + "'", long21 == 31L);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        long long28 = remainderDateTimeField22.roundHalfCeiling(1560345100914L);
        long long30 = remainderDateTimeField22.remainder((long) (short) 100);
        org.joda.time.DurationField durationField31 = remainderDateTimeField22.getDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560345120000L + "'", long28 == 1560345120000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.seconds();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.year();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = gJChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField23, 0);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.minus(readableDuration28);
        int int30 = dateTime29.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay31 = dateTime29.toYearMonthDay();
        int[] intArray37 = new int[] { (byte) 1, 5, ' ', (short) -1 };
        int[] intArray39 = skipUndoDateTimeField25.addWrapField((org.joda.time.ReadablePartial) yearMonthDay31, 0, intArray37, 4);
        int int40 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay31);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1970 + "'", int30 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay31);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear(69);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds(0);
        java.util.Date date12 = dateTime9.toDate();
        org.joda.time.DateTime.Property property13 = dateTime9.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        java.lang.String str15 = property13.getAsText();
        org.joda.time.DateTime dateTime17 = property13.addToCopy(58528);
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime17);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.withYearOfCentury((int) '4');
        int int8 = dateTime7.getDayOfWeek();
        org.joda.time.DateTime dateTime10 = dateTime7.plusMinutes((-2066));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("100", "", (int) 'a', (int) (byte) 10);
        org.joda.time.DateTime dateTime16 = dateTime10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        java.lang.String str4 = property3.getName();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        long long12 = offsetDateTimeField10.roundHalfCeiling((-210865896000000L));
        long long14 = offsetDateTimeField10.remainder((long) 2019);
        long long16 = offsetDateTimeField10.roundHalfEven(1560345104283L);
        int int17 = dateTime5.get((org.joda.time.DateTimeField) offsetDateTimeField10);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField10.getType();
        long long20 = offsetDateTimeField10.remainder((-210866803200000L));
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "yearOfEra" + "'", str4.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210866803200000L) + "'", long12 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30499202019L + "'", long14 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1547424000000L + "'", long16 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292272991 + "'", int17 == 292272991);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.centuryOfEra();
        int int6 = property5.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField7 = property5.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2922789 + "'", int6 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.plus(readableDuration3);
        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) (short) 10, 0);
        boolean boolean8 = buddhistChronology0.equals((java.lang.Object) 0);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.year();
        try {
            mutableDateTime9.setMillisOfSecond(22303951);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 22303951 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        long long7 = property5.remainder();
        org.joda.time.DateTime dateTime8 = property5.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = property5.roundHalfCeilingCopy();
        long long10 = property5.remainder();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        try {
            mutableDateTime0.setDayOfWeek((-8));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -8 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = buddhistChronology3.add(readablePeriod4, 0L, 6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) -1);
        long long13 = offsetDateTimeField11.roundHalfCeiling((-210865896000000L));
        long long15 = offsetDateTimeField11.remainder((long) 2019);
        long long18 = offsetDateTimeField11.set((-719528L), 1968);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology3, (org.joda.time.DateTimeField) offsetDateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-210866803200000L) + "'", long13 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 30499202019L + "'", long15 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-719528L) + "'", long18 == (-719528L));
    }
}

