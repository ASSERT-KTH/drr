import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfDay((int) 'a');
        int int7 = dateTime6.getEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTime dateTime10 = dateTime6.withZoneRetainFields(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(207359999991L, dateTimeZone9);
        int int14 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "7", 2922789);
        boolean boolean16 = mutableDateTime11.isAfter((long) 90);
        mutableDateTime11.addMinutes(24);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2922790) + "'", int14 == (-2922790));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime7.minusMinutes(3);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone19);
        mutableDateTime20.addDays(0);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime20.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime25 = property23.add((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration26 = null;
        mutableDateTime25.add(readableDuration26);
        boolean boolean28 = dateTime11.isEqual((org.joda.time.ReadableInstant) mutableDateTime25);
        int int29 = mutableDateTime25.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 28990 + "'", int29 == 28990);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks(365);
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfMinute();
        org.joda.time.DateTime dateTime7 = property6.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime7 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property8 = dateTime1.dayOfYear();
        java.lang.Object obj9 = null;
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime1, obj9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        int int9 = fixedDateTimeZone4.getStandardOffset(57600560L);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone13 = dateTimeZoneBuilder10.toDateTimeZone("hi!", true);
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(readableInterval4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(20);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withZone(dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((-503448L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.withSecondOfMinute(0);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        int int38 = dividedDateTimeField36.get(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = julianChronology0.seconds();
        org.joda.time.DurationField durationField3 = julianChronology0.millis();
        java.lang.String str4 = julianChronology0.toString();
        long long8 = julianChronology0.add(52L, (long) 1970, 2116);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4168572L + "'", long8 == 4168572L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        java.util.GregorianCalendar gregorianCalendar9 = mutableDateTime8.toGregorianCalendar();
        org.joda.time.Instant instant10 = new org.joda.time.Instant((java.lang.Object) mutableDateTime8);
        org.joda.time.Instant instant12 = instant10.plus(100L);
        org.joda.time.Instant instant14 = instant10.minus((long) 57599);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(instant14);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 3600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        java.util.Locale locale35 = null;
        java.lang.String str36 = remainderDateTimeField22.getAsShortText((long) '4', locale35);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "0" + "'", str36.equals("0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime.Property property6 = dateTime1.era();
        org.joda.time.DateTime dateTime8 = dateTime1.minusMonths(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.DateTimeZone dateTimeZone4 = mutableDateTime0.getZone();
//        org.joda.time.DateTime dateTime5 = mutableDateTime0.toDateTime();
//        org.joda.time.Chronology chronology6 = dateTime5.getChronology();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1817658810576002000L + "'", long3 == 1817658810576002000L);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(chronology6);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        java.lang.String str7 = offsetDateTimeField3.toString();
        long long10 = offsetDateTimeField3.set((-210866803200000L), "1970");
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField3.getAsText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[weekyear]" + "'", str7.equals("DateTimeField[weekyear]"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32400000000L + "'", long10 == 32400000000L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 90, "");
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("7", "-2922790", 69, (int) '#');
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        int int18 = fixedDateTimeZone16.getStandardOffset((long) (short) -1);
        org.joda.time.Chronology chronology19 = iSOChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime3.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test023");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
//        int int4 = instant0.get(dateTimeField3);
//        org.joda.time.Instant instant7 = instant0.withDurationAdded((long) '4', 100);
//        org.joda.time.MutableDateTime mutableDateTime8 = instant7.toMutableDateTimeISO();
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57601284 + "'", int4 == 57601284);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder0.toDateTimeZone("6", true);
        java.lang.String str9 = dateTimeZone8.toString();
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "6" + "'", str9.equals("6"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = property11.add((int) (short) 100);
        org.joda.time.DateTimeField dateTimeField14 = property11.getField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        mutableDateTime18.setZone(dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.seconds();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.year();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField26 = gJChronology25.weeks();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField27, 0);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField29.getAsShortText(readablePartial30, (int) (short) 1, locale32);
        mutableDateTime18.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField29);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = skipUndoDateTimeField29.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField37 = new org.joda.time.field.RemainderDateTimeField(dateTimeField17, dateTimeFieldType35, (int) (short) 10);
        boolean boolean39 = remainderDateTimeField37.isLeap(0L);
        long long41 = remainderDateTimeField37.roundHalfEven(207359999991L);
        java.lang.String str43 = remainderDateTimeField37.getAsText((-12959983159412L));
        boolean boolean45 = remainderDateTimeField37.isLeap((long) (short) 0);
        long long48 = remainderDateTimeField37.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime49 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime49.centuryOfEra();
        int int51 = property50.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField52 = property50.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property50.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField58 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField37, dateTimeFieldType53);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField59 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType53);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 207360000000L + "'", long41 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "7" + "'", str43.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2922789 + "'", int51 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("1969-12-31T15:59:59.999-08:00", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.getDifferenceAsLong(1560345096758L, (long) (short) 10);
        org.joda.time.DurationField durationField40 = dividedDateTimeField36.getDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2600575L + "'", long39 == 2600575L);
        org.junit.Assert.assertNotNull(durationField40);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test028");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        mutableDateTime1.setZone(dateTimeZone2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
//        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
//        mutableDateTime1.addYears((int) 'a');
//        int int8 = mutableDateTime1.getWeekyear();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime1.year();
//        org.joda.time.MutableDateTime mutableDateTime10 = property9.getMutableDateTime();
//        java.lang.String str11 = property9.getAsShortText();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1817658810576002000L + "'", long4 == 1817658810576002000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57601381 + "'", int8 == 57601381);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57601381" + "'", str11.equals("57601381"));
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.LocalDateTime localDateTime11 = dateTimeFormatter9.parseLocalDateTime("1969-12");
        long long13 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime11, (long) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2678400000L) + "'", long13 == (-2678400000L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime11 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 100);
        int int14 = dateTime13.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        long long17 = dateTime16.getMillis();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours(0);
        boolean boolean20 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime16);
        boolean boolean22 = dateTime16.isBefore((long) (-24));
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        mutableDateTime1.setZone(dateTimeZone2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
//        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
//        mutableDateTime1.addYears((int) 'a');
//        int int8 = mutableDateTime1.getWeekyear();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime1.year();
//        java.lang.String str10 = property9.toString();
//        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
//        org.joda.time.MutableDateTime mutableDateTime13 = property9.addWrapField(365);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1817658810576002000L + "'", long4 == 1817658810576002000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 57601381 + "'", int8 == 57601381);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[year]" + "'", str10.equals("Property[year]"));
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime7 = dateTime1.withHourOfDay(0);
        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfDay();
        int int9 = dateTime1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(207360000000L);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test034");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        int int1 = mutableDateTime0.getDayOfMonth();
//        mutableDateTime0.addWeekyears(0);
//        int int4 = mutableDateTime0.getWeekOfWeekyear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((int) 'a');
//        int int8 = dateTimeFormatter5.getDefaultYear();
//        java.lang.String str10 = dateTimeFormatter5.print((long) 2);
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter5.getZone();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("1970-01-01T00:00:05.199Z", "1969-12", (-28800000), (-9));
//        long long18 = fixedDateTimeZone16.previousTransition(133225L);
//        long long20 = fixedDateTimeZone16.nextTransition((-6051600000L));
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime0, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
//        try {
//            mutableDateTime22.setWeekOfWeekyear(1969);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for weekOfWeekyear must be in the range [1,53]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2000 + "'", int8 == 2000);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969-12" + "'", str10.equals("1969-12"));
//        org.junit.Assert.assertNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 133225L + "'", long18 == 133225L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-6051600000L) + "'", long20 == (-6051600000L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        int int2 = gJChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField4 = gJChronology1.weeks();
        org.joda.time.DurationField durationField5 = gJChronology1.millis();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.add((-12959982422000L), 0);
        int int40 = dividedDateTimeField36.getMinimumValue();
        boolean boolean42 = dividedDateTimeField36.isLeap(20L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-12959982422000L) + "'", long39 == (-12959982422000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.clockhourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        boolean boolean9 = dateTimeZone7.isStandardOffset(1036800010L);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology11 = julianChronology1.withZone(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 10, 19, (-2066), 22296758, (-292269056), 31, 16320);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 22296758 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays(4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        boolean boolean17 = gJChronology14.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.dayOfYear();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology14.hourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime12.toDateTime((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        int int22 = dateTime20.getMinuteOfDay();
        org.joda.time.DateTime.Property property23 = dateTime20.minuteOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 960 + "'", int22 == 960);
        org.junit.Assert.assertNotNull(property23);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(0);
        boolean boolean11 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property12 = dateTime6.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        int int14 = property12.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        int int12 = dateTime10.getMinuteOfHour();
        org.joda.time.DateTime dateTime14 = dateTime10.minusSeconds((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime14.minusHours(0);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime14.plus(readableDuration17);
        org.joda.time.DateTime.Property property19 = dateTime18.secondOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears(1969);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(0);
        java.util.Date date10 = dateTime7.toDate();
        org.joda.time.DateTime dateTime12 = dateTime7.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime14 = dateTime7.minusMillis((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime7.withCenturyOfEra((int) '#');
        org.joda.time.LocalDate localDate17 = dateTime7.toLocalDate();
        org.joda.time.DateTime dateTime18 = dateTime3.withFields((org.joda.time.ReadablePartial) localDate17);
        org.joda.time.DateTime.Property property19 = dateTime18.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.add((-719528L), 1560345102464L);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField43.getLeapDurationField();
        int int49 = zeroIsMaxDateTimeField43.getMinimumValue(14745600L);
        long long52 = zeroIsMaxDateTimeField43.add((long) (short) 1, 3120690201828L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 93620706147120472L + "'", long46 == 93620706147120472L);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 187241412109680001L + "'", long52 == 187241412109680001L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        long long5 = dateTime4.getMillis();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours(0);
        org.joda.time.DateTime.Property property8 = dateTime4.weekyear();
        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        long long5 = dateTimeZone2.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology7 = buddhistChronology0.withZone(dateTimeZone2);
        java.lang.String str8 = buddhistChronology0.toString();
        java.lang.String str9 = buddhistChronology0.toString();
        org.joda.time.Chronology chronology10 = buddhistChronology0.withUTC();
        org.joda.time.DurationField durationField11 = buddhistChronology0.millis();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str8.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str9.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("19691231T155959-0800", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        mutableDateTime4.setZone(dateTimeZone5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.yearOfEra();
        int int10 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "GregorianChronology[UTC]", 2922789);
        boolean boolean11 = buddhistChronology0.equals((java.lang.Object) "GregorianChronology[UTC]");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long18 = fixedDateTimeZone16.nextTransition((long) (-2));
        int int20 = fixedDateTimeZone16.getStandardOffset((long) 10);
        org.joda.time.Chronology chronology21 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DurationField durationField22 = buddhistChronology0.days();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-2922790) + "'", int10 == (-2922790));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2L) + "'", long18 == (-2L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        boolean boolean5 = property4.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(3);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime9 = property4.set("Friday, December 31, -0001");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Friday, December 31, -0001\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1767705149911L + "'", long3 == 1767705149911L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test051");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        int int1 = mutableDateTime0.getDayOfMonth();
//        mutableDateTime0.addWeekyears(0);
//        mutableDateTime0.setYear(0);
//        mutableDateTime0.setMinuteOfDay((int) (byte) 0);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        mutableDateTime0.add(readablePeriod8, 0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withDayOfMonth(576012);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 576012 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        int int7 = fixedDateTimeZone5.getStandardOffset((long) (short) -1);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str9 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str9.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj0, dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gregorianChronology10.seconds();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.year();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField16, 0);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField18.getAsText((int) (short) 1, locale20);
        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField18);
        mutableDateTime9.setSecondOfDay(0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(57599999, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond(22303, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendDayOfYear(90);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        mutableDateTime9.addDays(0);
        mutableDateTime9.setDayOfYear((int) '#');
        mutableDateTime9.addMillis(16);
        int int18 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "ISOChronology[UTC]", 1970);
        mutableDateTime9.setMillis((long) 16);
        mutableDateTime9.addDays((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1971) + "'", int18 == (-1971));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("UTC", true);
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder5.writeTo("1969-12-31", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.hourOfDay();
        org.joda.time.DurationField durationField5 = gJChronology1.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.secondOfDay();
        long long10 = gJChronology1.add((-28800001L), 0L, 240);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28800001L) + "'", long10 == (-28800001L));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        int int8 = offsetDateTimeField3.get(921600L);
        long long11 = offsetDateTimeField3.getDifferenceAsLong(30499202019L, (-28800000L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1968 + "'", int8 == 1968);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.lang.StringBuffer stringBuffer2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        java.lang.String str4 = property3.getName();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        long long12 = offsetDateTimeField10.roundHalfCeiling((-210865896000000L));
        long long14 = offsetDateTimeField10.remainder((long) 2019);
        long long16 = offsetDateTimeField10.roundHalfEven(1560345104283L);
        int int17 = dateTime5.get((org.joda.time.DateTimeField) offsetDateTimeField10);
        int int19 = offsetDateTimeField10.getLeapAmount((-210866846400000L));
        long long22 = offsetDateTimeField10.add((long) 97, 0L);
        java.lang.String str24 = offsetDateTimeField10.getAsText((long) 22303);
        org.joda.time.DateTimeField dateTimeField25 = offsetDateTimeField10.getWrappedField();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "yearOfEra" + "'", str4.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210866803200000L) + "'", long12 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30499202019L + "'", long14 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1547424000000L + "'", long16 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292272990 + "'", int17 == 292272990);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1968" + "'", str24.equals("1968"));
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        java.lang.Object obj4 = null;
        boolean boolean5 = gJChronology1.equals(obj4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gJChronology1.add(readablePeriod6, (long) 31, (int) '#');
        int int10 = gJChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31L + "'", long9 == 31L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeParserBucket7.getZone();
        org.joda.time.Chronology chronology10 = dateTimeParserBucket7.getChronology();
        dateTimeParserBucket7.setPivotYear((java.lang.Integer) 22296758);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        int int1 = mutableDateTime0.getDayOfMonth();
//        mutableDateTime0.addWeekyears(0);
//        mutableDateTime0.addMillis((int) (byte) 0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        mutableDateTime0.add(readableDuration6, (int) '4');
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        org.joda.time.DateTime dateTime13 = property11.addToCopy(0);
        org.joda.time.DateTime dateTime14 = property11.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime15 = property11.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.add((-12959982422000L), 0);
        int int40 = dividedDateTimeField36.getMinimumValue();
        org.joda.time.DurationField durationField41 = dividedDateTimeField36.getDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-12959982422000L) + "'", long39 == (-12959982422000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(durationField41);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology12.millisOfSecond();
        java.lang.String str14 = julianChronology12.toString();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology12, locale15, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology12.getZone();
        org.joda.time.DateTime dateTime20 = dateTime10.toDateTime((org.joda.time.Chronology) julianChronology12);
        org.joda.time.DateTime.Property property21 = dateTime10.secondOfMinute();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JulianChronology[UTC]" + "'", str14.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(433429L, (long) 16320);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 7073561280");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.add((-719528L), 1560345102464L);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField43.getLeapDurationField();
        long long50 = zeroIsMaxDateTimeField43.add((long) (byte) 10, 1);
        long long53 = zeroIsMaxDateTimeField43.getDifferenceAsLong((-2L), 30206930944L);
        long long55 = zeroIsMaxDateTimeField43.roundHalfCeiling(60010L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 93620706147120472L + "'", long46 == 93620706147120472L);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 60010L + "'", long50 == 60010L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-503448L) + "'", long53 == (-503448L));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 60000L + "'", long55 == 60000L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        int int9 = gJChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DurationField durationField11 = gJChronology8.weeks();
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology8.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(5, 5, 1, 100, 0, 1968, 28990, (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.add((-12959982422000L), 0);
        int int40 = dividedDateTimeField36.getDivisor();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-12959982422000L) + "'", long39 == (-12959982422000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        mutableDateTime0.addWeeks((int) (byte) -1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        mutableDateTime0.add(readablePeriod5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gJChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 59, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.yearOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = gregorianChronology8.seconds();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = gJChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField14, 0);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField16.getAsShortText(readablePartial17, (int) (short) 1, locale19);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField16, 0);
        org.joda.time.DurationField durationField23 = gJChronology2.hours();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DurationField durationField3 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone13);
        java.util.GregorianCalendar gregorianCalendar15 = mutableDateTime14.toGregorianCalendar();
        int int18 = dateTimeFormatter5.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime14, "", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        mutableDateTime14.setZoneRetainFields(dateTimeZone22);
        boolean boolean24 = julianChronology1.equals((java.lang.Object) dateTimeZone22);
        org.joda.time.Chronology chronology25 = julianChronology1.withUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2) + "'", int18 == (-2));
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant2.plus(readableDuration3);
        org.joda.time.Instant instant7 = instant4.withDurationAdded((long) (short) 10, 0);
        boolean boolean8 = buddhistChronology0.equals((java.lang.Object) 0);
        long long12 = buddhistChronology0.add(1560345103146L, (long) 1970, 999);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560347071176L + "'", long12 == 1560347071176L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) (-2922790), 0L);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2922790L) + "'", long3 == (-2922790L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "");
        java.lang.Number number7 = illegalFieldValueException6.getIllegalNumberValue();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException6);
        java.lang.String str9 = illegalFieldValueException2.toString();
        java.lang.String str10 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for GregorianChronology[UTC] is not supported" + "'", str9.equals("org.joda.time.IllegalFieldValueException: Value \"\" for GregorianChronology[UTC] is not supported"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.millisOfSecond();
        java.lang.String str4 = julianChronology2.toString();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology9 = dateTimeParserBucket8.getChronology();
        boolean boolean10 = buddhistChronology0.equals((java.lang.Object) dateTimeParserBucket8);
        long long13 = dateTimeParserBucket8.computeMillis(false, "1970");
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 100);
        int int3 = dateTime2.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readableDuration4);
        long long6 = dateTime5.getMillis();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
        java.lang.String str9 = dateTimeFormatter0.print(1587137699761L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31" + "'", str7.equals("1969-12-31"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2020-04-17" + "'", str9.equals("2020-04-17"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime1.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime1.plusMinutes((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime1.withDate(57600, 0, 2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test082");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        mutableDateTime0.addHours(0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        java.lang.String str8 = gregorianChronology7.toString();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.clockhourOfDay();
//        org.joda.time.DurationField durationField11 = gregorianChronology7.weeks();
//        mutableDateTime0.setChronology((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime0.weekyear();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1767705151548L + "'", long3 == 1767705151548L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(57599999, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendCenturyOfEra(100, (-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.millisOfSecond();
        java.lang.String str13 = julianChronology11.toString();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology11, locale14, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology18 = dateTimeParserBucket17.getChronology();
        boolean boolean19 = buddhistChronology9.equals((java.lang.Object) dateTimeParserBucket17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = gJChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology21.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = gregorianChronology26.seconds();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.year();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = gJChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, dateTimeField32, 0);
        boolean boolean35 = skipUndoDateTimeField34.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField34);
        int int37 = skipDateTimeField36.getMinimumValue();
        long long39 = skipDateTimeField36.roundFloor((long) 1970);
        long long41 = skipDateTimeField36.roundHalfCeiling((long) 16);
        boolean boolean42 = skipDateTimeField36.isLenient();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.centuryOfEra();
        int int45 = property44.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField46 = property44.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property44.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType47);
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, "");
        dateTimeParserBucket17.saveField(dateTimeFieldType47, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType47, 1968, 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder55.appendFractionOfHour((-24), 57599999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JulianChronology[UTC]" + "'", str13.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2922789 + "'", int45 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        java.util.Locale locale1 = null;
        java.util.Calendar calendar2 = mutableDateTime0.toCalendar(locale1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        mutableDateTime0.add(readablePeriod3, 0);
        mutableDateTime0.addMillis(576012);
        org.junit.Assert.assertNotNull(calendar2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj0, dateTimeZone3);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gregorianChronology10.seconds();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.year();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField16, 0);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField18.getAsText((int) (short) 1, locale20);
        mutableDateTime9.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField18);
        org.joda.time.DurationField durationField23 = skipUndoDateTimeField18.getLeapDurationField();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.minus(readableDuration26);
        org.joda.time.DateTime dateTime29 = dateTime25.withMillisOfSecond(100);
        org.joda.time.LocalDate localDate30 = dateTime25.toLocalDate();
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) localDate30, 22296758, locale32);
        java.util.Locale locale34 = null;
        int int35 = skipUndoDateTimeField18.getMaximumTextLength(locale34);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "22296758" + "'", str33.equals("22296758"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        long long19 = skipDateTimeField16.roundFloor((long) 1970);
        int int20 = skipDateTimeField16.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test087");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.millisOfSecond();
//        java.lang.String str4 = julianChronology2.toString();
//        java.util.Locale locale5 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) (-2922790), (int) ' ');
//        org.joda.time.Chronology chronology9 = dateTimeParserBucket8.getChronology();
//        boolean boolean10 = buddhistChronology0.equals((java.lang.Object) dateTimeParserBucket8);
//        java.lang.Integer int11 = dateTimeParserBucket8.getOffsetInteger();
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        java.util.Locale locale13 = null;
//        java.util.Calendar calendar14 = mutableDateTime12.toCalendar(locale13);
//        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.dayOfWeek();
//        boolean boolean16 = dateTimeParserBucket8.restoreState((java.lang.Object) property15);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 100);
//        int int19 = dateTime18.getDayOfYear();
//        boolean boolean20 = property15.equals((java.lang.Object) int19);
//        long long21 = property15.remainder();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(int11);
//        org.junit.Assert.assertNotNull(calendar14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 365 + "'", int19 == 365);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 18751827L + "'", long21 == 18751827L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.withYearOfCentury((int) '4');
        int int8 = dateTime7.getDayOfWeek();
        org.joda.time.DateTime dateTime10 = dateTime7.minusSeconds(6);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime11 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withMillisOfDay((int) (short) 0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitWeekyear((-2));
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimeParser8);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTimeZoneShortName(strMap10);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.centuryOfEra();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        int int17 = dateTime16.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime16.plus(readableDuration18);
        org.joda.time.DateTime.Property property20 = dateTime16.secondOfMinute();
        boolean boolean21 = mutableDateTime13.isBefore((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime13.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = gJChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology24.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology24.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField30 = gregorianChronology29.seconds();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.year();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
        org.joda.time.DurationField durationField34 = gJChronology33.weeks();
        org.joda.time.DateTimeField dateTimeField35 = gJChronology33.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField37 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField35, 0);
        boolean boolean38 = skipUndoDateTimeField37.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology24, (org.joda.time.DateTimeField) skipUndoDateTimeField37);
        int int40 = skipDateTimeField39.getMinimumValue();
        long long42 = skipDateTimeField39.roundFloor((long) 1970);
        long long44 = skipDateTimeField39.roundHalfCeiling((long) 16);
        boolean boolean45 = skipDateTimeField39.isLenient();
        org.joda.time.MutableDateTime mutableDateTime46 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property47 = mutableDateTime46.centuryOfEra();
        int int48 = property47.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField49 = property47.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property47.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField39, dateTimeFieldType50);
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, "UTC");
        int int54 = mutableDateTime13.get(dateTimeFieldType50);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder9.appendFixedSignedDecimal(dateTimeFieldType50, 22303);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(strMap10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2922789 + "'", int48 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 20 + "'", int54 == 20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test091");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.monthOfYear();
//        java.lang.Object obj5 = null;
//        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        long long11 = dateTimeZone8.convertLocalToUTC((long) (short) 10, true);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology13 = buddhistChronology6.withZone(dateTimeZone8);
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(obj5, dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = gregorianChronology15.seconds();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.year();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField20 = gJChronology19.weeks();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField21, 0);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = skipUndoDateTimeField23.getAsText((int) (short) 1, locale25);
//        mutableDateTime14.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField23);
//        int int28 = property4.compareTo((org.joda.time.ReadableInstant) mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1767705152403L + "'", long3 == 1767705152403L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(buddhistChronology6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1" + "'", str26.equals("1"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        long long25 = remainderDateTimeField22.add(207359999991L, 1560345104283L);
        long long27 = remainderDateTimeField22.roundHalfEven((long) (short) 10);
        long long30 = remainderDateTimeField22.addWrapField(18059L, (-8));
        long long32 = remainderDateTimeField22.roundHalfEven((long) 97);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = remainderDateTimeField22.getType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 93620913616979991L + "'", long25 == 93620913616979991L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 138059L + "'", long30 == 138059L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime5.withDayOfYear(69);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.plus(readableDuration8);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime9.withFieldAdded(durationFieldType10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        int int17 = skipDateTimeField16.getMinimumValue();
        java.lang.String str19 = skipDateTimeField16.getAsText(0L);
        int int21 = skipDateTimeField16.get((long) 365);
        long long23 = skipDateTimeField16.roundCeiling((long) 31);
        long long26 = skipDateTimeField16.add((long) (-24), 1560345104090L);
        try {
            long long29 = skipDateTimeField16.set((-62105097599999L), 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfHalfday must be in the range [1,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4" + "'", str19.equals("4"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3600000L + "'", long23 == 3600000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5617242374723999976L + "'", long26 == 5617242374723999976L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime7 = dateTime1.withHourOfDay(0);
        int int8 = dateTime7.getDayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gJChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField15, 0);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField17.getAsShortText(readablePartial18, (int) (short) 1, locale20);
        long long24 = skipUndoDateTimeField17.add((long) (byte) -1, 0);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipUndoDateTimeField17.getAsText(1560345069015L, locale26);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology28.weekyear();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.minus(readableDuration32);
        int int34 = dateTime33.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay35 = dateTime33.toYearMonthDay();
        long long37 = julianChronology28.set((org.joda.time.ReadablePartial) yearMonthDay35, (long) 10);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay35, 31, locale39);
        boolean boolean41 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) yearMonthDay35);
        org.joda.time.DateTime dateTime42 = dateTime7.withFields((org.joda.time.ReadablePartial) yearMonthDay35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1" + "'", str21.equals("1"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "6" + "'", str27.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1970 + "'", int34 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1036800010L + "'", long37 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31" + "'", str40.equals("31"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dateTime42);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test096");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
//        int int4 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
//        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
//        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
//        org.joda.time.DateTime dateTime13 = property11.addToCopy(0);
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
//        int int15 = mutableDateTime14.getDayOfWeek();
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime14.weekyear();
//        int int17 = property11.compareTo((org.joda.time.ReadableInstant) mutableDateTime14);
//        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.centuryOfEra();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (byte) 100);
//        int int22 = dateTime21.getWeekOfWeekyear();
//        org.joda.time.ReadableDuration readableDuration23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime21.plus(readableDuration23);
//        org.joda.time.DateTime.Property property25 = dateTime21.secondOfMinute();
//        boolean boolean26 = mutableDateTime18.isBefore((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime28 = dateTime21.withYear((int) (byte) -1);
//        org.joda.time.DateTime dateTime30 = dateTime21.plusMonths((int) (byte) -1);
//        long long31 = property11.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.DateTime dateTime33 = property11.addWrapFieldToCopy(57601284);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-719528L) + "'", long31 == (-719528L));
//        org.junit.Assert.assertNotNull(dateTime33);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 365, "centuryOfEra");
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((-1L));
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        long long8 = dateTimeZone5.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology10 = buddhistChronology3.withZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withChronology(chronology10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withDefaultYear(57599999);
        try {
            org.joda.time.LocalTime localTime15 = dateTimeFormatter13.parseLocalTime("1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.100-08:00\" is malformed at \"-12-31T16:00:00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "19691231T155959-0800" + "'", str2.equals("19691231T155959-0800"));
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfWeek((int) 'a');
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (byte) 100);
        int int7 = dateTime6.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.plus(readableDuration8);
        long long10 = dateTime9.getMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        mutableDateTime14.setZone(dateTimeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.seconds();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.year();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = gJChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField23, 0);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipUndoDateTimeField25.getAsShortText(readablePartial26, (int) (short) 1, locale28);
        mutableDateTime14.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField25);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = skipUndoDateTimeField25.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType31, (int) (short) 10);
        boolean boolean35 = remainderDateTimeField33.isLeap(0L);
        long long37 = remainderDateTimeField33.roundHalfEven(207359999991L);
        java.lang.String str39 = remainderDateTimeField33.getAsText((-12959983159412L));
        boolean boolean41 = remainderDateTimeField33.isLeap((long) (short) 0);
        long long44 = remainderDateTimeField33.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime45.centuryOfEra();
        int int47 = property46.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField48 = property46.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property46.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField54 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField33, dateTimeFieldType49);
        org.joda.time.DateTime.Property property55 = dateTime9.property(dateTimeFieldType49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType49, 16, 57599999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder4.appendHourOfDay(6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder60.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 207360000000L + "'", long37 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "7" + "'", str39.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2922789 + "'", int47 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        long long25 = remainderDateTimeField22.add(207359999991L, 1560345104283L);
        long long27 = remainderDateTimeField22.roundHalfEven((long) (short) 10);
        long long30 = remainderDateTimeField22.addWrapField(18059L, (-8));
        long long32 = remainderDateTimeField22.roundHalfEven((long) 97);
        long long34 = remainderDateTimeField22.roundHalfCeiling(979200031L);
        long long36 = remainderDateTimeField22.roundHalfFloor((long) 22303951);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 93620913616979991L + "'", long25 == 93620913616979991L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 138059L + "'", long30 == 138059L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 979200000L + "'", long34 == 979200000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 22320000L + "'", long36 == 22320000L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime1.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.set(2922789);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField9 = gJChronology8.weeks();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.seconds();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.year();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gJChronology17.weeks();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology13, dateTimeField19, 0);
        boolean boolean22 = skipUndoDateTimeField21.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, (org.joda.time.DateTimeField) skipUndoDateTimeField21);
        int int24 = skipDateTimeField23.getMinimumValue();
        long long26 = skipDateTimeField23.roundFloor((long) 1970);
        long long28 = skipDateTimeField23.roundHalfCeiling((long) 16);
        boolean boolean29 = skipDateTimeField23.isLenient();
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.centuryOfEra();
        int int32 = property31.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField33 = property31.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property31.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField23, dateTimeFieldType34);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime5.property(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType34, 69, (-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder39.appendMillisOfSecond(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2922789 + "'", int32 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        org.joda.time.DurationField durationField25 = skipUndoDateTimeField20.getLeapDurationField();
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertNull(durationField25);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gJChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) 1, locale14);
        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField11);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField11.getAsShortText((-2L), locale18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.millisOfSecond();
        java.lang.String str26 = julianChronology24.toString();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket30 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology24, locale27, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology31 = dateTimeParserBucket30.getChronology();
        boolean boolean32 = buddhistChronology22.equals((java.lang.Object) dateTimeParserBucket30);
        java.lang.Integer int33 = dateTimeParserBucket30.getOffsetInteger();
        java.util.Locale locale34 = dateTimeParserBucket30.getLocale();
        try {
            long long35 = skipUndoDateTimeField11.set(31L, "Property[monthOfYear]", locale34);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[monthOfYear]\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3" + "'", str19.equals("3"));
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "JulianChronology[UTC]" + "'", str26.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(int33);
        org.junit.Assert.assertNotNull(locale34);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        java.lang.String str4 = property3.getName();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        long long12 = offsetDateTimeField10.roundHalfCeiling((-210865896000000L));
        long long14 = offsetDateTimeField10.remainder((long) 2019);
        long long16 = offsetDateTimeField10.roundHalfEven(1560345104283L);
        int int17 = dateTime5.get((org.joda.time.DateTimeField) offsetDateTimeField10);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField10.getMaximumShortTextLength(locale18);
        int int21 = offsetDateTimeField10.get(30499202019L);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "yearOfEra" + "'", str4.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210866803200000L) + "'", long12 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30499202019L + "'", long14 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1547424000000L + "'", long16 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292272990 + "'", int17 == 292272990);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime11 = dateTime3.minusHours((int) (byte) 100);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.minus(readableDuration14);
        int int16 = dateTime15.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTime dateTime18 = dateTime11.withFields((org.joda.time.ReadablePartial) yearMonthDay17);
        org.joda.time.DateTime.Property property19 = dateTime18.centuryOfEra();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        long long12 = skipUndoDateTimeField8.add((long) (short) 1, 0L);
        long long15 = skipUndoDateTimeField8.add(0L, 0L);
        int int16 = skipUndoDateTimeField8.getMinimumValue();
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField8.getAsText((int) (byte) 100, locale18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField27 = gJChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField28, 0);
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField30.getAsText((int) (short) 1, locale32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.seconds();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.year();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37);
        org.joda.time.DurationField durationField39 = gJChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField40 = gJChronology38.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, dateTimeField40, 0);
        org.joda.time.ReadablePartial readablePartial43 = null;
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipUndoDateTimeField42.getAsShortText(readablePartial43, (int) (short) 1, locale45);
        long long49 = skipUndoDateTimeField42.add((long) (byte) -1, 0);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipUndoDateTimeField42.getAsText(1560345069015L, locale51);
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = julianChronology53.weekyear();
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime58 = dateTime56.minus(readableDuration57);
        int int59 = dateTime58.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay60 = dateTime58.toYearMonthDay();
        long long62 = julianChronology53.set((org.joda.time.ReadablePartial) yearMonthDay60, (long) 10);
        java.util.Locale locale64 = null;
        java.lang.String str65 = skipUndoDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay60, 31, locale64);
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField68 = gregorianChronology67.seconds();
        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology67.year();
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone70);
        org.joda.time.DurationField durationField72 = gJChronology71.weeks();
        org.joda.time.DateTimeField dateTimeField73 = gJChronology71.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField75 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology67, dateTimeField73, 0);
        org.joda.time.ReadablePartial readablePartial76 = null;
        int[] intArray83 = new int[] { 3, 2000, 3, 9, (byte) 100, 100 };
        int int84 = skipUndoDateTimeField75.getMinimumValue(readablePartial76, intArray83);
        java.util.Locale locale86 = null;
        int[] intArray87 = skipUndoDateTimeField30.set((org.joda.time.ReadablePartial) yearMonthDay60, (int) (short) 0, intArray83, "4", locale86);
        int[] intArray89 = skipUndoDateTimeField8.add(readablePartial20, 5, intArray87, (int) (short) 0);
        try {
            org.joda.time.MutableDateTime mutableDateTime90 = new org.joda.time.MutableDateTime((java.lang.Object) skipUndoDateTimeField8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.SkipUndoDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1" + "'", str33.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1" + "'", str46.equals("1"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "6" + "'", str52.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1970 + "'", int59 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1036800010L + "'", long62 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "31" + "'", str65.equals("31"));
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray89);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(31L, 138059L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4279829L + "'", long2 == 4279829L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField3.getMaximumTextLength(locale7);
        long long10 = offsetDateTimeField3.remainder((long) (-292269056));
        long long13 = offsetDateTimeField3.set(0L, (int) ' ');
        long long16 = offsetDateTimeField3.getDifferenceAsLong((long) 20, (-62105094000000L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 30206930944L + "'", long10 == 30206930944L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61095686400000L) + "'", long13 == (-61095686400000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1967L + "'", long16 == 1967L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("(\"org.joda.time.JodaTimePermission\" \"4\")", "");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test110");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.DateTimeZone dateTimeZone4 = mutableDateTime0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
//        int int9 = mutableDateTime8.getDayOfMonth();
//        mutableDateTime8.addWeekyears(0);
//        int int12 = mutableDateTime8.getWeekOfWeekyear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        boolean boolean14 = dateTimeFormatter13.isParser();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withZone(dateTimeZone15);
//        mutableDateTime8.setZone(dateTimeZone15);
//        org.joda.time.Chronology chronology18 = iSOChronology7.withZone(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1767705154456L + "'", long3 == 1767705154456L);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(chronology18);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 1);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (-2066));
        int int11 = dateTime10.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(0);
        java.util.Date date14 = dateTime11.toDate();
        org.joda.time.DateTime dateTime16 = dateTime11.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate17 = dateTime11.toLocalDate();
        org.joda.time.DateTime dateTime19 = dateTime11.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime21 = dateTime19.withCenturyOfEra((int) (byte) 1);
        org.joda.time.DateTime dateTime23 = dateTime21.minusMinutes(22296758);
        org.joda.time.DateTime dateTime25 = dateTime23.withYearOfCentury(0);
        org.joda.time.DateTime dateTime26 = dateTime25.withEarlierOffsetAtOverlap();
        long long27 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime26);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 58992266102000L + "'", long27 == 58992266102000L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-2066), 0, (-8), 0, 57601381, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57601381 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test114");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        mutableDateTime1.setZone(dateTimeZone2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
//        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime1.secondOfMinute();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime1.yearOfCentury();
//        boolean boolean8 = mutableDateTime1.isEqualNow();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1767705154727L + "'", long4 == 1767705154727L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = property11.add((int) (short) 100);
        try {
            mutableDateTime13.setWeekOfWeekyear(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        int int8 = dateTimeParserBucket7.getOffset();
        dateTimeParserBucket7.setOffset((java.lang.Integer) 57601284);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime3.plusMillis((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime15.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime19 = property17.set(2922789);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.DurationField durationField23 = gJChronology22.weeks();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology22.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField28 = gregorianChronology27.seconds();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.year();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30);
        org.joda.time.DurationField durationField32 = gJChronology31.weeks();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField33, 0);
        boolean boolean36 = skipUndoDateTimeField35.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, (org.joda.time.DateTimeField) skipUndoDateTimeField35);
        int int38 = skipDateTimeField37.getMinimumValue();
        long long40 = skipDateTimeField37.roundFloor((long) 1970);
        long long42 = skipDateTimeField37.roundHalfCeiling((long) 16);
        boolean boolean43 = skipDateTimeField37.isLenient();
        org.joda.time.MutableDateTime mutableDateTime44 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime44.centuryOfEra();
        int int46 = property45.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField47 = property45.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property45.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField37, dateTimeFieldType48);
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime19.property(dateTimeFieldType48);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField14, dateTimeFieldType48);
        long long54 = zeroIsMaxDateTimeField51.addWrapField((-5056819621980L), 576012);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2922789 + "'", int46 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1817713246719600020L + "'", long54 == 1817713246719600020L);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        boolean boolean5 = property4.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.add(3);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
//        int int11 = property4.compareTo((org.joda.time.ReadablePartial) localDateTime10);
//        org.joda.time.MutableDateTime mutableDateTime13 = property4.add(433429L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1767705155065L + "'", long3 == 1767705155065L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(localDateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        mutableDateTime9.addDays(0);
        mutableDateTime9.setDayOfYear((int) '#');
        mutableDateTime9.addMillis(16);
        int int18 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "ISOChronology[UTC]", 1970);
        mutableDateTime9.setMillis((long) 16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.centuryOfEra();
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime22.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime26 = property24.set(2922789);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField30 = gJChronology29.weeks();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology29.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology29.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology29.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.seconds();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.year();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37);
        org.joda.time.DurationField durationField39 = gJChronology38.weeks();
        org.joda.time.DateTimeField dateTimeField40 = gJChronology38.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, dateTimeField40, 0);
        boolean boolean43 = skipUndoDateTimeField42.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, (org.joda.time.DateTimeField) skipUndoDateTimeField42);
        int int45 = skipDateTimeField44.getMinimumValue();
        long long47 = skipDateTimeField44.roundFloor((long) 1970);
        long long49 = skipDateTimeField44.roundHalfCeiling((long) 16);
        boolean boolean50 = skipDateTimeField44.isLenient();
        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.centuryOfEra();
        int int53 = property52.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField54 = property52.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property52.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField44, dateTimeFieldType55);
        org.joda.time.MutableDateTime.Property property57 = mutableDateTime26.property(dateTimeFieldType55);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder21.appendSignedDecimal(dateTimeFieldType55, 69, (-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder21.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder21.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder21.appendSecondOfMinute(2116);
        org.joda.time.chrono.BuddhistChronology buddhistChronology67 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology68 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology67);
        org.joda.time.DateTimeField dateTimeField69 = buddhistChronology67.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime70 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        mutableDateTime70.setZone(dateTimeZone71);
        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField74 = gregorianChronology73.seconds();
        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology73.year();
        org.joda.time.DateTimeZone dateTimeZone76 = null;
        org.joda.time.chrono.GJChronology gJChronology77 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone76);
        org.joda.time.DurationField durationField78 = gJChronology77.weeks();
        org.joda.time.DateTimeField dateTimeField79 = gJChronology77.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField81 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology73, dateTimeField79, 0);
        org.joda.time.ReadablePartial readablePartial82 = null;
        java.util.Locale locale84 = null;
        java.lang.String str85 = skipUndoDateTimeField81.getAsShortText(readablePartial82, (int) (short) 1, locale84);
        mutableDateTime70.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField81);
        org.joda.time.DateTimeFieldType dateTimeFieldType87 = skipUndoDateTimeField81.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField89 = new org.joda.time.field.RemainderDateTimeField(dateTimeField69, dateTimeFieldType87, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder90 = dateTimeFormatterBuilder66.appendShortText(dateTimeFieldType87);
        mutableDateTime9.set(dateTimeFieldType87, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1971) + "'", int18 == (-1971));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2922789 + "'", int53 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
        org.junit.Assert.assertNotNull(buddhistChronology67);
        org.junit.Assert.assertNotNull(chronology68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(gregorianChronology73);
        org.junit.Assert.assertNotNull(durationField74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(gJChronology77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "1" + "'", str85.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType87);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder90);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        mutableDateTime7.setZone(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField11 = gregorianChronology10.seconds();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.year();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology10, dateTimeField16, 0);
        org.joda.time.ReadablePartial readablePartial19 = null;
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipUndoDateTimeField18.getAsShortText(readablePartial19, (int) (short) 1, locale21);
        mutableDateTime7.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField18);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = skipUndoDateTimeField18.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType24, (int) (short) 10);
        boolean boolean28 = remainderDateTimeField26.isLeap(0L);
        long long30 = remainderDateTimeField26.roundHalfEven(207359999991L);
        java.lang.String str32 = remainderDateTimeField26.getAsText((-12959983159412L));
        boolean boolean34 = remainderDateTimeField26.isLeap((long) (short) 0);
        long long37 = remainderDateTimeField26.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime38 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.centuryOfEra();
        int int40 = property39.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField41 = property39.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property39.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField47 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField26, dateTimeFieldType42);
        long long50 = zeroIsMaxDateTimeField47.add((-719528L), 1560345102464L);
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = julianChronology51.weekyear();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration55 = null;
        org.joda.time.DateTime dateTime56 = dateTime54.minus(readableDuration55);
        int int57 = dateTime56.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay58 = dateTime56.toYearMonthDay();
        long long60 = julianChronology51.set((org.joda.time.ReadablePartial) yearMonthDay58, (long) 10);
        java.util.Locale locale62 = null;
        java.lang.String str63 = zeroIsMaxDateTimeField47.getAsText((org.joda.time.ReadablePartial) yearMonthDay58, 57601381, locale62);
        org.joda.time.field.SkipDateTimeField skipDateTimeField65 = new org.joda.time.field.SkipDateTimeField(chronology3, (org.joda.time.DateTimeField) zeroIsMaxDateTimeField47, 97);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1" + "'", str22.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 207360000000L + "'", long30 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "7" + "'", str32.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2922789 + "'", int40 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 93620706147120472L + "'", long50 == 93620706147120472L);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1970 + "'", int57 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1036800010L + "'", long60 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "57601381" + "'", str63.equals("57601381"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, 1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.getDifferenceAsLong(1560345096758L, (long) (short) 10);
        long long41 = dividedDateTimeField36.remainder((long) 39);
        long long43 = dividedDateTimeField36.remainder(58992266102000L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2600575L + "'", long39 == 2600575L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 39L + "'", long41 == 39L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 58992264302000L + "'", long43 == 58992264302000L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, 187241412109680001L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test124");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        boolean boolean5 = property4.isLeap();
//        int int6 = property4.getMaximumValueOverall();
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime8 = property4.roundHalfCeiling();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1767705156731L + "'", long3 == 1767705156731L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test125");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
//        int int2 = dateTime1.getWeekOfWeekyear();
//        org.joda.time.ReadableDuration readableDuration3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
//        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
//        int int6 = property5.getMaximumValue();
//        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
//        org.joda.time.Instant instant8 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        mutableDateTime9.setZone(dateTimeZone10);
//        long long12 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime9);
//        boolean boolean13 = instant8.isBefore((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTimeField dateTimeField14 = mutableDateTime9.getRoundingField();
//        int int15 = property5.getDifference((org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology16);
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology16.minuteOfHour();
//        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        mutableDateTime19.setZone(dateTimeZone20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField27 = gJChronology26.weeks();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField28, 0);
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        java.util.Locale locale33 = null;
//        java.lang.String str34 = skipUndoDateTimeField30.getAsShortText(readablePartial31, (int) (short) 1, locale33);
//        mutableDateTime19.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField30);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipUndoDateTimeField30.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField18, dateTimeFieldType36, (int) (short) 10);
//        long long41 = remainderDateTimeField38.add(207359999991L, 1560345104283L);
//        long long43 = remainderDateTimeField38.roundHalfEven((long) (short) 10);
//        long long46 = remainderDateTimeField38.addWrapField(18059L, (-8));
//        long long48 = remainderDateTimeField38.roundHalfEven((long) 97);
//        long long50 = remainderDateTimeField38.roundHalfCeiling(979200031L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = remainderDateTimeField38.getType();
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime9.property(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1767705156774L + "'", long12 == 1767705156774L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1767705156) + "'", int15 == (-1767705156));
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 93620913616979991L + "'", long41 == 93620913616979991L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 138059L + "'", long46 == 138059L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 979200000L + "'", long50 == 979200000L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(property52);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) 100);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter2.parseLocalDateTime("4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"4\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test127");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
//        int int4 = instant0.get(dateTimeField3);
//        long long5 = instant0.getMillis();
//        org.joda.time.DateTime dateTime6 = instant0.toDateTimeISO();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.Instant instant9 = instant0.withDurationAdded(readableDuration7, 16);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2026 + "'", int4 == 2026);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1767705157118L + "'", long5 == 1767705157118L);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(instant9);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("20", "org.joda.time.IllegalFieldValueException: : Value \"\" for GregorianChronology[UTC] is not supported", 9, 44654);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 57599, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        long long12 = skipUndoDateTimeField8.add((long) (short) 1, 0L);
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField8.getAsText(31, locale14);
        java.lang.String str17 = skipUndoDateTimeField8.getAsShortText((long) 2019);
        java.lang.Object obj18 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
        long long24 = dateTimeZone21.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.Chronology chronology26 = buddhistChronology19.withZone(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime(obj18, dateTimeZone21);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField29 = gregorianChronology28.seconds();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.year();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField33 = gJChronology32.weeks();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology32.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology28, dateTimeField34, 0);
        java.util.Locale locale38 = null;
        java.lang.String str39 = skipUndoDateTimeField36.getAsText((int) (short) 1, locale38);
        mutableDateTime27.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField36);
        org.joda.time.DurationField durationField41 = skipUndoDateTimeField36.getLeapDurationField();
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration44 = null;
        org.joda.time.DateTime dateTime45 = dateTime43.minus(readableDuration44);
        org.joda.time.DateTime dateTime47 = dateTime43.withMillisOfSecond(100);
        org.joda.time.LocalDate localDate48 = dateTime43.toLocalDate();
        java.util.Locale locale50 = null;
        java.lang.String str51 = skipUndoDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate48, 22296758, locale50);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = julianChronology55.millisOfSecond();
        java.lang.String str57 = julianChronology55.toString();
        java.util.Locale locale58 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology55, locale58, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology62 = dateTimeParserBucket61.getChronology();
        boolean boolean63 = buddhistChronology53.equals((java.lang.Object) dateTimeParserBucket61);
        java.lang.Integer int64 = dateTimeParserBucket61.getOffsetInteger();
        java.util.Locale locale65 = dateTimeParserBucket61.getLocale();
        java.text.DateFormatSymbols dateFormatSymbols66 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale65);
        java.lang.String str67 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDate48, (-2066), locale65);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31" + "'", str15.equals("31"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "22296758" + "'", str51.equals("22296758"));
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertNotNull(julianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "JulianChronology[UTC]" + "'", str57.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(int64);
        org.junit.Assert.assertNotNull(locale65);
        org.junit.Assert.assertNotNull(dateFormatSymbols66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "-2066" + "'", str67.equals("-2066"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        org.joda.time.ReadableDuration readableDuration25 = null;
        mutableDateTime8.add(readableDuration25, (-1));
        mutableDateTime8.addWeeks(69);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology30);
        mutableDateTime8.setChronology(chronology31);
        mutableDateTime8.setTime(0L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        int int9 = dateTime7.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.millisOfSecond();
        java.lang.String str4 = julianChronology2.toString();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology9 = dateTimeParserBucket8.getChronology();
        boolean boolean10 = buddhistChronology0.equals((java.lang.Object) dateTimeParserBucket8);
        java.lang.Integer int11 = dateTimeParserBucket8.getOffsetInteger();
        java.util.Locale locale12 = dateTimeParserBucket8.getLocale();
        dateTimeParserBucket8.setOffset((-25200000));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(int11);
        org.junit.Assert.assertNotNull(locale12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("1969-12");
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        try {
            java.lang.String str5 = dateTimeFormatter0.print(1036800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNull(int3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        int int4 = dateTime3.getWeekyear();
        org.joda.time.DateTime.Property property5 = dateTime3.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DurationField durationField3 = gJChronology1.years();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays(4);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        boolean boolean17 = gJChronology14.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.dayOfYear();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology14.hourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime12.toDateTime((org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        int int22 = dateTime20.getMinuteOfDay();
        org.joda.time.DateTime dateTime23 = dateTime20.toDateTimeISO();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 960 + "'", int22 == 960);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.getDifferenceAsLong(1560345103593L, 6975L);
        long long49 = zeroIsMaxDateTimeField43.add((long) 31, (long) 16320);
        long long52 = zeroIsMaxDateTimeField43.addWrapField(1560345104283L, 57601381);
        int int53 = zeroIsMaxDateTimeField43.getMaximumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 26005751L + "'", long46 == 26005751L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 979200031L + "'", long49 == 979200031L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560345164283L + "'", long52 == 1560345164283L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test140");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        mutableDateTime1.setZone(dateTimeZone2);
//        mutableDateTime1.addWeeks((int) (byte) -1);
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withPivotYear(0);
//        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2026-W01-2" + "'", str6.equals("2026-W01-2"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimePrinter9);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("4");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"4/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) '#');
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 0);
        java.lang.Appendable appendable6 = null;
        try {
            dateTimeFormatter5.printTo(appendable6, 1767705156731L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = property5.getDateTime();
        org.joda.time.DateTime dateTime9 = property5.roundCeilingCopy();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.millisOfSecond();
        java.lang.String str13 = julianChronology11.toString();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology11, locale14, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone18 = julianChronology11.getZone();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        long long22 = dateTimeZone18.convertLocalToUTC(365L, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTime dateTime24 = dateTime9.withChronology((org.joda.time.Chronology) gregorianChronology23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JulianChronology[UTC]" + "'", str13.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 365L + "'", long22 == 365L);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(57601284);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime13 = property11.add((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration14 = null;
        mutableDateTime13.add(readableDuration14);
        mutableDateTime13.setMinuteOfDay((int) '4');
        mutableDateTime13.setYear((-9));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test148");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        mutableDateTime1.setZone(dateTimeZone2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
//        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (short) -1);
//        long long12 = offsetDateTimeField9.set(3600000L, 0);
//        org.joda.time.DurationField durationField13 = offsetDateTimeField9.getLeapDurationField();
//        org.joda.time.DurationField durationField14 = offsetDateTimeField9.getLeapDurationField();
//        mutableDateTime1.setRounding((org.joda.time.DateTimeField) offsetDateTimeField9);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.seconds();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.year();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
//        org.joda.time.DurationField durationField23 = gJChronology22.weeks();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField26 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology18, dateTimeField24, 0);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime28.minus(readableDuration29);
//        int int31 = dateTime30.getWeekyear();
//        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
//        int[] intArray38 = new int[] { (byte) 1, 5, ' ', (short) -1 };
//        int[] intArray40 = skipUndoDateTimeField26.addWrapField((org.joda.time.ReadablePartial) yearMonthDay32, 0, intArray38, 4);
//        try {
//            int[] intArray42 = offsetDateTimeField9.addWrapField(readablePartial16, 58528, intArray40, 58528);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 58528");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1767705158320L + "'", long4 == 1767705158320L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62105094000000L) + "'", long12 == (-62105094000000L));
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1970 + "'", int31 == 1970);
//        org.junit.Assert.assertNotNull(yearMonthDay32);
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(intArray40);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        mutableDateTime0.addMonths(2000);
        mutableDateTime0.setMillis((long) 292272991);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (byte) 100);
        int int14 = dateTime13.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readableDuration15);
        long long17 = dateTime16.getMillis();
        java.lang.String str18 = dateTimeFormatter11.print((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        mutableDateTime19.setZone(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = gregorianChronology22.seconds();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.year();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.DurationField durationField27 = gJChronology26.weeks();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField28, 0);
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = skipUndoDateTimeField30.getAsShortText(readablePartial31, (int) (short) 1, locale33);
        mutableDateTime19.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField30);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = skipUndoDateTimeField30.getType();
        org.joda.time.DateTime.Property property37 = dateTime16.property(dateTimeFieldType36);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder10.appendFixedDecimal(dateTimeFieldType36, 2);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40);
        org.joda.time.DurationField durationField42 = gJChronology41.weeks();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology41.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology41.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology41.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField47 = gregorianChronology46.seconds();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.year();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
        org.joda.time.DurationField durationField51 = gJChronology50.weeks();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology50.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField54 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology46, dateTimeField52, 0);
        boolean boolean55 = skipUndoDateTimeField54.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField56 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology41, (org.joda.time.DateTimeField) skipUndoDateTimeField54);
        int int57 = skipDateTimeField56.getMinimumValue();
        long long59 = skipDateTimeField56.roundFloor((long) 1970);
        long long61 = skipDateTimeField56.roundHalfCeiling((long) 16);
        boolean boolean62 = skipDateTimeField56.isLenient();
        org.joda.time.MutableDateTime mutableDateTime63 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property64 = mutableDateTime63.centuryOfEra();
        int int65 = property64.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField66 = property64.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = property64.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField68 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField56, dateTimeFieldType67);
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder39.appendSignedDecimal(dateTimeFieldType67, 22296758, 292272991);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType67, 57600100, 576012);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31" + "'", str18.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2922789 + "'", int65 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long45 = remainderDateTimeField22.roundHalfFloor((long) 225);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfYear(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendDayOfMonth((-1767705156));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(9);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.plus(readableDuration13);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        org.joda.time.DateTime dateTime13 = property11.addToCopy(0);
        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(1969);
        org.joda.time.DateTime dateTime17 = dateTime13.plusSeconds(9);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("2019-06-12T06:11:43.500-07:00");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        mutableDateTime8.setDayOfYear((int) (short) 1);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime8.dayOfWeek();
        mutableDateTime8.addMinutes(0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        int int6 = property5.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = property5.getDateTime();
        boolean boolean9 = property5.isLeap();
        org.joda.time.DateTime dateTime11 = property5.addToCopy((long) 100);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.minus(readablePeriod14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) (-8));
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = fixedDateTimeZone4.getOffset((long) (short) 0);
        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        long long9 = offsetDateTimeField3.add(1560345124904L, (long) 11);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1907500324904L + "'", long9 == 1907500324904L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        org.joda.time.DurationField durationField4 = julianChronology1.weekyears();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket(1560345102967L, (org.joda.time.Chronology) julianChronology1, locale5, (java.lang.Integer) (-28800000), (-8));
        dateTimeParserBucket8.setOffset((java.lang.Integer) (-292269056));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(57599999, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear(2, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendCenturyOfEra(9, 69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (-9), 3);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(59);
        org.joda.time.DateTime.Property property12 = dateTime9.secondOfDay();
        org.joda.time.DateTime.Property property13 = dateTime9.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(2);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFixedSignedDecimal(dateTimeFieldType6, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.millisOfSecond();
        java.lang.String str4 = julianChronology2.toString();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology2, locale5, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology9 = dateTimeParserBucket8.getChronology();
        boolean boolean10 = buddhistChronology0.equals((java.lang.Object) dateTimeParserBucket8);
        java.lang.Object obj11 = dateTimeParserBucket8.saveState();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(57599999, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendCenturyOfEra(100, (-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.millisOfSecond();
        java.lang.String str13 = julianChronology11.toString();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology11, locale14, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology18 = dateTimeParserBucket17.getChronology();
        boolean boolean19 = buddhistChronology9.equals((java.lang.Object) dateTimeParserBucket17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = gJChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology21.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = gregorianChronology26.seconds();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.year();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = gJChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, dateTimeField32, 0);
        boolean boolean35 = skipUndoDateTimeField34.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField34);
        int int37 = skipDateTimeField36.getMinimumValue();
        long long39 = skipDateTimeField36.roundFloor((long) 1970);
        long long41 = skipDateTimeField36.roundHalfCeiling((long) 16);
        boolean boolean42 = skipDateTimeField36.isLenient();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.centuryOfEra();
        int int45 = property44.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField46 = property44.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property44.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType47);
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, "");
        dateTimeParserBucket17.saveField(dateTimeFieldType47, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType47, 1968, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder8.appendMinuteOfHour(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendSecondOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder57.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JulianChronology[UTC]" + "'", str13.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2922789 + "'", int45 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone8);
        mutableDateTime9.addDays(0);
        mutableDateTime9.setDayOfYear((int) '#');
        mutableDateTime9.addMillis(16);
        int int18 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "ISOChronology[UTC]", 1970);
        mutableDateTime9.setTime((long) 22303);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1971) + "'", int18 == (-1971));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime6.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) 'a');
        org.joda.time.DateTime dateTime5 = dateTime3.minusYears((-8));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        java.lang.String str7 = property5.getAsText();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField10 = gJChronology9.weeks();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.dayOfMonth();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.weekyear();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.minus(readableDuration17);
        int int19 = dateTime18.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay20 = dateTime18.toYearMonthDay();
        long long22 = julianChronology13.set((org.joda.time.ReadablePartial) yearMonthDay20, (long) 10);
        int[] intArray24 = gJChronology9.get((org.joda.time.ReadablePartial) yearMonthDay20, 100L);
        try {
            int int25 = property5.compareTo((org.joda.time.ReadablePartial) yearMonthDay20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1970 + "'", int19 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1036800010L + "'", long22 == 1036800010L);
        org.junit.Assert.assertNotNull(intArray24);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test170");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.yearOfEra();
//        int int4 = mutableDateTime0.getSecondOfDay();
//        mutableDateTime0.setDate((long) 97);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 18759 + "'", int4 == 18759);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gJChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = gregorianChronology8.seconds();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = gJChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField14, 0);
        boolean boolean17 = skipUndoDateTimeField16.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField16);
        int int19 = skipDateTimeField18.getMinimumValue();
        long long21 = skipDateTimeField18.roundFloor((long) 1970);
        long long23 = skipDateTimeField18.roundHalfCeiling((long) 16);
        mutableDateTime1.setRounding((org.joda.time.DateTimeField) skipDateTimeField18);
        long long26 = skipDateTimeField18.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GregorianChronology[UTC]", "");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.Throwable[] throwableArray4 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.getDifferenceAsLong(1560345103593L, 6975L);
        java.lang.String str47 = zeroIsMaxDateTimeField43.getName();
        long long49 = zeroIsMaxDateTimeField43.remainder(1560345097963L);
        int int51 = zeroIsMaxDateTimeField43.get((long) (-8));
        try {
            long long54 = zeroIsMaxDateTimeField43.set((long) (byte) 1, (-9));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for centuryOfEra must be in the range [1,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 26005751L + "'", long46 == 26005751L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "centuryOfEra" + "'", str47.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 37963L + "'", long49 == 37963L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 9 + "'", int51 == 9);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test175");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        int int1 = mutableDateTime0.getDayOfMonth();
//        mutableDateTime0.addWeekyears(0);
//        int int4 = mutableDateTime0.getWeekOfWeekyear();
//        mutableDateTime0.setMinuteOfDay((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.seconds();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = gJChronology11.weeks();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField13, 0);
//        boolean boolean16 = skipUndoDateTimeField15.isSupported();
//        long long19 = skipUndoDateTimeField15.add((long) (short) 1, 0L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField15.getAsText(31, locale21);
//        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField15);
//        long long26 = skipUndoDateTimeField15.add((-210866846400000L), 207360000000L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31" + "'", str22.equals("31"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 746285133153600000L + "'", long26 == 746285133153600000L);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.getDifferenceAsLong(1560345103593L, 6975L);
        java.lang.String str47 = zeroIsMaxDateTimeField43.getName();
        long long49 = zeroIsMaxDateTimeField43.remainder(1560345097963L);
        java.lang.String str50 = zeroIsMaxDateTimeField43.toString();
        long long52 = zeroIsMaxDateTimeField43.roundHalfFloor((-359999900L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 26005751L + "'", long46 == 26005751L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "centuryOfEra" + "'", str47.equals("centuryOfEra"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 37963L + "'", long49 == 37963L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str50.equals("DateTimeField[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-360000000L) + "'", long52 == (-360000000L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField3.getMaximumTextLength(locale7);
        long long10 = offsetDateTimeField3.remainder((long) (-292269056));
        long long13 = offsetDateTimeField3.set(0L, (int) ' ');
        long long15 = offsetDateTimeField3.roundFloor((long) 18759);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 30206930944L + "'", long10 == 30206930944L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61095686400000L) + "'", long13 == (-61095686400000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-30499200000L) + "'", long15 == (-30499200000L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(57599999, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendCenturyOfEra(100, (-1));
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.millisOfSecond();
        java.lang.String str13 = julianChronology11.toString();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology11, locale14, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology18 = dateTimeParserBucket17.getChronology();
        boolean boolean19 = buddhistChronology9.equals((java.lang.Object) dateTimeParserBucket17);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = gJChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology21.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = gregorianChronology26.seconds();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.year();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = gJChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, dateTimeField32, 0);
        boolean boolean35 = skipUndoDateTimeField34.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField34);
        int int37 = skipDateTimeField36.getMinimumValue();
        long long39 = skipDateTimeField36.roundFloor((long) 1970);
        long long41 = skipDateTimeField36.roundHalfCeiling((long) 16);
        boolean boolean42 = skipDateTimeField36.isLenient();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.centuryOfEra();
        int int45 = property44.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField46 = property44.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property44.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType47);
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, "");
        dateTimeParserBucket17.saveField(dateTimeFieldType47, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType47, 1968, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder8.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JulianChronology[UTC]" + "'", str13.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2922789 + "'", int45 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test179");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        int int1 = mutableDateTime0.getDayOfMonth();
//        mutableDateTime0.addWeekyears(0);
//        int int4 = mutableDateTime0.getWeekOfWeekyear();
//        mutableDateTime0.setMinuteOfDay((int) '4');
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.seconds();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
//        org.joda.time.DurationField durationField12 = gJChronology11.weeks();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField13, 0);
//        boolean boolean16 = skipUndoDateTimeField15.isSupported();
//        long long19 = skipUndoDateTimeField15.add((long) (short) 1, 0L);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = skipUndoDateTimeField15.getAsText(31, locale21);
//        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField15);
//        try {
//            long long26 = skipUndoDateTimeField15.set(20L, 292272991);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292272991 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31" + "'", str22.equals("31"));
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) '#');
        try {
            org.joda.time.LocalDateTime localDateTime7 = dateTimeFormatter5.parseLocalDateTime("27");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"27\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = skipUndoDateTimeField8.getAsShortText(readablePartial9, (int) (short) 1, locale11);
//        long long15 = skipUndoDateTimeField8.add((long) (byte) -1, 0);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = skipUndoDateTimeField8.getAsText(1560345069015L, locale17);
//        int int20 = skipUndoDateTimeField8.getMaximumValue((long) 58528);
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = skipUndoDateTimeField8.getAsText((-1961L), locale22);
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.weekyear();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.ReadableDuration readableDuration28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.minus(readableDuration28);
//        int int30 = dateTime29.getWeekyear();
//        org.joda.time.YearMonthDay yearMonthDay31 = dateTime29.toYearMonthDay();
//        long long33 = julianChronology24.set((org.joda.time.ReadablePartial) yearMonthDay31, (long) 10);
//        int[] intArray35 = null;
//        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        mutableDateTime37.setZone(dateTimeZone38);
//        long long40 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime37);
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime37.dayOfMonth();
//        boolean boolean42 = property41.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime43 = property41.roundCeiling();
//        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField45 = julianChronology44.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, (int) (short) -1);
//        long long49 = offsetDateTimeField47.roundHalfCeiling((-210865896000000L));
//        long long51 = offsetDateTimeField47.remainder((long) 2019);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.JulianChronology julianChronology55 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField56 = julianChronology55.millisOfSecond();
//        java.lang.String str57 = julianChronology55.toString();
//        java.util.Locale locale58 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket61 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology55, locale58, (java.lang.Integer) (-2922790), (int) ' ');
//        org.joda.time.Chronology chronology62 = dateTimeParserBucket61.getChronology();
//        boolean boolean63 = buddhistChronology53.equals((java.lang.Object) dateTimeParserBucket61);
//        java.lang.Integer int64 = dateTimeParserBucket61.getOffsetInteger();
//        java.util.Locale locale65 = dateTimeParserBucket61.getLocale();
//        java.lang.String str66 = offsetDateTimeField47.getAsShortText(6, locale65);
//        java.util.Calendar calendar67 = mutableDateTime43.toCalendar(locale65);
//        try {
//            int[] intArray68 = skipUndoDateTimeField8.set((org.joda.time.ReadablePartial) yearMonthDay31, 57599999, intArray35, "20", locale65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6" + "'", str18.equals("6"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "3" + "'", str23.equals("3"));
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1970 + "'", int30 == 1970);
//        org.junit.Assert.assertNotNull(yearMonthDay31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1036800010L + "'", long33 == 1036800010L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1767705160424L + "'", long40 == 1767705160424L);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertNotNull(julianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-210866803200000L) + "'", long49 == (-210866803200000L));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 30499202019L + "'", long51 == 30499202019L);
//        org.junit.Assert.assertNotNull(buddhistChronology53);
//        org.junit.Assert.assertNotNull(julianChronology55);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "JulianChronology[UTC]" + "'", str57.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNull(int64);
//        org.junit.Assert.assertNotNull(locale65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "6" + "'", str66.equals("6"));
//        org.junit.Assert.assertNotNull(calendar67);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        java.lang.String str4 = property3.getName();
        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (short) -1);
        long long12 = offsetDateTimeField10.roundHalfCeiling((-210865896000000L));
        long long14 = offsetDateTimeField10.remainder((long) 2019);
        long long16 = offsetDateTimeField10.roundHalfEven(1560345104283L);
        int int17 = dateTime5.get((org.joda.time.DateTimeField) offsetDateTimeField10);
        int int19 = offsetDateTimeField10.getLeapAmount((-210866846400000L));
        long long22 = offsetDateTimeField10.add((-28800001L), (long) 2);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "yearOfEra" + "'", str4.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210866803200000L) + "'", long12 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 30499202019L + "'", long14 == 30499202019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1547424000000L + "'", long16 == 1547424000000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292272990 + "'", int17 == 292272990);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 62870399999L + "'", long22 == 62870399999L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        long long12 = dateTimeZone9.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology14 = buddhistChronology7.withZone(dateTimeZone9);
        java.lang.String str15 = buddhistChronology7.toString();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((int) (short) 100, (int) (short) 1, 57601284, 69, 0, (int) (short) -1, 2, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57601284 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str15.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        int int44 = zeroIsMaxDateTimeField43.getMinimumValue();
        int int47 = zeroIsMaxDateTimeField43.getDifference(1036800000L, 57600000L);
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField49 = julianChronology48.weekyear();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration52 = null;
        org.joda.time.DateTime dateTime53 = dateTime51.minus(readableDuration52);
        int int54 = dateTime53.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay55 = dateTime53.toYearMonthDay();
        long long57 = julianChronology48.set((org.joda.time.ReadablePartial) yearMonthDay55, (long) 10);
        int[] intArray62 = new int[] { 18759, 6, 57599999, 27 };
        int int63 = zeroIsMaxDateTimeField43.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay55, intArray62);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 16320 + "'", int47 == 16320);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1970 + "'", int54 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1036800010L + "'", long57 == 1036800010L);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        int int6 = dateTime5.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withZone(dateTimeZone7);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime8.withZoneRetainFields(dateTimeZone10);
        org.joda.time.TimeOfDay timeOfDay13 = dateTime12.toTimeOfDay();
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (org.joda.time.ReadablePartial) timeOfDay13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 365 + "'", int6 == 365);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(timeOfDay13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusMillis((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime1.withCenturyOfEra((int) '#');
        org.joda.time.LocalDate localDate11 = dateTime1.toLocalDate();
        org.joda.time.DateTime dateTime13 = dateTime1.minusWeeks(1970);
        org.joda.time.DateTime dateTime15 = dateTime1.minus((-6025594249L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, 979200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.weekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        long long9 = dateTimeZone6.adjustOffset((long) (byte) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withDefaultYear(240);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withPivotYear((java.lang.Integer) 999);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("7");
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.dayOfYear();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-9));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.date();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (byte) 100);
        int int8 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.plus(readableDuration9);
        long long11 = dateTime10.getMillis();
        java.lang.String str12 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        mutableDateTime13.setZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField17 = gregorianChronology16.seconds();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.year();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = gJChronology20.weeks();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology20.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField22, 0);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipUndoDateTimeField24.getAsShortText(readablePartial25, (int) (short) 1, locale27);
        mutableDateTime13.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField24);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipUndoDateTimeField24.getType();
        org.joda.time.DateTime.Property property31 = dateTime10.property(dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder4.appendFixedDecimal(dateTimeFieldType30, 2);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, (int) '#', 960, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfHalfday must be in the range [960,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969-12-31" + "'", str12.equals("1969-12-31"));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1" + "'", str28.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = julianChronology1.eras();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 59, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.weekyear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test193");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfMonth();
//        boolean boolean5 = property4.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundCeiling();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(0);
//        java.util.Date date11 = dateTime8.toDate();
//        org.joda.time.DateTime dateTime13 = dateTime8.withYear((int) (byte) 1);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 100);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds(0);
//        boolean boolean18 = dateTime13.isAfter((org.joda.time.ReadableInstant) dateTime15);
//        long long19 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1767705161274L + "'", long3 == 1767705161274L);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 20460L + "'", long19 == 20460L);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        long long6 = gregorianChronology2.add((long) (short) 10, (long) 5, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gJChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField13, 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField15.getAsShortText(readablePartial16, (int) (short) 1, locale18);
        long long22 = skipUndoDateTimeField15.add((long) (byte) -1, 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField15.getAsText(1560345069015L, locale24);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.weekyear();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.minus(readableDuration30);
        int int32 = dateTime31.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        long long35 = julianChronology26.set((org.joda.time.ReadablePartial) yearMonthDay33, (long) 10);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay33, 31, locale37);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField15, 59);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.LocalDateTime localDateTime43 = dateTime42.toLocalDateTime();
        int[] intArray50 = new int[] { 69, (byte) 10, 22296758, 1968, 69 };
        try {
            int[] intArray52 = skipUndoDateTimeField15.addWrapField((org.joda.time.ReadablePartial) localDateTime43, 90, intArray50, 292272991);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 90");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 510L + "'", long6 == 510L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "6" + "'", str25.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1970 + "'", int32 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1036800010L + "'", long35 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31" + "'", str38.equals("31"));
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.getDifferenceAsLong(1560345096758L, (long) (short) 10);
        int int42 = dividedDateTimeField36.getDifference(26792601828L, 0L);
        int int44 = dividedDateTimeField36.get((long) 69);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2600575L + "'", long39 == 2600575L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 44654 + "'", int42 == 44654);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 1);
        long long6 = gregorianChronology2.add((long) (short) 10, (long) 5, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.seconds();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gJChronology11.weeks();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField13, 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField15.getAsShortText(readablePartial16, (int) (short) 1, locale18);
        long long22 = skipUndoDateTimeField15.add((long) (byte) -1, 0);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField15.getAsText(1560345069015L, locale24);
        org.joda.time.chrono.JulianChronology julianChronology26 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology26.weekyear();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime31 = dateTime29.minus(readableDuration30);
        int int32 = dateTime31.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        long long35 = julianChronology26.set((org.joda.time.ReadablePartial) yearMonthDay33, (long) 10);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay33, 31, locale37);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField40 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) skipUndoDateTimeField15, 59);
        boolean boolean42 = skipUndoDateTimeField15.isLeap(31L);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 510L + "'", long6 == 510L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "6" + "'", str25.equals("6"));
        org.junit.Assert.assertNotNull(julianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1970 + "'", int32 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1036800010L + "'", long35 == 1036800010L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31" + "'", str38.equals("31"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DurationField durationField4 = julianChronology2.hours();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology2.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone14);
        java.util.GregorianCalendar gregorianCalendar16 = mutableDateTime15.toGregorianCalendar();
        int int19 = dateTimeFormatter6.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime15, "", (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
        mutableDateTime15.setZoneRetainFields(dateTimeZone23);
        boolean boolean25 = julianChronology2.equals((java.lang.Object) dateTimeZone23);
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone33);
        mutableDateTime34.addDays(0);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (byte) 100);
        int int39 = dateTime38.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime41 = dateTime38.plus(readableDuration40);
        org.joda.time.DateTime.Property property42 = dateTime38.secondOfMinute();
        org.joda.time.DateTime dateTime44 = dateTime38.minusMinutes(0);
        mutableDateTime34.setDate((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime34.minuteOfDay();
        org.joda.time.MutableDateTime.Property property47 = mutableDateTime34.centuryOfEra();
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = julianChronology49.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, (int) (short) -1);
        long long54 = offsetDateTimeField52.roundHalfCeiling((-210865896000000L));
        long long56 = offsetDateTimeField52.remainder((long) 2019);
        org.joda.time.chrono.BuddhistChronology buddhistChronology58 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField61 = julianChronology60.millisOfSecond();
        java.lang.String str62 = julianChronology60.toString();
        java.util.Locale locale63 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket66 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology60, locale63, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology67 = dateTimeParserBucket66.getChronology();
        boolean boolean68 = buddhistChronology58.equals((java.lang.Object) dateTimeParserBucket66);
        java.lang.Integer int69 = dateTimeParserBucket66.getOffsetInteger();
        java.util.Locale locale70 = dateTimeParserBucket66.getLocale();
        java.lang.String str71 = offsetDateTimeField52.getAsShortText(6, locale70);
        org.joda.time.MutableDateTime mutableDateTime72 = property47.set("0", locale70);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket75 = new org.joda.time.format.DateTimeParserBucket((long) 1969, (org.joda.time.Chronology) julianChronology2, locale70, (java.lang.Integer) 365, 97);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-2) + "'", int19 == (-2));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-210866803200000L) + "'", long54 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 30499202019L + "'", long56 == 30499202019L);
        org.junit.Assert.assertNotNull(buddhistChronology58);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "JulianChronology[UTC]" + "'", str62.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(int69);
        org.junit.Assert.assertNotNull(locale70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "6" + "'", str71.equals("6"));
        org.junit.Assert.assertNotNull(mutableDateTime72);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gJChronology2.weeks();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 59, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.yearOfEra();
        long long11 = gJChronology2.add(999L, (long) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 999L + "'", long11 == 999L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        int int3 = dateTime1.getHourOfDay();
        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfDay();
        int int5 = property4.get();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 960 + "'", int5 == 960);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) 42L, (java.lang.Number) 2066, number3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertNull(str6);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test201");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Chronology chronology1 = instant0.getChronology();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
//        java.lang.String str4 = property3.getName();
//        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
//        org.joda.time.DateTime dateTime6 = dateTime5.toDateTimeISO();
//        int int7 = dateTime6.getMillisOfSecond();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "yearOfEra" + "'", str4.equals("yearOfEra"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 116 + "'", int7 == 116);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime4 = property2.set(2922789);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gJChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology7.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        boolean boolean21 = skipUndoDateTimeField20.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField22 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
        int int23 = skipDateTimeField22.getMinimumValue();
        long long25 = skipDateTimeField22.roundFloor((long) 1970);
        long long27 = skipDateTimeField22.roundHalfCeiling((long) 16);
        boolean boolean28 = skipDateTimeField22.isLenient();
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.centuryOfEra();
        int int31 = property30.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField32 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property30.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField22, dateTimeFieldType33);
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime4.property(dateTimeFieldType33);
        mutableDateTime4.setYear(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2922789 + "'", int31 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property35);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        int int7 = dateTime1.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime1.withMillis((long) 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-2));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder0.setStandardOffset(10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder0.setStandardOffset(1968);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        long long30 = remainderDateTimeField22.remainder(138059L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 18059L + "'", long30 == 18059L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay(19, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendYear((int) 'a', 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-1L));
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gJChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology3.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = gregorianChronology8.seconds();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.year();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField13 = gJChronology12.weeks();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField14, 0);
        boolean boolean17 = skipUndoDateTimeField16.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField16);
        int int19 = skipDateTimeField18.getMinimumValue();
        long long21 = skipDateTimeField18.roundFloor((long) 1970);
        long long23 = skipDateTimeField18.roundHalfCeiling((long) 16);
        mutableDateTime1.setRounding((org.joda.time.DateTimeField) skipDateTimeField18);
        org.joda.time.MutableDateTime mutableDateTime25 = mutableDateTime1.copy();
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(mutableDateTime25);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.withFields(readablePartial7);
        boolean boolean10 = dateTime6.isBefore((long) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime6.plusYears(2000);
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.DateTime.Property property14 = dateTime12.yearOfCentury();
        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
        try {
            org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime((java.lang.Object) property14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600100 + "'", int13 == 57600100);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone4.getID();
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        int int13 = dateTime12.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readableDuration14);
        org.joda.time.DateTime.Property property16 = dateTime12.secondOfMinute();
        boolean boolean17 = mutableDateTime9.isBefore((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime19 = dateTime12.withYear((int) (byte) -1);
        org.joda.time.DateTime.Property property20 = dateTime19.dayOfMonth();
        int int21 = dateTime19.getMinuteOfHour();
        org.joda.time.DateTime dateTime23 = dateTime19.minusSeconds((int) (short) -1);
        org.joda.time.DateTime dateTime25 = dateTime23.minusHours(0);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime27 = dateTime23.plus(readableDuration26);
        boolean boolean28 = fixedDateTimeZone4.equals((java.lang.Object) readableDuration26);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test211");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.millisOfSecond();
//        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = mutableDateTime6.toCalendar(locale7);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.dayOfWeek();
//        org.joda.time.DateTime dateTime10 = mutableDateTime6.toDateTimeISO();
//        boolean boolean11 = gJChronology1.equals((java.lang.Object) dateTime10);
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        mutableDateTime12.setZone(dateTimeZone13);
//        long long15 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.DateTimeZone dateTimeZone16 = mutableDateTime12.getZone();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = gJChronology1.withZone(dateTimeZone17);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1767705163047L + "'", long15 == 1767705163047L);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        long long12 = dateTimeZone9.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology14 = buddhistChronology7.withZone(dateTimeZone9);
        java.lang.String str15 = buddhistChronology7.toString();
        java.lang.String str16 = buddhistChronology7.toString();
        org.joda.time.Chronology chronology17 = buddhistChronology7.withUTC();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-194), (-9), (-26005751), 999, 0, 0, (int) (short) -1, (org.joda.time.Chronology) buddhistChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str15.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str16.equals("BuddhistChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) 57599999);
        long long12 = fixedDateTimeZone4.adjustOffset(1560345100914L, false);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00" + "'", str9.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560345100914L + "'", long12 == 1560345100914L);
        org.junit.Assert.assertNotNull(gJChronology13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) julianChronology2);
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(510L, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        int int7 = dateTime5.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 21 + "'", int7 == 21);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime(chronology3);
        mutableDateTime4.setMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.centuryOfEra();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime12 = property10.set(2922789);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField16 = gJChronology15.weeks();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology15.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = gregorianChronology20.seconds();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.year();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField25 = gJChronology24.weeks();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology24.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology20, dateTimeField26, 0);
        boolean boolean29 = skipUndoDateTimeField28.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, (org.joda.time.DateTimeField) skipUndoDateTimeField28);
        int int31 = skipDateTimeField30.getMinimumValue();
        long long33 = skipDateTimeField30.roundFloor((long) 1970);
        long long35 = skipDateTimeField30.roundHalfCeiling((long) 16);
        boolean boolean36 = skipDateTimeField30.isLenient();
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime37.centuryOfEra();
        int int39 = property38.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField40 = property38.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField30, dateTimeFieldType41);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime12.property(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType41, 69, (-9));
        boolean boolean47 = mutableDateTime4.isSupported(dateTimeFieldType41);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        mutableDateTime4.add(readablePeriod48);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2922789 + "'", int39 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        long long28 = remainderDateTimeField22.roundHalfCeiling(57600560L);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = remainderDateTimeField22.getType();
        org.joda.time.DurationField durationField30 = remainderDateTimeField22.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 57600000L + "'", long28 == 57600000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNull(durationField30);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        int int4 = dateTime3.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime7 = dateTime3.minus((long) 960);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8, (int) (byte) 1);
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology10.getZone();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime3.withZoneRetainFields(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("2922789");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2922789\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 18759, (org.joda.time.Chronology) julianChronology1);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        long long39 = dividedDateTimeField36.add((-12959982422000L), 0);
        long long42 = dividedDateTimeField36.add((-62105094000000L), 97);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField36);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-12959982422000L) + "'", long39 == (-12959982422000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62105035800000L) + "'", long42 == (-62105035800000L));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.withZone(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.minusHours(57600);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.weekyear();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone9);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime1.toMutableDateTime(dateTimeZone9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        mutableDateTime11.setDate(readableInstant12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        mutableDateTime11.add(readablePeriod14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        long long12 = skipUndoDateTimeField8.add((long) (short) 1, 0L);
        long long15 = skipUndoDateTimeField8.addWrapField((long) 57601381, 12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 57601381L + "'", long15 == 57601381L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendLiteral('4');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.seconds();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.year();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gJChronology13.weeks();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField17 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField15, 0);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.minus(readableDuration20);
        int int22 = dateTime21.getWeekyear();
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime21.toYearMonthDay();
        int[] intArray29 = new int[] { (byte) 1, 5, ' ', (short) -1 };
        int[] intArray31 = skipUndoDateTimeField17.addWrapField((org.joda.time.ReadablePartial) yearMonthDay23, 0, intArray29, 4);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.DateTime dateTime35 = dateTime33.minus(readableDuration34);
        org.joda.time.DateTime dateTime37 = dateTime33.withMillisOfSecond(100);
        org.joda.time.LocalDate localDate38 = dateTime33.toLocalDate();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipUndoDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate38, (-194), locale40);
        int int42 = skipUndoDateTimeField17.getMaximumValue();
        boolean boolean43 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatterBuilder8, (java.lang.Object) skipUndoDateTimeField17);
        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatterBuilder8.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1970 + "'", int22 == 1970);
        org.junit.Assert.assertNotNull(yearMonthDay23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "-194" + "'", str41.equals("-194"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 11 + "'", int42 == 11);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTimeParser44);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.minus(readablePeriod4);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
        org.joda.time.DateTime dateTime13 = property11.getDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (byte) 100);
        int int9 = dateTime8.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.withZone(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.withZoneRetainFields(dateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter16.withOffsetParsed();
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        mutableDateTime18.setZone(dateTimeZone19);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime18.yearOfEra();
        int int24 = dateTimeFormatter16.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime18, "GregorianChronology[UTC]", 2922789);
        int int25 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) mutableDateTime18);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone13);
        try {
            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(2019, (int) '#', 1968, 2922789, 0, 0, (-194), dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-2922790) + "'", int24 == (-2922790));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test228");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
//        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
//        boolean boolean15 = skipUndoDateTimeField14.isSupported();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
//        int int17 = skipDateTimeField16.getMinimumValue();
//        long long19 = skipDateTimeField16.roundFloor((long) 1970);
//        long long21 = skipDateTimeField16.roundHalfCeiling((long) 16);
//        boolean boolean22 = skipDateTimeField16.isLenient();
//        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.centuryOfEra();
//        int int25 = property24.getMaximumValueOverall();
//        org.joda.time.DateTimeField dateTimeField26 = property24.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, dateTimeFieldType27);
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        mutableDateTime29.setZone(dateTimeZone30);
//        long long32 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime29);
//        org.joda.time.MutableDateTime.Property property33 = mutableDateTime29.dayOfMonth();
//        boolean boolean34 = property33.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime35 = property33.roundCeiling();
//        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = julianChronology36.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (short) -1);
//        long long41 = offsetDateTimeField39.roundHalfCeiling((-210865896000000L));
//        long long43 = offsetDateTimeField39.remainder((long) 2019);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField48 = julianChronology47.millisOfSecond();
//        java.lang.String str49 = julianChronology47.toString();
//        java.util.Locale locale50 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology47, locale50, (java.lang.Integer) (-2922790), (int) ' ');
//        org.joda.time.Chronology chronology54 = dateTimeParserBucket53.getChronology();
//        boolean boolean55 = buddhistChronology45.equals((java.lang.Object) dateTimeParserBucket53);
//        java.lang.Integer int56 = dateTimeParserBucket53.getOffsetInteger();
//        java.util.Locale locale57 = dateTimeParserBucket53.getLocale();
//        java.lang.String str58 = offsetDateTimeField39.getAsShortText(6, locale57);
//        java.util.Calendar calendar59 = mutableDateTime35.toCalendar(locale57);
//        int int60 = skipDateTimeField16.getMaximumTextLength(locale57);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2922789 + "'", int25 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1767705164044L + "'", long32 == 1767705164044L);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(julianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-210866803200000L) + "'", long41 == (-210866803200000L));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 30499202019L + "'", long43 == 30499202019L);
//        org.junit.Assert.assertNotNull(buddhistChronology45);
//        org.junit.Assert.assertNotNull(julianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "JulianChronology[UTC]" + "'", str49.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNull(int56);
//        org.junit.Assert.assertNotNull(locale57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "6" + "'", str58.equals("6"));
//        org.junit.Assert.assertNotNull(calendar59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test229");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = julianChronology1.eras();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        boolean boolean5 = dateTimeZone3.isStandardOffset((long) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        mutableDateTime7.setZone(dateTimeZone8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.addWrapField(100);
//        boolean boolean14 = gJChronology6.equals((java.lang.Object) 100);
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) gJChronology6, locale15, (java.lang.Integer) 1970, 31);
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology6.weekyear();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1767705164402L + "'", long10 == 1767705164402L);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 10);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.add((-719528L), 1560345102464L);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField43.getLeapDurationField();
        long long50 = zeroIsMaxDateTimeField43.add((long) (byte) 10, 1);
        long long53 = zeroIsMaxDateTimeField43.getDifferenceAsLong((-2L), 30206930944L);
        int int56 = zeroIsMaxDateTimeField43.getDifference((long) 3, (-62105035800000L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 93620706147120472L + "'", long46 == 93620706147120472L);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 60010L + "'", long50 == 60010L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-503448L) + "'", long53 == (-503448L));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1035083930 + "'", int56 == 1035083930);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gJChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField6, 0);
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        long long12 = skipUndoDateTimeField8.add((long) (short) 1, 0L);
        long long15 = skipUndoDateTimeField8.add(0L, 0L);
        int int16 = skipUndoDateTimeField8.getMinimumValue();
        org.joda.time.DateTimeField dateTimeField17 = skipUndoDateTimeField8.getWrappedField();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendTwoDigitWeekyear((-2));
        boolean boolean21 = dateTimeFormatterBuilder18.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder18.appendMillisOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder23.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendLiteral('4');
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (byte) 100);
        int int29 = dateTime28.getWeekOfWeekyear();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime28.toMutableDateTime(chronology30);
        mutableDateTime31.setMillisOfSecond(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.centuryOfEra();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime35.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime39 = property37.set(2922789);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41);
        org.joda.time.DurationField durationField43 = gJChronology42.weeks();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology42.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology42.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField46 = gJChronology42.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField48 = gregorianChronology47.seconds();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.year();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50);
        org.joda.time.DurationField durationField52 = gJChronology51.weeks();
        org.joda.time.DateTimeField dateTimeField53 = gJChronology51.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology47, dateTimeField53, 0);
        boolean boolean56 = skipUndoDateTimeField55.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology42, (org.joda.time.DateTimeField) skipUndoDateTimeField55);
        int int58 = skipDateTimeField57.getMinimumValue();
        long long60 = skipDateTimeField57.roundFloor((long) 1970);
        long long62 = skipDateTimeField57.roundHalfCeiling((long) 16);
        boolean boolean63 = skipDateTimeField57.isLenient();
        org.joda.time.MutableDateTime mutableDateTime64 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property65 = mutableDateTime64.centuryOfEra();
        int int66 = property65.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField67 = property65.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property65.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField57, dateTimeFieldType68);
        org.joda.time.MutableDateTime.Property property70 = mutableDateTime39.property(dateTimeFieldType68);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder34.appendSignedDecimal(dateTimeFieldType68, 69, (-9));
        boolean boolean74 = mutableDateTime31.isSupported(dateTimeFieldType68);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder26.appendSignedDecimal(dateTimeFieldType68, 57599999, 2116);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField78 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17, dateTimeFieldType68);
        org.joda.time.IllegalFieldValueException illegalFieldValueException82 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType68, (java.lang.Number) 921600L, (java.lang.Number) 18751827L, (java.lang.Number) 1560345098484L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2922789 + "'", int66 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.getDifferenceAsLong(1560345103593L, 6975L);
        long long49 = zeroIsMaxDateTimeField43.add((long) 31, (long) 16320);
        long long51 = zeroIsMaxDateTimeField43.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "7" + "'", str28.equals("7"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 26005751L + "'", long46 == 26005751L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 979200031L + "'", long49 == 979200031L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds((-25200000));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        java.util.Locale locale1 = null;
        java.util.Calendar calendar2 = mutableDateTime0.toCalendar(locale1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(0);
        java.util.Date date8 = dateTime5.toDate();
        org.joda.time.DateTime dateTime10 = dateTime5.withYear((int) (byte) 1);
        mutableDateTime0.setDate((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gJChronology14.weeks();
        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology14.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.seconds();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.year();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gJChronology23.weeks();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology23.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField25, 0);
        boolean boolean28 = skipUndoDateTimeField27.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, (org.joda.time.DateTimeField) skipUndoDateTimeField27);
        int int30 = skipDateTimeField29.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, (org.joda.time.DateTimeField) skipDateTimeField29, 0);
        org.joda.time.DurationField durationField33 = skipDateTimeField29.getDurationField();
        org.junit.Assert.assertNotNull(calendar2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(durationField33);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
        org.joda.time.DateTime dateTime7 = dateTime1.plus((long) 1);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, (-2066));
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withDayOfMonth(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        org.joda.time.Instant instant9 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology10 = instant9.getChronology();
        mutableDateTime8.setChronology(chronology10);
        try {
            mutableDateTime8.setSecondOfMinute((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(chronology10);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test238");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        mutableDateTime1.setZone(dateTimeZone2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime1);
//        boolean boolean5 = instant0.isBefore((org.joda.time.ReadableInstant) mutableDateTime1);
//        mutableDateTime1.addYears((int) 'a');
//        int int8 = mutableDateTime1.getWeekyear();
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime1.year();
//        java.lang.String str10 = property9.toString();
//        org.joda.time.DurationField durationField11 = property9.getRangeDurationField();
//        org.joda.time.MutableDateTime mutableDateTime13 = property9.add((-2));
//        boolean boolean14 = property9.isLeap();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1767705165354L + "'", long4 == 1767705165354L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2123 + "'", int8 == 2123);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[year]" + "'", str10.equals("Property[year]"));
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone4);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology1, locale9, (java.lang.Integer) 57599);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime17 = dateTime15.withMillisOfDay((int) 'a');
        int int18 = dateTime17.getEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.DateTime dateTime21 = dateTime17.withZoneRetainFields(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(207359999991L, dateTimeZone20);
        org.joda.time.Chronology chronology23 = gregorianChronology1.withZone(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime(0L);
        org.joda.time.MutableDateTime mutableDateTime26 = mutableDateTime25.copy();
        try {
            org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) mutableDateTime26, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(mutableDateTime26);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime1.minusMillis((int) ' ');
        org.joda.time.DateTime dateTime9 = dateTime1.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 10);
        long long10 = fixedDateTimeZone4.previousTransition(2440588L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2440588L + "'", long10 == 2440588L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 1968);
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime10 = dateTime3.withYear((int) (byte) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfMonth();
        org.joda.time.DateTime dateTime13 = property11.addToCopy(0);
        org.joda.time.DateTime dateTime15 = dateTime13.minus((long) (byte) -1);
        org.joda.time.DateTime dateTime17 = dateTime13.plusMillis(10);
        org.joda.time.DateTime dateTime19 = dateTime13.plusYears(57599999);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test245");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
//        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
//        boolean boolean15 = skipUndoDateTimeField14.isSupported();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
//        int int17 = skipUndoDateTimeField14.getMinimumValue();
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        mutableDateTime20.setZone(dateTimeZone21);
//        long long23 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime20);
//        org.joda.time.MutableDateTime.Property property24 = mutableDateTime20.dayOfMonth();
//        boolean boolean25 = property24.isLeap();
//        org.joda.time.MutableDateTime mutableDateTime26 = property24.roundCeiling();
//        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.weekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) (short) -1);
//        long long32 = offsetDateTimeField30.roundHalfCeiling((-210865896000000L));
//        long long34 = offsetDateTimeField30.remainder((long) 2019);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.millisOfSecond();
//        java.lang.String str40 = julianChronology38.toString();
//        java.util.Locale locale41 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket44 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology38, locale41, (java.lang.Integer) (-2922790), (int) ' ');
//        org.joda.time.Chronology chronology45 = dateTimeParserBucket44.getChronology();
//        boolean boolean46 = buddhistChronology36.equals((java.lang.Object) dateTimeParserBucket44);
//        java.lang.Integer int47 = dateTimeParserBucket44.getOffsetInteger();
//        java.util.Locale locale48 = dateTimeParserBucket44.getLocale();
//        java.lang.String str49 = offsetDateTimeField30.getAsShortText(6, locale48);
//        java.util.Calendar calendar50 = mutableDateTime26.toCalendar(locale48);
//        try {
//            long long51 = skipUndoDateTimeField14.set(3600035L, "57599999", locale48);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599999 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1767705165580L + "'", long23 == 1767705165580L);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(julianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-210866803200000L) + "'", long32 == (-210866803200000L));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 30499202019L + "'", long34 == 30499202019L);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(julianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "JulianChronology[UTC]" + "'", str40.equals("JulianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNull(int47);
//        org.junit.Assert.assertNotNull(locale48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "6" + "'", str49.equals("6"));
//        org.junit.Assert.assertNotNull(calendar50);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(dateTimeZone1);
        mutableDateTime2.setSecondOfDay(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.DateTime dateTime1 = instant0.toDateTime();
        org.joda.time.Instant instant3 = instant0.minus(138059L);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Property[year]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Property[year]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        long long12 = dateTimeZone8.convertLocalToUTC(365L, true);
        try {
            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (-62105035800000L), (-57600000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -57600000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 365L + "'", long12 == 365L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = gregorianChronology1.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology8 = gregorianChronology1.withZone(dateTimeZone4);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology1, locale9, (java.lang.Integer) 57599);
        long long13 = dateTimeParserBucket11.computeMillis(true);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(57599999, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond(22303, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendYear((int) '#', 576012);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeParserBucket7.getZone();
        dateTimeParserBucket7.setOffset(11);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        mutableDateTime8.addDays(0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime8.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.seconds();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.year();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.DurationField durationField17 = gJChronology16.weeks();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField18, 0);
        java.util.Locale locale22 = null;
        java.lang.String str23 = skipUndoDateTimeField20.getAsText((int) (short) 1, locale22);
        mutableDateTime8.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField20);
        mutableDateTime8.setDayOfYear((int) (short) 1);
        mutableDateTime8.addSeconds((-1));
        int int29 = mutableDateTime8.getRoundingMode();
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) (short) -1);
        long long6 = offsetDateTimeField3.set(3600000L, 0);
        java.util.Locale locale7 = null;
        int int8 = offsetDateTimeField3.getMaximumTextLength(locale7);
        long long10 = offsetDateTimeField3.remainder((long) (-292269056));
        int int11 = offsetDateTimeField3.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105094000000L) + "'", long6 == (-62105094000000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 30206930944L + "'", long10 == 30206930944L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292272991 + "'", int11 == 292272991);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder10.setFixedSavings("", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder15 = dateTimeZoneBuilder10.setStandardOffset((-2));
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeZoneBuilder15.toDateTimeZone("UTC", true);
        org.joda.time.Chronology chronology19 = buddhistChronology1.withZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(1560345103146L, (org.joda.time.Chronology) buddhistChronology1);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        long long25 = remainderDateTimeField22.add(207359999991L, 1560345104283L);
        long long27 = remainderDateTimeField22.roundHalfEven((long) (short) 10);
        long long29 = remainderDateTimeField22.remainder((long) 22303);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 93620913616979991L + "'", long25 == 93620913616979991L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 22303L + "'", long29 == 22303L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime1.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime7 = dateTime1.withYear((int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(0);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property11 = dateTime7.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond(57599999, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendClockhourOfDay((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.centuryOfEra();
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime14.centuryOfEra();
        org.joda.time.MutableDateTime mutableDateTime18 = property16.set(2922789);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField22 = gJChronology21.weeks();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology21.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = gregorianChronology26.seconds();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology26.year();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
        org.joda.time.DurationField durationField31 = gJChronology30.weeks();
        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, dateTimeField32, 0);
        boolean boolean35 = skipUndoDateTimeField34.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, (org.joda.time.DateTimeField) skipUndoDateTimeField34);
        int int37 = skipDateTimeField36.getMinimumValue();
        long long39 = skipDateTimeField36.roundFloor((long) 1970);
        long long41 = skipDateTimeField36.roundHalfCeiling((long) 16);
        boolean boolean42 = skipDateTimeField36.isLenient();
        org.joda.time.MutableDateTime mutableDateTime43 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.centuryOfEra();
        int int45 = property44.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField46 = property44.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property44.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField48 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType47);
        org.joda.time.MutableDateTime.Property property49 = mutableDateTime18.property(dateTimeFieldType47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder13.appendSignedDecimal(dateTimeFieldType47, 69, (-9));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder13.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder13.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder13.appendSecondOfMinute(2116);
        org.joda.time.chrono.BuddhistChronology buddhistChronology59 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology60 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology59);
        org.joda.time.DateTimeField dateTimeField61 = buddhistChronology59.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime62 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        mutableDateTime62.setZone(dateTimeZone63);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField66 = gregorianChronology65.seconds();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology65.year();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68);
        org.joda.time.DurationField durationField70 = gJChronology69.weeks();
        org.joda.time.DateTimeField dateTimeField71 = gJChronology69.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology65, dateTimeField71, 0);
        org.joda.time.ReadablePartial readablePartial74 = null;
        java.util.Locale locale76 = null;
        java.lang.String str77 = skipUndoDateTimeField73.getAsShortText(readablePartial74, (int) (short) 1, locale76);
        mutableDateTime62.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField73);
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = skipUndoDateTimeField73.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField81 = new org.joda.time.field.RemainderDateTimeField(dateTimeField61, dateTimeFieldType79, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder82 = dateTimeFormatterBuilder58.appendShortText(dateTimeFieldType79);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType79, 44654, 576012);
        org.joda.time.IllegalFieldValueException illegalFieldValueException89 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType79, (java.lang.Number) 187241412109680001L, (java.lang.Number) 1036800010L, (java.lang.Number) 1560345164283L);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField90 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2922789 + "'", int45 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(buddhistChronology59);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(durationField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "1" + "'", str77.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        boolean boolean15 = skipUndoDateTimeField14.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField14);
        boolean boolean18 = skipUndoDateTimeField14.isLeap((long) 4);
        long long21 = skipUndoDateTimeField14.set(59L, 3);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10800059L + "'", long21 == 10800059L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(dateTimeZone0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTime.Property property3 = dateTime1.hourOfDay();
        org.joda.time.DateTime dateTime4 = property3.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime6 = property3.setCopy(9);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfDay();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond(57599999, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfSecond(22303, 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(1969, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        int int2 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        long long5 = dateTime4.getMillis();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours(0);
        org.joda.time.DateTime.Property property8 = dateTime4.weekyear();
        org.joda.time.DateTime dateTime10 = dateTime4.withMillis(32400000000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.minus(readableDuration13);
        org.joda.time.DateTime dateTime16 = dateTime12.withMillisOfSecond(100);
        org.joda.time.DateTime dateTime18 = dateTime12.withYear((int) 'a');
        org.joda.time.DateTime dateTime20 = dateTime18.minusMonths(0);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime18);
        int int22 = dateTime18.getDayOfWeek();
        try {
            org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime18, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 20");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.minuteOfHour();
        org.joda.time.DateTime dateTime13 = dateTime10.withWeekyear(20);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        int int26 = remainderDateTimeField22.getMaximumValue((long) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime27.centuryOfEra();
        int int29 = property28.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField30 = property28.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType31, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType31);
        java.lang.String str37 = dividedDateTimeField36.getName();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2922789 + "'", int29 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "centuryOfEra" + "'", str37.equals("centuryOfEra"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField2 = gJChronology1.weeks();
        boolean boolean4 = gJChronology1.equals((java.lang.Object) "1969-12-31T15:59:59.999-08:00");
        org.joda.time.DurationField durationField5 = gJChronology1.weeks();
        long long8 = durationField5.subtract((-6025594249L), 0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-6025594249L) + "'", long8 == (-6025594249L));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        long long6 = dateTimeZone3.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology8 = buddhistChronology1.withZone(dateTimeZone3);
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(obj0, dateTimeZone3);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone3);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.add((-719528L), 1560345102464L);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField43.getLeapDurationField();
        int int49 = zeroIsMaxDateTimeField43.getMinimumValue(14745600L);
        int int51 = zeroIsMaxDateTimeField43.get((long) 22303951);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = zeroIsMaxDateTimeField43.getType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 93620706147120472L + "'", long46 == 93620706147120472L);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test273");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        mutableDateTime0.setZone(dateTimeZone1);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime0);
//        org.joda.time.DateTimeZone dateTimeZone4 = mutableDateTime0.getZone();
//        org.joda.time.DateTime dateTime5 = mutableDateTime0.toDateTime();
//        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1767705166544L + "'", long3 == 1767705166544L);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localTime6);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test274");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = julianChronology1.eras();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        boolean boolean5 = dateTimeZone3.isStandardOffset((long) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
//        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        mutableDateTime7.setZone(dateTimeZone8);
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.addWrapField(100);
//        boolean boolean14 = gJChronology6.equals((java.lang.Object) 100);
//        java.util.Locale locale15 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 1970, (org.joda.time.Chronology) gJChronology6, locale15, (java.lang.Integer) 1970, 31);
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = julianChronology19.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone21 = julianChronology19.getZone();
//        org.joda.time.DateTimeField dateTimeField22 = julianChronology19.monthOfYear();
//        boolean boolean23 = gJChronology6.equals((java.lang.Object) julianChronology19);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1767705166570L + "'", long10 == 1767705166570L);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        int int44 = zeroIsMaxDateTimeField43.getMinimumValue();
        int int47 = zeroIsMaxDateTimeField43.getDifference(1036800000L, 57600000L);
        int int48 = zeroIsMaxDateTimeField43.getMinimumValue();
        int int51 = zeroIsMaxDateTimeField43.getDifference((-1961L), 1560345104090L);
        int int53 = zeroIsMaxDateTimeField43.getMinimumValue(1560345096758L);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.ReadableDuration readableDuration56 = null;
        org.joda.time.DateTime dateTime57 = dateTime55.minus(readableDuration56);
        org.joda.time.DateTime dateTime59 = dateTime57.minusWeeks(365);
        org.joda.time.DateTime.Property property60 = dateTime59.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.LocalDateTime localDateTime63 = dateTimeFormatter61.parseLocalDateTime("1969-12");
        int int64 = property60.compareTo((org.joda.time.ReadablePartial) localDateTime63);
        int int65 = zeroIsMaxDateTimeField43.getMaximumValue((org.joda.time.ReadablePartial) localDateTime63);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 16320 + "'", int47 == 16320);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-26005751) + "'", int51 == (-26005751));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertNotNull(localDateTime63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone7);
        java.util.GregorianCalendar gregorianCalendar9 = mutableDateTime8.toGregorianCalendar();
        mutableDateTime8.setMinuteOfDay((int) (short) 0);
        boolean boolean12 = mutableDateTime8.isAfterNow();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = julianChronology13.eras();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology13.getZone();
        mutableDateTime8.setZoneRetainFields(dateTimeZone16);
        long long20 = dateTimeZone16.convertLocalToUTC((long) (byte) -1, true);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) 'a');
        java.lang.Integer int3 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((int) '#');
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(4, 10, (int) (short) 1, 4, 3, (int) (byte) 10, 365, dateTimeZone13);
        mutableDateTime14.addDays(0);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (byte) 100);
        int int19 = dateTime18.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.plus(readableDuration20);
        org.joda.time.DateTime.Property property22 = dateTime18.secondOfMinute();
        org.joda.time.DateTime dateTime24 = dateTime18.minusMinutes(0);
        mutableDateTime14.setDate((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime14.minuteOfDay();
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime14.centuryOfEra();
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.weekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (short) -1);
        long long34 = offsetDateTimeField32.roundHalfCeiling((-210865896000000L));
        long long36 = offsetDateTimeField32.remainder((long) 2019);
        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = julianChronology40.millisOfSecond();
        java.lang.String str42 = julianChronology40.toString();
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology40, locale43, (java.lang.Integer) (-2922790), (int) ' ');
        org.joda.time.Chronology chronology47 = dateTimeParserBucket46.getChronology();
        boolean boolean48 = buddhistChronology38.equals((java.lang.Object) dateTimeParserBucket46);
        java.lang.Integer int49 = dateTimeParserBucket46.getOffsetInteger();
        java.util.Locale locale50 = dateTimeParserBucket46.getLocale();
        java.lang.String str51 = offsetDateTimeField32.getAsShortText(6, locale50);
        org.joda.time.MutableDateTime mutableDateTime52 = property27.set("0", locale50);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter5.withLocale(locale50);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-210866803200000L) + "'", long34 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 30499202019L + "'", long36 == 30499202019L);
        org.junit.Assert.assertNotNull(buddhistChronology38);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "JulianChronology[UTC]" + "'", str42.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(int49);
        org.junit.Assert.assertNotNull(locale50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "6" + "'", str51.equals("6"));
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gJChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7, 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology1);
        try {
            long long15 = gregorianChronology1.getDateTimeMillis(3, 21, (-8), 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test281");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        int int1 = mutableDateTime0.getDayOfMonth();
//        mutableDateTime0.addWeekyears(0);
//        int int4 = mutableDateTime0.getWeekOfWeekyear();
//        int int5 = mutableDateTime0.getHourOfDay();
//        try {
//            mutableDateTime0.setDate(57601284, 63, 4);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 63 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.DateTime dateTime3 = dateTime0.withDurationAdded(readableDuration1, 2019);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test283");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(3);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(57599999, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitYear(2, false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendCenturyOfEra(9, 69);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendDayOfWeek(11);
//        org.joda.time.Instant instant14 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        mutableDateTime15.setZone(dateTimeZone16);
//        long long18 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) mutableDateTime15);
//        boolean boolean19 = instant14.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
//        mutableDateTime15.addYears((int) 'a');
//        int int22 = mutableDateTime15.getWeekyear();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField24 = gregorianChronology23.seconds();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.year();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26);
//        org.joda.time.DurationField durationField28 = gJChronology27.weeks();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField31 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology23, dateTimeField29, 0);
//        boolean boolean32 = skipUndoDateTimeField31.isSupported();
//        long long35 = skipUndoDateTimeField31.add(2440588L, 0);
//        java.util.Locale locale36 = null;
//        int int37 = skipUndoDateTimeField31.getMaximumTextLength(locale36);
//        mutableDateTime15.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField31);
//        org.joda.time.MutableDateTime mutableDateTime39 = new org.joda.time.MutableDateTime();
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.centuryOfEra();
//        int int41 = property40.getMaximumValueOverall();
//        org.joda.time.DateTimeField dateTimeField42 = property40.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property40.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField31, dateTimeFieldType43, 1, 22296758, 12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1767705167242L + "'", long18 == 1767705167242L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2123 + "'", int22 == 2123);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2440588L + "'", long35 == 2440588L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2922789 + "'", int41 == 2922789);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded((long) (-9), 3);
        org.joda.time.DateTime dateTime11 = dateTime9.withYearOfCentury(59);
        int int12 = dateTime9.getMonthOfYear();
        try {
            org.joda.time.Instant instant13 = new org.joda.time.Instant((java.lang.Object) int12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        mutableDateTime0.setZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology3.seconds();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.year();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gJChronology7.weeks();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField9, 0);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = skipUndoDateTimeField11.getAsShortText(readablePartial12, (int) (short) 1, locale14);
        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField11);
        long long18 = skipUndoDateTimeField11.roundHalfEven((-12959983159412L));
        org.joda.time.DurationField durationField19 = skipUndoDateTimeField11.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-12959982000000L) + "'", long18 == (-12959982000000L));
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(365L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000042245d + "'", double1 == 2440587.5000042245d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[UTC]", "GregorianChronology[UTC]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) (-2));
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[UTC]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2L) + "'", long6 == (-2L));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(0);
        java.util.Date date4 = dateTime1.toDate();
        org.joda.time.DateTime dateTime6 = dateTime1.withYear((int) (byte) 1);
        org.joda.time.LocalDate localDate7 = dateTime1.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime1.minus(1560345097933L);
        org.joda.time.DateTime dateTime11 = dateTime1.minusMonths(57601284);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.millisOfSecond();
        java.lang.String str3 = julianChronology1.toString();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) '4', (org.joda.time.Chronology) julianChronology1, locale4, (java.lang.Integer) (-2922790), (int) ' ');
        int int8 = dateTimeParserBucket7.getOffset();
        long long11 = dateTimeParserBucket7.computeMillis(false, "1970-01-01T00:00:05.199Z");
        java.util.Locale locale12 = dateTimeParserBucket7.getLocale();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(locale12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (byte) 100);
        int int4 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        boolean boolean8 = mutableDateTime0.isBefore((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property9 = dateTime3.millisOfSecond();
        org.joda.time.DateTime dateTime11 = property9.addToCopy((long) (-2922790));
        org.joda.time.DateTime dateTime13 = dateTime11.minus(1036800000L);
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gJChronology5.weeks();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField7, 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology1.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology13 = gregorianChronology12.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        long long18 = dateTimeZone15.convertLocalToUTC((long) (short) 10, true);
        org.joda.time.Chronology chronology19 = gregorianChronology12.withZone(dateTimeZone15);
        java.lang.String str20 = dateTimeZone15.getID();
        org.joda.time.Chronology chronology21 = gregorianChronology1.withZone(dateTimeZone15);
        java.lang.String str22 = gregorianChronology1.toString();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTC" + "'", str20.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "GregorianChronology[UTC]" + "'", str22.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.minuteOfHour();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime3.setZone(dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.seconds();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.year();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gJChronology10.weeks();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12, 0);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipUndoDateTimeField14.getAsShortText(readablePartial15, (int) (short) 1, locale17);
        mutableDateTime3.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField14);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = skipUndoDateTimeField14.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType20, (int) (short) 10);
        boolean boolean24 = remainderDateTimeField22.isLeap(0L);
        long long26 = remainderDateTimeField22.roundHalfEven(207359999991L);
        java.lang.String str28 = remainderDateTimeField22.getAsText((-12959983159412L));
        boolean boolean30 = remainderDateTimeField22.isLeap((long) (short) 0);
        long long33 = remainderDateTimeField22.getDifferenceAsLong(6975L, 32L);
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.centuryOfEra();
        int int36 = property35.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField37 = property35.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property35.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 59, (java.lang.Number) (byte) 1, (java.lang.Number) 4);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField22, dateTimeFieldType38);
        long long46 = zeroIsMaxDateTimeField43.add((-719528L), 1560345102464L);
        org.joda.time.DurationField durationField47 = zeroIsMaxDateTimeField43.getLeapDurationField();
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (byte) 100);
        org.joda.time.LocalDateTime localDateTime50 = dateTime49.toLocalDateTime();
        int[] intArray51 = null;
        int int52 = zeroIsMaxDateTimeField43.getMinimumValue((org.joda.time.ReadablePartial) localDateTime50, intArray51);
        long long54 = zeroIsMaxDateTimeField43.remainder((long) 365);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 207360000000L + "'", long26 == 207360000000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2922789 + "'", int36 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 93620706147120472L + "'", long46 == 93620706147120472L);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 365L + "'", long54 == 365L);
    }
}

