import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) (byte) 1, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) 100, periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '#');
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        try {
            int int4 = period2.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 'a', (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Seconds");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Seconds/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType9 = periodType8.withWeeksRemoved();
        org.joda.time.PeriodType periodType10 = periodType8.withMinutesRemoved();
        java.lang.String str11 = periodType10.getName();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((int) (short) -1, (int) (byte) 10, 200, (int) (byte) 0, 1, (int) '4', (int) (byte) 100, (int) (byte) 0, periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Seconds" + "'", str11.equals("Seconds"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        int int7 = period6.getMinutes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, (int) (byte) -1, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.weekyears();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) 100);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) 200);
        java.lang.Class<?> wildcardClass3 = period2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType6 = periodType5.withWeeksRemoved();
        org.joda.time.PeriodType periodType7 = periodType5.withMinutesRemoved();
        org.joda.time.Period period8 = period4.withPeriodType(periodType5);
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) -1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField5 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((-1), (int) (byte) -1, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.weekyears();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        try {
            org.joda.time.Period period6 = period3.withPeriodType(periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType6 = periodType5.withWeeksRemoved();
        org.joda.time.PeriodType periodType7 = periodType5.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.weekyears();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.yearOfEra();
        try {
            org.joda.time.Period period11 = new org.joda.time.Period((java.lang.Object) period4, periodType5, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
//        org.joda.time.Period period6 = period4.minusMonths((int) '#');
//        org.joda.time.Period period8 = period6.minusMillis(10);
//        org.joda.time.Period period10 = period6.plusMinutes((int) (short) 1);
//        long long13 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period6, 0L, 4);
//        try {
//            long long19 = gregorianChronology0.getDateTimeMillis((long) 'a', (int) (short) 100, (-100), (-1), 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-368326799612L) + "'", long13 == (-368326799612L));
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) '4');
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        int int7 = period6.getSeconds();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 10, 0, (int) (byte) 1, (int) (byte) 0, 100, (int) (byte) 1, 4, (int) (short) -1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        org.joda.time.DurationField durationField3 = gregorianChronology1.seconds();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField4 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
//        org.joda.time.Period period6 = period4.minusMonths((int) '#');
//        org.joda.time.Period period8 = period6.minusMillis(10);
//        org.joda.time.Period period10 = period6.plusMinutes((int) (short) 1);
//        long long13 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period6, 0L, 4);
//        try {
//            long long21 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, 4, 0, (int) (short) -1, 0, 4, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-368326799612L) + "'", long13 == (-368326799612L));
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 99L, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "-00:00:00.001");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) 200);
        org.joda.time.Period period4 = period2.minusHours(1);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        try {
            org.joda.time.Period period10 = period8.plusMonths(1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.Period period1 = org.joda.time.Period.millis(10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray2 = period1.getFieldTypes();
        int int3 = period1.getWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(durationFieldTypeArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(3L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) 200);
        int int3 = period2.getDays();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 10, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Seconds");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 0, (int) (byte) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.plusWeeks((int) (byte) 100);
        try {
            int int13 = period9.getValue(200);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        try {
            long long14 = unsupportedDurationField11.getMillis((long) '#', (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) strSet0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.util.TreeSet");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((int) (short) -1, (int) '4', (int) '#', 0, (int) 'a', (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        try {
            long long14 = unsupportedDurationField11.add((long) '#', (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 100, 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
//        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
//        java.lang.String str7 = dateTimeZone1.getName(2440588L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pacific Standard Time" + "'", str7.equals("Pacific Standard Time"));
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '4', (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField2 = gregorianChronology0.seconds();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            long long5 = gregorianChronology0.set(readablePartial3, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        try {
            long long13 = unsupportedDurationField11.getMillis(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        try {
            int int13 = unsupportedDurationField11.getValue(2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.junit.Assert.assertNotNull(period0);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
//        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
//        java.lang.String str6 = gregorianChronology0.toString();
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.secondOfMinute();
//        int int10 = gregorianChronology8.getMinimumDaysInFirstWeek();
//        int int11 = gregorianChronology8.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField12 = gregorianChronology8.weeks();
//        org.joda.time.DurationField durationField13 = gregorianChronology8.hours();
//        java.lang.String str14 = gregorianChronology8.toString();
//        org.joda.time.Period period16 = org.joda.time.Period.weeks((-1));
//        int[] intArray19 = gregorianChronology8.get((org.joda.time.ReadablePeriod) period16, (long) 'a', (long) 10);
//        try {
//            gregorianChronology0.validate(readablePartial7, intArray19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str14.equals("GregorianChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertNotNull(intArray19);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period8 = period4.plusMinutes((int) (short) 1);
        org.joda.time.Period period10 = period4.minusMonths((int) (short) 0);
        org.joda.time.Period period12 = period10.plusMonths((int) (short) 100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 100, (-36000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36000100L + "'", long2 == 36000100L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePartial3, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfYear();
        org.joda.time.DurationField durationField13 = iSOChronology11.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology1.hours();
        org.joda.time.Chronology chronology4 = iSOChronology1.withUTC();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (byte) 100, chronology4);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.035");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.035/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        long long9 = durationField6.subtract((long) (byte) 0, (int) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfMinute();
        int int12 = gregorianChronology10.getMinimumDaysInFirstWeek();
        int int13 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField14 = gregorianChronology10.weeks();
        org.joda.time.DurationField durationField15 = gregorianChronology10.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField16 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField6, durationField15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-36000000L) + "'", long9 == (-36000000L));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) '4', "");
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType13 = periodType12.withWeeksRemoved();
        org.joda.time.PeriodType periodType14 = periodType12.withMinutesRemoved();
        org.joda.time.Period period15 = period11.withPeriodType(periodType12);
        org.joda.time.Period period16 = period8.withPeriodType(periodType12);
        try {
            org.joda.time.Period period18 = period8.plusMonths(4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        try {
            long long6 = iSOChronology0.getDateTimeMillis((int) (byte) 0, (int) (byte) 0, (int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        try {
            long long14 = unsupportedDurationField11.add((-36000000L), 20L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays((int) (short) 1);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period7.toString(periodFormatter10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0S" + "'", str11.equals("PT0S"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType3);
        int int7 = period6.getDays();
        try {
            org.joda.time.Period period9 = period6.withHours((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.Period period5 = period3.minusMonths((int) (byte) -1);
        int int6 = period3.getYears();
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period3.toString(periodFormatter7);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PT0.097S" + "'", str8.equals("PT0.097S"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        int int3 = period2.getMinutes();
        int int4 = period2.size();
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        int int6 = period2.getDays();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = iSOChronology1.set(readablePartial6, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType3);
        int int7 = period6.getDays();
        int int8 = period6.getMillis();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(8);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.millisOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.minutes();
        org.joda.time.DurationField durationField5 = iSOChronology1.years();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 20L, (java.lang.Number) (-1.0f), (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        try {
            int int26 = unsupportedDurationField11.getValue((long) (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, 100, 8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
//        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
//        java.lang.String str7 = dateTimeZone1.getShortName((long) (short) 10);
//        org.joda.time.LocalDateTime localDateTime8 = null;
//        boolean boolean9 = dateTimeZone1.isLocalDateTimeGap(localDateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, (-100), (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (short) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 43 + "'", int3 == 43);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        try {
            long long27 = unsupportedDurationField11.add((-1L), (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Pacific Standard Time' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField14 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.joda.time.Period period5 = org.joda.time.Period.months((int) (short) 1);
        long long8 = iSOChronology0.add((org.joda.time.ReadablePeriod) period5, (long) (short) 10, 0);
        int int9 = period5.getMillis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period9 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) 'a', chronology11);
        org.joda.time.Period period14 = period12.minusMonths((int) '#');
        int int15 = period14.getHours();
        org.joda.time.Period period17 = period14.minusSeconds((int) '#');
        boolean boolean18 = period9.equals((java.lang.Object) period14);
        int[] intArray20 = gregorianChronology7.get((org.joda.time.ReadablePeriod) period14, 0L);
        try {
            iSOChronology1.validate(readablePartial6, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) 100, 28800132L, periodType2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        int int8 = period6.getWeeks();
        org.joda.time.Period period10 = period6.withHours(4);
        int int11 = period10.getWeeks();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType13 = periodType12.withWeeksRemoved();
        org.joda.time.PeriodType periodType14 = periodType12.withMinutesRemoved();
        org.joda.time.Period period15 = period11.withPeriodType(periodType12);
        org.joda.time.Period period16 = period8.withPeriodType(periodType12);
        org.joda.time.PeriodType periodType17 = periodType12.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DurationFieldType durationFieldType8 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(durationFieldType8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) -1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        int int5 = dateTimeZone3.getOffset(readableInstant4);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weeks();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.plusMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField8 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        boolean boolean27 = unsupportedDurationField11.isPrecise();
        try {
            int int30 = unsupportedDurationField11.getValue((long) 0, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        try {
            long long13 = iSOChronology6.getDateTimeMillis((int) (short) 0, (int) '4', 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        try {
            long long10 = offsetDateTimeField6.set((long) (short) -1, "+00:00:00.035");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.035\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 43);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210863044800000L) + "'", long1 == (-210863044800000L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField1, (int) (short) 100, 8, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [8,8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period8 = period6.plusMonths(0);
        org.joda.time.Period period9 = period6.normalizedStandard();
        org.joda.time.Period period10 = new org.joda.time.Period((java.lang.Object) period6);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
//        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        int int8 = dateTimeZone1.getOffsetFromLocal((long) '4');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Coordinated Universal Time/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
        org.joda.time.Period period35 = period33.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType37 = period33.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField38 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType37);
        org.joda.time.DurationFieldType durationFieldType39 = unsupportedDurationField38.getType();
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField41 = new org.joda.time.field.ScaledDurationField((org.joda.time.DurationField) unsupportedDurationField11, durationFieldType39, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertNotNull(unsupportedDurationField38);
        org.junit.Assert.assertNotNull(durationFieldType39);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period2.toDurationFrom(readableInstant10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period14.withMillis((int) (short) 100);
        org.joda.time.Period period23 = period21.withDays((int) 'a');
        int int24 = period21.size();
        org.joda.time.Period period25 = period2.minus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period27 = period21.minusYears(0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField11.getType();
        try {
            long long15 = unsupportedDurationField11.getDifferenceAsLong((long) 100, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(durationFieldType12);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale10 = null;
//        try {
//            java.lang.String str11 = offsetDateTimeField6.getAsText(readablePartial9, locale10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(100L, (long) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        try {
            int int15 = unsupportedDurationField11.getDifference((long) 'a', (-36000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        java.lang.String str29 = periodType21.getName();
        org.joda.time.PeriodType periodType30 = periodType21.withMonthsRemoved();
        org.joda.time.PeriodType periodType31 = periodType21.withWeeksRemoved();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Seconds" + "'", str29.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-1), (int) (byte) 100, (int) 'a', 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 99 + "'", int4 == 99);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            int[] intArray7 = gregorianChronology0.get(readablePartial5, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset(0L);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        int int6 = fixedDateTimeZone4.getOffset((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-92015999903L), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(8);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        java.util.Locale locale14 = null;
//        try {
//            long long15 = offsetDateTimeField6.set((long) (byte) 100, "years", locale14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"years\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.plusWeeks((int) (byte) 100);
        int int12 = period11.getMonths();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) 'a');
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) '#');
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.minusSeconds((int) '#');
        boolean boolean14 = period5.equals((java.lang.Object) period10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period10.toDurationTo(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType24 = periodType23.withWeeksRemoved();
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = period22.withPeriodType(periodType23);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant18, periodType23);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType23, chronology29);
        org.joda.time.Period period34 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) 'a', chronology36);
        org.joda.time.Period period39 = period37.minusMonths((int) '#');
        int int40 = period39.getHours();
        org.joda.time.Period period42 = period39.minusSeconds((int) '#');
        boolean boolean43 = period34.equals((java.lang.Object) period39);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Duration duration45 = period39.toDurationTo(readableInstant44);
        long long46 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration45);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period(readableDuration49, readableInstant50);
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType53 = periodType52.withWeeksRemoved();
        org.joda.time.PeriodType periodType54 = periodType52.withMinutesRemoved();
        org.joda.time.Period period55 = period51.withPeriodType(periodType52);
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) -1, periodType52);
        org.joda.time.Period period57 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration45, readableInstant47, periodType52);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.Period period59 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType52, chronology58);
        java.lang.String str60 = periodType52.getName();
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period(readableDuration61, readableInstant62);
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology66);
        org.joda.time.Period period68 = period63.withFields((org.joda.time.ReadablePeriod) period67);
        org.joda.time.Period period69 = period67.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType71 = period67.getFieldType(0);
        int int72 = periodType52.indexOf(durationFieldType71);
        int int73 = periodType23.indexOf(durationFieldType71);
        org.joda.time.Period period74 = period1.normalizedStandard(periodType23);
        org.joda.time.PeriodType periodType75 = period74.getPeriodType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-92015999903L) + "'", long17 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(duration45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-92015999903L) + "'", long46 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Seconds" + "'", str60.equals("Seconds"));
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(periodType75);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 100, (-28800000), 200);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("PST", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(200, (-25200000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-25199800) + "'", int2 == (-25199800));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        try {
            int int27 = unsupportedDurationField11.getDifference((long) 10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period2.toDurationFrom(readableInstant10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period14.withMillis((int) (short) 100);
        org.joda.time.Period period23 = period21.withDays((int) 'a');
        int int24 = period21.size();
        org.joda.time.Period period25 = period2.minus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.MutablePeriod mutablePeriod26 = period21.toMutablePeriod();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(mutablePeriod26);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.Period period1 = org.joda.time.Period.parse("PT0S");
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866414400000L) + "'", long1 == (-210866414400000L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology9);
        org.joda.time.Period period11 = period6.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period6.withMillis((int) (short) 100);
        org.joda.time.Period period15 = period13.withDays((int) 'a');
        int int16 = period13.size();
        org.joda.time.Period period18 = period13.plusYears((int) (short) -1);
        org.joda.time.Period period19 = period3.plus((org.joda.time.ReadablePeriod) period18);
        try {
            org.joda.time.Weeks weeks20 = period18.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period7.minusHours((int) 'a');
        org.joda.time.PeriodType periodType10 = period9.getPeriodType();
        org.joda.time.PeriodType periodType11 = periodType10.withDaysRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withMillisRemoved();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
        org.joda.time.Period period6 = period4.minusMonths((int) '#');
        int int7 = period6.getHours();
        org.joda.time.Period period9 = period6.minusSeconds((int) '#');
        boolean boolean10 = period1.equals((java.lang.Object) period6);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period6.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-92015999903L) + "'", long13 == (-92015999903L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-92015999903L) + "'", long14 == (-92015999903L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType13 = periodType12.withWeeksRemoved();
        org.joda.time.PeriodType periodType14 = periodType12.withMinutesRemoved();
        org.joda.time.Period period15 = period11.withPeriodType(periodType12);
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) -1, periodType12);
        try {
            org.joda.time.Period period17 = new org.joda.time.Period(1, 0, (-100), (int) (short) 10, 1, (int) (byte) 100, (int) (byte) -1, (int) (short) 100, periodType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        java.util.Locale locale12 = null;
//        try {
//            java.lang.String str13 = offsetDateTimeField6.getAsText(readablePartial11, locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "11");
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.lang.String str2 = dateTimeZone1.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-00:00:00.001" + "'", str2.equals("-00:00:00.001"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        boolean boolean27 = unsupportedDurationField11.isPrecise();
        try {
            long long30 = unsupportedDurationField11.add(8553600002L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        int int4 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology1.hours();
        long long9 = durationField6.subtract((long) (byte) 0, (int) (byte) 10);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField10 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-36000000L) + "'", long9 == (-36000000L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = offsetDateTimeField6.getAsShortText(readablePartial8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText(200, locale10);
        long long14 = offsetDateTimeField6.addWrapField((long) 1, (int) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "200" + "'", str11.equals("200"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 259200001L + "'", long14 == 259200001L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.Period period4 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', chronology6);
        org.joda.time.Period period9 = period7.minusMonths((int) '#');
        int int10 = period9.getHours();
        org.joda.time.Period period12 = period9.minusSeconds((int) '#');
        boolean boolean13 = period4.equals((java.lang.Object) period9);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period9.toDurationTo(readableInstant14);
        long long16 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Period period21 = new org.joda.time.Period(readableDuration19, readableInstant20);
        org.joda.time.PeriodType periodType22 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType23 = periodType22.withWeeksRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withMinutesRemoved();
        org.joda.time.Period period25 = period21.withPeriodType(periodType22);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, periodType22);
        org.joda.time.Period period27 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration15, readableInstant17, periodType22);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType22, chronology28);
        java.lang.String str30 = periodType22.getName();
        org.joda.time.PeriodType periodType31 = periodType22.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period33 = new org.joda.time.Period((long) 8, periodType22, (org.joda.time.Chronology) gregorianChronology32);
        try {
            org.joda.time.Period period35 = period33.minusHours((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-92015999903L) + "'", long16 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Seconds" + "'", str30.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(259200001L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 259200001L + "'", long0 == 259200001L);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        long long13 = offsetDateTimeField6.add((long) 2, 99);
//        try {
//            long long16 = offsetDateTimeField6.set((long) (-28800000), 9700);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9700 for dayOfWeek must be in the range [9,15]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8553600002L + "'", long13 == 8553600002L);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        java.lang.String str5 = dateTimeZone2.getName((long) (-25199800));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.Period period4 = new org.joda.time.Period(0, (int) (short) 100, 0, (int) ' ');
        org.joda.time.Minutes minutes5 = period4.toStandardMinutes();
        org.junit.Assert.assertNotNull(minutes5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.withDays((int) 'a');
        org.joda.time.Period period13 = period11.minusMonths(0);
        int int14 = period11.getWeeks();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 43);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(0L, periodType3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.withDays((int) 'a');
        int int12 = period9.size();
        org.joda.time.Period period14 = period9.plusYears((int) (short) -1);
        org.joda.time.Period period16 = period9.minusHours(0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.minusYears((int) (byte) 0);
        org.joda.time.Period period11 = period2.plusHours((int) (byte) -1);
        org.joda.time.Period period13 = period11.minusSeconds(0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period8.toDurationFrom(readableInstant16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology23);
        org.joda.time.Period period25 = period20.withFields((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period20.withMillis((int) (short) 100);
        org.joda.time.Period period29 = period27.withDays((int) 'a');
        int int30 = period27.size();
        org.joda.time.Period period31 = period8.minus((org.joda.time.ReadablePeriod) period27);
        long long34 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (short) 1, (int) 'a');
        org.joda.time.ReadablePartial readablePartial35 = null;
        try {
            long long37 = gregorianChronology0.set(readablePartial35, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
//        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
//        java.lang.String str7 = dateTimeZone1.getShortName((long) (short) 10);
//        int int9 = dateTimeZone1.getOffsetFromLocal((long) (byte) 100);
//        java.lang.String str11 = dateTimeZone1.getShortName((-210863044800000L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(99L, (long) 1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, 0, (int) (byte) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for halfdayOfDay must be in the range [1,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        try {
            long long29 = unsupportedDurationField11.add((-368326799612L), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 100);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        int int4 = dateTimeZone2.getOffsetFromLocal((-368326799612L));
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        int int12 = offsetDateTimeField6.getMinimumValue();
//        java.util.Locale locale15 = null;
//        try {
//            long long16 = offsetDateTimeField6.set(10L, "PeriodType[Seconds]", locale15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[Seconds]\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology0.halfdays();
        java.lang.Object obj8 = null;
        boolean boolean9 = gregorianChronology0.equals(obj8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DurationField durationField3 = iSOChronology0.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        boolean boolean13 = offsetDateTimeField6.isLeap((long) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        java.util.Locale locale15 = null;
//        try {
//            java.lang.String str16 = offsetDateTimeField6.getAsText(readablePartial14, locale15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(9, (int) '4', (int) ' ', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("200");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"200/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        long long13 = offsetDateTimeField6.add((long) 2, 99);
//        java.lang.String str15 = offsetDateTimeField6.getAsShortText((-368326799612L));
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        java.util.Locale locale17 = null;
//        try {
//            java.lang.String str18 = offsetDateTimeField6.getAsShortText(readablePartial16, locale17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8553600002L + "'", long13 == 8553600002L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "11" + "'", str15.equals("11"));
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        boolean boolean4 = dateTimeZone2.isStandardOffset((long) (short) 0);
//        boolean boolean6 = dateTimeZone2.isStandardOffset(1L);
//        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField9 = gregorianChronology8.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.Chronology chronology11 = iSOChronology7.withZone(dateTimeZone10);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        int int14 = dateTimeZone10.getOffsetFromLocal(36000100L);
//        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone0, (java.lang.Object) dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(iSOChronology7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(8, 0, 4, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("hi!", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology6);
        org.joda.time.Period period8 = period3.withFields((org.joda.time.ReadablePeriod) period7);
        org.joda.time.Period period9 = period7.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType11 = period7.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField12 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType11);
        org.joda.time.PeriodType periodType15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.secondOfMinute();
        int int18 = gregorianChronology16.getMinimumDaysInFirstWeek();
        int int19 = gregorianChronology16.getMinimumDaysInFirstWeek();
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType15, (org.joda.time.Chronology) gregorianChronology16);
        org.joda.time.DurationField durationField21 = gregorianChronology16.weeks();
        int int22 = unsupportedDurationField12.compareTo(durationField21);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField23 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(unsupportedDurationField12);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '4', (int) (short) 100, 8, (-1), false, (-28800000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(8);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder13.addRecurringSavings("Pacific Standard Time", (int) '#', 35, 100, '#', (int) (byte) 1, (-1), 99, true, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT0S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT0S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        long long8 = durationField5.subtract((long) 4, 8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799996L) + "'", long8 == (-28799996L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Period period10 = period8.plusYears(200);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        boolean boolean27 = unsupportedDurationField11.isPrecise();
        try {
            long long30 = unsupportedDurationField11.getMillis(9, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        int int12 = offsetDateTimeField6.getMinimumValue();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField6.getAsText((long) 10, locale14);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
//        int int21 = period20.getMinutes();
//        int int22 = period20.size();
//        org.joda.time.Period period24 = org.joda.time.Period.seconds(43);
//        org.joda.time.Period period25 = period20.minus((org.joda.time.ReadablePeriod) period24);
//        int[] intArray26 = period24.getValues();
//        try {
//            int[] intArray28 = offsetDateTimeField6.set(readablePartial16, (-25199800), intArray26, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -25199800");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12" + "'", str15.equals("12"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period25);
//        org.junit.Assert.assertNotNull(intArray26);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        try {
            long long28 = unsupportedDurationField23.add((-368326799612L), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period8.toDurationFrom(readableInstant16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology23);
        org.joda.time.Period period25 = period20.withFields((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period20.withMillis((int) (short) 100);
        org.joda.time.Period period29 = period27.withDays((int) 'a');
        int int30 = period27.size();
        org.joda.time.Period period31 = period8.minus((org.joda.time.ReadablePeriod) period27);
        long long34 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (short) 1, (int) 'a');
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
        org.joda.time.Period period6 = period4.minusMonths((int) '#');
        org.joda.time.Period period8 = period6.minusMillis(10);
        org.joda.time.Period period10 = period6.plusMinutes((int) (short) 1);
        long long13 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period6, 0L, 4);
        org.joda.time.ReadablePartial readablePartial14 = null;
        try {
            long long16 = gregorianChronology0.set(readablePartial14, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-368323199612L) + "'", long13 == (-368323199612L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 99, (-25200000), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException2.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(dateTimeFieldType8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period13 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) 'a', chronology15);
        org.joda.time.Period period18 = period16.minusMonths((int) '#');
        int int19 = period18.getHours();
        org.joda.time.Period period21 = period18.minusSeconds((int) '#');
        boolean boolean22 = period13.equals((java.lang.Object) period18);
        int[] intArray24 = gregorianChronology11.get((org.joda.time.ReadablePeriod) period18, 0L);
        org.joda.time.DurationField durationField25 = gregorianChronology11.eras();
        org.joda.time.Period period27 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) 'a', chronology29);
        org.joda.time.Period period32 = period30.minusMonths((int) '#');
        int int33 = period32.getHours();
        org.joda.time.Period period35 = period32.minusSeconds((int) '#');
        boolean boolean36 = period27.equals((java.lang.Object) period32);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.Duration duration38 = period32.toDurationTo(readableInstant37);
        long long39 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration38);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.Period period44 = new org.joda.time.Period(readableDuration42, readableInstant43);
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType46 = periodType45.withWeeksRemoved();
        org.joda.time.PeriodType periodType47 = periodType45.withMinutesRemoved();
        org.joda.time.Period period48 = period44.withPeriodType(periodType45);
        org.joda.time.Period period49 = new org.joda.time.Period((long) (short) -1, periodType45);
        org.joda.time.Period period50 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration38, readableInstant40, periodType45);
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.ReadableDuration readableDuration53 = null;
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period(readableDuration53, readableInstant54);
        org.joda.time.PeriodType periodType56 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType57 = periodType56.withWeeksRemoved();
        org.joda.time.PeriodType periodType58 = periodType56.withMinutesRemoved();
        org.joda.time.Period period59 = period55.withPeriodType(periodType56);
        org.joda.time.Period period60 = new org.joda.time.Period((long) (short) -1, periodType56);
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period(readableDuration61, readableInstant62);
        org.joda.time.PeriodType periodType64 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType65 = periodType64.withWeeksRemoved();
        org.joda.time.PeriodType periodType66 = periodType64.withMinutesRemoved();
        org.joda.time.Period period67 = period63.withPeriodType(periodType64);
        org.joda.time.Period period68 = period60.withPeriodType(periodType64);
        org.joda.time.Period period69 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration38, readableInstant51, periodType64);
        int[] intArray72 = gregorianChronology11.get((org.joda.time.ReadablePeriod) period69, 11L, 10L);
        try {
            int[] intArray74 = offsetDateTimeField6.addWrapField(readablePartial9, 9700, intArray72, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9700");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(duration38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-92015999903L) + "'", long39 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(periodType58);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(periodType64);
        org.junit.Assert.assertNotNull(periodType65);
        org.junit.Assert.assertNotNull(periodType66);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        int int12 = offsetDateTimeField6.getLeapAmount(28800132L);
        int int14 = offsetDateTimeField6.getMaximumValue(28800132L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField6.getAsText(readablePartial15, (int) (short) 100, locale17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        try {
            long long15 = unsupportedDurationField11.getValueAsLong((long) (short) 0, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 1);
        org.joda.time.Period period2 = period1.normalizedStandard();
        org.joda.time.Period period4 = period1.plusMonths((int) '#');
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) 'a', chronology6);
        org.joda.time.Period period9 = period7.minusMonths((int) '#');
        org.joda.time.Period period11 = period9.minusMillis(10);
        org.joda.time.Period period12 = period4.minus((org.joda.time.ReadablePeriod) period11);
        int int13 = period4.getMillis();
        int int14 = period4.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            int[] intArray5 = iSOChronology0.get(readablePartial3, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        long long4 = dateTimeZone0.adjustOffset((-36000000L), true);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-36000000L) + "'", long4 == (-36000000L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 200, "hi!");
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.days();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology0.get(readablePartial4, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(99, (int) 'a', 15, (int) (byte) 100, 35, (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) -1, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) gregorianChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.millisOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology1.minutes();
        org.joda.time.Period period5 = new org.joda.time.Period((long) '#', (org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        long long6 = dateTimeZone3.adjustOffset((long) 8, false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8L + "'", long6 == 8L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.Period period2 = new org.joda.time.Period(0L, 132L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        try {
            long long28 = unsupportedDurationField11.add((long) (short) 10, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField11.getType();
        java.lang.String str13 = unsupportedDurationField11.getName();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 4, periodType15);
        org.joda.time.DurationFieldType durationFieldType18 = periodType15.getFieldType(0);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField20 = new org.joda.time.field.ScaledDurationField((org.joda.time.DurationField) unsupportedDurationField11, durationFieldType18, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(durationFieldType18);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        java.lang.String str6 = gregorianChronology0.toString();
        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField14 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[UTC]" + "'", str6.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) (short) 0);
        boolean boolean6 = dateTimeZone2.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.centuryOfEra();
        org.joda.time.Period period9 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology7);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology7.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        try {
//            long long17 = zonedChronology12.getDateTimeMillis(200, 200, (int) (byte) -1, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 200 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordinated Universal Time" + "'", str11.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.Period period1 = org.joda.time.Period.days(2);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(28800132L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((-1L), 43, (int) '#', (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 43 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-36000000L));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField6, 15, (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for dayOfWeek must be in the range [32,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) '#');
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.minusSeconds((int) '#');
        boolean boolean14 = period5.equals((java.lang.Object) period10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period10.toDurationTo(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType24 = periodType23.withWeeksRemoved();
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = period22.withPeriodType(periodType23);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant18, periodType23);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType23, chronology29);
        java.lang.String str31 = periodType23.getName();
        org.joda.time.PeriodType periodType32 = periodType23.withMonthsRemoved();
        org.joda.time.PeriodType periodType33 = periodType23.withSecondsRemoved();
        try {
            org.joda.time.Period period34 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-92015999903L) + "'", long17 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Seconds" + "'", str31.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays(1);
        org.joda.time.Period period11 = period7.minusYears((-25199800));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField11.getType();
        java.lang.String str13 = unsupportedDurationField11.getName();
        try {
            long long16 = unsupportedDurationField11.getMillis(10, 36000100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((-1), (-28800000), 8, (-25200000), (int) '#', (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
        long long12 = offsetDateTimeField6.roundCeiling(28800132L);
        long long15 = offsetDateTimeField6.add((long) (short) 0, (long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400000L + "'", long12 == 86400000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3024000000L + "'", long15 == 3024000000L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.millisOfDay();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 4, (-92015999903L), (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '4', (int) (short) 100, 8, (-1), false, (-28800000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset((int) (byte) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder11.setFixedSavings("200", (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
        long long13 = offsetDateTimeField6.add((long) 2, 99);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType14, 35, (int) (short) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8553600002L + "'", long13 == 8553600002L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long9 = cachedDateTimeZone7.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        try {
            long long26 = unsupportedDurationField23.getMillis(9700);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.minutes();
        org.joda.time.DurationField durationField4 = iSOChronology0.years();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            int[] intArray7 = iSOChronology0.get(readablePartial5, 20L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType16 = periodType15.withWeeksRemoved();
        org.joda.time.PeriodType periodType17 = periodType15.withMinutesRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
        try {
            org.joda.time.Period period19 = period12.withPeriodType(periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'millis'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField26 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        try {
            long long28 = unsupportedDurationField26.getMillis((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(unsupportedDurationField26);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
//        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
//        java.lang.String str6 = gregorianChronology0.toString();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        try {
//            int[] intArray9 = gregorianChronology0.get(readablePeriod7, (long) (-100));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) -1, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) 200);
        int[] intArray3 = period2.getValues();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Duration duration5 = period2.toDurationFrom(readableInstant4);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(duration5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 200);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        int int12 = offsetDateTimeField6.getMinimumValue();
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale14 = null;
//        try {
//            java.lang.String str15 = offsetDateTimeField6.getAsText(readablePartial13, locale14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
        int int2 = period1.getHours();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PST' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
//        boolean boolean16 = offsetDateTimeField15.isLenient();
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField15.getMaximumShortTextLength(locale17);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.secondOfMinute();
//        int int23 = gregorianChronology21.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology21.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology21.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology21.minuteOfHour();
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.ReadableInstant readableInstant28 = null;
//        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
//        org.joda.time.Chronology chronology32 = null;
//        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology32);
//        org.joda.time.Period period34 = period29.withFields((org.joda.time.ReadablePeriod) period33);
//        org.joda.time.Period period36 = period29.withMillis((int) (short) 100);
//        org.joda.time.Period period38 = period36.withDays((int) 'a');
//        int int39 = period36.size();
//        org.joda.time.Period period41 = period36.plusYears((int) (short) -1);
//        int[] intArray44 = gregorianChronology21.get((org.joda.time.ReadablePeriod) period36, (long) 'a', (long) 'a');
//        try {
//            int[] intArray46 = offsetDateTimeField15.addWrapField(readablePartial19, 8, intArray44, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period36);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
//        org.junit.Assert.assertNotNull(period41);
//        org.junit.Assert.assertNotNull(intArray44);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.millisOfDay();
        org.joda.time.DurationField durationField4 = iSOChronology2.hours();
        org.joda.time.Chronology chronology5 = iSOChronology2.withUTC();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) (short) 1, chronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(9700);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
        org.joda.time.Period period6 = period4.minusMonths((int) '#');
        int int7 = period6.getHours();
        org.joda.time.Period period9 = period6.minusSeconds((int) '#');
        boolean boolean10 = period1.equals((java.lang.Object) period6);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period6.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableDuration16, readableInstant17);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType20 = periodType19.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = periodType19.withMinutesRemoved();
        org.joda.time.Period period22 = period18.withPeriodType(periodType19);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) -1, periodType19);
        org.joda.time.Period period24 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant14, periodType19);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableDuration readableDuration27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Period period29 = new org.joda.time.Period(readableDuration27, readableInstant28);
        org.joda.time.PeriodType periodType30 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType31 = periodType30.withWeeksRemoved();
        org.joda.time.PeriodType periodType32 = periodType30.withMinutesRemoved();
        org.joda.time.Period period33 = period29.withPeriodType(periodType30);
        org.joda.time.Period period34 = new org.joda.time.Period((long) (short) -1, periodType30);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period(readableDuration35, readableInstant36);
        org.joda.time.PeriodType periodType38 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType39 = periodType38.withWeeksRemoved();
        org.joda.time.PeriodType periodType40 = periodType38.withMinutesRemoved();
        org.joda.time.Period period41 = period37.withPeriodType(periodType38);
        org.joda.time.Period period42 = period34.withPeriodType(periodType38);
        org.joda.time.Period period43 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant25, periodType38);
        org.joda.time.Period period45 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.Period period48 = new org.joda.time.Period(readableDuration46, readableInstant47);
        org.joda.time.Chronology chronology51 = null;
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology51);
        org.joda.time.Period period53 = period48.withFields((org.joda.time.ReadablePeriod) period52);
        org.joda.time.Period period55 = period48.withMillis((int) (short) 100);
        org.joda.time.Period period56 = period45.withFields((org.joda.time.ReadablePeriod) period55);
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Period period59 = new org.joda.time.Period(readableDuration57, readableInstant58);
        org.joda.time.Chronology chronology62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology62);
        org.joda.time.Period period64 = period59.withFields((org.joda.time.ReadablePeriod) period63);
        org.joda.time.Period period65 = period63.normalizedStandard();
        org.joda.time.Period period67 = period63.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType69 = period63.getFieldType((int) (short) 0);
        int int70 = period55.indexOf(durationFieldType69);
        int int71 = period43.indexOf(durationFieldType69);
        int int72 = period43.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-92015999903L) + "'", long13 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertNotNull(period65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(durationFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period8 = period4.plusMinutes((int) (short) 1);
        org.joda.time.Period period10 = period4.minusMonths((int) (short) 0);
        org.joda.time.Period period12 = period10.minusDays(100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("+00:00:00.035", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"+00:00:00.035/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.Period period8 = new org.joda.time.Period((-28800000), 9, (int) '4', (int) (byte) 0, 99, (int) (byte) 0, 8, 200);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        int int4 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.monthOfYear();
        org.joda.time.Period period6 = new org.joda.time.Period((-36000000L), periodType1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period2.toDurationFrom(readableInstant10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period14.withMillis((int) (short) 100);
        org.joda.time.Period period23 = period21.withDays((int) 'a');
        int int24 = period21.size();
        org.joda.time.Period period25 = period2.minus((org.joda.time.ReadablePeriod) period21);
        int int26 = period2.getDays();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("dayOfWeek");
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType3);
        java.lang.String str7 = period2.toString();
        int int8 = period2.getMonths();
        org.joda.time.Period period9 = period2.negated();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        org.joda.time.Period period10 = org.joda.time.Period.days((-1));
        int[] intArray13 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period10, (long) 200, (long) (short) 0);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.time();
        org.joda.time.Period period15 = period10.normalizedStandard(periodType14);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) 0, "Seconds");
        java.lang.String str3 = illegalInstantException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Seconds)" + "'", str3.equals("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1970-01-01T00:00:00.000 (Seconds)"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.Period period1 = org.joda.time.Period.days((-25200000));
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
//        java.lang.String str7 = dateTimeZone6.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-00:00:00.001" + "'", str7.equals("-00:00:00.001"));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 200, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "-00:00:00.001", 0, 43);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.Period period3 = org.joda.time.Period.weeks((int) 'a');
        org.joda.time.Period period7 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) 'a', chronology9);
        org.joda.time.Period period12 = period10.minusMonths((int) '#');
        int int13 = period12.getHours();
        org.joda.time.Period period15 = period12.minusSeconds((int) '#');
        boolean boolean16 = period7.equals((java.lang.Object) period12);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = period12.toDurationTo(readableInstant17);
        long long19 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration18);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(readableDuration22, readableInstant23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType26 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType27 = periodType25.withMinutesRemoved();
        org.joda.time.Period period28 = period24.withPeriodType(periodType25);
        org.joda.time.Period period29 = new org.joda.time.Period((long) (short) -1, periodType25);
        org.joda.time.Period period30 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration18, readableInstant20, periodType25);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType25, chronology31);
        org.joda.time.Period period36 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) 'a', chronology38);
        org.joda.time.Period period41 = period39.minusMonths((int) '#');
        int int42 = period41.getHours();
        org.joda.time.Period period44 = period41.minusSeconds((int) '#');
        boolean boolean45 = period36.equals((java.lang.Object) period41);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Duration duration47 = period41.toDurationTo(readableInstant46);
        long long48 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration47);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableDuration readableDuration51 = null;
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period(readableDuration51, readableInstant52);
        org.joda.time.PeriodType periodType54 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType55 = periodType54.withWeeksRemoved();
        org.joda.time.PeriodType periodType56 = periodType54.withMinutesRemoved();
        org.joda.time.Period period57 = period53.withPeriodType(periodType54);
        org.joda.time.Period period58 = new org.joda.time.Period((long) (short) -1, periodType54);
        org.joda.time.Period period59 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration47, readableInstant49, periodType54);
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.Period period61 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType54, chronology60);
        java.lang.String str62 = periodType54.getName();
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Period period65 = new org.joda.time.Period(readableDuration63, readableInstant64);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.Period period69 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology68);
        org.joda.time.Period period70 = period65.withFields((org.joda.time.ReadablePeriod) period69);
        org.joda.time.Period period71 = period69.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType73 = period69.getFieldType(0);
        int int74 = periodType54.indexOf(durationFieldType73);
        int int75 = periodType25.indexOf(durationFieldType73);
        org.joda.time.Period period76 = period3.normalizedStandard(periodType25);
        java.lang.String str77 = periodType25.toString();
        org.joda.time.Period period78 = new org.joda.time.Period(0L, 259200001L, periodType25);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-92015999903L) + "'", long19 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(duration47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-92015999903L) + "'", long48 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Seconds" + "'", str62.equals("Seconds"));
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertNotNull(durationFieldType73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(period76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "PeriodType[Seconds]" + "'", str77.equals("PeriodType[Seconds]"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Duration duration11 = period2.toDurationFrom(readableInstant10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period14.withMillis((int) (short) 100);
        org.joda.time.Period period23 = period21.withDays((int) 'a');
        int int24 = period21.size();
        org.joda.time.Period period25 = period2.minus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType29 = periodType28.withWeeksRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableDuration26, readableInstant27, periodType28);
        java.lang.String str31 = periodType28.toString();
        org.joda.time.Period period32 = period25.normalizedStandard(periodType28);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PeriodType[Seconds]" + "'", str31.equals("PeriodType[Seconds]"));
        org.junit.Assert.assertNotNull(period32);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.withDays((int) 'a');
        int int12 = period9.size();
        org.joda.time.Hours hours13 = period9.toStandardHours();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(hours13);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("-00:00:00.001");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType13 = periodType12.withWeeksRemoved();
        org.joda.time.PeriodType periodType14 = periodType12.withMinutesRemoved();
        org.joda.time.Period period15 = period11.withPeriodType(periodType12);
        org.joda.time.Period period16 = period8.withPeriodType(periodType12);
        try {
            org.joda.time.Period period18 = period16.minusMillis((-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
//        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
//        long long12 = offsetDateTimeField6.roundCeiling(28800132L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField15 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType13, (-25200000));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400001L + "'", long12 == 86400001L);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
//        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
//        java.lang.String str6 = gregorianChronology0.toString();
//        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
//        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
//        java.lang.String str12 = gregorianChronology0.toString();
//        org.joda.time.DurationField durationField13 = gregorianChronology0.days();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str12.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        java.lang.String str29 = periodType21.getName();
        org.joda.time.PeriodType periodType30 = periodType21.withMonthsRemoved();
        int int31 = periodType30.size();
        org.joda.time.PeriodType periodType32 = periodType30.withSecondsRemoved();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Seconds" + "'", str29.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(periodType32);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getRangeDurationField();
        try {
            long long11 = offsetDateTimeField6.set((long) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [9,15]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-28800000), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        java.lang.String str13 = unsupportedDurationField11.getName();
        try {
            long long16 = unsupportedDurationField11.getDifferenceAsLong((long) (-100), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        java.lang.String str29 = periodType21.getName();
        int int30 = periodType21.size();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Seconds" + "'", str29.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(0, 9, 9, (int) 'a', (-25199800), 43, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-25199800));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        int int13 = period11.getMonths();
        int int14 = period11.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        long long12 = offsetDateTimeField6.roundHalfCeiling(0L);
//        boolean boolean13 = offsetDateTimeField6.isLenient();
//        boolean boolean14 = offsetDateTimeField6.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfEven((long) 35);
//        long long15 = offsetDateTimeField6.roundHalfEven((-36000000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = zonedChronology12.equals(obj13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        int int21 = dateTimeZone16.getOffset(readableInstant20);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
//        boolean boolean25 = cachedDateTimeZone22.isFixed();
//        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.Chronology chronology27 = zonedChronology12.withUTC();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField7 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.Period period1 = org.joda.time.Period.parse("PT0.097S");
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(43, (int) (byte) 10, (int) (byte) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.PeriodType periodType1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
//        int int4 = gregorianChronology2.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.monthOfYear();
//        org.joda.time.Period period6 = new org.joda.time.Period((-36000000L), periodType1, (org.joda.time.Chronology) gregorianChronology2);
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.millisOfDay();
//        java.lang.String str8 = gregorianChronology2.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str8.equals("GregorianChronology[-00:00:00.001]"));
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText(200, locale10);
        java.util.Locale locale14 = null;
        try {
            long long15 = offsetDateTimeField6.set(0L, "100", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [9,15]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "200" + "'", str11.equals("200"));
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
//        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
//        long long12 = offsetDateTimeField6.roundCeiling(28800132L);
//        try {
//            org.joda.time.Period period13 = new org.joda.time.Period((java.lang.Object) long12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86400001L + "'", long12 == 86400001L);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology0.getZone();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("GregorianChronology[UTC]", (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(43);
        int int2 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.weekyears();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.Chronology chronology10 = iSOChronology6.withZone(dateTimeZone9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            int[] intArray14 = iSOChronology11.get(readablePartial12, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(iSOChronology11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays((int) (short) 1);
        boolean boolean11 = period7.equals((java.lang.Object) 15);
        int int12 = period7.getMonths();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) readableInterval10);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period(readableDuration14, readableInstant15);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology19);
        org.joda.time.Period period21 = period16.withFields((org.joda.time.ReadablePeriod) period20);
        org.joda.time.Period period22 = period20.normalizedStandard();
        org.joda.time.Period period24 = period20.plusHours((-25199800));
        boolean boolean25 = cachedDateTimeZone7.equals((java.lang.Object) (-25199800));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        java.lang.String str13 = unsupportedDurationField11.getName();
        try {
            long long16 = unsupportedDurationField11.getValueAsLong((long) (-1), (-210866414400000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField26 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType25);
        java.lang.String str27 = unsupportedDurationField26.getName();
        try {
            long long30 = unsupportedDurationField26.subtract((long) '#', (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertNotNull(unsupportedDurationField26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "years" + "'", str27.equals("years"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        try {
            int int27 = unsupportedDurationField11.getValue(0L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        int int4 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.monthOfYear();
        org.joda.time.Period period6 = new org.joda.time.Period((-36000000L), periodType1, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField10 = new org.joda.time.field.DividedDateTimeField(dateTimeField7, dateTimeFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        try {
            org.joda.time.Period period10 = period8.minusYears(99);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str4 = illegalFieldValueException2.getFieldName();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.minuteOfDay();
        org.joda.time.Chronology chronology12 = gregorianChronology3.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '4', (int) (short) 100, 8, (-1), false, (-28800000));
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder11.writeTo("UTC", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Period period10 = period6.plusYears((-100));
        org.joda.time.Period period15 = new org.joda.time.Period(0, (int) (short) 100, 0, (int) ' ');
        org.joda.time.Period period16 = period15.normalizedStandard();
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration17, readableInstant18);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology22);
        org.joda.time.Period period24 = period19.withFields((org.joda.time.ReadablePeriod) period23);
        org.joda.time.Period period25 = period23.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType27 = period23.getFieldType(0);
        boolean boolean28 = period16.isSupported(durationFieldType27);
        int int29 = period16.getYears();
        org.joda.time.Period period30 = period10.plus((org.joda.time.ReadablePeriod) period16);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(period30);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        int int8 = period6.getWeeks();
        org.joda.time.Period period10 = org.joda.time.Period.millis(10);
        boolean boolean11 = period6.equals((java.lang.Object) period10);
        int int12 = period10.getYears();
        org.joda.time.DurationFieldType[] durationFieldTypeArray13 = period10.getFieldTypes();
        org.joda.time.Seconds seconds14 = period10.toStandardSeconds();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray13);
        org.junit.Assert.assertNotNull(seconds14);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.millisOfDay();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.Period period5 = new org.joda.time.Period(obj0, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.millisOfSecond();
        try {
            long long11 = iSOChronology1.getDateTimeMillis((int) (short) 1, 100, (int) ' ', 9700);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "11");
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.Period period1 = new org.joda.time.Period((long) '#');
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset(20L);
        boolean boolean10 = cachedDateTimeZone7.isFixed();
        int int12 = cachedDateTimeZone7.getOffset((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = zonedChronology12.equals(obj13);
//        try {
//            long long22 = zonedChronology12.getDateTimeMillis(10, 0, 0, 0, 0, 15, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(readableInterval4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField7 = iSOChronology6.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology6.halfdays();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getName(99L, locale12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone10.getOffset(readableInstant14);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        int int18 = cachedDateTimeZone16.getStandardOffset((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone19 = cachedDateTimeZone16.getUncachedZone();
        boolean boolean20 = iSOChronology6.equals((java.lang.Object) cachedDateTimeZone16);
        java.util.Locale locale22 = null;
        java.lang.String str23 = cachedDateTimeZone16.getShortName((long) (-28800000), locale22);
        boolean boolean24 = cachedDateTimeZone16.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-00:00:00.001" + "'", str23.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PST", "GregorianChronology[America/Los_Angeles]", 0, (int) (short) 100);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withDaysRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 100, (long) 'a', periodType6);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("PST");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PST/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
//        boolean boolean10 = offsetDateTimeField6.isLeap(0L);
//        try {
//            long long13 = offsetDateTimeField6.set((long) (short) 1, 35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfWeek must be in the range [9,15]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology0.minutes();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) periodType3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GregorianChronology[-00:00:00.001]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(132L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        long long13 = offsetDateTimeField6.add((long) 2, 99);
//        java.lang.String str14 = offsetDateTimeField6.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 8553600002L + "'", long13 == 8553600002L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfWeek" + "'", str14.equals("dayOfWeek"));
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfEven((long) 35);
//        long long16 = offsetDateTimeField6.add((long) 8, 28800132L);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        int[] intArray19 = null;
//        try {
//            int[] intArray21 = offsetDateTimeField6.addWrapField(readablePartial17, 200, intArray19, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2488331404800008L + "'", long16 == 2488331404800008L);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        java.lang.String str2 = periodType0.getName();
        int int3 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Seconds" + "'", str2.equals("Seconds"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int[] intArray10 = gregorianChronology3.get(readablePartial8, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addCutover((int) (short) 100, '4', (int) (short) 100, 8, (-1), false, (-28800000));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(8);
        java.io.DataOutput dataOutput15 = null;
        try {
            dateTimeZoneBuilder13.writeTo("12", dataOutput15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("GregorianChronology[UTC]", 43);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset(20L);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.minuteOfDay();
        boolean boolean15 = cachedDateTimeZone7.equals((java.lang.Object) dateTimeField14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[America/Los_Angeles]", "", (int) '#', 100);
        long long22 = fixedDateTimeZone20.nextTransition(100L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = fixedDateTimeZone20.getName((-92015999903L), locale24);
        boolean boolean26 = cachedDateTimeZone7.equals((java.lang.Object) locale24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+00:00:00.035" + "'", str25.equals("+00:00:00.035"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField11.getType();
        java.lang.String str13 = unsupportedDurationField11.getName();
        long long14 = unsupportedDurationField11.getUnitMillis();
        try {
            long long16 = unsupportedDurationField11.getMillis((-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) 'a');
        org.joda.time.Period period5 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 'a', chronology7);
        org.joda.time.Period period10 = period8.minusMonths((int) '#');
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.minusSeconds((int) '#');
        boolean boolean14 = period5.equals((java.lang.Object) period10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period10.toDurationTo(readableInstant15);
        long long17 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period(readableDuration20, readableInstant21);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType24 = periodType23.withWeeksRemoved();
        org.joda.time.PeriodType periodType25 = periodType23.withMinutesRemoved();
        org.joda.time.Period period26 = period22.withPeriodType(periodType23);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.Period period28 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration16, readableInstant18, periodType23);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType23, chronology29);
        org.joda.time.Period period34 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) 'a', chronology36);
        org.joda.time.Period period39 = period37.minusMonths((int) '#');
        int int40 = period39.getHours();
        org.joda.time.Period period42 = period39.minusSeconds((int) '#');
        boolean boolean43 = period34.equals((java.lang.Object) period39);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Duration duration45 = period39.toDurationTo(readableInstant44);
        long long46 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration45);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period(readableDuration49, readableInstant50);
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType53 = periodType52.withWeeksRemoved();
        org.joda.time.PeriodType periodType54 = periodType52.withMinutesRemoved();
        org.joda.time.Period period55 = period51.withPeriodType(periodType52);
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) -1, periodType52);
        org.joda.time.Period period57 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration45, readableInstant47, periodType52);
        org.joda.time.Chronology chronology58 = null;
        org.joda.time.Period period59 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType52, chronology58);
        java.lang.String str60 = periodType52.getName();
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.Period period63 = new org.joda.time.Period(readableDuration61, readableInstant62);
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology66);
        org.joda.time.Period period68 = period63.withFields((org.joda.time.ReadablePeriod) period67);
        org.joda.time.Period period69 = period67.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType71 = period67.getFieldType(0);
        int int72 = periodType52.indexOf(durationFieldType71);
        int int73 = periodType23.indexOf(durationFieldType71);
        org.joda.time.Period period74 = period1.normalizedStandard(periodType23);
        java.lang.String str75 = periodType23.toString();
        try {
            org.joda.time.DurationFieldType durationFieldType77 = periodType23.getFieldType((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(duration16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-92015999903L) + "'", long17 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(duration45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-92015999903L) + "'", long46 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Seconds" + "'", str60.equals("Seconds"));
        org.junit.Assert.assertNotNull(period68);
        org.junit.Assert.assertNotNull(period69);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "PeriodType[Seconds]" + "'", str75.equals("PeriodType[Seconds]"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = new org.joda.time.Period(99L, (long) 1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField4, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
//        java.lang.String str9 = offsetDateTimeField6.getName();
//        int int11 = offsetDateTimeField6.getMinimumValue(86400000L);
//        int int13 = offsetDateTimeField6.getLeapAmount((long) 200);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfWeek" + "'", str9.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.withDays((int) 'a');
        org.joda.time.Period period13 = period11.minusMonths(0);
        org.joda.time.Period period15 = period11.withMonths(8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
//        long long17 = offsetDateTimeField6.roundHalfFloor(0L);
//        long long19 = offsetDateTimeField6.roundHalfEven((long) 9700);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays((int) (short) 1);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableDuration10, readableInstant11);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology15);
        org.joda.time.Period period17 = period12.withFields((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period18 = period16.normalizedStandard();
        org.joda.time.Period period20 = period16.plusYears((-100));
        org.joda.time.DurationFieldType durationFieldType22 = period16.getFieldType((int) (short) 0);
        int int23 = period7.get(durationFieldType22);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration4, readableInstant5);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology9);
        org.joda.time.Period period11 = period6.withFields((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period6.withMillis((int) (short) 100);
        org.joda.time.Period period15 = period13.withDays((int) 'a');
        int int16 = period13.size();
        org.joda.time.Period period18 = period13.plusYears((int) (short) -1);
        org.joda.time.Period period19 = period3.plus((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period3.plusWeeks((int) (short) 1);
        org.joda.time.Period period25 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) 'a', chronology27);
        org.joda.time.Period period30 = period28.minusMonths((int) '#');
        int int31 = period30.getHours();
        org.joda.time.Period period33 = period30.minusSeconds((int) '#');
        boolean boolean34 = period25.equals((java.lang.Object) period30);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Duration duration36 = period30.toDurationTo(readableInstant35);
        long long37 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration36);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Period period42 = new org.joda.time.Period(readableDuration40, readableInstant41);
        org.joda.time.PeriodType periodType43 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType44 = periodType43.withWeeksRemoved();
        org.joda.time.PeriodType periodType45 = periodType43.withMinutesRemoved();
        org.joda.time.Period period46 = period42.withPeriodType(periodType43);
        org.joda.time.Period period47 = new org.joda.time.Period((long) (short) -1, periodType43);
        org.joda.time.Period period48 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration36, readableInstant38, periodType43);
        org.joda.time.Chronology chronology49 = null;
        org.joda.time.Period period50 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType43, chronology49);
        org.joda.time.Period period54 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.Period period57 = new org.joda.time.Period((long) 'a', chronology56);
        org.joda.time.Period period59 = period57.minusMonths((int) '#');
        int int60 = period59.getHours();
        org.joda.time.Period period62 = period59.minusSeconds((int) '#');
        boolean boolean63 = period54.equals((java.lang.Object) period59);
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Duration duration65 = period59.toDurationTo(readableInstant64);
        long long66 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration65);
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.ReadableDuration readableDuration69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.Period period71 = new org.joda.time.Period(readableDuration69, readableInstant70);
        org.joda.time.PeriodType periodType72 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType73 = periodType72.withWeeksRemoved();
        org.joda.time.PeriodType periodType74 = periodType72.withMinutesRemoved();
        org.joda.time.Period period75 = period71.withPeriodType(periodType72);
        org.joda.time.Period period76 = new org.joda.time.Period((long) (short) -1, periodType72);
        org.joda.time.Period period77 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration65, readableInstant67, periodType72);
        org.joda.time.Chronology chronology78 = null;
        org.joda.time.Period period79 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType72, chronology78);
        java.lang.String str80 = periodType72.getName();
        org.joda.time.ReadableDuration readableDuration81 = null;
        org.joda.time.ReadableInstant readableInstant82 = null;
        org.joda.time.Period period83 = new org.joda.time.Period(readableDuration81, readableInstant82);
        org.joda.time.Chronology chronology86 = null;
        org.joda.time.Period period87 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology86);
        org.joda.time.Period period88 = period83.withFields((org.joda.time.ReadablePeriod) period87);
        org.joda.time.Period period89 = period87.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType91 = period87.getFieldType(0);
        int int92 = periodType72.indexOf(durationFieldType91);
        int int93 = periodType43.indexOf(durationFieldType91);
        org.joda.time.IllegalFieldValueException illegalFieldValueException97 = new org.joda.time.IllegalFieldValueException(durationFieldType91, (java.lang.Number) 9, (java.lang.Number) (-1L), (java.lang.Number) 100.0d);
        int int98 = period3.indexOf(durationFieldType91);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(duration36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-92015999903L) + "'", long37 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType43);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(period62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(duration65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-92015999903L) + "'", long66 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType72);
        org.junit.Assert.assertNotNull(periodType73);
        org.junit.Assert.assertNotNull(periodType74);
        org.junit.Assert.assertNotNull(period75);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "Seconds" + "'", str80.equals("Seconds"));
        org.junit.Assert.assertNotNull(period88);
        org.junit.Assert.assertNotNull(period89);
        org.junit.Assert.assertNotNull(durationFieldType91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1) + "'", int92 == (-1));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-28800000), (-25200000), 15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        int int12 = offsetDateTimeField6.getMinimumValue();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField6.getAsText((long) 10, locale14);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int int17 = offsetDateTimeField6.getMinimumValue(readablePartial16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType18, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12" + "'", str15.equals("12"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        java.util.Locale locale11 = null;
        java.lang.String str12 = cachedDateTimeZone7.getShortName(8553600010L, locale11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-00:00:00.001" + "'", str12.equals("-00:00:00.001"));
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        java.lang.String str14 = dateTimeZone5.getName(36000100L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-00:00:00.001" + "'", str14.equals("-00:00:00.001"));
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("0", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"0/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType13 = periodType12.withWeeksRemoved();
        org.joda.time.PeriodType periodType14 = periodType12.withMinutesRemoved();
        org.joda.time.Period period15 = period11.withPeriodType(periodType12);
        org.joda.time.Period period16 = period8.withPeriodType(periodType12);
        int int17 = period16.getSeconds();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
        org.joda.time.Period period5 = period4.normalizedStandard();
        org.joda.time.Period period7 = period5.minusMonths((int) (byte) -1);
        int int8 = period5.getYears();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period5.toDurationFrom(readableInstant9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType12 = periodType11.withWeeksRemoved();
        org.joda.time.PeriodType periodType13 = periodType11.withMinutesRemoved();
        org.joda.time.PeriodType periodType14 = periodType11.withWeeksRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withDaysRemoved();
        org.joda.time.PeriodType periodType16 = periodType15.withSecondsRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration10, periodType16);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10, periodType18);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
//        long long10 = offsetDateTimeField6.roundHalfFloor((long) (-100));
//        java.lang.String str12 = offsetDateTimeField6.getAsShortText((long) '#');
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField6.getMaximumShortTextLength(locale13);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-10));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12" + "'", str12.equals("12"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        java.util.Locale locale17 = null;
//        try {
//            java.lang.String str18 = offsetDateTimeField15.getAsShortText(readablePartial16, locale17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Period period14 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) 'a', chronology16);
        org.joda.time.Period period19 = period17.minusMonths((int) '#');
        int int20 = period19.getHours();
        org.joda.time.Period period22 = period19.minusSeconds((int) '#');
        boolean boolean23 = period14.equals((java.lang.Object) period19);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Duration duration25 = period19.toDurationTo(readableInstant24);
        long long26 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration25);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Period period31 = new org.joda.time.Period(readableDuration29, readableInstant30);
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType33 = periodType32.withWeeksRemoved();
        org.joda.time.PeriodType periodType34 = periodType32.withMinutesRemoved();
        org.joda.time.Period period35 = period31.withPeriodType(periodType32);
        org.joda.time.Period period36 = new org.joda.time.Period((long) (short) -1, periodType32);
        org.joda.time.Period period37 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration25, readableInstant27, periodType32);
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType32, chronology38);
        org.joda.time.Period period43 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.Period period46 = new org.joda.time.Period((long) 'a', chronology45);
        org.joda.time.Period period48 = period46.minusMonths((int) '#');
        int int49 = period48.getHours();
        org.joda.time.Period period51 = period48.minusSeconds((int) '#');
        boolean boolean52 = period43.equals((java.lang.Object) period48);
        org.joda.time.ReadableInstant readableInstant53 = null;
        org.joda.time.Duration duration54 = period48.toDurationTo(readableInstant53);
        long long55 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration54);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableDuration readableDuration58 = null;
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.Period period60 = new org.joda.time.Period(readableDuration58, readableInstant59);
        org.joda.time.PeriodType periodType61 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType62 = periodType61.withWeeksRemoved();
        org.joda.time.PeriodType periodType63 = periodType61.withMinutesRemoved();
        org.joda.time.Period period64 = period60.withPeriodType(periodType61);
        org.joda.time.Period period65 = new org.joda.time.Period((long) (short) -1, periodType61);
        org.joda.time.Period period66 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration54, readableInstant56, periodType61);
        org.joda.time.Chronology chronology67 = null;
        org.joda.time.Period period68 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType61, chronology67);
        java.lang.String str69 = periodType61.getName();
        org.joda.time.ReadableDuration readableDuration70 = null;
        org.joda.time.ReadableInstant readableInstant71 = null;
        org.joda.time.Period period72 = new org.joda.time.Period(readableDuration70, readableInstant71);
        org.joda.time.Chronology chronology75 = null;
        org.joda.time.Period period76 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology75);
        org.joda.time.Period period77 = period72.withFields((org.joda.time.ReadablePeriod) period76);
        org.joda.time.Period period78 = period76.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType80 = period76.getFieldType(0);
        int int81 = periodType61.indexOf(durationFieldType80);
        int int82 = periodType32.indexOf(durationFieldType80);
        org.joda.time.PeriodType periodType83 = periodType32.withHoursRemoved();
        org.joda.time.Period period84 = new org.joda.time.Period(1L, (long) 'a', periodType32);
        org.joda.time.Period period85 = period6.minus((org.joda.time.ReadablePeriod) period84);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(duration25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-92015999903L) + "'", long26 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(duration54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-92015999903L) + "'", long55 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType61);
        org.junit.Assert.assertNotNull(periodType62);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Seconds" + "'", str69.equals("Seconds"));
        org.junit.Assert.assertNotNull(period77);
        org.junit.Assert.assertNotNull(period78);
        org.junit.Assert.assertNotNull(durationFieldType80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(periodType83);
        org.junit.Assert.assertNotNull(period85);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        org.joda.time.PeriodType periodType29 = periodType21.withMinutesRemoved();
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period(readableDuration30, readableInstant31);
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.Period period36 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology35);
        org.joda.time.Period period37 = period32.withFields((org.joda.time.ReadablePeriod) period36);
        org.joda.time.Period period38 = period36.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType40 = period36.getFieldType(0);
        int int41 = periodType21.indexOf(durationFieldType40);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.withDays((int) 'a');
        int int12 = period9.size();
        org.joda.time.Period period14 = period9.plusYears((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Duration duration16 = period14.toDurationFrom(readableInstant15);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(duration16);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = zonedChronology12.equals(obj13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        int int21 = dateTimeZone16.getOffset(readableInstant20);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
//        boolean boolean25 = cachedDateTimeZone22.isFixed();
//        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = zonedChronology12.equals(obj27);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        java.lang.String str26 = unsupportedDurationField23.getName();
        try {
            long long28 = unsupportedDurationField23.getMillis(10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "years" + "'", str26.equals("years"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        java.lang.String str5 = dateTimeZone3.getShortName((-94723200000L));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00" + "'", str5.equals("+00:00"));
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        int int12 = offsetDateTimeField6.getLeapAmount(28800132L);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.seconds();
//        org.joda.time.PeriodType periodType16 = periodType15.withWeeksRemoved();
//        org.joda.time.PeriodType periodType17 = periodType15.withMinutesRemoved();
//        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType15);
//        org.joda.time.PeriodType periodType19 = periodType15.withWeeksRemoved();
//        org.joda.time.PeriodType periodType20 = periodType19.withWeeksRemoved();
//        try {
//            org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) offsetDateTimeField6, periodType19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.OffsetDateTimeField");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(periodType15);
//        org.junit.Assert.assertNotNull(periodType16);
//        org.junit.Assert.assertNotNull(periodType17);
//        org.junit.Assert.assertNotNull(periodType19);
//        org.junit.Assert.assertNotNull(periodType20);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) 'a', chronology4);
        org.joda.time.Period period7 = period5.minusMonths((int) '#');
        int int8 = period7.getHours();
        org.joda.time.Period period10 = period7.minusSeconds((int) '#');
        boolean boolean11 = period2.equals((java.lang.Object) period7);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Duration duration13 = period7.toDurationTo(readableInstant12);
        long long14 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration13);
        java.lang.Class<?> wildcardClass15 = duration13.getClass();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType17 = periodType16.withWeeksRemoved();
        org.joda.time.PeriodType periodType18 = periodType16.withMinutesRemoved();
        org.joda.time.PeriodType periodType19 = periodType16.withWeeksRemoved();
        java.lang.String str20 = periodType16.getName();
        org.joda.time.PeriodType periodType21 = periodType16.withDaysRemoved();
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13, periodType21);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(duration13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-92015999903L) + "'", long14 == (-92015999903L));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Seconds" + "'", str20.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType21);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.remainder((long) (byte) 1);
//        java.lang.String str9 = offsetDateTimeField6.getName();
//        long long12 = offsetDateTimeField6.getDifferenceAsLong((long) 43, (long) 100);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "dayOfWeek" + "'", str9.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        try {
            long long13 = unsupportedDurationField11.getValueAsLong((-36000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Period period10 = period6.plusHours((-25199800));
        org.joda.time.Period period12 = period6.minusYears((-1));
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.Period period14 = period1.plusSeconds(10);
        org.joda.time.Period period16 = period1.withDays(2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("-00:00:00.001", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("200", (-28800000));
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (short) 0);
//        boolean boolean5 = dateTimeZone1.isStandardOffset(1L);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getShortName(86400001L, locale10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-92015999903L), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-92015999893L) + "'", long2 == (-92015999893L));
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField6.getMaximumTextLength(locale9);
//        int int12 = offsetDateTimeField6.getLeapAmount(28800132L);
//        int int14 = offsetDateTimeField6.getMaximumValue(28800132L);
//        org.joda.time.DurationField durationField15 = offsetDateTimeField6.getRangeDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
//        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
//        java.lang.String str6 = gregorianChronology0.toString();
//        org.joda.time.Period period8 = org.joda.time.Period.weeks((-1));
//        int[] intArray11 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (long) 'a', (long) 10);
//        org.joda.time.Period period13 = period8.withMonths((int) '4');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(period13);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField26 = new org.joda.time.field.DecoratedDurationField((org.joda.time.DurationField) unsupportedDurationField11, durationFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        try {
            int int28 = unsupportedDurationField11.getValue((-28799996L), (long) 43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
//        long long17 = offsetDateTimeField15.roundHalfEven(86400000L);
//        boolean boolean18 = offsetDateTimeField15.isSupported();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Period period23 = org.joda.time.Period.days((-1));
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.Period period26 = new org.joda.time.Period((long) 'a', chronology25);
//        org.joda.time.Period period28 = period26.minusMonths((int) '#');
//        int int29 = period28.getHours();
//        org.joda.time.Period period31 = period28.minusSeconds((int) '#');
//        boolean boolean32 = period23.equals((java.lang.Object) period28);
//        int[] intArray34 = gregorianChronology21.get((org.joda.time.ReadablePeriod) period28, 0L);
//        try {
//            int[] intArray36 = offsetDateTimeField15.addWrapField(readablePartial19, 2, intArray34, 200);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400001L + "'", long17 == 86400001L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(period31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(intArray34);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period10 = period8.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType12 = period8.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField13 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType12);
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField13.getType();
        int int15 = period1.indexOf(durationFieldType14);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertNotNull(unsupportedDurationField13);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableDuration1, readableInstant2);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withMinutesRemoved();
        org.joda.time.Period period7 = period3.withPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType13 = periodType12.withWeeksRemoved();
        org.joda.time.PeriodType periodType14 = periodType12.withMinutesRemoved();
        org.joda.time.Period period15 = period11.withPeriodType(periodType12);
        org.joda.time.Period period16 = period8.withPeriodType(periodType12);
        java.lang.String str17 = periodType12.toString();
        org.joda.time.PeriodType periodType18 = periodType12.withMillisRemoved();
        org.joda.time.PeriodType periodType19 = periodType12.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PeriodType[Seconds]" + "'", str17.equals("PeriodType[Seconds]"));
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        int int7 = offsetDateTimeField6.getOffset();
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfMinute();
//        int int12 = gregorianChronology10.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        boolean boolean17 = dateTimeZone15.isStandardOffset((long) (short) 0);
//        boolean boolean19 = dateTimeZone15.isStandardOffset(1L);
//        java.lang.String str21 = dateTimeZone15.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone15);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = zonedChronology22.equals(obj23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone26.getName(99L, locale28);
//        org.joda.time.ReadableInstant readableInstant30 = null;
//        int int31 = dateTimeZone26.getOffset(readableInstant30);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
//        int int34 = cachedDateTimeZone32.getStandardOffset(20L);
//        boolean boolean35 = cachedDateTimeZone32.isFixed();
//        org.joda.time.Chronology chronology36 = zonedChronology22.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone32);
//        org.joda.time.ReadableDuration readableDuration37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.Period period39 = new org.joda.time.Period(readableDuration37, readableInstant38);
//        org.joda.time.Chronology chronology42 = null;
//        org.joda.time.Period period43 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology42);
//        org.joda.time.Period period44 = period39.withFields((org.joda.time.ReadablePeriod) period43);
//        org.joda.time.Period period46 = period39.withMillis((int) (short) 100);
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.Duration duration48 = period39.toDurationFrom(readableInstant47);
//        int[] intArray50 = zonedChronology22.get((org.joda.time.ReadablePeriod) period39, 36000100L);
//        try {
//            int[] intArray52 = offsetDateTimeField6.set(readablePartial8, (int) (byte) 10, intArray50, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfWeek must be in the range [9,15]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-00:00:00.001" + "'", str21.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-00:00:00.001" + "'", str29.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(period46);
//        org.junit.Assert.assertNotNull(duration48);
//        org.junit.Assert.assertNotNull(intArray50);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gregorianChronology3.withZone(dateTimeZone9);
        org.joda.time.DurationField durationField11 = gregorianChronology3.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        java.lang.String str26 = unsupportedDurationField23.getName();
        try {
            int int29 = unsupportedDurationField23.getDifference((long) 4, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "years" + "'", str26.equals("years"));
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        int int6 = dateTimeZone1.getOffset(readableInstant5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
//        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.secondOfMinute();
//        int int13 = gregorianChronology11.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology11.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 8);
//        long long19 = offsetDateTimeField17.roundHalfEven((long) 100);
//        java.util.Locale locale20 = null;
//        int int21 = offsetDateTimeField17.getMaximumTextLength(locale20);
//        int int23 = offsetDateTimeField17.getLeapAmount(28800132L);
//        boolean boolean24 = cachedDateTimeZone7.equals((java.lang.Object) 28800132L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.Period period3 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) 'a', chronology5);
        org.joda.time.Period period8 = period6.minusMonths((int) '#');
        int int9 = period8.getHours();
        org.joda.time.Period period11 = period8.minusSeconds((int) '#');
        boolean boolean12 = period3.equals((java.lang.Object) period8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period8.toDurationTo(readableInstant13);
        long long15 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType22 = periodType21.withWeeksRemoved();
        org.joda.time.PeriodType periodType23 = periodType21.withMinutesRemoved();
        org.joda.time.Period period24 = period20.withPeriodType(periodType21);
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period26 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant16, periodType21);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType21, chronology27);
        org.joda.time.PeriodType periodType29 = periodType21.withDaysRemoved();
        java.lang.Object obj30 = null;
        boolean boolean31 = periodType21.equals(obj30);
        org.joda.time.PeriodType periodType32 = periodType21.withYearsRemoved();
        org.joda.time.Period period34 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.Period period37 = new org.joda.time.Period((long) 'a', chronology36);
        org.joda.time.Period period39 = period37.minusMonths((int) '#');
        int int40 = period39.getHours();
        org.joda.time.Period period42 = period39.minusSeconds((int) '#');
        boolean boolean43 = period34.equals((java.lang.Object) period39);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Duration duration45 = period39.toDurationTo(readableInstant44);
        long long46 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration45);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Period period51 = new org.joda.time.Period(readableDuration49, readableInstant50);
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType53 = periodType52.withWeeksRemoved();
        org.joda.time.PeriodType periodType54 = periodType52.withMinutesRemoved();
        org.joda.time.Period period55 = period51.withPeriodType(periodType52);
        org.joda.time.Period period56 = new org.joda.time.Period((long) (short) -1, periodType52);
        org.joda.time.Period period57 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration45, readableInstant47, periodType52);
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.ReadableDuration readableDuration60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.Period period62 = new org.joda.time.Period(readableDuration60, readableInstant61);
        org.joda.time.PeriodType periodType63 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType64 = periodType63.withWeeksRemoved();
        org.joda.time.PeriodType periodType65 = periodType63.withMinutesRemoved();
        org.joda.time.Period period66 = period62.withPeriodType(periodType63);
        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) -1, periodType63);
        org.joda.time.ReadableDuration readableDuration68 = null;
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.Period period70 = new org.joda.time.Period(readableDuration68, readableInstant69);
        org.joda.time.PeriodType periodType71 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType72 = periodType71.withWeeksRemoved();
        org.joda.time.PeriodType periodType73 = periodType71.withMinutesRemoved();
        org.joda.time.Period period74 = period70.withPeriodType(periodType71);
        org.joda.time.Period period75 = period67.withPeriodType(periodType71);
        org.joda.time.Period period76 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration45, readableInstant58, periodType71);
        boolean boolean77 = periodType32.equals((java.lang.Object) readableInstant58);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-92015999903L) + "'", long15 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(duration45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-92015999903L) + "'", long46 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(periodType64);
        org.junit.Assert.assertNotNull(periodType65);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertNotNull(periodType71);
        org.junit.Assert.assertNotNull(periodType72);
        org.junit.Assert.assertNotNull(periodType73);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertNotNull(period75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        java.lang.String str2 = periodType1.toString();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[Seconds]" + "'", str2.equals("PeriodType[Seconds]"));
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500002315d + "'", double1 == 2440587.500002315d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        org.joda.time.DurationFieldType durationFieldType25 = unsupportedDurationField11.getType();
        long long26 = unsupportedDurationField11.getUnitMillis();
        boolean boolean27 = unsupportedDurationField11.isPrecise();
        try {
            long long30 = unsupportedDurationField11.subtract((-368326799612L), (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(durationFieldType25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        long long10 = offsetDateTimeField6.roundCeiling(3024000000L);
//        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getLeapDurationField();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3024000001L + "'", long10 == 3024000001L);
//        org.junit.Assert.assertNull(durationField11);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("-00:00:00.001");
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withMinutesRemoved();
        org.joda.time.Period period6 = period2.withPeriodType(periodType3);
        java.lang.String str7 = period2.toString();
        int int8 = period2.getMonths();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration9, readableInstant10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology14);
        org.joda.time.Period period16 = period11.withFields((org.joda.time.ReadablePeriod) period15);
        org.joda.time.Period period17 = period15.normalizedStandard();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology23);
        org.joda.time.Period period25 = period20.withFields((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period20.withMillis((int) (short) 100);
        org.joda.time.Period period29 = period27.withDays((int) 'a');
        int int30 = period27.size();
        org.joda.time.Period period31 = period15.plus((org.joda.time.ReadablePeriod) period27);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.Period period33 = period27.plus(readablePeriod32);
        org.joda.time.Period period34 = period2.withFields((org.joda.time.ReadablePeriod) period33);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period34);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType[] durationFieldTypeArray9 = period8.getFieldTypes();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.forFields(durationFieldTypeArray9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.forFields(durationFieldTypeArray9);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldTypeArray9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int7 = offsetDateTimeField6.getOffset();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int int9 = offsetDateTimeField6.getMinimumValue(readablePartial8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.Period period14 = period1.plusSeconds(10);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) 'a', chronology17);
        org.joda.time.Period period19 = period18.normalizedStandard();
        org.joda.time.Period period21 = period19.minusMonths((int) (byte) -1);
        int int22 = period19.getYears();
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Duration duration24 = period19.toDurationFrom(readableInstant23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType26 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType27 = periodType25.withMinutesRemoved();
        org.joda.time.PeriodType periodType28 = periodType25.withWeeksRemoved();
        org.joda.time.PeriodType periodType29 = periodType28.withDaysRemoved();
        org.joda.time.PeriodType periodType30 = periodType29.withSecondsRemoved();
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant15, (org.joda.time.ReadableDuration) duration24, periodType30);
        org.joda.time.Period period32 = period1.plus((org.joda.time.ReadablePeriod) period31);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(period32);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.joda.time.PeriodType periodType8 = periodType6.withMinutesRemoved();
        org.joda.time.Period period9 = period5.withPeriodType(periodType6);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, periodType6);
        org.joda.time.PeriodType periodType11 = periodType6.withMinutesRemoved();
        int int12 = periodType11.size();
        java.lang.Object obj13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfDay();
        java.lang.Object obj16 = null;
        boolean boolean17 = iSOChronology14.equals(obj16);
        org.joda.time.Period period18 = new org.joda.time.Period(obj13, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.clockhourOfHalfday();
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 1, (-368200799611L), periodType11, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology14.minuteOfDay();
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Minutes minutes8 = period7.toStandardMinutes();
        org.joda.time.Period period10 = period7.minusWeeks((-25200000));
        org.joda.time.Period period12 = period10.withHours((int) 'a');
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(minutes8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = periodType2.withWeeksRemoved();
        java.lang.String str6 = periodType2.getName();
        org.joda.time.PeriodType periodType7 = periodType2.withDaysRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Seconds" + "'", str6.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField5 = gregorianChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.joda.time.PeriodType periodType8 = periodType6.withMinutesRemoved();
        org.joda.time.Period period9 = period5.withPeriodType(periodType6);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, periodType6);
        org.joda.time.PeriodType periodType11 = periodType6.withMinutesRemoved();
        int int12 = periodType11.size();
        java.lang.Object obj13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfDay();
        java.lang.Object obj16 = null;
        boolean boolean17 = iSOChronology14.equals(obj16);
        org.joda.time.Period period18 = new org.joda.time.Period(obj13, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.clockhourOfHalfday();
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 1, (-368200799611L), periodType11, (org.joda.time.Chronology) iSOChronology14);
        try {
            org.joda.time.Period period22 = period20.minusDays(9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.Period period4 = period2.withFields(readablePeriod3);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.Period period4 = new org.joda.time.Period(0, 1, (int) (short) 0, (-28800000));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 200);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 200 + "'", int1 == 200);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        int int3 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.minuteOfHour();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Period period9 = period7.minusDays((int) (short) 1);
        org.joda.time.Period period11 = period9.plusMonths(10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "PST", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "years", "PeriodType[Seconds]");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period8.toDurationFrom(readableInstant16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration18, readableInstant19);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology23);
        org.joda.time.Period period25 = period20.withFields((org.joda.time.ReadablePeriod) period24);
        org.joda.time.Period period27 = period20.withMillis((int) (short) 100);
        org.joda.time.Period period29 = period27.withDays((int) 'a');
        int int30 = period27.size();
        org.joda.time.Period period31 = period8.minus((org.joda.time.ReadablePeriod) period27);
        long long34 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period8, (long) (short) 1, (int) 'a');
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Duration duration36 = period8.toDurationFrom(readableInstant35);
        long long37 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration36);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Period period39 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration36, readableInstant38);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(duration36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = zonedChronology12.equals(obj13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        int int21 = dateTimeZone16.getOffset(readableInstant20);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
//        boolean boolean25 = cachedDateTimeZone22.isFixed();
//        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        try {
//            long long32 = zonedChronology12.getDateTimeMillis((long) 2, (int) '4', (int) (short) 0, 9700, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) 0, 0L, chronology2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long7 = cachedDateTimeZone5.nextTransition(2440588L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2440588L + "'", long7 == 2440588L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration2, readableInstant3);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology7);
        org.joda.time.Period period9 = period4.withFields((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period4.withMillis((int) (short) 100);
        org.joda.time.Period period12 = period1.withFields((org.joda.time.ReadablePeriod) period11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        int int15 = period12.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 'a', chronology3);
        org.joda.time.Period period6 = period4.minusMonths((int) '#');
        int int7 = period6.getHours();
        org.joda.time.Period period9 = period6.minusSeconds((int) '#');
        boolean boolean10 = period1.equals((java.lang.Object) period6);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period6.toDurationTo(readableInstant11);
        long long13 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableDuration16, readableInstant17);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType20 = periodType19.withWeeksRemoved();
        org.joda.time.PeriodType periodType21 = periodType19.withMinutesRemoved();
        org.joda.time.Period period22 = period18.withPeriodType(periodType19);
        org.joda.time.Period period23 = new org.joda.time.Period((long) (short) -1, periodType19);
        org.joda.time.Period period24 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant14, periodType19);
        try {
            org.joda.time.Period period26 = period24.minusYears((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-92015999903L) + "'", long13 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 10, (long) (-1), periodType2, (org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        long long11 = durationField8.subtract(3024000001L, (int) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3628800001L + "'", long11 == 3628800001L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (byte) 0, 43, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration3, readableInstant4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType7 = periodType6.withWeeksRemoved();
        org.joda.time.PeriodType periodType8 = periodType6.withMinutesRemoved();
        org.joda.time.Period period9 = period5.withPeriodType(periodType6);
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, periodType6);
        org.joda.time.PeriodType periodType11 = periodType6.withMinutesRemoved();
        int int12 = periodType11.size();
        java.lang.Object obj13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.millisOfDay();
        java.lang.Object obj16 = null;
        boolean boolean17 = iSOChronology14.equals(obj16);
        org.joda.time.Period period18 = new org.joda.time.Period(obj13, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology14.clockhourOfHalfday();
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) 1, (-368200799611L), periodType11, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology14, dateTimeZone21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period8 = period4.plusMinutes((int) (short) 1);
        org.joda.time.Period period10 = period4.minusMonths((int) (short) 0);
        org.joda.time.Period period12 = period10.withYears(100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(259200002L, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 25142400194");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period((long) 'a', chronology1);
        org.joda.time.Period period4 = period2.minusMonths((int) '#');
        org.joda.time.Period period6 = period4.minusMillis(10);
        org.joda.time.Period period8 = period4.plusMinutes((int) (short) 1);
        int int9 = period8.size();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        java.lang.Object obj13 = null;
//        boolean boolean14 = zonedChronology12.equals(obj13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getName(99L, locale18);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        int int21 = dateTimeZone16.getOffset(readableInstant20);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        int int24 = cachedDateTimeZone22.getStandardOffset(20L);
//        boolean boolean25 = cachedDateTimeZone22.isFixed();
//        org.joda.time.Chronology chronology26 = zonedChronology12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        try {
//            long long32 = zonedChronology12.getDateTimeMillis((-210863044800000L), 10, (-100), (-28800000), 35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(chronology26);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.Period period1 = new org.joda.time.Period((-94723200000L));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (-1), (long) (-100));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.secondOfMinute();
        org.joda.time.Period period3 = new org.joda.time.Period(0L, (org.joda.time.Chronology) gregorianChronology1);
        try {
            long long8 = gregorianChronology1.getDateTimeMillis((int) ' ', 0, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, (long) 200);
        int[] intArray3 = period2.getValues();
        org.joda.time.Period period5 = period2.withMillis((int) (byte) -1);
        int[] intArray6 = period2.getValues();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology0.halfdays();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(10, 8, 99, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField11.getType();
        java.lang.String str13 = unsupportedDurationField11.getName();
        long long14 = unsupportedDurationField11.getUnitMillis();
        try {
            long long17 = unsupportedDurationField11.getValueAsLong(0L, 259200001L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (-2520000000L), (int) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2520000000L) + "'", long5 == (-2520000000L));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfMinute();
        int int5 = gregorianChronology3.getMinimumDaysInFirstWeek();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.hourOfDay();
        org.joda.time.DurationField durationField8 = gregorianChronology3.hours();
        org.joda.time.Period period9 = new org.joda.time.Period((-28799996L), periodType1, (org.joda.time.Chronology) gregorianChronology3);
        java.lang.String str10 = periodType1.toString();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PeriodType[Seconds]" + "'", str10.equals("PeriodType[Seconds]"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
//        boolean boolean7 = dateTimeZone5.isStandardOffset((long) (short) 0);
//        boolean boolean9 = dateTimeZone5.isStandardOffset(1L);
//        java.lang.String str11 = dateTimeZone5.getName(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.Chronology chronology14 = zonedChronology12.withZone(dateTimeZone13);
//        try {
//            long long22 = zonedChronology12.getDateTimeMillis((int) (short) 10, (-10), 4, (int) (byte) 0, (-25199800), 4, 43);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25199800 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
//        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
//        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
//        int int11 = offsetDateTimeField6.getDifference((long) (byte) 1, (long) (byte) 10);
//        long long13 = offsetDateTimeField6.roundHalfFloor((long) 43);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, (-28800000));
//        long long17 = offsetDateTimeField15.roundHalfEven(86400000L);
//        java.util.Locale locale18 = null;
//        int int19 = offsetDateTimeField15.getMaximumShortTextLength(locale18);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 86400001L + "'", long17 == 86400001L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period2.withMillis((int) (short) 100);
        org.joda.time.Period period11 = period9.plusWeeks((int) (byte) 100);
        org.joda.time.Period period13 = period9.plusSeconds(43);
        org.joda.time.Seconds seconds14 = period13.toStandardSeconds();
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(seconds14);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfMinute();
        int int4 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.minuteOfHour();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (byte) 0, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Period period10 = period8.minusDays((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationFrom(readableInstant11);
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration12);
        org.joda.time.Period period15 = period13.minusYears((int) '#');
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 259200001L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 22184013326400000L + "'", long1 == 22184013326400000L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType12 = unsupportedDurationField11.getType();
        java.lang.String str13 = unsupportedDurationField11.getName();
        long long14 = unsupportedDurationField11.getUnitMillis();
        try {
            long long16 = unsupportedDurationField11.getValueAsLong(345600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration6, readableInstant7);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology11);
        org.joda.time.Period period13 = period8.withFields((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period15 = period8.withMillis((int) (short) 100);
        org.joda.time.Period period17 = period15.withDays((int) 'a');
        int int18 = period15.size();
        org.joda.time.Period period20 = period15.plusYears((int) (short) -1);
        int[] intArray23 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period15, (long) 'a', (long) 'a');
        org.joda.time.Period period25 = period15.minusMonths((-1));
        int int26 = period25.getWeeks();
        org.joda.time.Period period30 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) 'a', chronology32);
        org.joda.time.Period period35 = period33.minusMonths((int) '#');
        int int36 = period35.getHours();
        org.joda.time.Period period38 = period35.minusSeconds((int) '#');
        boolean boolean39 = period30.equals((java.lang.Object) period35);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.Duration duration41 = period35.toDurationTo(readableInstant40);
        long long42 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration41);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.ReadableDuration readableDuration45 = null;
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.Period period47 = new org.joda.time.Period(readableDuration45, readableInstant46);
        org.joda.time.PeriodType periodType48 = org.joda.time.PeriodType.seconds();
        org.joda.time.PeriodType periodType49 = periodType48.withWeeksRemoved();
        org.joda.time.PeriodType periodType50 = periodType48.withMinutesRemoved();
        org.joda.time.Period period51 = period47.withPeriodType(periodType48);
        org.joda.time.Period period52 = new org.joda.time.Period((long) (short) -1, periodType48);
        org.joda.time.Period period53 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration41, readableInstant43, periodType48);
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period((long) (byte) -1, (long) (-100), periodType48, chronology54);
        java.lang.String str56 = periodType48.getName();
        org.joda.time.PeriodType periodType57 = periodType48.withMonthsRemoved();
        org.joda.time.PeriodType periodType58 = periodType48.withSecondsRemoved();
        try {
            org.joda.time.Period period59 = period25.withPeriodType(periodType48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(duration41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-92015999903L) + "'", long42 == (-92015999903L));
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Seconds" + "'", str56.equals("Seconds"));
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(periodType58);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "hi!");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        java.lang.String str4 = dateTimeZone2.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableDuration0, readableInstant1);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology5);
        org.joda.time.Period period7 = period2.withFields((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration12, readableInstant13);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) (short) 1, (long) (short) 10, chronology17);
        org.joda.time.Period period19 = period14.withFields((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period20 = period18.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField23 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        int int24 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField23);
        java.lang.String str25 = unsupportedDurationField23.getName();
        java.lang.String str26 = unsupportedDurationField23.getName();
        try {
            long long29 = unsupportedDurationField23.add((long) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "years" + "'", str25.equals("years"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "years" + "'", str26.equals("years"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getName(99L, locale3);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone1.getOffset(readableInstant5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getStandardOffset((long) 'a');
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        boolean boolean13 = cachedDateTimeZone7.equals((java.lang.Object) readableInterval10);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        int int16 = cachedDateTimeZone7.getOffset((long) (byte) 100);
        long long19 = cachedDateTimeZone7.convertLocalToUTC(259200001L, true);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 259200002L + "'", long19 == 259200002L);
        org.junit.Assert.assertNotNull(dateTimeZone20);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        int int8 = offsetDateTimeField6.getLeapAmount((long) (byte) 0);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsText((long) (-1), locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap((long) ' ');
        long long15 = offsetDateTimeField6.roundCeiling((long) (short) 0);
        int int17 = offsetDateTimeField6.getMinimumValue((long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 8);
        long long8 = offsetDateTimeField6.roundHalfEven((long) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.secondOfMinute();
        int int12 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.millisOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 8);
        int int18 = offsetDateTimeField16.getLeapAmount((long) (byte) 0);
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period22 = org.joda.time.Period.days((-1));
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) 'a', chronology24);
        org.joda.time.Period period27 = period25.minusMonths((int) '#');
        int int28 = period27.getHours();
        org.joda.time.Period period30 = period27.minusSeconds((int) '#');
        boolean boolean31 = period22.equals((java.lang.Object) period27);
        int[] intArray33 = gregorianChronology20.get((org.joda.time.ReadablePeriod) period27, 0L);
        int int34 = offsetDateTimeField16.getMinimumValue(readablePartial19, intArray33);
        int int35 = offsetDateTimeField6.getMinimumValue(readablePartial9, intArray33);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
    }
}

